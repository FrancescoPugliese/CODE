#include "stdafx.h"

/*******************************************************************************************************************\
|																													|
| Modul Funkkommunikation.cpp																						|
|																													|
| In diesem Modul sind Funktionen zur Berechnung diverser Formeln aus dem Bereich der Funkkommunikation mit den		|
| zugeh�rigen Dialogsfunktion.																						|
|  																													|
\*******************************************************************************************************************/

int Rauschzahl_Aufruf( HWND hWnd )
{
  // Aufruf der zugeh�rigen Dialogfunktion, s. andere Module

  return 0;
}

int Freifelddaempfung_Aufruf( HWND hWnd )
{
  // Aufruf der zugeh�rigen Dialogfunktion

  return 0;
}

int Robuste_Richtfunk_Aufruf( HWND hWnd )
{
  // Aufruf der zugeh�rigen Dialogfunktion
 
  return 0;
}