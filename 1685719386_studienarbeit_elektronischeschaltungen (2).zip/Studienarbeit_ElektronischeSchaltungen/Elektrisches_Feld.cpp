#include "stdafx.h"
/*******************************************************************************************************************\
|																													|
| Modul Elektrisches_Feld.cpp																						|
|																													|
| In diesem Modul sind dieFunktionen zur Berechnung und Anzeige des Elektrischen Feldes enthalten					|
| - Berechne_E_Feld();																								|
| - Elektrisches_Feld_Aufruf();																						|
| - init_Ladungen();																								|
| - Kopiere_Ladungen();																								|
| - Schreibe_neue_E_Feld_Liste();																					|
| - Zeichne_Ladungen();																								|
|  																													|
\*******************************************************************************************************************/
int Elektrisches_Feld_Aufruf(void)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_E_FELD), hWndElektronikMain, Elektrisches_Feld_Dialog);
	return 0;
}

int init_Ladungen(Ladungs_Struktur *LadungsStruktur)
{
	int i;

	LadungsStruktur->Anzahl_Ladungen = 0;
	LadungsStruktur->Anzahl_Sonde = 0;
	LadungsStruktur->Massstab = 0.01;

	for (i = 0; i < 20; i++)
	{
		LadungsStruktur->Elektrische_Ladung[i] = 0;
		LadungsStruktur->x_pos[i] = 0;
		LadungsStruktur->y_pos[i] = 0;
		LadungsStruktur->Masse[i] = 0;
		LadungsStruktur->x_pos_Sonde[i] = 0;
		LadungsStruktur->y_pos_Sonde[i] = 0;
	}

	return 0;
} // end of init_Ladungen

int Berechne_E_Feld(void)
{
	int i, j;
	double Abstand_x, Abstand_y, Abstand;

	for (j = 0; j < Ladung.Anzahl_Sonde; j++)
	{
		// E-Feld f�r Sonde 1 berechnen
		Ladung.x_Feld_Sonde[j] = 0.0;
		Ladung.y_Feld_Sonde[j] = 0.0;
		for (i = 0; i < Ladung.Anzahl_Ladungen; i++)
		{
			Abstand_x = Ladung.x_pos_Sonde[j] - Ladung.x_pos[i];
			Abstand_y = -Ladung.y_pos_Sonde[j] + Ladung.y_pos[i];
			Abstand = sqrt(Abstand_x * Abstand_x + Abstand_y * Abstand_y);
			Ladung.x_Feld_Sonde[j] += 1.0 / (4.0*pi*eps_0)*Ladung.Elektrische_Ladung[i] / (Abstand*Abstand*Abstand)*Abstand_x;
			Ladung.y_Feld_Sonde[j] += 1.0 / (4.0*pi*eps_0)*Ladung.Elektrische_Ladung[i] / (Abstand*Abstand*Abstand)*Abstand_y;
		}
	}

	return 0;
}
// end of Berechne_E_Feld

int Schreibe_neue_E_Feld_Liste(HWND hDlg)
{
	int tab[6] = { 25, 60, 95, 145, 175, 230 };
	int i;
	char Zeile[100];
	char cWert1[20], cWert2[20], cWert3[20], cWert4[20], cWert5[20];
	double E_Feld_Betrag, E_Feld_Winkel;

	SendMessage(GetDlgItem(hDlg, ID_E_FELD), LB_RESETCONTENT, NULL, NULL);
	SendMessage(GetDlgItem(hDlg, ID_E_FELD), LB_SETTABSTOPS, (WPARAM)(WORD)6, (LPARAM)tab);
	SendMessage(GetDlgItem(hDlg, ID_E_FELD), LB_ADDSTRING, NULL, (LPARAM)(LPSTR)"Sonde \tX \tY \tBetrag \tWinkel \t Betrag_X \tBetrag_Y");

	for (i = 0; i < Ladung.Anzahl_Sonde; i++)
	{
		E_Feld_Betrag = sqrt(Ladung.y_Feld_Sonde[i] * Ladung.y_Feld_Sonde[i] + Ladung.x_Feld_Sonde[i] * Ladung.x_Feld_Sonde[i]);
		E_Feld_Winkel = 180.0 / pi*atan2(Ladung.y_Feld_Sonde[i], Ladung.x_Feld_Sonde[i]);
		Bestimme_Laengenbezeichner(cWert1, Ladung.x_pos_Sonde[i], 19);
		Bestimme_Laengenbezeichner(cWert2, Ladung.y_pos_Sonde[i], 19);
		Bestimme_E_Feld_Bezeichner_m(cWert3, E_Feld_Betrag, 19);
		Bestimme_E_Feld_Bezeichner_m(cWert4, Ladung.x_Feld_Sonde[i], 19);
		Bestimme_E_Feld_Bezeichner_m(cWert5, Ladung.y_Feld_Sonde[i], 19);
		sprintf_s(Zeile, 99, "%u \t%s \t%s \t%s \t%.4g� \t%s \t%s", i + 1, cWert1, cWert2, cWert3, E_Feld_Winkel, cWert4, cWert5);
		SendMessage(GetDlgItem(hDlg, ID_E_FELD), LB_ADDSTRING, NULL, (LPARAM)(LPSTR)Zeile);
	}
	// Hier auch die Ladungen ausgeben
	SendMessage(GetDlgItem(hDlg, ID_E_LADUNG), LB_RESETCONTENT, NULL, NULL);
	SendMessage(GetDlgItem(hDlg, ID_E_LADUNG), LB_SETTABSTOPS, (WPARAM)(WORD)3, (LPARAM)tab);
	SendMessage(GetDlgItem(hDlg, ID_E_LADUNG), LB_ADDSTRING, NULL, (LPARAM)(LPSTR)"Nr. \tX \tY \tLadung");

	for (i = 0; i < Ladung.Anzahl_Ladungen; i++)
	{
		Bestimme_Laengenbezeichner(cWert1, Ladung.x_pos[i], 19);
		Bestimme_Laengenbezeichner(cWert2, Ladung.y_pos[i], 19); 
		Bestimme_Ladungsbezeichner(cWert3, Ladung.Elektrische_Ladung[i], 19);
		sprintf_s(Zeile, 99, "%u \t%s \t%s \t%s", i + 1, cWert1, cWert2, cWert3);
		SendMessage(GetDlgItem(hDlg, ID_E_LADUNG), LB_ADDSTRING, NULL, (LPARAM)(LPSTR)Zeile);
	}
	return 0;
}
// end of Schreibe_neue_E_Feld_Liste

int Zeichne_Ladungen(Ladungs_Struktur Ladung, HDC hdc, bool Kopie_Zwischenablage)
{
	HPEN hStiftSchwarz2, hStiftAlt, hStiftGrau;
	HBRUSH hPinselSchwarz, hPinselAlt, hPinselBlau, hPinselGruen, hPinselGelb, hPinselRot;
	char cWert1[20];
	char cText[100];
	int i;

	// Fenster neu zeichnen: Ladungen einzeichnen

	// Hintergrund des Koordinatensystems in wei�
	Rectangle(hdc, 20, 20, 420, 420);

	// In der Mitte ein Kreis ("0") als koordinatenursprung
	hStiftGrau = CreatePen(PS_SOLID, 1, RGB(128, 128, 128));
	hStiftAlt = (HPEN)SelectObject(hdc, hStiftGrau);

	Ellipse_BH(hdc, 212, 212, 17, 17);
	SetPolyFillMode(hdc, WINDING);

	// Gitter zeichnen
	SetBkMode(hdc, TRANSPARENT); // "L�cken" transparent
	for (i = 0; i < 11; i++)
	{
		ZP_Linie(hdc, 20, 20 + i * 40, 420, 20 + i * 40);
		ZP_Linie(hdc, 20 + i * 40, 20, 20 + i * 40, 420);
	}
	hStiftGrau = CreatePen(PS_DOT, 1, RGB(192, 192, 192));
	SelectObject(hdc, hStiftGrau);
	for (i = 0; i < 10; i++)
	{
		ZP_Linie(hdc, 20, 40 + i * 40, 420, 40 + i * 40);
		ZP_Linie(hdc, 40 + i * 40, 20, 40 + i * 40, 420);
	}

	hPinselBlau = CreateSolidBrush(RGB(0, 0, 255));
	hPinselRot = CreateSolidBrush(RGB(255, 0, 0));
	hPinselGruen = CreateSolidBrush(RGB(0, 255, 0));
	hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselBlau);

	for (i = 0; i < Ladung.Anzahl_Ladungen; i++)
	{
		SelectObject(hdc, hPinselGruen);
		if (Ladung.Elektrische_Ladung[i] < 0)
			SelectObject(hdc, hPinselRot);
		if (Ladung.Elektrische_Ladung[i] > 0)
			SelectObject(hdc, hPinselBlau);
		// Wieder auf Bildschirmkoordinaten zur�ckrechnen: *= 40/Ladung.Massstab
		Ellipse_BH(hdc, (int)(Ladung.x_pos[i] * 40 / Ladung.Massstab - 7 + 220), (int)(220 - Ladung.y_pos[i] * 40 / Ladung.Massstab - 7), 14, 14);
		Bestimme_Ladungsbezeichner(cWert1, Ladung.Elektrische_Ladung[i], 19);
		Zeichne_Text_xy(hdc, cWert1, (int)(Ladung.x_pos[i] * 40 / Ladung.Massstab + 5 + 220), (int)(220 - Ladung.y_pos[i] * 40 / Ladung.Massstab + 5));
	}

	hPinselGelb = CreateSolidBrush(RGB(255, 255, 0));
	SelectObject(hdc, hPinselGelb);

	for (i = 0; i < Ladung.Anzahl_Sonde; i++)
	{
		Ellipse_BH(hdc, (int)(Ladung.x_pos_Sonde[i] * 40 / Ladung.Massstab - 7 + 220), (int)(220 - Ladung.y_pos_Sonde[i] * 40 / Ladung.Massstab - 7), 14, 14);
		sprintf_s(cText, 99, "%u", i + 1);
		Zeichne_Text_xy(hdc, cText, (int)(Ladung.x_pos_Sonde[i] * 40 / Ladung.Massstab + 5 + 220), (int)(220 - Ladung.y_pos_Sonde[i] * 40 / Ladung.Massstab + 5));
	}
	// Legende anzeigen:
	Ellipse_BH(hdc, 20, 428, 14, 14);
	Zeichne_Text_xy(hdc, "Sonde", 40, 428);
	SelectObject(hdc, hPinselRot);
	Ellipse_BH(hdc, 100, 428, 14, 14);
	Zeichne_Text_xy(hdc, "negative Ladung", 120, 428);
	SelectObject(hdc, hPinselBlau);
	Ellipse_BH(hdc, 260, 428, 14, 14);
	Zeichne_Text_xy(hdc, "positive Ladung", 280, 428);

	hStiftSchwarz2 = CreatePen(PS_SOLID, 2, BLACK_PEN);
	hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
	hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
	hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

	// Massstab einzeichnen
	ZP_Linie(hdc, 430, 380, 430, 420);
	ZP_Linie(hdc, 422, 380, 438, 380);
	ZP_Linie(hdc, 422, 420, 438, 420);
	Bestimme_Laengenbezeichner(cText, Ladung.Massstab, 99);
	Zeichne_Text_xy(hdc, cText, 440, 395);

	if (Kopie_Zwischenablage)
	{
		double E_Feld_Betrag, E_Feld_Winkel;
		int y_position;

		// Tabellenkopf ausgeben
		TextOut(hdc, 0, 470, "Ladung", 6);
		TextOut(hdc, 100, 470, "Pos_x", 5);
		TextOut(hdc, 200, 470, "Pos_y", 5);

		// Tabellen darunter ausgeben
		for (i = 0; i < Ladung.Anzahl_Ladungen; i++)
		{
			Bestimme_Ladungsbezeichner(cWert1, Ladung.Elektrische_Ladung[i], 19);
			TextOut(hdc, 0, 490 + i * 20, cWert1, strlen(cWert1));
			Bestimme_Laengenbezeichner(cWert1, Ladung.x_pos[i], 19);
			TextOut(hdc, 200, 490 + i * 20, cWert1, strlen(cWert1));
			Bestimme_Laengenbezeichner(cWert1, Ladung.y_pos[i], 19);
			TextOut(hdc, 100, 490 + i * 20, cWert1, strlen(cWert1));
		}
		y_position =500 + i * 20;

		// Tabellenkopf ausgeben
		TextOut(hdc, 0, y_position, "Sonde", 5);
		y_position += 20;
		TextOut(hdc, 0, y_position, "Pos_x", 5);
		TextOut(hdc, 100, y_position, "Pos_y", 5);
		TextOut(hdc, 200, y_position, "E_Feld_Betrag", 13);
		TextOut(hdc, 300, y_position, "x_Feld", 6);
		TextOut(hdc, 400, y_position, "y_Feld", 6);
		y_position += 20;

		for (i = 0; i < Ladung.Anzahl_Sonde; i++)
		{
			E_Feld_Betrag = sqrt(Ladung.y_Feld_Sonde[i] * Ladung.y_Feld_Sonde[i] + Ladung.x_Feld_Sonde[i] * Ladung.x_Feld_Sonde[i]);
			E_Feld_Winkel = 180.0 / pi*atan2(Ladung.y_Feld_Sonde[i], Ladung.x_Feld_Sonde[i]);
			Bestimme_Laengenbezeichner(cWert1, Ladung.x_pos_Sonde[i], 19);
			TextOut(hdc, 0, y_position+i*20, cWert1, strlen(cWert1));
			Bestimme_Laengenbezeichner(cWert1, Ladung.y_pos_Sonde[i], 19);
			TextOut(hdc, 100, y_position + i * 20, cWert1, strlen(cWert1));
			Bestimme_E_Feld_Bezeichner_m(cWert1, E_Feld_Betrag, 19);
			TextOut(hdc, 200, y_position + i * 20, cWert1, strlen(cWert1));
			Bestimme_E_Feld_Bezeichner_m(cWert1, Ladung.x_Feld_Sonde[i], 19);
			TextOut(hdc, 300, y_position + i * 20, cWert1, strlen(cWert1));
			Bestimme_E_Feld_Bezeichner_m(cWert1, Ladung.y_Feld_Sonde[i], 19);
			TextOut(hdc, 400, y_position + i * 20, cWert1, strlen(cWert1));
		}
	}

	SelectObject(hdc, hPinselAlt);
	DeleteObject(hPinselBlau);
	DeleteObject(hPinselSchwarz);
	DeleteObject(hPinselGelb);
	DeleteObject(hPinselRot);
	SelectObject(hdc, hStiftAlt);
	DeleteObject(hStiftGrau);
	DeleteObject(hStiftSchwarz2);

	return 0;
}

int Kopiere_Ladungen(Ladungs_Struktur Ladung)
{
	HDC hdcMeta;
	HENHMETAFILE hMeta;

	hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
	Zeichne_Ladungen(Ladung, hdcMeta, true);
	hMeta = CloseEnhMetaFile(hdcMeta);
	// Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
	OpenClipboard(hWndElektronikMain);
	EmptyClipboard();
	SetClipboardData(CF_ENHMETAFILE, hMeta);
	CloseClipboard();

	return 0;
} // end of Kopiere_Ladungen