#include "stdafx.h"

/*******************************************************************************************************************\
|																													|
| Modul Utils.cpp																									|
|																													|
| In diesem Modul sind diverse globale Variablen und Strukturen definiert. Au�erdem sind hier diverse				|
| Initialisierungs- und Hilfsfunktionen enthalten																	|
| - a_to_hex();																										|
| - About_Aufruf();																									|
| - Benenne_Exponent();																								|
| - Bestimme_Bezeichner();																							|
| - Bestimme_Bezeichner_Festspannungsregler();																		|
| - Bestimme_Bezeichner_Steilheit();																				|
| - Bestimme_Bezeichner_wissenschaftlich();																			|
| - Bestimme_Blindleistungsbezeichner();																			|
| - Bestimme_E_Feld_Bezeichner_cm();																				|
| - Bestimme_E_Feld_Bezeichner_m();																					|
| - Bestimme_Exponent();																							|
| - Bestimme_Frequenzbezeichner();																					|
| - Bestimme_Induktivitaetsbezeichner();																			|
| - Bestimme_Kapazitaetsbezeichner();																				|
| - Bestimme_komplexen_Widerstandsbezeichner_Betrag_Winkel();														|
| - Bestimme_komplexen_Widerstandsbezeichner_real_imag();															|
| - Bestimme_Koordinaten_Wert();																					|
| - Bestimme_Ladungsbezeichner();																					|
| - Bestimme_Bezeichner_Ladungsdichte_cm3();																		|
| - Bestimme_Laengenbezeichner();																					|
| - Bestimme_Leistungsbezeichner();																					|
| - Bestimme_Prozentbezeichner();																					|
| - Bestimme_Scheinleistungsbezeichner();																			|
| - Bestimme_Spannungsbezeichner();																					|
| - Bestimme_Strombezeichner();																						|
| - Bestimme_Technologiebezeichner();																				|
| - Bestimme_Temperaturbezeichner();																				|
| - Bestimme_Widerstandsbezeichner();																				|
| - Bestimme_Winkelbezeichner();																					|
| - char_to_widechar();																								|
| - Daten_geaendert();																								|
| - Daten_gespeichert();																							|
| - Eingabe_parsen();																								|
| - init();																											|
| - init_DezibelRechner();																							|
| - init_EingabeDialog();																							|
| - init_Gleichrichter();																							|
| - init_Halbleiter();																								|
| - init_Stern_Dreieck_Umrechnung();																				|
| - init_ThermischerWiderstand();																					|
| - init_Zeigerdiagramm();																							|
| - init_Zeigerdiagramm_S();																						|
| - kopiere_substring();																							|
| - lese_string_aus_zeile();																						|
| - lese_wert_aus_zeile();																							|
| - Parallelschaltung();																							|
| - Phase();																										|
| - setze_Maximalwert();																							|
| - setze_Minimalwert();																							|
| - sortiere_frequenzpunkte();																						|
| - Ueberpruefe_Kennwort();																							|
| - widechar_to_char();																								|
| - Zahl_uebernehmen();																								|
| - Hilfe_Aufruf();																									|
| - loese_kubische_Gleichung();																						|
| - Berechne_Schnittpunkte_Kreise();																				|
| - String_anhaengen();																								|
|  																													|
\*******************************************************************************************************************/

using namespace std;

//globale Variablen

struct Dialog_Steuerung Eingabe_Dialog;
// Initialisierungswerte 
struct Initialisierung init_werte;
// pn-Uebergang
struct Halbleiter_pn pn_Uebergang;
float pn_Potential[200], pn_E_Feld[200], x_Feld[200];
// Gleichrichter und Festspannungsregler; Thermischer Widerstand
struct Dioden_Gleichrichter Gleichrichter;
struct Therm_Widerstand R_th;
//Transistorberechnung
struct Bipolartransistor Basis_Schaltung, Kollektor_Schaltung, Emitter_Schaltung;
struct Schalter_Bipolartransistor Bipolartransistor_als_Schalter;
struct MOS_Transistor Source_Schaltung, Drain_Schaltung, Gate_Schaltung;
struct Kennlinie_MOS FET_Kennlinie;
struct Diff_verstaerker Differenzverstaerker;
// Dezibel Rechner
struct dB_Rechner DezibelRechner, dBm_Rechner;
// Elektrisches Feld
struct Ladungs_Struktur Ladung;
// Operationsverst�rker
struct Operationsverstaerker Invertierender_OP, Nichtinvertierender_OP, Summations_OP, Differenzierer_OP, Integrierer_OP, OP_Bode;
// Zeigerdiagramm
struct Komplexer_Zeiger Zeigerdiagramm;
struct Zeiger_S Z_Reihen, Z_Parallel;
// Stern-Dreieck-Umrechnung
struct Zeiger_Stern_Dreieck Z_Stern_Dreieck;
// Halbleitermaterial
struct Halbleiter_Physik Halbleiter_Material, Halbleiter_Fermi, Halbleiter_spez_R, Halbleiter_Hall;
// Hochfrequenztechnik: Smith-Diagramm
struct Hochfrequenz_Impedanz HF_Impedanz, HF_Anpassung;
// Hochfrequenztechnik: �bertragungsleitung
struct Uebertragungsleitung HF_Leitung;
// Hochfrequenztechnik: Leitungs-Ersatzschaltbild
struct Leitungs_Ersatzschaltbild Leitungs_ESB;
// Doppel-Emitterschaltung
struct Doppel_Bipolartransistor Doppel_Emitter_Schaltung;

// Ein- und Ausgabe
bool Dateiname_vorhanden = false;
bool Datei_gespeichert = false;
bool Daten_ver�ndert = false;
char Dateiname[1024];
char Initialisierungsdatei[MAX_DATEINAME];

// Schriftart f�r Ausgaben
HFONT hFont;
int Zeichenbreite = 0, Zeichenhoehe = 0;

// Allgemeine Funktionen

// Initialisierungsfunktionnen
int init(void)
{
	// Initialisierung der Variablen f�r die vier Programmteile.
	// Au�erdem werden die globalen Variablen gesetzt: Datei wurde nicht gespeichert, Datei wurde ver�ndert
	init_EingabeDialog();
	init_Gleichrichter(&Gleichrichter);
	init_ThermischerWiderstand(&R_th);
	init_Emitterschaltung(&Emitter_Schaltung);
	init_Kollektorschaltung(&Kollektor_Schaltung); 
	init_Basisschaltung(&Basis_Schaltung);
	init_Transistor_als_Schalter(&Bipolartransistor_als_Schalter);
	init_Differenzverstaerker(&Differenzverstaerker);
	init_DezibelRechner(&DezibelRechner);
	init_Ladungen(&Ladung);
	init_OP(&Invertierender_OP);
	init_OP(&Nichtinvertierender_OP);
	init_OP_Integrator_Differenzierer(&Differenzierer_OP);
	init_OP_Integrator_Differenzierer(&Integrierer_OP);
	init_OP_Summation(&Summations_OP);
	init_Zeigerdiagramm(&Zeigerdiagramm);
	init_Zeigerdiagramm_S(&Z_Reihen);
	init_Zeigerdiagramm_S(&Z_Parallel);
	init_OP_Bode(&OP_Bode);
	init_Stern_Dreieck_Umrechnung(&Z_Stern_Dreieck);
	init_Reihen_Parallel_Schaltung(&Z_Parallel);
	init_Reihen_Parallel_Schaltung(&Z_Reihen);
	init_Doppel_Emitterschaltung( &Doppel_Emitter_Schaltung );

	Dateiname_vorhanden = false;
//	Datei_gespeichert = false;  // Programm wurde ge�ffnet, damit gibt es noch keine �nderung
	Dateiname[0] = 0;
	StatusMeldung_5("");
//	Daten_ver�ndert = false;	// Alle Werte zur�ckgesetzt: das entspricht "keiner �nderung"
	Daten_neu();		// Menupunkt entspricht einer "Speicherung", setzt auch die Flags Daten_gespeichert und Daten_ver�ndert
	// Menupunkt Speichern ausgrauen
	EnableMenuItem(GetMenu(hWndElektronikMain), IDM_SPEICHERN, MF_DISABLED);
	DrawMenuBar(hWndElektronikMain);
	
	return 0;
} // end of init

int init_EingabeDialog()
{
	// Zu Beginn alle Elemente der Struktur auf false setzen, d.h. es ist kein Dialogfenster offen
	Eingabe_Dialog.Eingabe_BipolarTransistor = false;
	Eingabe_Dialog.Eingabe_Kondensator = false;
	Eingabe_Dialog.Eingabe_BipolarTransistor = false;
	Eingabe_Dialog.Eingabe_Spannung = false;
	Eingabe_Dialog.Eingabe_BipolarTransistor = false;
	Eingabe_Dialog.Eingabe_FetTransistor = false;
	Eingabe_Dialog.Eingabe_Spannungsregler = false;
	Eingabe_Dialog.Eingabe_Widerstand = false;
	Eingabe_Dialog.Eingabe_Wechselspannung = false;
	Eingabe_Dialog.Eingabe_Gleichrichter = false;
	Eingabe_Dialog.Eingabe_R_TH = false;
	Eingabe_Dialog.Eingabe_Schalt_Transistor = false;
	Eingabe_Dialog.Eingabe_Differenzverstaerker = false;
	Eingabe_Dialog.Eingabe_OP = false;
	Eingabe_Dialog.Dezibel_Rechner = false;
	Eingabe_Dialog.Auswahl_dB = true;
	Eingabe_Dialog.Eingabe_Impedanz = false;
	Eingabe_Dialog.x_min = 0;
	Eingabe_Dialog.x_max = 0;
	Eingabe_Dialog.Eingabe_Laenge = false;
	Eingabe_Dialog.Eingabe_Beta = false;
	Eingabe_Dialog.Eingabe_kompl_Impedanz = false;
	Eingabe_Dialog.Eingabe_Dialog_Positionieren = false;
	Eingabe_Dialog.hDlg_Aufrufer = NULL;

	return 0;
}	// end of init_EingabeDialog

int init_Gleichrichter(Dioden_Gleichrichter *Gleich)
{
	Gleich->U_eff = 5.0;	// 5Volt
	Gleich->U_D = 0.6;	// Diodenspannung
	Gleich->f = 50.0;	//50Hz
	Gleich->Effektivwert = true;	//Angabe ist Effektivwert
	Gleich->einweg = true;
	Gleich->positiv_gleichrichter = true;
	Gleich->C = 1.0e-3;	// 1000�F
	Gleich->positiv_regler = true;
	Gleich->Festspannung = 5;	//7805
	Gleich->R = 10.0;	//10 Ohm Lastwiderstand
	Gleich->Welligkeit = 0.1;
	Gleich->U_Max = 6.5;
	Gleich->U_amplitude = 7.4;
	Gleich->U_diode_sperr = 7.4;
	Gleich->Schaltung_berechenbar = false;
	Gleich->U_Drop = 2.0;
	Gleich->U_Ausgang = 5.0;
	Gleich->P_V = 0.0;

	return 0;
}	// end of init_Gleichrichter

int init_ThermischerWiderstand(struct Therm_Widerstand *R_Therm)
{
	R_Therm->neuer_Widerstand = false;
	R_Therm->P_V = 3.0;	//3Watt Verlustleistung
	R_Therm->Rth_CK = 1.0;	//	1K/W f�r Isolationsscheibe
	R_Therm->Rth_JC = 30.0;	//	30K/W thermische Verlustleistung  
	R_Therm->Rth_KA = 20.0; //	20K/W f�r K�hlk�rper
	R_Therm->T_junc = 150.0;	// 150�C maximale Halbleitertemperatur
	R_Therm->T_max = 85.0;	// 85�C max. Umgebungstemperatur

	return 0;
}	// end of init_ThermischerWiderstand

int init_DezibelRechner(dB_Rechner *DBR)
// Initialisierung der globalen Variablen f�r den Dezibel-Rechner
{

	DBR->U_0 = 255e-3;
	DBR->U_1 = 255e-3;
	DBR->P_0 = 1.0e-3;
	DBR->P_1 = 1.0e-3;
	DBR->dB_Wert = 1.0;
	return 0;
} // end of init_DezibelRechner

int init_Zeigerdiagramm(Komplexer_Zeiger *ZD)
// Initialisierung der globalen Variablen f�r das Zeigerdiagramm
{
	int i;

	for (i = 0; i < 12; i++)
	{
		ZD->modus[i] = 0;
		ZD->C[i] = -1.0;	// negative Zahlenwerte: Das Bauteil wird nicht verwendet
		ZD->L[i] = -1.0;
		ZD->R[i] = -1.0;
		ZD->I[i] = 0.0;
		ZD->U[i] = 0.0;
		ZD->verwendet[i] = false;
		ZD->Z[i] = 0.0;
		ZD->P[i] = 0.0;
		ZD->Q[i] = 0.0;
		ZD->S[i] = 0.0;
	}
	ZD->Frequenz = 100.0;
	ZD->Kreisfrequenz = 200.0 * pi;
	ZD->U_Z_gesamt = 10.0; //10V als Anfangswert
	ZD->P_Ges = 0.0;
	ZD->Q_Ges = 0.0;
	ZD->S_Ges = 0.0;

	return 0;
}	// end of init_Zeigerdiagramm

int init_Zeigerdiagramm_S(Zeiger_S *ZD)
// Initialisierung der globalen Variablen f�r die komplexe Reihen- und Parallelschaltung
{
	int i;

	for (i = 0; i < 6; i++)
	{
		ZD->modus[i] = 0;
		ZD->C[i] = -1.0;	// negative Zahlenwerte: Das Bauteil wird nicht verwendet
		ZD->L[i] = -1.0;
		ZD->R[i] = -1.0;
		ZD->verwendet[i] = false;
	}
	ZD->Frequenz = 100.0;
	ZD->Kreisfrequenz = 200.0 * pi;
	ZD->Z_Ges = 0.0; 
	ZD->R_Ges = 0.0;
	ZD->L_Ges = 0.0;
	ZD->C_Ges = 0.0;
	ZD->R_verwendet = false;
	ZD->C_verwendet = false;
	ZD->L_verwendet = false;

	return 0;
}	// end of init_Zeigerdiagramm_S

int init_Stern_Dreieck_Umrechnung(Zeiger_Stern_Dreieck *ZD)
// Initialisierung der globalen Variablen f�r die komplexe Dreieck-Stern-Umwandlung
{
	int i;

	for (i = 0; i < 3; i++)
	{
		ZD->R_Stern[i] = -1.0;
		ZD->C_Stern[i] = -1.0;
		ZD->L_Stern[i] = -1.0;
		ZD->R_Dreieck[i] = -1.0;
		ZD->C_Dreieck[i] = -1.0;
		ZD->L_Dreieck[i] = -1.0;
		ZD->modus_Stern[i] = 0;
		ZD->modus_Dreieck[i] = 0;
		ZD->Z_Stern[i] = 0.0;
		ZD->Z_Dreieck[i] = 0.0;
		ZD->Reihenschaltung_Dreieck[i] = false;
		ZD->Reihenschaltung_Stern[i] = false;
	}
	ZD->Dreieck_Berechnen = false;
	ZD->Frequenz = 100.0;
	ZD->Kreisfrequenz = 200.0 * pi;
	ZD->Werte_berechenbar = false;
	ZD->Schaltung_berechenbar = true;
	ZD->Transformation_berechnet = false;

	return 0;
}	// end of init_Zeigerdiagramm_S

int init_Reihen_Parallel_Schaltung(Zeiger_S *Zeiger)
// Initialisierung der globalen Variablen f�r die komplexe Reihen- und Parallelschaltung
{
	int i;

	for (i = 0; i < 6; i++)
	{
		Zeiger->C[i] = -1.0;
		Zeiger->R[i] = -1.0;
		Zeiger->L[i] = -1.0;
		Zeiger->modus[i] = 0;
		Zeiger->Z[i] = 0.0;
		Zeiger->verwendet[i] = false;
	}
	Zeiger->Schaltung_berechenbar = false;
	Zeiger->Frequenz = 100.0;
	Zeiger->Kreisfrequenz = 200.0 * pi;
	Zeiger->C_verwendet = false;
	Zeiger->L_verwendet = false;
	Zeiger->R_verwendet = false;
	Zeiger->C_Ges = 0.0;
	Zeiger->L_Ges = 0.0;
	Zeiger->R_Ges = 0.0;

	return 0;
}	// end of init_Reihen_Parallel_Schaltung


// Hilfsfunktionen
int Bestimme_Exponent(double wert)
{
	// Diese Funktion bestimmt den Exponenten so, dass eine Anzeige ohne Komma m�glich ist
	// Der Exponent wird auf Vielfache von drei gerundet
	// Funktion in Ordnung, M. Alles, M�rz 2016
	int ergebnis;
	double hilf;

	if (wert == 0)
		ergebnis = 0;
	else
	{
		ergebnis = (int)log10(fabs(wert));
		if ((ergebnis % 3) != 0)
			if (ergebnis >= 0)
				ergebnis = 3 * (ergebnis / 3);
			else
			{
				ergebnis = 3 * (ergebnis / 3 - 1);
			}
		hilf = wert / ((double)pow((double)10.0, ergebnis));
		if (fabs(hilf) < 1.0)
			ergebnis -= 3;
		if (fabs(hilf) >= 1000.0)
			ergebnis += 3;
	}
	return ergebnis;
} // end of Bestimme_Exponent

unsigned char Benenne_Exponent(int Exponent)
{
	// Diese Funktion liefert das Vorsatzzeichen in Abh�ngigkeit des Exponenten
	// Funktion in Ordnung, M. Alles, M�rz 2016
	unsigned char ergebnis;

	switch (Exponent)
	{
	case 24:ergebnis = 'Y'; break;
	case 21:ergebnis = 'Z'; break;
	case 18:ergebnis = 'E'; break;
	case 15:ergebnis = 'P'; break;
	case 12:ergebnis = 'T'; break;
	case 9: ergebnis = 'G'; break;
	case 6: ergebnis = 'M'; break;
	case 3: ergebnis = 'k'; break;
	case 0: ergebnis = ' '; break;
	case -3: ergebnis = 'm'; break;
	case -6: ergebnis = (unsigned char)'�'; break;
	case -9: ergebnis = 'n'; break;
	case -12: ergebnis = 'p'; break;
	case -15: ergebnis = 'f'; break;
	case -18: ergebnis = 'a'; break;
	case -21: ergebnis = 'z'; break;
	case -24: ergebnis = 'y'; break;

	default:ergebnis = 'x';
	}

	return ergebnis;
} // end of Benenne_Exponent

int Bestimme_Kapazitaetsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int	Exponent,i;

	if (wert<0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "Fehler!");
	else
	{
		Exponent = Bestimme_Exponent(wert);
		hilf = wert / ((double)pow((double)10.0, Exponent));
		ch = Benenne_Exponent(Exponent);
		if (Exponent!=0)
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cF", hilf, ch);
		else
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gF", hilf);
		// Punkt durch Komma austauschen
		for (i = 0; i < Max_Zahl_Zeichen; i++)
		{
			if (Bezeichner[i] == '.')
				Bezeichner[i] = ',';
			if (Bezeichner[i] == 0)
				break;
		}
	}
	return 0;
} // end of Bestimme_Kapazitaetsbezeichner
int Bestimme_Bezeichner_Kapazitaetsbelag(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int	Exponent,i;

	if (wert<0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "Fehler!");
	else
	{
		Exponent = Bestimme_Exponent(wert);
		hilf = wert / ((double)pow((double)10.0, Exponent));
		ch = Benenne_Exponent(Exponent);
		if (Exponent!=0)
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cF/m", hilf, ch);
		else
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gF/m", hilf);
		// Punkt durch Komma austauschen
		for (i = 0; i < Max_Zahl_Zeichen; i++)
		{
			if (Bezeichner[i] == '.')
				Bezeichner[i] = ',';
			if (Bezeichner[i] == 0)
				break;
		}
	}
	return 0;
} // end of Bestimme_Bezeichner_Kapazitaetsbelag
int Bestimme_Bezeichner_Induktivitaetsbelag(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int	Exponent,i;

	if (wert<0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "Fehler!");
	else
	{
		Exponent = Bestimme_Exponent(wert);
		hilf = wert / ((double)pow((double)10.0, Exponent));
		ch = Benenne_Exponent(Exponent);
		if (Exponent!=0)
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cH/m", hilf, ch);
		else
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gH/m", hilf);
		// Punkt durch Komma austauschen
		for (i = 0; i < Max_Zahl_Zeichen; i++)
		{
			if (Bezeichner[i] == '.')
				Bezeichner[i] = ',';
			if (Bezeichner[i] == 0)
				break;
		}
	}
	return 0;
} // end of Bestimme_Bezeichner_Induktivitaetsbelag
int Bestimme_Bezeichner_Widerstandsbelag(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int	Exponent,i;

	if (wert<0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "Fehler!");
	else
	{
		Exponent = Bestimme_Exponent(wert);
		hilf = wert / ((double)pow((double)10.0, Exponent));
		ch = Benenne_Exponent(Exponent);
		if (Exponent!=0)
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cOhm/m", hilf, ch);
		else
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gOhm/m", hilf);
		// Punkt durch Komma austauschen
		for (i = 0; i < Max_Zahl_Zeichen; i++)
		{
			if (Bezeichner[i] == '.')
				Bezeichner[i] = ',';
			if (Bezeichner[i] == 0)
				break;
		}
	}
	return 0;
} // end of Bestimme_Bezeichner_Widerstandsbelag
int Bestimme_Widerstandsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;
	
	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cOhm", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gOhm", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Widerstandsbezeichner

int Bestimme_komplexen_Widerstandsbezeichner_real_imag(char *Bezeichner, complex <double> wert, int Max_Zahl_Zeichen)
{
	// Ausgabe eines komplexen Widerstands 
	// M. Alles, 14.2.2018
	unsigned char ch_re, ch_im, Vorzeichen;
	double hilf, realteil, imagteil;
	int Exponent_re, Exponent_im, i;

	realteil = real(wert);
	imagteil = imag(wert);
	Exponent_re = Bestimme_Exponent(realteil);
	hilf = realteil / ((double)pow((double)10.0, Exponent_re));
	ch_re = Benenne_Exponent(Exponent_re);
	realteil = hilf;
	// Das gleiche nochmal mit Imagin�rteil
	Exponent_im = Bestimme_Exponent(imagteil);
	hilf = imagteil / ((double)pow((double)10.0, Exponent_im));
	ch_im = Benenne_Exponent(Exponent_im);
	imagteil = hilf;
	if (imagteil < 0)
		Vorzeichen = '-';
	else
		Vorzeichen = '+';
	// Das Vorzeichen ist jetzt bestimmt. Damit nicht doppelte Minuszeichen ausgegeben werden, muss der Imagin�rteil als
	// Betrag ausgegeben werden.
	imagteil = fabs(imagteil);
	if ((Exponent_re != 0)&&(Exponent_im!=0))
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cOhm%cj%.4g%cOhm", realteil, ch_re, Vorzeichen, imagteil, ch_im);
	else
	{
		if (Exponent_re != 0)
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cOhm%cj%.4gOhm", realteil, ch_re, Vorzeichen, imagteil);
		else
		{
			if (Exponent_im != 0)
				sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gOhm%cj%.4g%cOhm", realteil, Vorzeichen, imagteil, ch_im);
			else
				sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gOhm%cj%.4gOhm", realteil, Vorzeichen, imagteil);
		}
	}
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_komplexen_Widerstandsbezeichner_real_imag

int Bestimme_komplexen_Widerstandsbezeichner_Betrag_Winkel(char *Bezeichner, complex <double> wert, int Max_Zahl_Zeichen)
{
	// Ausgabe eines komplexen Widerstands 
	// M. Alles, 14.2.2018
	unsigned char ch, Vorzeichen;
	double hilf, betrag, winkel;
	int Exponent, i;

	betrag = abs(wert);
	winkel = arg(wert)*180.0 / pi;
	Exponent = Bestimme_Exponent(betrag);
	hilf = betrag / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	betrag = hilf;
	if (winkel < 0.0)
		Vorzeichen = '-';
	else
		Vorzeichen = '+';
	// Betrag des Winkels bestimmen, damit das Vorzeichen nicht doppelt ausgegeben wird 
	winkel = fabs(winkel);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cOhm; %c%.4g�", betrag, ch, Vorzeichen, winkel);
	else
	{
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gOhm; %c%.4g�", betrag, Vorzeichen, winkel);
	}
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_komplexen_Widerstandsbezeichner_Betrag_Winkel

int Bestimme_komplexen_Bezeichner_Betrag_Winkel(char *Bezeichner, complex <double> wert, int Max_Zahl_Zeichen)
{
	// Ausgabe einer Polarkoordinate mit Betrag und Wink�l 
	// M. Alles, 29.6.2019
	unsigned char ch, Vorzeichen;
	double hilf, betrag, winkel;
	int Exponent, i;

	betrag = abs(wert);
	winkel = arg(wert)*180.0 / pi;
	Exponent = Bestimme_Exponent(betrag);
	hilf = betrag / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	betrag = hilf;
	if (winkel < 0.0)
		Vorzeichen = '-';
	else
		Vorzeichen = '+';
	// Betrag des Winkels bestimmen, damit das Vorzeichen nicht doppelt ausgegeben wird 
	winkel = fabs(winkel);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%c; %c%.4g�", betrag, ch, Vorzeichen, winkel);
	else
	{
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g; %c%.4g�", betrag, Vorzeichen, winkel);
	}
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_komplexen_Bezeichner_Betrag_Winkel
int Bestimme_komplexen_Bezeichner_real_imag(char *Bezeichner, complex <double> wert, int Max_Zahl_Zeichen)
{
	// Ausgabe eines komplexen Wertes 
	// M. Alles, 19.10.2019
	unsigned char ch_re, ch_im, Vorzeichen;
	double hilf, realteil, imagteil;
	int Exponent_re, Exponent_im, i;

	realteil = real(wert);
	imagteil = imag(wert);
	Exponent_re = Bestimme_Exponent(realteil);
	hilf = realteil / ((double)pow((double)10.0, Exponent_re));
	ch_re = Benenne_Exponent(Exponent_re);
	realteil = hilf;
	// Das gleiche nochmal mit Imagin�rteil
	Exponent_im = Bestimme_Exponent(imagteil);
	hilf = imagteil / ((double)pow((double)10.0, Exponent_im));
	ch_im = Benenne_Exponent(Exponent_im);
	imagteil = hilf;
	if (imagteil < 0)
		Vorzeichen = '-';
	else
		Vorzeichen = '+';
	// Das Vorzeichen ist jetzt bestimmt. Damit nicht doppelte Minuszeichen ausgegeben werden, muss der Imagin�rteil als
	// Betrag ausgegeben werden.
	imagteil = fabs(imagteil);
	if ((Exponent_re != 0)&&(Exponent_im!=0))
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%c%cj%.4g%c", realteil, ch_re, Vorzeichen, imagteil, ch_im);
	else
	{
		if (Exponent_re != 0)
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%c%cj%.4g", realteil, ch_re, Vorzeichen, imagteil);
		else
		{
			if (Exponent_im != 0)
				sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gOhm%cj%.4g%cOhm", realteil, Vorzeichen, imagteil, ch_im);
			else
				sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gOhm%cj%.4gOhm", realteil, Vorzeichen, imagteil);
		}
	}
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_komplexen_Bezeichner_real_imag
int Bestimme_komplexen_Leitwertsbezeichner_real_imag(char *Bezeichner, complex <double> wert, int Max_Zahl_Zeichen)
{
	// Ausgabe eines komplexen Leitwerts 
	// M. Alles, 110.11.2019
	unsigned char ch_re, ch_im, Vorzeichen;
	double hilf, realteil, imagteil;
	int Exponent_re, Exponent_im, i;

	realteil = real(wert);
	imagteil = imag(wert);
	Exponent_re = Bestimme_Exponent(realteil);
	hilf = realteil / ((double)pow((double)10.0, Exponent_re));
	ch_re = Benenne_Exponent(Exponent_re);
	realteil = hilf;
	// Das gleiche nochmal mit Imagin�rteil
	Exponent_im = Bestimme_Exponent(imagteil);
	hilf = imagteil / ((double)pow((double)10.0, Exponent_im));
	ch_im = Benenne_Exponent(Exponent_im);
	imagteil = hilf;
	if (imagteil < 0)
		Vorzeichen = '-';
	else
		Vorzeichen = '+';
	// Das Vorzeichen ist jetzt bestimmt. Damit nicht doppelte Minuszeichen ausgegeben werden, muss der Imagin�rteil als
	// Betrag ausgegeben werden.
	imagteil = fabs(imagteil);
	if ((Exponent_re != 0)&&(Exponent_im!=0))
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cS%cj%.4g%cS", realteil, ch_re, Vorzeichen, imagteil, ch_im);
	else
	{
		if (Exponent_re != 0)
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cS%cj%.4gS", realteil, ch_re, Vorzeichen, imagteil);
		else
		{
			if (Exponent_im != 0)
				sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gS%cj%.4g%cS", realteil, Vorzeichen, imagteil, ch_im);
			else
				sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gS%cj%.4gS", realteil, Vorzeichen, imagteil);
		}
	}
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_komplexen_Leitwertsbezeichner_real_imag
int Bestimme_imaginaeren_Widerstandsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	// Ausgabe eines rein imagin�ren Widerstands 
	// M. Alles, 7.11.2019
	unsigned char ch_im, Vorzeichen;
	double hilf;
	int Exponent_im, i;

	// Das gleiche nochmal mit Imagin�rteil
	Exponent_im = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent_im));
	ch_im = Benenne_Exponent(Exponent_im);
	if (hilf < 0)
		Vorzeichen = '-';
	else
		Vorzeichen = '+';
	// Das Vorzeichen ist jetzt bestimmt. Damit nicht doppelte Minuszeichen ausgegeben werden, muss der Imagin�rteil als
	// Betrag ausgegeben werden.
	hilf = fabs(hilf);
	if (Exponent_im!=0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%cj%.4g%cOhm", Vorzeichen, hilf, ch_im);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%cj%.4gOhm", Vorzeichen, hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_imaginaeren_Widerstandsbezeichner
int Bestimme_Induktivitaetsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int	Exponent, i;

	if (wert<0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "Fehler!");
	else
	{
		Exponent = Bestimme_Exponent(wert);
		hilf = wert / ((double)pow((double)10.0, Exponent));
		ch = Benenne_Exponent(Exponent);
		if (Exponent != 0)
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cH", hilf, ch);
		else
			sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gH", hilf);
		// Punkt durch Komma austauschen
		for (i = 0; i < Max_Zahl_Zeichen; i++)
		{
			if (Bezeichner[i] == '.')
				Bezeichner[i] = ',';
			if (Bezeichner[i] == 0)
				break;
		}
	}
	return 0;
} // end of Bestimme_Induktivitaetsbezeichner

int Bestimme_Spannungsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent,i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cV", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gV", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Spannungsbezeichner

int Bestimme_Leistungsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cW", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gW", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Leistungsbezeichner

int Bestimme_Dezibelbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	// Ausgabe eines Dezibelwertes in einen String
	// hier werden keine Vorsatzzeichen verwendet
	int i;

	sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gdB", wert);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Dezibelbezeichner
int Bestimme_Strombezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cA", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gA", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Strombezeichner

int Bestimme_Prozentbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	int i;

	sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%g%%", wert*100.0);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Prozentbezeichner

int Bestimme_Technologiebezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cA/V�", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gA/V�", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Technologiebezeichner

int Bestimme_Bezeichner_Steilheit(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cA/V", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gA/V", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Technologiebezeichner

int Bestimme_Frequenzbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%cHz", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4gHz", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Frequenzbezeichner

int Bestimme_Laengenbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cm", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gm", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Laengenbezeichner

int Bestimme_E_Feld_Bezeichner_cm(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	// Achtung: Ausgabe in V/cm, der Vorfaktor betrifft nur die Einheit Volt!
	unsigned char ch;
	double hilf;
	int Exponent, i;

	wert /= 100.0;
	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cV/cm", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gV/cm", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Feld_Bezeichner

int Bestimme_E_Feld_Bezeichner_m(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	// Achtung: Ausgabe in V/m, der Vorfaktor betrifft nur die Einheit Volt!
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cV/m", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gV/m", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Feld_Bezeichner

int Bestimme_Ladungsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cC", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gC", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Ladungsbezeichner

int Bestimme_Winkelbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%c�", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g�", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Winkelbezeichner

int Bestimme_Blindleistungsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cvar", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gvar", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Blindleistungsbezeichner

int Bestimme_Scheinleistungsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cVA", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gVA", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Scheinleistungsbezeichner

int Bestimme_Bezeichner_Festspannungsregler(char *Bezeichner, int Spannung, bool Positivregler, int Max_Zahl_Zeichen)
{
	if (Spannung < 0)
		Spannung = -Spannung;
	if (Positivregler)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "78%02u", Spannung);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "79%02u", Spannung);
	return 0;
}	// end of Bestimme_Bezeichner_Festspannungsregler

int Bestimme_Bezeichner_wissenschaftlich(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%g%c", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%g", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Bezeichner_wissenschaftlich
int Bestimme_Bezeichner_Exponent(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	int i;

	sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%g", wert);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Bezeichner_Exponent
int Bestimme_Bezeichner_wissenschaftlich(char *Bezeichner, double wert, int Max_Zahl_Zeichen, WCHAR *Einheit, int Laenge_Einheit)
{
	/* Diese Funktion erstellt aus einer Flie�kommazahl eine Zahl mit Einheit und Vorsatzzeichen. Die Einheit und die L�nge der Einheit werden 
	   als Parameter mit �bergeben. */
	unsigned char ch;
	double hilf;
	int Exponent, i;

	// Kontrolle Einheit
	Einheit[Laenge_Einheit] = 0;
	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%g%c%s", hilf, ch, (wchar_t *)Einheit);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%g%s", hilf, (wchar_t *)Einheit);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Bezeichner_wissenschaftlich

int Bestimme_Bezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	int i;

	sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%g", wert);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Bezeichner

int Bestimme_Temperaturbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%cK", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5gK", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Temperaturbezeichner

int Bestimme_Bezeichner_Elektronenvolt(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4g%ceV", hilf, ch);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.4geV", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Bezeichner_Elektronenvolt

int Bestimme_Bezeichner_Ladungsdichte_cm3(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	int i;

	wert *= 1.0e-6;
	sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%gcm^-3", wert);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Bezeichner_Ladungsdichte_cm3

int Bestimme_Bezeichner_Beweglichkeit(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	int i;

	sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%gcm^2/Vs", wert);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Bezeichner_Beweglichkeit

int Bestimme_Bezeichner_Beweglichkeit_cm2(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	int i;

	wert *= 1.0e-4;
	sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%gcm^2/Vs", wert);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Bezeichner_Beweglichkeit_cm2

int Bestimme_Bezeichner_spezifischer_Widerstand_Ohm_Meter(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	int i;

	sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%gOhm*m", wert);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Bezeichner_spezifischer_Widerstand_Ohm_Meter

int Bestimme_Bezeichner_Phase(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	unsigned char ch;
	double hilf;
	int Exponent, i;

	Exponent = Bestimme_Exponent(wert);
	hilf = wert / ((double)pow((double)10.0, Exponent));
	ch = Benenne_Exponent(Exponent);
	if (Exponent != 0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g%d 1/m", hilf, Exponent);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.5g 1/m", hilf);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Bezeichner_Phase

int Bestimme_Bezeichner_Wert_Smith(char *Bezeichner, double wert, int Max_Zahl_Zeichen)
{
	// Diese Funktion bestimmt den Bezeichner f�r die Beschriftung im Smith-Diagramm
	// Maximal eine Nachkommastelle wird ausgegeben.
	// Falls es eine ganze Zahl ist, gibt es keine Nachkommastelle
	int i;

	if (wert==(double)((int)wert*10)/10.0)
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%d", (int)wert);
	else
		sprintf_s(Bezeichner, Max_Zahl_Zeichen, "%.1f", wert);
	// Punkt durch Komma austauschen
	for (i = 0; i < Max_Zahl_Zeichen; i++)
	{
		if (Bezeichner[i] == '.')
			Bezeichner[i] = ',';
		if (Bezeichner[i] == 0)
			break;
	}
	return 0;
} // end of Bestimme_Bezeichner_Wert_Smith



double setze_Maximalwert(double wert)
{
	// Funktion bestimmt sinnvollen Maximalwert f�r ein xy-Diagramm
	double hilf, Vorzeichen=1.0;
	long hilf2;
	// falls der Wert negativ ist, wird zun�chst der Betrag gebildet und das Minuszeichen am Ende angeh�ngt.

	if (wert <0.0)
	{
		Vorzeichen = -1.0;
		wert = -wert;
	}
	hilf = log10(wert);
	hilf2 = (long int)hilf;
	if (hilf == (double)hilf2) // Glatter "Zehner"-Wert
		hilf = wert;
	else
	{
		if (hilf > 0) hilf += 1.0;
		hilf2 = (long int)hilf;
		hilf = pow(10, (double)hilf2);

		if (hilf / 5 > wert) hilf /= 5.0;
		if (hilf / 2 > wert) hilf /= 2.0;
	}

	return Vorzeichen*hilf;
} // end of Setze_Maximalwert

double setze_Minimalwert(double wert)
{
	// Funktion bestimmt sinnvollen Minimalwert f�r ein xy-Diagramm
	// 21.4.2019 M. Alles
	double hilf, Vorzeichen = 1.0;
	long hilf2;
	// falls der Wert negativ ist, wird die Berechnung mit dem Betrag durchgef�hrt.

	if (wert<0.0)
	{
		Vorzeichen = -1.0;
		wert = -wert;
	}

	hilf = log10(wert);
	hilf2 = (long int)hilf;
	if (hilf == (double)hilf2) // Glatter "Zehner"-Wert
		hilf = wert;
	else
	{
		hilf -= 1.0;
		hilf2 = (long int)hilf;
		hilf = pow(10, (double)hilf2);

		if (hilf * 5 <= wert) hilf *= 5.0;
		if (hilf * 2 <= wert) hilf *= 2.0;
	}

	return Vorzeichen*hilf;
} // end of Setze_Minimalwert

int Bestimme_Koordinaten_Wert(long Koordinate_min, long Koordinate_max, double Wert_min, double Wert_max, double akt_wert, bool linear)
{
	double rueckgabe=0.0;

	if (linear)
		rueckgabe = Koordinate_min + (Koordinate_max - Koordinate_min) * (akt_wert-Wert_min) / (Wert_max-Wert_min);
	else
	{
		if ((akt_wert != 0.0) && (Wert_max != 0)&&(Wert_min != 0 ))
			rueckgabe = Koordinate_min + (Koordinate_max - Koordinate_min) * ( log10(akt_wert)-log10(Wert_min) ) / (log10(Wert_max)-log10(Wert_min));
	}
	if (rueckgabe < Koordinate_min)
		rueckgabe = Koordinate_min;
	if (rueckgabe > Koordinate_max)
		rueckgabe = Koordinate_max;

	return (int)rueckgabe;
}

int sortiere_frequenzpunkte(double *phasen_frequenz, int max_zahl)
{
	int i, j, k; 
	double hilf;

	for (i=0; i<max_zahl-1; i++)
		for (j = i + 1; j < max_zahl; j++)
		{
			if (phasen_frequenz[i] == phasen_frequenz[j])
			{
				// zwei gleiche Eintr�ge gefunden
				for (k = j; k < max_zahl - 1; k++)
					phasen_frequenz[k] = phasen_frequenz[k + 1];
				max_zahl--;
				// Durch das Kopieren kann im Feld von j ein neuer Doppelwert stehen
				j--;
			}
		}
	// Jetzt muss das Feld noch sortiert werden
	for (i = 0; i < max_zahl; i++)
	{
		for (j = 1; j < max_zahl; j++)
		{
			if (phasen_frequenz[j - 1] > phasen_frequenz[j])
			{
				// umsortieren
				hilf = phasen_frequenz[j - 1];
				phasen_frequenz[j - 1] = phasen_frequenz[j];
				phasen_frequenz[j] = hilf;
			}
		}
	}
	return max_zahl;
}

// Funktionen f�r Kennwort-Eingabe
bool Ueberpruefe_Kennwort(void)
{
	return true;
}

int a_to_hex(char zeichen)
{
	// Umwandlung von Ascii-Zeichen in Hexadezimalzahl
	// Funktion in Ordnung, M. Alles 2015

	int rueckgabe;

	switch (zeichen)
	{
	case '0': rueckgabe = 0; break;
	case '1': rueckgabe = 1; break;
	case '2': rueckgabe = 2; break;
	case '3': rueckgabe = 3; break;
	case '4': rueckgabe = 4; break;
	case '5': rueckgabe = 5; break;
	case '6': rueckgabe = 6; break;
	case '7': rueckgabe = 7; break;
	case '8': rueckgabe = 8; break;
	case '9': rueckgabe = 9; break;
	case 'a':
	case 'A': rueckgabe = 10; break;
	case 'b':
	case 'B': rueckgabe = 11; break;
	case 'c':
	case 'C': rueckgabe = 12; break;
	case 'd':
	case 'D': rueckgabe = 13; break;
	case 'e':
	case 'E': rueckgabe = 14; break;
	case 'f':
	case 'F': rueckgabe = 15; break;
	default: rueckgabe = -1;
	}
	return rueckgabe;
} // end of a_to_hex

bool widechar_to_char(char *ausgabe, WCHAR *eingabe, int max_zahl)
{
	// Funktion wandelt einen Wide-Character-String in einen Ascii-String um
	int i, max;

	max = wcslen(eingabe);
	if (max > max_zahl)
		max = max_zahl;
	for (i = 0; i < max; i++)
	{
//		switch( eingabe[i] )
//		{
//		default: 
		ausgabe[i] = (char)eingabe[i];
//		}
	}
	ausgabe[i] = 0;
	return true;
}	// end of widechar_to_Char

bool char_to_widechar(WCHAR *ausgabe, char *eingabe, int max_zahl)
{
	// Funktion wandelt einen Ascii-String in einen Wide-Character-String um
	int i, max;

	max = strlen(eingabe);
	if (max > max_zahl)
		max = max_zahl;
	for (i = 0; i < max; i++)
	{
		switch( eingabe[i])
		{
		case '�': ausgabe[i]=956; break;
		case '�': ausgabe[i]=178;break;
		case '�': ausgabe[i]=179; break;
		case '�': ausgabe[i]=228; break;
		case '�': ausgabe[i]=196; break;
		case '�': ausgabe[i]=246; break;
		case '�': ausgabe[i]=214; break;
		case '�': ausgabe[i]=252; break;
		case '�': ausgabe[i]=220; break;
		case '�': ausgabe[i]=223; break;
								
		default: ausgabe[i] = (WCHAR)eingabe[i];
		}
	}
	ausgabe[i] = 0;
	return true;
}	// end of char_to_widechar

bool kopiere_substring(char *ausgabe, char *eingabe, int start_pos, int anzahl_zeichen, int max_zahl)
{
	// Funktion kopiert die durch anzahl_zeichen angegebene Anzahl von Zeichen, beginnend ab start_pos von der eingabe zur ausgabe. 
	int i;

	if (start_pos + anzahl_zeichen >= max_zahl)
		// Fehler
		return false;
	for (i = 0; i < anzahl_zeichen; i++)
	{
		ausgabe[i] = eingabe[i + start_pos];
	}
	ausgabe[i] = 0;	//abschliessendes Null-Zeichen

	return true;
}	//end of kopiere_substring

bool lese_wert_aus_zeile(double *wert, char *zeile, char *Index_String)
{
	// Funktion sucht in der zeile den Index_String und versucht danach den Zahlenwert als double zu lesen
	// Index nicht gefunden -> R�ckgabe false

	char *position, eingabe[MAX_ANZAHL_ZEICHEN_PRO_ZEILE];
	bool rueckgabe = true;

	position = strstr(zeile, Index_String);
	if (position != NULL)
	{
		kopiere_substring(eingabe, position, strlen(Index_String) + 1, strlen(position) - 4, MAX_ANZAHL_ZEICHEN_PRO_ZEILE);
		*wert = atof(eingabe);
	}
	else
		rueckgabe = false;

	return rueckgabe;
}	// end of lese_wert_aus_zeile

bool lese_string_aus_zeile(char *ausgabe, char *eingabe, char *Index_String, unsigned int anzahl_zu_lesen)
{
	// Funktion sucht in der zeile den Index_String und versucht danach die angegebene Anzahl Zeichen zu lesen
	// Index nicht gefunden -> R�ckgabe false

	char *position;
	bool rueckgabe = false;
	unsigned int i;

	position = strstr(eingabe, Index_String);
	if (position != NULL)
	{
		if (strlen(position) >= anzahl_zu_lesen)
		{
			for (i = 0; i < anzahl_zu_lesen; i++)
				ausgabe[i] = position[strlen(Index_String) + 1 + i];
			ausgabe[i] = 0;
			rueckgabe = true;
		}
	}

	return rueckgabe;
} // end of lese_string_aus_zeile

double Zahl_uebernehmen(char *eingabe, int max_zahl)
{
	// Funktion "�bersetzt" die Eingabe in eine Zahl
	// Funktion i.O.
	// Erg�nzung 19.1.2020 - Die Funktion erkennt und verarbeitet alle Vorsatzzeichen, die auch bei der Ausgabe verwendet werden.
	int i, index, laenge;
	bool punkt_gefunden = false;
	double faktor = 1.0, rueckgabe = 0.0;

	// Suche und ersetze Komma durch Punkt
	// Suche und l�sche die folgenden Zeichen: k, m, u, �, M, n, p, G, dazu passenden Vorfaktor bestimmen
	// ggf. das gel�schte Zeichen durch Punkt ersetzen, falls vorher noch kein Punkt im Strin enthalten war. 
	laenge = strlen(eingabe);
	if (laenge > max_zahl)
	{
		laenge = max_zahl;
		eingabe[laenge] = 0;
	}
	// Suche nach einem Komma
	for (i = 0; i < laenge; i++)
	{
		if (eingabe[i] == '.')
			punkt_gefunden = true;
	}
	// falls kein Punkt gefunden wurde, nach einem Komma suchen und das Komma durch den Punkt ersetzen
	if (!punkt_gefunden)
		for (i = 0; i < laenge; i++)
		{
			if (eingabe[i] == ',')
			{
				eingabe[i] = '.';
				punkt_gefunden = true;
			}
		}
	// Jetzt sollte kein Komma mehr vorhanden sein...
	// Also nach den Zeichen oben suchen...
	// Ist ein Zeichen enthalten?
	index = strcspn(eingabe, "kKmu�MnNpPfFEzZgG");
	laenge = strlen(eingabe);
	while (index != laenge)
	{
		// Eines der Vorsatzzeichen gefunden
		switch (eingabe[index])
		{
		case 'm': faktor *= 0.001; break;
		case 'u':
		case '�': faktor *= 0.000001; break;
		case 'n': 
		case 'N': faktor *= 1.0e-9; break;
		case 'p': faktor *= 1.0e-12; break;
		case 'f':
		case 'F': faktor *= 1.0e-15; break;
		case 'a': 
		case 'A': faktor *= 1.0e-18; break;
		case 'z': faktor *= 1.0e-21; break;
		case 'y': faktor *= 1.0e-24; break;

		case 'k': 
		case 'K': faktor *= 1000.0; break;
		case 'M': faktor *= 1000000.0; break;
		case 'G': 
		case 'g': faktor *= 1.0e9; break;
		case 'T':
		case 't': faktor *= 1.0e12; break; 
		case 'P': faktor *= 1.0e15; break;
		case 'E': faktor *= 1.0e18; break;
		case 'Z': faktor *= 1.0e21; break; 
		case 'Y': faktor *= 1.0e24; break; 

		}
		// Falls noch kein Punkt gefunden wurde, wird an die Stelle des Vorsatzzeichens ein Punkt gesetzt
		if (!punkt_gefunden)
		{
			eingabe[index] = '.';
			punkt_gefunden = true;
		}
		else
			// Ansonsen einfach auf Null setzen...
			eingabe[index] = '0';
		// Kontrolle: Ist noch ein Vorsatzzeichen enthalten?
		index = strcspn(eingabe, "mu�nNpfFaAzykKMgGtTPEZY");
	}
	// Jetzt noch den Zahlenwert lesen
	sscanf_s(eingabe, "%lg", &rueckgabe);
	return rueckgabe*faktor;

}	// end of Zahl_uebernehmen

double Eingabe_parsen(HWND hDlg, int ID)
{
	// Funktion liest die Eingabe aus einem Edit-Feld aus, wandelt die Eingabe in ASCII-Code um und
	// interpretiert die Zeichen als Zahl. Vorsatzzeichen (k,m, ...) werden ber�cksichtigt.

	char cEingabe[100];

	GetDlgItemText(hDlg, ID, (LPSTR)cEingabe, 99);

	return Zahl_uebernehmen(cEingabe, 99);
} // end of Eingabe_parsen

bool Kennwort_ok(char wort1[6], char wort2[6], char wort3[6], char wort4[6], int jahr, bool WiSe)
{
	// �berpr�fung eines Kennwortes
	// Funktion in Ordnung, M. Alles M�rz 2016

	// Die einzelnen Strings in Zahlen umwandeln
	int zahl1 = 0, zahl2 = 0, zahl3 = 0, zahl4 = 0;
	bool rueckgabe = false, universal = false, semester = false;

	zahl1 = a_to_hex(wort1[4]) + 13 * a_to_hex(wort1[3]) + 169 * a_to_hex(wort1[2]) + 2197 * a_to_hex(wort1[1]) + 28561 * a_to_hex(wort1[0]);
	zahl2 = a_to_hex(wort2[4]) + 13 * a_to_hex(wort2[3]) + 169 * a_to_hex(wort2[2]) + 2197 * a_to_hex(wort2[1]) + 28561 * a_to_hex(wort2[0]);
	zahl3 = a_to_hex(wort3[4]) + 13 * a_to_hex(wort3[3]) + 169 * a_to_hex(wort3[2]) + 2197 * a_to_hex(wort3[1]) + 28561 * a_to_hex(wort3[0]);
	zahl4 = a_to_hex(wort4[4]) + 13 * a_to_hex(wort4[3]) + 169 * a_to_hex(wort4[2]) + 2197 * a_to_hex(wort4[1]) + 28561 * a_to_hex(wort4[0]);
	// Erste Kontrolle auf Semestercode:
	if ((zahl1 + zahl2 + zahl3 + zahl4) % 77 == 0)
	{
		rueckgabe = true;
		// Zweite Kontrolle:
		if ((zahl1 - zahl2) % jahr == 0)
		{
			if ((zahl4 - zahl3) % 83 == 0)
				if (WiSe)
					semester = true;
			if ((zahl4 - zahl3) % 87 == 0)
				if (!WiSe)
					semester = true;
		}
	}
	// Erste Kontrolle auf Semestercode:
	if ((zahl1 + zahl2 + zahl3 + zahl4) % 787 == 0)
	{
		rueckgabe = true;
		// Zweite Kontrolle:
		if ((zahl1 - zahl2) % 373 == 0)
			if ((zahl4 - zahl3) % 737 == 0)
				universal = true;
	}

	if (rueckgabe)
	{
		if ((!universal) && (!semester))
			rueckgabe = false;
	}
	return rueckgabe;
} // end of Kennwort_ok

double Parallelschaltung(double R1, double R2)
{
	// Berechnung einer Parallelschaltung von R1 und R2
	double ergebnis;

	if ((R1*R2) != 0.0)
		ergebnis = R1*R2 / (R1 + R2);
	else
		ergebnis = -1.0;

	return ergebnis;
} // end of Parallelschaltung

double Phase(complex <double> komplexe_zahl)
// Bestimmt die Phase einer komplexen Zahl in Grad
{
	return arg(komplexe_zahl)*180.0 / pi;
} // end of Phase

int Daten_geaendert(void)
{
	// Flag setzen
	Datei_gespeichert = false;
	Daten_ver�ndert = true;
	// Flag in Stustuszeile setzen:
	SendMessage(hWndStatus, (UINT)SB_SETTEXT, (WPARAM)(INT)2, (LPARAM)L"�");
	return 0;
}	// end of Daten_geaendert

int Daten_gespeichert(void)
{
	// Flag setzen
	Datei_gespeichert = true;
	Daten_ver�ndert = false;
	// Flag in Stustuszeile setzen:
	SendMessage(hWndStatus, (UINT)SB_SETTEXT, (WPARAM)(INT)2, (LPARAM)L"S");
	return 0;
}	// end of Daten_gespeichert

int Daten_neu(void)
{
	// Flag setzen
	Datei_gespeichert = false;
	Daten_ver�ndert = false;
	// Flag in Stustuszeile setzen:
	SendMessage(hWndStatus, (UINT)SB_SETTEXT, (WPARAM)(INT)2, (LPARAM)L"N");
	return 0;
}	// end of Daten_neu

int About_Aufruf(void)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWndElektronikMain, About_Dialog);
	return 0;
} // end of About_Aufruf

int Hilfe_Aufruf(void)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_HILFEBOX), hWndElektronikMain, Hilfe_Dialog);
	return 0;
} // end of Hilfe_Aufruf

int loese_kubische_Gleichung( double a_x3, double b_x2, double c_x, double d, double loesung[] )
{
	// Die Gleichung bestimmt die reellen L�sungen einer kubischen Gleichung
	double p, q;
	complex <double> Dis, z1, z2, u, v, y1, y2, y3, x1, x2, x3;
	complex <double> f1, f2, wurzel_3;
	int i = 0;

	p = (3 * a_x3*c_x - b_x2*b_x2) / 9.0 / a_x3 / a_x3;
	q = 2 * b_x2*b_x2*b_x2 / 27.0 / a_x3 / a_x3 / a_x3 - b_x2*c_x / 3.0 / a_x3 / a_x3 + d / a_x3;
	q = q / 2;
	Dis = q*q + p*p*p;
	z1 = -q + sqrt(Dis);
	z2 = -q - sqrt(Dis);
	if (real(z1) < 0.0)
		u = -pow(-z1, 1.0 / 3.0);
	else
		u = pow(z1, 1.0 / 3.0);
	if (real(z2) < 0.0)
		v = -pow(-z2, 1.0 / 3.0);
	else
		v = pow(z2, 1.0 / 3.0);
	wurzel_3 = -3 / 4.0;
	f1 = -1 / 2.0 + sqrt(wurzel_3);
	f2 = -1 / 2.0 - sqrt(wurzel_3);

	y1 = u + v;
	y2 = f1*u + f2*v;
	y3 = f2*u + f1*v;

	x1 = y1 - b_x2 / 3.0 / a_x3;
	x2 = y2 - b_x2 / 3.0 / a_x3;
	x3 = y3 - b_x2 / 3.0 / a_x3;

	// L�sungen sortieren bzw. nur reelle L�sungen zur�ckgeben
	if (imag(x1) == 0.0)
	{
		loesung[0] = real(x1);
		i++;
	}
	if (imag(x2) == 0.0)
	{
		loesung[i] = real(x2);
		i++;
	}
	if (imag(x3) == 0.0)
	{
		loesung[i] = real(x3);
		i++;
	}
	return i;
}

int Berechne_Schnittpunkte_Kreise( double *loes_x1, double *loes_y1, double *loes_x2, double *loes_y2, double x1, double y1, double r1, double x2, double y2, double r2)
/***********************************************************************************************************\
| Berechnung von zwei Schnittpunkten zweier Kreise. Die Kreise haben die Mittelpunkte x1, y1 und x2, y2		|
| und die Radien r1 und r2																					|
| Der R�ckgabewert der Funktion ist 0, wenn die Funktion den Schnittpunkt berechnen konnte. In diesem Fall  |
| werden die L�sungen in den beiden Variablen loes1 und loes2 gespeichert.									|
| Funktion i.O.																								|
\***********************************************************************************************************/
{
	// Hilfsvariablen
	double a, b, c, zaehler, nenner, wurzel, ergebnis_y1, ergebnis_y2;
	int rueckgabe = 0;

	zaehler = r1*r1-x1*x1-y1*y1-r2*r2+x2*x2+y2*y2;
	nenner = 2.0*(x2-x1);
	if ( (nenner==0.0)&&(zaehler!=0.0) )
	{
		rueckgabe = 1;
		return rueckgabe;
	}
	if ( (nenner==0.0)&&(zaehler==0.0) )
		a=0.0; // oder auch Fehlermeldung?
	else
		a=zaehler/nenner;
	c = a-x1;
	zaehler = y2-y1;
	nenner = x2-x1;
	if ( (nenner==0.0)&&(zaehler!=0.0) )
	{
		rueckgabe = 2;
		return rueckgabe;
	}
	if ( (nenner==0.0)&&(zaehler==0.0) )
		b = 0.0; // Fehlermeldung?
	else 
		b = zaehler / nenner;
	wurzel = (y1+b*c)*(y1+b*c)/(1+b*b)/(1+b*b)-(c*c+y1*y1-r1*r1)/(1+b*b);
	if (wurzel<0.0)
	{
		rueckgabe = 3;
		return rueckgabe;
	}
	wurzel = sqrt( wurzel );
	ergebnis_y1=(y1+b*c)/(1.0+b*b)+wurzel;
	ergebnis_y2=(y1+b*c)/(1.0+b*b)-wurzel;
	*loes_y1=ergebnis_y1;
	*loes_y2=ergebnis_y2;
	*loes_x1=a-ergebnis_y1*b;
	*loes_x2=a-ergebnis_y2*b;

	return rueckgabe;
}

double Berechne_Kreiswinkel_aus_Schnittpunkt( double Mittelpunkt_x, double Mittelpunkt_y, double Schnittpunkt_x, double Schnittpunkt_y)
/***********************************************************************************************************\
| Berechnung des Winkels von einem Schnittpunkt zum Mittelpunkt eines Kreise.								|
| und die Radien r1 und r2																					|
| Der R�ckgabewert der Funktion ist der Winkel in Grad, wenn die Funktion den Schnittpunkt berechnen		|
| konnte.																									|
\***********************************************************************************************************/
{
	// Hilfsvariablen
	double rueckgabe;
	rueckgabe = 180.0/pi*atan2( Mittelpunkt_y-Schnittpunkt_y, Mittelpunkt_x-Schnittpunkt_x);
	return rueckgabe;
}

bool Berechne_Kreis_aus_drei_Punkten( double x1, double y1, double x2, double y2, double x3, double y3, double *Mitte_x, double *Mitte_y, double *Radius )
/***********************************************************************************************************\
| Berechnung des Mittelpunkt und Radius eines Kreise aus drei Punkten x1, y1, x2, y2 und x3, y3				|
|																											|
| Der R�ckgabewert der Funktion ist true, wenn die Funktion den Kreis berechnen	konnte.						|
| Der R�ckgabewert ist in Mitte_x, Mitte_y und Radius gespeichert. 											|
\***********************************************************************************************************/
{
	double diff_x21, diff_x31, diff_y21, diff_y31, quadrat_1, quadrat_2, quadrat_3;
	double nenner, zaehler;

	diff_x21 = x2-x1;
	diff_x31 = x3-x1;
	diff_y21 = y2-y1;
	diff_y31 = y3-y1;
	quadrat_1 = x1*x1+y1*y1;
	quadrat_2 = x2*x2+y2*y2;
	quadrat_3 = x3*x3+y3*y3;

	nenner = 2.0*( diff_x21*diff_y31-diff_x31*diff_y21 );
	zaehler = (quadrat_1-quadrat_3)*diff_y21-(quadrat_1-quadrat_2)*diff_y31;
	if (nenner!=0.0)
		*Mitte_x=zaehler/nenner;
	else
		return false;
	nenner = 2.0*( diff_y31*diff_x21 - diff_y21*diff_x31 );
	zaehler = (quadrat_1-quadrat_2)*diff_x31 - (quadrat_1-quadrat_3)*diff_x21;
	if (nenner!=0.0)
		*Mitte_y=zaehler/nenner;
	else
		return false;
	
	*Radius = sqrt( (x1-(*Mitte_x))*(x1-(*Mitte_x))+(y1-(*Mitte_y))*(y1-(*Mitte_y)) );

	return true;
}


bool String_anhaengen(int max_len, WCHAR string1[], WCHAR string2[], WCHAR string3[], WCHAR string4[], WCHAR string5[])
/***********************************************************************************************************************\
|																														|
| Die Funktion h�ngt mehrere Widecharacter-Strings an den ersten String an. Dabei wird die maximale Zeichenzahl			|
| ber�cksichtigt.																										|
| Wenn ein Fehler auftritt, wird als R�ckgabewert false zur�ckgegeben.													|
|																														|
\***********************************************************************************************************************/
{
	int i=0, laenge, laenge_string2;
	bool rueckgabe = true;

	laenge = wcslen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if ( string2 != NULL )
	{
		laenge_string2 = wcslen(string2);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string2[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (char)0;
	}
	// ggf. dritten String anh�ngen. Dazu erst neue L�nge bestimmen
	laenge = wcslen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string3 != NULL)
	{
		laenge_string2 = wcslen(string3);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string3[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (WCHAR)0;
	}
	// ggf. vierten String anh�ngen. Dazu erst neue L�nge bestimmen
	laenge = wcslen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string4 != NULL)
	{
		laenge_string2 = wcslen(string4);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string4[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (WCHAR)0;
	}
	// ggf. fuenften String anh�ngen. Dazu erst neue L�nge bestimmen
	laenge = wcslen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string5 != NULL)
	{
		laenge_string2 = wcslen(string5);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string5[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (WCHAR)0;
	}
	return rueckgabe;
} // end of String_anhaengen mit f�nf Strings_WCHAR
bool String_anhaengen(int max_len, char string1[], char string2[], char string3[], char string4[], char string5[])
/***********************************************************************************************************************\
|																														|
| Die Funktion h�ngt mehrere Widecharacter-Strings an den ersten String an. Dabei wird die maximale Zeichenzahl			|
| ber�cksichtigt.																										|
| Wenn ein Fehler auftritt, wird als R�ckgabewert false zur�ckgegeben.													|
|																														|
\***********************************************************************************************************************/
{
	int i=0, laenge, laenge_string2;
	bool rueckgabe = true;

	laenge = strlen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if ( string2 != NULL )
	{
		laenge_string2 = strlen(string2);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string2[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (char)0;
	}
	// ggf. dritten String anh�ngen. Dazu erst neue L�nge bestimmen
	laenge = strlen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string3 != NULL)
	{
		laenge_string2 = strlen(string3);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string3[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (char)0;
	}
	// ggf. vierten String anh�ngen. Dazu erst neue L�nge bestimmen
	laenge = strlen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string4 != NULL)
	{
		laenge_string2 = strlen(string4);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string4[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (char)0;
	}
	// ggf. fuenften String anh�ngen. Dazu erst neue L�nge bestimmen
	laenge = strlen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string5 != NULL)
	{
		laenge_string2 = strlen(string5);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string5[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (char)0;
	}
	return rueckgabe;
} // end of String_anhaengen mit f�nf Strings char

bool String_anhaengen(int max_len, WCHAR string1[], WCHAR string2[], WCHAR string3[], WCHAR string4[])
/***********************************************************************************************************************\
|																														|
| Die Funktion h�ngt mehrere Widecharacter-Strings an den ersten String an. Dabei wird die maximale Zeichenzahl			|
| ber�cksichtigt.																										|
| Wenn ein Fehler auftritt, wird als R�ckgabewert false zur�ckgegeben.													|
|																														|
\***********************************************************************************************************************/
{
	int i=0, laenge, laenge_string2;
	bool rueckgabe = true;

	laenge = wcslen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string2 != NULL)
	{
		laenge_string2 = wcslen(string2);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string2[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (char)0;
	}
	// ggf. dritten String anh�ngen. Dazu erst neue L�nge bestimmen
	laenge = wcslen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string3 != NULL)
	{
		laenge_string2 = wcslen(string3);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string3[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (WCHAR)0;
	}
	// ggf. vierten String anh�ngen. Dazu erst neue L�nge bestimmen
	laenge = wcslen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string4 != NULL)
	{
		laenge_string2 = wcslen(string4);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string4[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (WCHAR)0;
	}
	return rueckgabe;
} // end of String_anhaengen mit vier Strings WCHAR

bool String_anhaengen(int max_len, char string1[], char string2[], char string3[], char string4[])
/***********************************************************************************************************************\
|																														|
| Die Funktion h�ngt mehrere Widecharacter-Strings an den ersten String an. Dabei wird die maximale Zeichenzahl			|
| ber�cksichtigt.																										|
| Wenn ein Fehler auftritt, wird als R�ckgabewert false zur�ckgegeben.													|
|																														|
\***********************************************************************************************************************/
{
	int i=0, laenge, laenge_string2;
	bool rueckgabe = true;

	laenge = strlen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string2 != NULL)
	{
		laenge_string2 = strlen(string2);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string2[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (char)0;
	}
	// ggf. dritten String anh�ngen. Dazu erst neue L�nge bestimmen
	laenge = strlen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string3 != NULL)
	{
		laenge_string2 = strlen(string3);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string3[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (char)0;
	}
	// ggf. vierten String anh�ngen. Dazu erst neue L�nge bestimmen
	laenge = strlen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string4 != NULL)
	{
		laenge_string2 = strlen(string4);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string4[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (char)0;
	}
	return rueckgabe;
} // end of String_anhaengen mit vier Strings char

bool String_anhaengen(int max_len, WCHAR string1[], WCHAR string2[])
/***********************************************************************************************************************\
|																														|
| Die Funktion h�ngt mehrere Widecharacter-Strings an den ersten String an. Dabei wird die maximale Zeichenzahl			|
| ber�cksichtigt.																										|
| Wenn ein Fehler auftritt, wird als R�ckgabewert false zur�ckgegeben.													|
|																														|
\***********************************************************************************************************************/
{
	int i=0, laenge, laenge_string2;
	bool rueckgabe = true;

	laenge = wcslen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string2 != NULL)
	{
		laenge_string2 = wcslen(string2);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string2[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (char)0;
	}
	return rueckgabe;
} // end of String_anhaengen mit zwei Strings WCHAR

bool String_anhaengen(int max_len, char string1[], char string2[])
/***********************************************************************************************************************\
|																														|
| Die Funktion h�ngt mehrere Widecharacter-Strings an den ersten String an. Dabei wird die maximale Zeichenzahl			|
| ber�cksichtigt.																										|
| Wenn ein Fehler auftritt, wird als R�ckgabewert false zur�ckgegeben.													|
|																														|
\***********************************************************************************************************************/
{
	int i=0, laenge, laenge_string2;
	bool rueckgabe = true;

	laenge = strlen(string1);
	// Das Zeichen string1[laenge] sollte eine Null sein.
	if (string2 != NULL)
	{
		laenge_string2 = strlen(string2);
		if (laenge + laenge_string2 <= max_len)
		{
			for (i = 0; i < laenge_string2; i++)
				string1[i + laenge] = string2[i];
		}
		else
			rueckgabe = false;
		// abschliessendes NULL-Zeichen setzen
		string1[i + laenge] = (char)0;
	}
	return rueckgabe;
} // end of String_anhaengen mit zwei Strings char

//int Hex_Editor_Aufruf(HWND hWnd)
//{
//	DialogBox(hInst, MAKEINTRESOURCE(IDD_HEX_EDITION), hWnd, Hex_Editor_Dialog);
//
//	return 0;
//}	// end of Hex_Editor_Aufruf
