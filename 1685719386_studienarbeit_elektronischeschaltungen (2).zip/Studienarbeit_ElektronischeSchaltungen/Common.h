#pragma once
#include "stdafx.h"

using namespace std;

#define MAX_LOADSTRING 100
#define MAX_ZEILEN 505
#define MAX_ANZAHL_ZEICHEN_PRO_ZEILE 255
#define MAX_DATEINAME 1024
#define MAX_GATE_SCHRITTE 16
#define MAX_DRAIN_SCHRITTE 101

// Konstanten f�r die Schaltungsarten
#define BASIS_SCHALTUNG						1
#define EMITTER_SCHALTUNG					2
#define KOLLEKTOR_SCHALTUNG					3
#define SOURCE_SCHALTUNG					4
#define DRAIN_SCHALTUNG						5
#define GATE_SCHALTUNG						6
#define GLEICHRICHTER						7
#define TRANSISTOR_ALS_SCHALTER				8
#define TRANSISTOR_ALS_SCHALTER_U_SCHALT	9
#define DIFFERENZVERSTAERKER				10
#define DIFFERENZVERSTAERKER_STROMQUELLE	11
#define INVERTIERENDER_OP					12
#define NICHTINVERTIERENDER_OP				13
#define SUMMATIONS_OP						14
#define SUMMATIONS_OP_EINGANG_2				15
#define DIFFERENZIERER_OP					16
#define INTEGRIERER_OP						17
#define ZEIGERDIAGRAMM						18
#define OP_BODEPLOT							19
#define REIHENSCHALTUNG						20
#define PARALLELSCHALTUNG					21
#define STERN_DREIECK						22
#define FET_KENNLINIE						23
#define HF_LEITUNG							24
#define SMITH_DIAGRAMM						25
#define HF_LEITUNG_ESB						26
#define DOPPEL_EMITTER						27
#define DOPPEL_EMITTER_TRANS_2				28

// Konstanten f�r Bauteile
#define C_HORIZONTAL						true
#define C_VERTIKAL							false
#define DC_QUELLE_MASSE						true
#define NPN_TRANSISTOR						true
#define PNP_TRANSISTOR						false

// Konstanten zur Festlegung der anzuzeigenden Parameter bei Bipolartransistoren
#define BIPOLAR_EARLYSPANNUNG		1
#define BIPOLAR_U_CE_SAT			8
#define BIPOLAR_I_CB_SPERR			16
#define BIPOLAR_TEMPERATUR			32

// Konstanten f�r Widerst�nde, Kondensatoren, ...
// Bipolartransistorschaltungen
#define R_BASIS_UB				0
#define R_BASIS_GND				1
#define R_KOLLEKTOR_BS_NPN		2	//BS: Basisschaltung
#define R_EMITTER_BS_PNP		2
#define R_EMITTER_BS_NPN		3
#define R_KOLLEKTOR_BS_PNP		3
#define R_EMITTER_KS			2	//KS: Kollektorschaltung
#define R_KOLLEKTOR_ES_NPN		2	//ES: Emitterschaltung
#define R_EMITTER_DC_ES			3
#define R_EMITTER_AC_ES_NPN		4
#define R_EMITTER_AC_ES_PNP		2
#define R_KOLLEKTOR_ES_PNP		4
// Konstanten f�r Doppel-Emitter, falls abweichend
#define R_KOLLEKTOR_DES_NPN		5  //DES: Doppel-Emitterschaltung, zweiter Transistor
#define R_EMITTER_DC_DES		6
#define R_EMITTER_AC_DES_NPN	7
#define R_EMITTER_AC_DES_PNP	5
#define R_KOLLEKTOR_DES_PNP		7

#define C_EIN					0
#define C_AUS					1
#define C_BASIS_BS				2
#define C_EMITTER_ES			2

// Feldeffekttransistorschaltungen
#define R_GATE					0
#define R_DRAIN_SS_N			1
#define R_SOURCE_DC_SS			2	//SS: Sourceschaltung
#define R_SOURCE_AC_SS_N		3
#define R_SOURCE_AC_SS_P		1
#define R_DRAIN_SS_P			3
#define R_SOURCE_DS				2	//DS: Drainschaltung // Bei der Drainschaltung gibt es nur einen Drainwiderstand!
#define R_GATE_U_B				0
#define R_GATE_GND				1
#define R_DRAIN_GS_N			1	//GS: Gateschaltung
#define R_SOURCE_GS_N			2
#define R_SOURCE_GS_P			1
#define R_DRAIN_GS_P			2

//OP-Schaltungen
#define R_OP_EIN				0
#define R_OP_RUECKKOPPEL		1
#define R_OP_RUECK_MASSE		0
#define R_OP_DIFF				0
#define R_OP_INTEGR				0
#define R_OP_EIN_1				0
#define R_OP_EIN_2				1
#define R_OP_SUMME_RUECKKOPPEL	2
#define OP_V_0_AENDERBAR		1
#define OP_V_0_DB_AENDERBAR		2
#define OP_GRENZFREQ_AENDERBAR	4
#define OP_U_B_AENDERBAR		8
#define OP_DELTA_U_AUS			16

// Gleichrichter, OP
#define U_AC_SPANNUNG			1
#define U_AC_FREQUENZ			2

// Transistor als Schalter
#define U_BETRIEB				0
#define U_SCHALT				1
#define U_REFERENZ				2
#define U_EINGANG				3
#define U_EIN_1					4
#define U_EIN_2					5
#define U_WECHSEL				6

// dB- und dBm-Rechner
#define U1_P1_AUS_DB			1
#define U0_P0_AUS_DB			2
#define DB_AUS_U				3
#define DB_AUS_P				4

#define BERECHNE_R_TH_JC		1
#define BERECHNE_R_TH_CK		2
#define BERECHNE_R_TH_KA		3
#define BERECHNE_P_V			4
#define BERECHNE_T_J			5
#define BERECHNE_T_MAX			6

// Halbleiterberechnung
#define MATERIAL_SI				1
#define MATERIAL_GE				2
#define MATERIAL_GAAS			3
#define MATERIAL_INP			4
#define MATERIAL_BENUTZER		5

// Hochfrequenzleitung
#define HF_LEITUNG_LAENGE		1
#define HF_LEITUNG_BETA			1
#define HF_ESB_WIDERSTAND		1
#define HF_ESB_SPULE			2
#define HF_ESB_KONDENSATOR		3

// Darstellung Eingabefenster
#define UEBERLAPPUNG			10

// Globale Variable
extern HWND hWndElektronikMain;
extern HWND hWndStatus;									// Fensterhandle der Statuszeile
extern HINSTANCE hInst;									// Aktuelle Instanz
extern WCHAR szChild[MAX_LOADSTRING];					// Klassenname des Dialogfensters

extern bool Datei_gespeichert, Daten_ver�ndert;
extern char Dateiname[MAX_DATEINAME];
extern char Initialisierungsdatei[MAX_DATEINAME];		// Kompletter Pfad zur ini-Datei

// Schriftart f�r Ausgabe
extern int Zeichenbreite, Zeichenhoehe;

struct Initialisierung
{
	int Version;
	char Code1[10], Code2[10], Code3[10], Code4[10];
};
extern struct Initialisierung init_werte;

struct Halbleiter_pn
{
	double N_A, N_D;
	double Temp;
	double U_Sperr, U_D, U_T;
	double Weite, Weite_N, Weite_P, E_max;
	double Flaeche;
	int material;		//0: Si, 1: Ge, 2: GaAs, 3: InP
	bool U_T_genau, Sperrspannung_anlegen;
	bool neue_Struktur;
	bool berechenbar;
	double C;
	char Materialbezeichner[16];
};
extern struct Halbleiter_pn pn_Uebergang;
// Felder f�r pn-�bergang: E-Feld und Potential:
extern float pn_Potential[200], pn_E_Feld[200], x_Feld[200];

struct Therm_Widerstand
{
	double T_junc, T_max;
	double P_V;
	double Rth_JC, Rth_CK, Rth_KA;
	bool neuer_Widerstand;
};
extern struct Therm_Widerstand R_th;

struct Dioden_Gleichrichter
{
	double U_eff, f, U_amplitude;
	bool Effektivwert;
	bool einweg, positiv_gleichrichter;
	bool Schaltung_berechenbar;
	double U_D, U_diode_sperr, U_Max, U_Drop, U_Ausgang;
	double C, R, Welligkeit, P_V;
	int Festspannung;
	bool positiv_regler;
};
extern struct Dioden_Gleichrichter Gleichrichter;

struct Bipolartransistor
{
	double R[5], C[3];
	// R[0]: Basiswiderstand an U_B, R[1]: Basiswiderstand an GND, R[2]: Kollektorwiderstand, R[3]: Emitterwiderstand, R[4]: additiver Emitterwiderstand bei Emitterschaltung
	// C[0]: Koppelkondensator Eingang, C[1]: Koppelkondensator Ausgang, C[2]: Gegenkopplungskondensator f�r Emitterschaltung
	int R_Max, C_Max;
	double Beta, T, U_AF;
	bool NPN;
	double I_B, I_C, I_E;
	double U_Basis, U_C, U_E, U_B, U_BE;
	double r_BE, r_CE;								// Kleinsignalwiderst�nde (berechnet)
	double r_Ein_AC, r_Aus_AC, V_U_AC, V_U_DC;		// Ein- und Ausgangswiderstand, Verst�rkungswerte (berechnet)
	double U_BE_min, U_BE_max, Delta_U_BE, A_N, I_ES, I_CS, U_CE_Max;		// Daten f�r Kennliniendarstellung
	bool neue_Schaltung;
	bool Naeherung_r_CE, Naeherung_U_T;
	bool Schaltung_berechenbar;
};
extern struct Bipolartransistor Basis_Schaltung, Kollektor_Schaltung, Emitter_Schaltung;

struct Doppel_Bipolartransistor
{
	double R[8], C[4];
	// R[0]: Basiswiderstand an U_B, R[1]: Basiswiderstand an GND, R[2]: Kollektorwiderstand, R[3]: Emitterwiderstand, R[4]: additiver Emitterwiderstand bei Emitterschaltung
	// C[0]: Koppelkondensator Eingang, C[1]: Koppelkondensator Ausgang, C[2]: Gegenkopplungskondensator f�r Emitterschaltung
	int R_Max, C_Max;
	double Beta_T1, Beta_T2, T, U_AF_T1, U_AF_T2;
	bool NPN_T1, NPN_T2;
	double I_B_T1, I_B_T2, I_C_T1, I_C_T2, I_E_T1, I_E_T2;
	double U_Basis_T1, U_Basis_T2, U_C_T1, U_C_T2, U_E_T1, U_E_T2, U_B, U_BE_T1, U_BE_T2;
	double r_BE_T1, r_BE_T2, r_CE_T1, r_CE_T2;								// Kleinsignalwiderst�nde (berechnet)
	double r_Ein_AC, r_Aus_AC, V_U_AC_T1, V_U_AC_T2, V_U_AC_Ges, V_U_DC_T1, V_U_DC_T2, V_U_DC_Ges;		// Ein- und Ausgangswiderstand, Verst�rkungswerte (berechnet)
	bool neue_Schaltung;
	bool Naeherung_r_CE, Naeherung_U_T;
	bool Schaltung_berechenbar;
};
extern struct Doppel_Bipolartransistor Doppel_Emitter_Schaltung;

struct Schalter_Bipolartransistor
{
	double R[3], C;
	// R[0]: Basiswiderstand in Reihe, R[1]: Lastwiderstand, R[2]: Basiswiderstand an Masse (Ableitwiderstand)
	// C: Kondensator parallel zu R[1]
	// Berechnung ohne Kapazit�t C!
	double Beta;
	double m, U_CE_Sat;
	double I_CB_Sperr;	// Sperrstrom in �A
	bool NPN;
	double I_B, I_C, I_E, I_Ableit;
	double U_Basis, U_C, U_E, U_B, U_BE, U_Schalt, U_BE_Sperr;
	bool neue_Schaltung;
	bool Schaltung_berechenbar;
};
extern struct Schalter_Bipolartransistor Bipolartransistor_als_Schalter;

struct Diff_verstaerker
{
	double R[4];
	// R[0]: Kollektorwiderstand, R[1]: Basiswiderstand, R[2]: Emitterwiderstand, R[3]: Gemeinsamer Widerstand im Emitter
	double Beta_T1, Beta_T2;
	double I_B, I_C, I_E, I_Gemeinsam;
	double I_B_T2, I_C_T2, I_E_T2;	// T2: Stromquellentransistor
	double U_Basis, U_C, U_E, U_B, U_BE_T1, U_AF_T1, U_BE_T2;
	double U_Basis_T2, U_C_T2, U_E_T2, U_Ref;
	double V_U_Wechsel, V_U_Gleichtakt, CMRR;
	double r_Ein_AC, r_Ein_DC;
	bool NPN_T1, NPN_T2, V_U_Gleichtakt_ist_Null;
	bool verwende_Stromquelle;
	bool r_CE_hochohmig;
	bool neue_Schaltung;
	bool Schaltung_berechenbar;
};
extern struct Diff_verstaerker Differenzverstaerker;

struct MOS_Transistor
{
	double R[5], C[3];
	int R_Max, C_Max;
	double Weite, Laenge;			// in �m
	double Oxiddicke;				// in nm
	double U_Th, U_AF, U_B;
	double I_SperrGate;				// in pA
	double mue, Technologieparameter;	// W/L*K
	bool Naeherung_r_DS;
	bool n_Kanal;
	bool MOS;
	double I_D;
	double U_G, U_D, U_S;
	double g_m, C_Ox;					
	double r_DS;
	double r_Ein_AC, r_Aus_AC, V_U_AC, V_U_DC;		// Ein- und Ausgangswiderstand, Verst�rkungswerte (berechnet)
	bool neue_Schaltung;
	bool Schaltung_berechenbar;
};
extern struct MOS_Transistor Source_Schaltung, Drain_Schaltung, Gate_Schaltung;

struct Kennlinie_MOS
{
	double Weite, Laenge;			// in �m
	double Oxiddicke;				// in nm
	double U_Th, U_AF, U_B;
	double mue, Technologieparameter;	// W/L*K
	bool n_Kanal;
	bool MOS;
	double I_D;
	double U_G_Min, U_G_Max, U_G_Delta, U_DS_Min, U_DS_Max, U_DS_Delta;
	struct MOS_Transistor *Fet_Schaltung;
	double U_G, U_D, U_S;
	double g_m, C_Ox;					
	bool neue_Schaltung;
	bool Kennlinie_darstellbar;
	int Schritte_Gate, Schritte_U_DS;
};
extern struct Kennlinie_MOS FET_Kennlinie;

struct Koordinatensystem
{
	int Rand_x_min, Rand_x_max, Rand_y_min, Rand_y_max;
	int Grafik_x_min, Grafik_x_max, Grafik_y_min, Grafik_y_max;
	double x_min1, x_max1, y_min1, y_max1;
	double x_min2, x_max2, y_min2, y_max2;
	// int pfeilspitze = 5, skalenstrich = 4, delta_min = 50, delta_max = 30;
	int pfeilspitze, skalenstrich, delta_min, delta_max;
	int anzahl_graphen;
	double abstand_graphen;
};

struct Bodeplot_Grafik
{
	int Rand_x_min, Rand_x_max, Rand_y_min, Rand_y_max;
	int Grafik_x_min, Grafik_x_max, Grafik_y_min, Grafik_y_max;
	int Grafik_y_max_oben, Grafik_y_min_unten;
	double f_min, f_max;
	int f_max_dB, f_min_dB;
	int V_U_max_dB, V_U_min_dB, V_U_delta_dB;
	double y_min2, y_max2;
	double Phase_min, Phase_max, Phase_Teilung;
//	int pfeilspitze = 5, skalenstrich = 4, delta_min = 50, delta_max = 30;
	int pfeilspitze, skalenstrich, delta_min, delta_max;
};

struct dB_Rechner
{
	double U_0, U_1, P_0, P_1, dB_Wert;
};
extern struct dB_Rechner DezibelRechner, dBm_Rechner;

struct Ladungs_Struktur
{
	int Anzahl_Ladungen;
	double Elektrische_Ladung[20];
	double x_pos[20];
	double y_pos[20];
	double Massstab;
	double Masse[20];

	int Anzahl_Sonde;
	double x_pos_Sonde[20];
	double y_pos_Sonde[20];

	double x_Feld_Sonde[20];
	double y_Feld_Sonde[20];
};
extern struct Ladungs_Struktur Ladung;

struct Operationsverstaerker
{
	double R[5];
	int R_Max;
	double C;
	double R_Ein, R_Ein_2, R_Aus;
	double U_B;
	double U_Ein, U_Ein_2, U_Aus;
	double freq;
	double Slewrate, V_0_dB, V_0;
	double Grenzfrequenz[3];
	double Amplitudenreserve, Phasenreserve, Transitfrequenz, Frequenz_Phasenreserve, Frequenz_Instabilitaet, Frequenz_Amplitudenreserve;
	double Betrag_bei_f_Instabil;
	// F�r den Bodeplot (Grafik) wird die Frequenz berechnet, bei der die Verst�rkung -60dB betr�gt.
	double Frequenz_minus_60dB;
	double V_U, V_U_2;
	bool Idealer_OP;
	double U_Abstand; // Abstand zwischen Ausgangsspannung und Versorgungsspannung
	bool neue_Schaltung;
	bool Schaltung_berechenbar;
	bool U_Begrenzung;
	bool OP_Stabil;
};
extern struct Operationsverstaerker Invertierender_OP, Nichtinvertierender_OP, Summations_OP, Differenzierer_OP, Integrierer_OP, OP_Bode;

struct Komplexer_Zeiger
{
	double Frequenz, Kreisfrequenz;
	double R[12], C[12], L[12];
	double P[12], Q[12], S[12], P_Ges, Q_Ges, S_Ges;
	bool verwendet[12];
	bool Schaltung_berechenbar;
	short int modus[12]; // modus: 1: Widerstand, 2: Kapazit�t, 4: Induktivit�t
	complex <double> Z[12], U[12], I[12];
	complex <double> Z1_2, Z3_4, Z5_6_7, Z8, Z9, Z10_11_12, Z_links, Z_rechts, Z_gesamt;
	complex <double> U_Z_gesamt, U_Z_links, U_Z_rechts, I_Z_gesamt, I_Z_links, I_Z_rechts;
	complex <double> I_Z1_2, I_Z3_4, I_Z5_6_7, I_Z8, I_Z9, I_Z10_11_12;
};
extern struct Komplexer_Zeiger Zeigerdiagramm;

struct Zeiger_S
{
	double Frequenz, Kreisfrequenz;
	double R[6], C[6], L[6];
	double R_Ges, L_Ges, C_Ges;
	bool verwendet[6];
	bool R_verwendet, C_verwendet, L_verwendet;
	bool Schaltung_berechenbar;
	short int modus[6]; // modus: 1: Widerstand, 2: Kapazit�t, 4: Induktivit�t
	complex <double> Z[6];
	complex <double> Z_Ges;
};
extern struct Zeiger_S Z_Reihen, Z_Parallel;

struct Zeiger_Stern_Dreieck
{
	double Frequenz, Kreisfrequenz;
	double R_Stern[3], C_Stern[3], L_Stern[3];
	double R_Dreieck[3], C_Dreieck[3], L_Dreieck[3];
	bool Schaltung_berechenbar;
	bool Werte_berechenbar;
	bool Reihenschaltung_Stern[3];
	bool Reihenschaltung_Dreieck[3];
	bool Dreieck_Berechnen;
	bool Transformation_berechnet;
	short int modus_Stern[3], modus_Dreieck[3]; // modus: 1: Widerstand, 2: Kapazit�t, 4: Induktivit�t
	complex <double> Z_Dreieck[3], Z_Stern[3];
};
extern struct Zeiger_Stern_Dreieck Z_Stern_Dreieck;

struct Dialog_Steuerung
{
	bool Eingabe_Kondensator;
	int Auswahl_Kondensator;
	int Anzahl_Kondensator;
	int Auswahl_Schaltung;		// 1: Basis, 2: Emitter, 3: Kollektor, 4: Source, (5: Drain, 6: Gate, ) 7: Gleichrichter, 8: Transistor als Schalter (U_B),
								// 9: Transistor als Schalter (U_Schalt), 10: Differenzverst�rker (U_B), 11: Differenzverst�rker (U_Ref), 12: Differenz-
								// verst�rker (U_C0)
	bool Eingabe_Widerstand;
	int Auswahl_Widerstand;
	int Anzahl_Widerstand;
	bool Eingabe_Spannung;
	int Auswahl_Spannung; // 0: Versorgungsspannung, 1: Schaltspannung, 2: Referenzspannung, 4: 
	bool Eingabe_BipolarTransistor;
	int Parameter_Bipolartransistor; // 0: alle Parameter �nderbar, 1: keine Earlyspannung, 2: nur NPN, 4: nur PNP-Transistor, 8: kein U_CE_Sat, 
									 // 16: kein I_CB_Sperr; 32: keine Temperatur
	
	bool Eingabe_Leitungswiderstand; // F�r HF-Leitung
	int Auswahl_Leitungswiderstand;
	int Anzahl_Leitungswiderstand;

	bool Eingabe_FetTransistor;
	bool Eingabe_Spannungsregler;
	bool Eingabe_Wechselspannung;
	int Auswahl_Parameter_Wechselspg;
	bool Eingabe_Gleichrichter;
	bool Eingabe_R_TH;
	bool Eingabe_Schalt_Transistor;
	bool Eingabe_Differenzverstaerker;
	bool Eingabe_OP;
	int Parameter_OP;
	int Auswahl_Impedanz;
	bool Eingabe_Impedanz;
	unsigned int x_min, x_max;

	bool Dezibel_Rechner;
	bool Auswahl_dB;

	bool Eingabe_Laenge;
	int Auswahl_Laenge;
	bool Eingabe_Beta;
	int Auswahl_Beta;
	bool Eingabe_kompl_Impedanz;
	HWND hDlg_Aufrufer;
	bool Eingabe_Dialog_Positionieren;
};
extern struct Dialog_Steuerung Eingabe_Dialog;

struct Halbleiter_Physik
{
	double Temp;
	int Leitungsband_Minima;
	double m_e_eff, m_h_eff;
	double E_G, E_F;
	double n, p;
	int material;
	double Gitterkonstante;
	double u_n, u_p;
	double eps_r;
	double n_i_berechnet, n_i_Messung;
	double Misch_x, Misch_y;
	double N_A, N_D;
	double B;
	bool verwende_n_i_Messwert;
	bool beruecksichtige_Dotierung_fuer_Beweglichkeit;
	bool benutzerdefiniert_neu; // Wird zur Steuerung des benutzerdefinierten Halbleiters verwendet.
	// Jedes "normale" Materialsystem setzt die Variable auf true. Bei einem Wechsel auf benutzerdefiniert werden
	// dann die Standardwerte eingestellt. Dabei wird diese Variable auf false gesetzt. Danach k�nnen die Parameter 
	// beliebig verstellt werden
};
extern struct Halbleiter_Physik Halbleiter_Material, Halbleiter_Fermi, Halbleiter_spez_R, Halbleiter_Hall;

struct Hochfrequenz_Impedanz
{
	int Anzahl_Impedanzen, Anzahl_Transformation;
	double Impedanz_re[20];
	double Impedanz_im[20];
	double l_durch_lambda[20];
	double Z_Referenz[20];
	double Referenzwiderstand;
	complex <double> Impedanz_Reihe[20];
	complex <double> Impedanz_Parallel[20];
	double frequenz, wellenl�nge, eps_eff;
};
extern struct Hochfrequenz_Impedanz HF_Impedanz, HF_Anpassung;

struct Uebertragungsleitung
{
	double Spannung, U_Max, U_Min;
	double Wellenwiderstand, Abschlusswiderstand;
	double Laenge, Ausbreitungskonstante, eps_r, Frequenz, lambda;
	double Koord_x_min, Koord_y_max, Koord_Pos_x_min, Koord_Pos_x_max, Koord_Pos_y_min, Koord_Pos_y_max;
	complex <double> U_hin, U_zurueck, I_hin, I_zurueck;
	complex <double> Gamma_Ende, Gamma_Anfang, Abschluss_R;
	complex <double> U_Leitung[200];
	float U_Ges[200], Ort[200]; // ortsabh�ngige Spannungen und Str�me
};
extern struct Uebertragungsleitung HF_Leitung;

struct Leitungs_Ersatzschaltbild
{
	double R_strich, C_strich, L_strich;
	double Frequenz, Beta, Alpha, Z, Wellenlaenge, rho;
	double R_innen, R_aussen, eps_r_eff;
	int Material; // 0: Kupfer, 1: Silber, 2: Gold
	bool Berechne_Belaege_aus_Geometrie;
	double R_strich_innen_berechnet, R_strich_aussen_berechnet, C_strich_berechnet, L_strich_berechnet, Eindringtiefe;
};
extern struct Leitungs_Ersatzschaltbild Leitungs_ESB;

// Globale Konstanten f�r die Ausgabe des Smith-Diagramms
extern const int Mittelpunkt_Smith_X;
extern const int Mittelpunkt_Smith_Y;
extern const int Radius_Smith;

//Liste der physikalischen Konstanten
const double h = 6.62606957e-34;  //Ws Plancksches Wirkungsquantum 
const double q_0 = 1.602e-19; //C  Elementarladung
const double eps_0 = 8.854e-12; //F/m elektrische Dielektrizit�tskonstante
const double k_b = 1.3806488e-23;  //J/K Boltzmann-Konstante
const double pi = 3.14159265358979323846;	// pi
const double eps_r_SiO2 = 3.9;
const double m_0 = 9.10938291e-31;	//Elektronenmasse
const double c_0 = 2.99792458e8;
const double u_0 = 4.0*pi*1.0e-7; // H/m magnetische Permittivit�t
