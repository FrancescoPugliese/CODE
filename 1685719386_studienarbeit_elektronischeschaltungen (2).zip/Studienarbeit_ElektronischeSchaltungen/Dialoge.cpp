#include "stdafx.h"

/*******************************************************************************************************************\
|																													|
| Modul Dialoge.cpp																									|
|																													|
| In diesem Modul sind die Meldungshandler f�r die Dialoge enthalten												|
| - Abfrage();																										|
| - About_Dialog();																									|
| - Additions_OP_Dialog();																							|
| - Ausgabe_Werte_Zeigerdiagramm_Dialog();																			|
| - Differenzierer_OP_Dialog();																						|
| - Differenzverstaerker_Bipolar_Dialog();																			|
| - DrainSchaltung_Dialog();																						|
| - Eingabe_FetTransistorwerte_Dialog();																			|
| - Eingabe_Impedanz_Zeigerdiagramm_Dialog();																		|
| - Eingabe_Komplexe_Spannung_Dialog();																				|
| - Eingabe_Operationsverstaerker_Dialog();																			|
| - Eingabe_pn_Dialog();																							|
| - EingabeGleichrichter_Dialog();																					|
| - EingabeFreischaltcode_Dialog();																					|
| - EingabeSpannungsregler_Dialog();																				|
| - EingabeWechselSpannung_Dialog();																				|
| - Elektrisches_Feld_Dialog();																						|
| - Ergebnis_Additions_OP_Dialog();																					|
| - Ergebnis_Differenzierer_OP_Dialog();																			|
| - Ergebnis_Differenzverstaerker_Dialog();																			|
| - Ergebnis_Integrierer_OP_Dialog();																				|
| - Ergebnis_Invertierender_OP_Dialog();																			|
| - Ergebnis_Nichtinvertierender_OP_Dialog();																		|
| - Ergebnis_pn_Dialog();																							|
| - ErgebnisDrainSchaltung_Dialog();																				|
| - ErgebnisGateSchaltung_Dialog();																					|
| - ErgebnisGleichrichterSchaltung_Dialog();																		|
| - ErgebnisSourceSchaltung_Dialog();																				|
| - ESB_DrainSchaltung_Dialog();																					|
| - ESB_SourceSchaltung_Dialog();																					|
| - FehlerMeldung();																								|
| - GateSchaltung_Dialog();																							|
| - GleichrichterSchaltung_Dialog();																				|
| - Hilfe_Dialog();																									|
| - Integrierer_OP_Dialog();																						|
| - Invertierender_OP_Dialog();																						|
| - Kurzhilfe_Menu();																								|
| - Meldung();																										|
| - Nichtinvertierender_OP_Dialog();																				|
| - StatusMeldung_5();																								|
| - StatusMeldung_4();																								|
| - Stern_Dreieckschaltung_Dialog();																				|
| - SourceSchaltung_Dialog();																						|
| - ThermischerWiderstand_Dialog;																					|
| - Warnung();																										|
| - Zeichne_Zeigerdiagramm_Dialog();																				|
| - Zeichne_OP_Bodeplot_Dialog();																					|
| - Zeigerdiagramm_Dialog();																						|
|  																													|
\*******************************************************************************************************************/

int Kurzhilfe_Menu(WORD Param, HWND hWndStatuszeile)
/*	In dieser Funktion wird eine kurze Hilfszeile in der Statuszeile angezeigt.
	�bergabeparameter ist die gew�hlte Menu-ID (Param) und das Fensterhandle
	auf die Statuszeile.
	R�ckgabewert: 0. */
{
	char Hilfstext[80];

	Hilfstext[0] = 0;

	switch (Param)
	{
	case IDM_NEU:
		strcpy_s( Hilfstext, 79, KT_Hilfe_Datei_Neu);
		break;
	case IDM_OEFFNEN:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Datei_Oeffnen);
		break;
	case IDM_SPEICHERN:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Datei_Speichern);
		break;
	case  IDM_SPEICHERN_UNTER:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Datei_Speicher_unter);
		break;
	case IDM_EXIT:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Datei_Beenden);
		break;
	case IDM_PN_BERECHNEN:
		strcpy_s(Hilfstext, 79, KT_Hilfe_pn_Berechnen);
		break;
	case IDM_GLEICH:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Gleichrichter_Schaltung);
		break;
	case IDM_WAERME:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Gleichrichter_thermischer_Widerstand);
		break;
	case IDM_B_BASIS:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Bipolar_Basis);
		break;
	case IDM_B_EMITTER:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Bipolar_Emitter);
		break;
	case IDM_B_KOLLEKTOR:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Bipolar_Kollektor);
		break;
	case IDM_B_SCHALT:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Trans_Schalter);
		break;
	case IDM_T_DIFFERENZ:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Trans_Differenz);
		break;
	case IDM_T_AUSGANG:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Trans_Ausgangsstufe);
		break;
	case IDM_T_KASKODE:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Trans_Kaskode);
		break;
	case IDM_T_SPIEGEL:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Trans_Stromspiegel);
		break;
	case IDM_OP_INV:
		strcpy_s(Hilfstext, 79, KT_Hilfe_OP_INV);
		break;
	case IDM_OP_NONINV:
		strcpy_s(Hilfstext, 79, KT_Hilfe_OP_NONINV);
		break;
	case IDM_OP_INTEGRATOR:
		strcpy_s(Hilfstext, 79, KT_Hilfe_OP_INTEGRATOR);
		break;
	case IDM_OP_SUMME:
		strcpy_s(Hilfstext, 79, KT_Hilfe_OP_SUMMATION);
		break;
	case IDM_OP_DIFFERENZIERER:
		strcpy_s(Hilfstext, 79, KT_Hilfe_OP_DIFFERENZIERER);
		break;
	case IDM_OP_R_OUT:
		strcpy_s(Hilfstext, 79, KT_Hilfe_OP_R_AUS);
		break;
	case IDM_BODE:
		strcpy_s(Hilfstext, 79, KT_Hilfe_OP_BODE);
		break;
	case IDM_DB_U_I:		
		strcpy_s(Hilfstext, 79, KT_Hilfe_DB_Spannung);
		break;
	case IDM_DB_P_NF:
		strcpy_s(Hilfstext, 79, KT_Hilfe_DB_Leistung);
		break;	
	case IDM_E_FELD:
		strcpy_s(Hilfstext, 79, KT_Hilfe_E_FELD);
		break;
	case IDM_RECHNER:
		strcpy_s(Hilfstext, 79, KT_Hilfe_RECHNER);
		break;
	case IDM_EDITOR:
		strcpy_s(Hilfstext, 79, KT_Hilfe_EDITOR);
		break;
	case IDM_ABOUT:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Hilfe_Info);
		break;
	case IDM_HILFE:
		strcpy_s(Hilfstext, 79, KT_Hilfe_Hilfe_Hilfe);
		break;
	}
	SendMessage(hWndStatuszeile, (UINT)SB_SETTEXT, (WPARAM)(INT)3, (LPARAM)(LPSTR)Hilfstext);
	return 0;
}	// end of Kurzhilfe_Menu

int StatusMeldung_5(char *Text)
/*	Diese Funktion zeigt eine kurze Meldung in der Statuszeile an. Der �bergabeparameter
	ist ein Zeiger auf den auszugebenden Text.
	R�ckgabewert: 0 */
{
	SendMessage(hWndStatus, (UINT)SB_SETTEXT, (WPARAM)(INT)4, (LPARAM)(LPSTR)Text);
	return 0;
}	// end of StatusMeldung_5

int StatusMeldung_4(char *Text)
/*	Diese Funktion zeigt eine kurze Meldung in der Statuszeile an. Der �bergabeparameter
ist ein Zeiger auf den auszugebenden Text.
R�ckgabewert: 0 */
{
	SendMessage(hWndStatus, (UINT)SB_SETTEXT, (WPARAM)(INT)3, (LPARAM)(LPSTR)Text);
	return 0;
}	// end of StatusMeldung_4

int Meldung(LPSTR Meldung)
/*	Diese Funktion zeigt eine kurze Meldung an. Der �bergabeparameter ist ein Zeiger auf den auszugebenden Text.
	R�ckgabewert: 0 */
{
	MessageBox(hWndElektronikMain, (LPCSTR)Meldung, (LPCSTR)KT_Programm01, MB_ICONINFORMATION | MB_OK);
	return 0;
}	// end of Meldung

int FehlerMeldung(LPSTR Meldung)
/*	Funktion zeigt eine Fehlermeldung an. �bergabeparameter ist ein Zeiger auf den Text.
	R�ckgabewert: 0. */
{

	MessageBox(hWndElektronikMain, (LPCSTR)Meldung, (LPCSTR)KT_Programm01, MB_ICONHAND | MB_OK);
	return 0;
}	// end of FehlerMeldung

int Warnung(LPSTR Meldung)
/*	Funktion zeigt eine Warnung an. �bergabeparameter ist ein Zeiger auf den Text.
	R�ckgabewert: ggf. Fehlermeldung. */
{
	return MessageBox(hWndElektronikMain, (LPCSTR)Meldung, (LPCSTR)KT_Programm01, MB_ICONWARNING | MB_OK);;
}	// end of Warnung

int Abfrage(char *Meldung)
/*	Funktion zeigt eine Abfrage an. �bergabeparameter ist ein Zeiger auf den Text.
	R�ckgabewert ist 0, falls OK ausgew�hlt wurde, ansonsten 1. */
{
	int rueckgabe = 1;

	if (MessageBox(hWndElektronikMain, (LPSTR)Meldung, KT_Programm01, MB_ICONQUESTION | MB_YESNO) == IDYES)
		rueckgabe = 0;

	return rueckgabe;
}	// end of Abfrage

	// Meldungshandler f�r EingabeSpannungsregler
INT_PTR CALLBACK EingabeSpannungsregler_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Ausgabe ge�ndert auf die Funktion "Bestimme_Bezeichner_wissenschaftlich. So wird ein Komma angezeigt
	// M. Alles 15.2.2018
	UNREFERENCED_PARAMETER(lParam);
	char cText[40];
	HICON hIcon;
	static int aktuelle_Spannung = 5;
	static bool polaritaet_positiv = true;

	switch (message)
	{
	case WM_INITDIALOG:
	{
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_SPANNUNGSREGLER), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		switch (Gleichrichter.Festspannung)
		{
		case 5:
		case-5: SendMessage(GetDlgItem(hDlg, ID_7805), BM_SETCHECK, 1, 0); break;
		case 6:
		case-6:	SendMessage(GetDlgItem(hDlg, ID_7806), BM_SETCHECK, 1, 0); break;
		case 8:
		case-8: SendMessage(GetDlgItem(hDlg, ID_7808), BM_SETCHECK, 1, 0); break;
		case 9:
		case-9: SendMessage(GetDlgItem(hDlg, ID_7809), BM_SETCHECK, 1, 0); break;
		case 10:
		case-10: SendMessage(GetDlgItem(hDlg, ID_7810), BM_SETCHECK, 1, 0); break;
		case 12:
		case-12: SendMessage(GetDlgItem(hDlg, ID_7812), BM_SETCHECK, 1, 0); break;
		case 15:
		case-15: SendMessage(GetDlgItem(hDlg, ID_7815), BM_SETCHECK, 1, 0); break;
		case 18:
		case-18: SendMessage(GetDlgItem(hDlg, ID_7818), BM_SETCHECK, 1, 0); break;
		case 24:
		case-24: SendMessage(GetDlgItem(hDlg, ID_7824), BM_SETCHECK, 1, 0); break;
		}
		aktuelle_Spannung = Gleichrichter.Festspannung;
		if (Gleichrichter.positiv_regler)
		{
			SendMessage(GetDlgItem(hDlg, ID_SPG_REG), BM_SETCHECK, 1, 0);
			polaritaet_positiv = true;
		}
		else
		{
			SendMessage(GetDlgItem(hDlg, ID_SPG_REG), BM_SETCHECK, 1, 0);
			polaritaet_positiv = false;
		}
		Bestimme_Bezeichner_Festspannungsregler(cText, Gleichrichter.Festspannung, Gleichrichter.positiv_regler, 39);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Gleichrichter.U_Drop, 39);
		SetDlgItemText(hDlg, ID_U_DROP, (LPCSTR)cText);
	}
	return (INT_PTR)TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_7805:
			aktuelle_Spannung = 5;
			Bestimme_Bezeichner_Festspannungsregler(cText, aktuelle_Spannung, polaritaet_positiv, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Daten_geaendert();
			break;
		case ID_7806:
			aktuelle_Spannung = 6;
			Bestimme_Bezeichner_Festspannungsregler(cText, aktuelle_Spannung, polaritaet_positiv, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Daten_geaendert();
			break;
		case ID_7808:
			aktuelle_Spannung = 8;
			Bestimme_Bezeichner_Festspannungsregler(cText, aktuelle_Spannung, polaritaet_positiv, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Daten_geaendert();
			break;
		case ID_7809:
			aktuelle_Spannung = 9;
			Bestimme_Bezeichner_Festspannungsregler(cText, aktuelle_Spannung, polaritaet_positiv, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Daten_geaendert();
			break;
		case ID_7810:
			aktuelle_Spannung = 10;
			Bestimme_Bezeichner_Festspannungsregler(cText, aktuelle_Spannung, polaritaet_positiv, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Daten_geaendert();
			break;
		case ID_7812:
			aktuelle_Spannung = 12;
			Bestimme_Bezeichner_Festspannungsregler(cText, aktuelle_Spannung, polaritaet_positiv, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Daten_geaendert();
			break;
		case ID_7815:
			aktuelle_Spannung = 15;
			Bestimme_Bezeichner_Festspannungsregler(cText, aktuelle_Spannung, polaritaet_positiv, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Daten_geaendert();
			break;
		case ID_7818:
			aktuelle_Spannung = 18;
			Bestimme_Bezeichner_Festspannungsregler(cText, aktuelle_Spannung, polaritaet_positiv, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Daten_geaendert();
			break;
		case ID_7824:
			aktuelle_Spannung = 24;
			Bestimme_Bezeichner_Festspannungsregler(cText, aktuelle_Spannung, polaritaet_positiv, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Daten_geaendert();
			break;
		case ID_SPG_REG:
			(IsDlgButtonChecked(hDlg, ID_SPG_REG) == BST_CHECKED) ? polaritaet_positiv = true : polaritaet_positiv = false;
			Bestimme_Bezeichner_Festspannungsregler(cText, aktuelle_Spannung, polaritaet_positiv, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Daten_geaendert();
			break;

		case IDOK: // Eingabe �bernehmen
		{
			double wert1;

			// Die Werte speichern und das Dialogfenster schlie�en
			Gleichrichter.Festspannung = aktuelle_Spannung;
			Gleichrichter.positiv_regler = polaritaet_positiv;
			if (!polaritaet_positiv)
				Gleichrichter.Festspannung = -Gleichrichter.Festspannung;

			wert1 = Eingabe_parsen(hDlg, ID_U_DROP);
			if (wert1 <= 0.0)
			{
				Warnung("Spannungswert U_Drop muss gr��er 0V sein!");
				SetDlgItemText(hDlg, ID_U_DROP, (LPCSTR)"2");
			}
			else
			{
				Gleichrichter.U_Drop = wert1;
				Daten_geaendert();
				EndDialog(hDlg, LOWORD(wParam));
			}
			break;
		}
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of EingabeSpannungsregler

// Meldungshandler f�r EingabeWechselSpannung.
INT_PTR CALLBACK EingabeWechselSpannung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Ausgabe ge�ndert auf die Funktion "Bestimme_Bezeichner_wissenschaftlich. So wird ein Komma angezeigt
	// M. Alles 15.2.2018
	UNREFERENCED_PARAMETER(lParam);
	char cText[40];
	HICON hIcon;

	switch (message)
	{
	case WM_SHOWWINDOW:
		if (Eingabe_Dialog.Auswahl_Parameter_Wechselspg == U_AC_SPANNUNG)
			SetFocus(GetDlgItem(hDlg, ID_TXT1)); SendMessage(GetDlgItem(hDlg, ID_TXT1), EM_SETSEL, 0, -1);
		if (Eingabe_Dialog.Auswahl_Parameter_Wechselspg == U_AC_FREQUENZ)
			SetFocus(GetDlgItem(hDlg, ID_TXT2)); SendMessage(GetDlgItem(hDlg, ID_TXT2), EM_SETSEL, 0, -1);
		break;
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_SPANNUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		switch (Eingabe_Dialog.Auswahl_Schaltung)
		{
		case GLEICHRICHTER:
			// Daten der Spannungsquelle eintragen
			Bestimme_Bezeichner_wissenschaftlich(cText, Gleichrichter.U_eff, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Bestimme_Bezeichner_wissenschaftlich(cText, Gleichrichter.f, 39);
			SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
			break;
		case INTEGRIERER_OP:
			// Daten der Spannungsquelle eintragen
			Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.U_Ein, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.freq, 39);
			SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
			break;
		case DIFFERENZIERER_OP:
			// Daten der Spannungsquelle eintragen
			Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.U_Ein, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.freq, 39);
			SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
			break;
		case HF_LEITUNG:
			// Daten der Spannungsquelle der HF_Leitung eintragen
			Bestimme_Bezeichner_wissenschaftlich(cText, HF_Leitung.Spannung, 39);
			SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
			Bestimme_Bezeichner_wissenschaftlich(cText, HF_Leitung.Frequenz, 39);
			SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
			break;
		default: 
			FehlerMeldung((LPSTR)"Unbekannte Schaltungsauswahl f�r die Eingabe der Spannung oder Frequenz.");
		}
		switch (Eingabe_Dialog.Auswahl_Parameter_Wechselspg)
		{
		case U_AC_SPANNUNG: SetFocus(GetDlgItem(hDlg, ID_TXT1)); break;
		case U_AC_FREQUENZ: SetFocus(GetDlgItem(hDlg, ID_TXT2)); break;
		}

		return (INT_PTR)TRUE;
	case WM_PAINT: // Spannungsquelle zeichnen
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz3, hStiftAlt;
		HDC hdc = BeginPaint(hDlg, &ps);

		hStiftSchwarz3 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz3);

		Zeichne_Wechselspannungsquelle(hdc, 220, 70, 60, false, 20);

		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz3);
		EndPaint(hDlg, &ps);
	}
	break;
	case WM_COMMAND:
		switch (wParam)
		{
		case IDOK: // Eingabe pr�fen und �bernehmen
		{
			double wert1, wert2;
			bool eingabe_ok = true;

			wert1 = Eingabe_parsen(hDlg, ID_TXT1);
			wert2 = Eingabe_parsen(hDlg, ID_TXT2);

			// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
			if (wert1 <= 0.0)
			{
				Warnung((LPSTR)"Spannungswert muss gr��er 0 sein!");
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)"5");
				eingabe_ok = false;
			}
			if (wert2 <= 0.0)
			{
				Warnung("Frequenz muss gr��er 0 sein!");
				SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"5");
				eingabe_ok = false;
			}
			if (eingabe_ok)
			{
				switch (Eingabe_Dialog.Auswahl_Schaltung)
				{
				case GLEICHRICHTER:
					Gleichrichter.U_eff = wert1;
					Gleichrichter.f = wert2;
					break;
				case INTEGRIERER_OP:
					Integrierer_OP.U_Ein = wert1;
					Integrierer_OP.freq = wert2;
					break;
				case DIFFERENZIERER_OP:
					Differenzierer_OP.U_Ein = wert1;
					Differenzierer_OP.freq = wert2;
					break;
				case HF_LEITUNG:
					HF_Leitung.Spannung = wert1;
					HF_Leitung.Frequenz = wert2;
					break;
				}
				Daten_geaendert();
				EndDialog(hDlg, LOWORD(wParam));
			}
		}
		break;
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of EingabeWechselSpannung.

// Meldungshandler f�r EingabeGleichrichter
INT_PTR CALLBACK EingabeGleichrichter_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Ausgabe ge�ndert auf die Funktion "Bestimme_Bezeichner_wissenschaftlich. So wird ein Komma angezeigt
	// M. Alles 15.2.2018
	UNREFERENCED_PARAMETER(lParam);
	char cText[40];
	HICON hIcon;
	static BOOL EinwegGleichrichter, PositivGleichrichter;

	switch (message)
	{
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_EINGABE_GLEICHRICHTER), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Daten des Gleichrichters eintragen
		if (Gleichrichter.positiv_gleichrichter)
		{
			SendMessage(GetDlgItem(hDlg, ID_POSITIV), BM_SETCHECK, 1, 0);
			PositivGleichrichter = true;
		}
		else
		{
			SendMessage(GetDlgItem(hDlg, ID_NEGATIV), BM_SETCHECK, 1, 0);
			PositivGleichrichter = false;
		}
		if (Gleichrichter.einweg)
		{
			SendMessage(GetDlgItem(hDlg, ID_EINWEG), BM_SETCHECK, 1, 0);
			EinwegGleichrichter = true;
		}
		else
		{
			SendMessage(GetDlgItem(hDlg, ID_VOLLWELLEN), BM_SETCHECK, 1, 0);
			EinwegGleichrichter = false;
		}
		Bestimme_Bezeichner_wissenschaftlich(cText, Gleichrichter.U_D, 39);
		SetDlgItemText(hDlg, ID_U_BE, (LPCSTR)cText);
		return (INT_PTR)TRUE;
	case WM_COMMAND:
		switch (wParam)
		{
		case ID_POSITIV: PositivGleichrichter = true; Daten_geaendert(); break;
		case ID_NEGATIV: PositivGleichrichter = false; Daten_geaendert(); break;
		case ID_EINWEG: EinwegGleichrichter = true; Daten_geaendert(); break;
		case ID_VOLLWELLEN: EinwegGleichrichter = false; Daten_geaendert(); break;
		case IDOK: // Eingabe pr�fen und �bernehmen
		{
			double wert1;

			wert1 = Eingabe_parsen(hDlg, ID_U_BE);
			if (wert1 <= 0.0)
			{
				Warnung("Spannungswert f�r Diodenspannung muss gr��er 0 sein!");
				SetDlgItemText(hDlg, ID_U_D, (LPCSTR)"600m");
			}
			else
			{
				Gleichrichter.U_D = wert1;
				// Hier gibt es immer eine Warnung beim Compilieren, also umformuliert in if-Anweisung.
				// Gleichrichter.einweg = (bool)EinwegGleichrichter;
				// Gleichrichter.positiv_gleichrichter = (bool)PositivGleichrichter;
				if (EinwegGleichrichter)
					Gleichrichter.einweg = true;
				else
					Gleichrichter.einweg = false;
				if (PositivGleichrichter)
					Gleichrichter.positiv_gleichrichter = true;
				else
					Gleichrichter.positiv_gleichrichter = false;

				Daten_geaendert();
				EndDialog(hDlg, LOWORD(wParam));
			}
		}
		break;
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of EingabeGleichrichter

// Meldungshandler f�r Eingabe Daten Operationsverst�rker
INT_PTR CALLBACK Eingabe_Operationsverstaerker_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Ausgabe ge�ndert auf die Funktion "Bestimme_Bezeichner_wissenschaftlich. So wird ein Komma angezeigt
	// M. Alles 15.2.2018
	UNREFERENCED_PARAMETER(lParam);
	static bool NPN;
	HICON hIcon;
	char cText[40];

	switch (message)
	{
	case WM_SHOWWINDOW:
		// Fokus auf das erste Feld und die Eingabe komplett markieren
		SetFocus(GetDlgItem(hDlg, ID_TXT1)); 
		SendMessage(GetDlgItem(hDlg, ID_TXT1), EM_SETSEL, 0, -1);
		break;
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OPSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Alle Werte ersteinmal auf 0 setzen:
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)"0");
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"0");
		SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)"0");
		SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)"0");
		SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)"0");
		SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)"0");
		SetDlgItemText(hDlg, ID_TXT7, (LPCSTR)"0");
		// Nicht darzustellende Werte ausgrauen
		if (!(Eingabe_Dialog.Parameter_OP & OP_V_0_AENDERBAR))	// V_0 nicht �nderbar
			EnableWindow(GetDlgItem(hDlg, ID_TXT1), FALSE);
		if (!(Eingabe_Dialog.Parameter_OP & OP_V_0_DB_AENDERBAR))	// V_0 (linear) nicht �nderbar
			EnableWindow(GetDlgItem(hDlg, ID_TXT2), FALSE);
		if (!(Eingabe_Dialog.Parameter_OP & OP_GRENZFREQ_AENDERBAR))	// Grenzfrequenz nicht �nderbar
		{
			EnableWindow(GetDlgItem(hDlg, ID_TXT5), FALSE);
			EnableWindow(GetDlgItem(hDlg, ID_TXT6), FALSE);
			EnableWindow(GetDlgItem(hDlg, ID_TXT7), FALSE);
		}
		if (!(Eingabe_Dialog.Parameter_OP & OP_U_B_AENDERBAR))	// U_B nicht �nderbar
			EnableWindow(GetDlgItem(hDlg, ID_TXT3), FALSE);
		if (!(Eingabe_Dialog.Parameter_OP & OP_DELTA_U_AUS))	// Spannungsdifferenz zw. U_Aus und U_B
			EnableWindow(GetDlgItem(hDlg, ID_TXT4), FALSE);
		// Daten des OPs eintragen
		switch (Eingabe_Dialog.Auswahl_Schaltung)
		{
			case INVERTIERENDER_OP:	// Invertierender OP
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Invertierender_OP.V_0, 39);
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Invertierender_OP.V_0_dB, 39);
				SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Invertierender_OP.U_B, 39);
				SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Invertierender_OP.U_Abstand, 39);
				SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Invertierender_OP.Grenzfrequenz[0], 39);
				SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Invertierender_OP.Grenzfrequenz[1], 39);
				SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Invertierender_OP.Grenzfrequenz[2], 39);
				SetDlgItemText(hDlg, ID_TXT7, (LPCSTR)cText);
				break;
			}
			case NICHTINVERTIERENDER_OP:	// Nichtinvertierender OP
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Nichtinvertierender_OP.V_0, 39);
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Nichtinvertierender_OP.V_0_dB, 39);
				SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Nichtinvertierender_OP.U_B, 39);
				SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Nichtinvertierender_OP.U_Abstand, 39);
				SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Nichtinvertierender_OP.Grenzfrequenz[0], 39);
				SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Nichtinvertierender_OP.Grenzfrequenz[1], 39);
				SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Nichtinvertierender_OP.Grenzfrequenz[2], 39);
				SetDlgItemText(hDlg, ID_TXT7, (LPCSTR)cText);
				break;
			}
			case DIFFERENZIERER_OP:	// Differenzierender OP
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.V_0, 39);
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.V_0_dB, 39);
				SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.U_B, 39);
				SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.U_Abstand, 39);
				SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.Grenzfrequenz[0], 39);
				SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.Grenzfrequenz[1], 39);
				SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.Grenzfrequenz[2], 39);
				SetDlgItemText(hDlg, ID_TXT7, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.Grenzfrequenz[3], 39);
				break;
			}
			case INTEGRIERER_OP:	// Integrierender OP
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.V_0, 39);
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.V_0_dB, 39);
				SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.U_B, 39);
				SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.U_Abstand, 39);
				SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.Grenzfrequenz[0], 39);
				SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.Grenzfrequenz[1], 39);
				SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.Grenzfrequenz[2], 39);
				SetDlgItemText(hDlg, ID_TXT7, (LPCSTR)cText);
				break;
			}
			case SUMMATIONS_OP:	// summierender OP
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.V_0, 39);
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.V_0_dB, 39);
				SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.U_B, 39);
				SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.U_Abstand, 39);
				SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.Grenzfrequenz[0], 39);
				SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.Grenzfrequenz[1], 39);
				SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.Grenzfrequenz[2], 39);
				SetDlgItemText(hDlg, ID_TXT7, (LPCSTR)cText);
				break;
			}
			case OP_BODEPLOT:	// summierender OP
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, OP_Bode.V_0, 39);
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, OP_Bode.V_0_dB, 39);
				SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, OP_Bode.Grenzfrequenz[0], 39);
				SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, OP_Bode.Grenzfrequenz[1], 39);
				SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, OP_Bode.Grenzfrequenz[2], 39);
				SetDlgItemText(hDlg, ID_TXT7, (LPCSTR)cText);
				break;
			}
		}
		return (INT_PTR)TRUE;
	case WM_PAINT: // OP zeichnen
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz3, hStiftAlt;
		HDC hdc = BeginPaint(hDlg, &ps);

		Rechteck_BH_Flaeche(hdc, 220, 300, 300, 400, (HBRUSH)COLOR_WINDOW);

		hStiftSchwarz3 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz3);

		// OP Position: x: 200-300 y: 350-450
		Zeichne_OP_mit_Anschluessen(hdc, 200, 340, 70, 70, 15, 15, true);

		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz3);

		EndPaint(hDlg, &ps);
	}
	break;
	case WM_COMMAND:
		switch (wParam)
		{
		case IDOK: // Eingabe pr�fen und �bernehmen
		{
			double wert1=0.0, wert2=0.0, wert3=0.0, wert4=0.0, wert5=0.0, wert6=0.0, wert7=0.0;
			bool eingabe_ok = true;

			wert1 = Eingabe_parsen(hDlg, ID_TXT1);
			// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
			if ( (wert1 <= 0.0)&&(Eingabe_Dialog.Parameter_OP& OP_V_0_AENDERBAR) )
			{
				Warnung((LPSTR)"Wert f�r Verst�rkung muss gr��er 0 sein!");
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)"100k");
				eingabe_ok = false;
			}
			wert2 = Eingabe_parsen(hDlg, ID_TXT2);
			// Die Werte kontrollieren: negative Werte sind unsinnig...
			if ((wert2 < 0.0) && (Eingabe_Dialog.Parameter_OP&OP_V_0_DB_AENDERBAR) )
			{
				Warnung((LPSTR)"Wert f�r Verst�rkung muss gr��er oder gleich 0dB sein!");
				SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"100");
				eingabe_ok = false;
			}
			// Falls V_0 eingegeben wurde, wird hier die Verst�rkung in dB bestimmt.
			if (eingabe_ok && (Eingabe_Dialog.Parameter_OP&OP_V_0_AENDERBAR))
				wert2 = 20.0*log10(wert1);
			// Falls V_0_DB eingegeben wurde, wird hier die Verst�rkung linear bestimmt.
			if (eingabe_ok && (Eingabe_Dialog.Parameter_OP&OP_V_0_DB_AENDERBAR))
				wert1 = pow(10.0, wert2 / 20.0);
			wert3 = Eingabe_parsen(hDlg, ID_TXT3);
			if ((wert3 <= 0.0)&&(Eingabe_Dialog.Parameter_OP&OP_U_B_AENDERBAR)) // Versorgungsspannung auswerten
			{
				Warnung((LPSTR)"Wert f�r (positive) Versorgungsspannung muss gr��er 0V sein!");
				SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)"15");
				eingabe_ok = false;
			}
			wert4 = Eingabe_parsen(hDlg, ID_TXT4);
			if ((wert4 < 0.0) && (Eingabe_Dialog.Parameter_OP&OP_DELTA_U_AUS)) // Spannungsdifferenz zw. U_Aus und U_B auswerten
			{
				Warnung((LPSTR)"Wert f�r Spannungsabstand zw. U_B und U_Aus muss gr��er oder gleich 0V sein!");
				SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)"0");
				eingabe_ok = false;
			}
			if (Eingabe_Dialog.Parameter_OP&OP_GRENZFREQ_AENDERBAR)
			{
				wert5 = Eingabe_parsen(hDlg, ID_TXT5);
				if (wert5 < 0.0) // Grenzfreq. 1 auswerten
				{
					Warnung((LPSTR)"Wert f�r Grenzfreq. 1 muss gr��er 0Hz sein!");
					SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)"1k");
					eingabe_ok = false;
				}
				wert6 = Eingabe_parsen(hDlg, ID_TXT6);
				if ( (wert6 < 0.0)||(wert6<wert5) ) // Grenzfreq. 2 auswerten
				{
					Warnung((LPSTR)"Wert f�r Grenzfreq. 2 muss gr��er 0Hz und gr��er oder gleich Grenzfreq. 1 sein!");
					SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)"1k");
					eingabe_ok = false;
				}
				wert7 = Eingabe_parsen(hDlg, ID_TXT7);
				if ((wert7 < 0.0) || (wert7<wert6)) // Grenzfreq. 3 auswerten
				{
					Warnung((LPSTR)"Wert f�r Grenzfreq. 3 muss gr��er 0Hz und gr��er oder gleich Grenzfreq. 2 sein!");
					SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)"1k");
					eingabe_ok = false;
				}
			}
			if (eingabe_ok)
			{
				switch (Eingabe_Dialog.Auswahl_Schaltung)
				{
					case INVERTIERENDER_OP: // Die Werte speichern und das Dialogfenster schlie�en
					{
						Invertierender_OP.V_0=wert1;
						Invertierender_OP.V_0_dB = wert2;
						Invertierender_OP.U_B = wert3;
						Invertierender_OP.U_Abstand = wert4;
						if (Eingabe_Dialog.Parameter_OP&OP_GRENZFREQ_AENDERBAR)
						{
							Invertierender_OP.Grenzfrequenz[0] = wert5;
							Invertierender_OP.Grenzfrequenz[1] = wert6;
							Invertierender_OP.Grenzfrequenz[2] = wert7;
						}
						break;
					}
					case NICHTINVERTIERENDER_OP: // Die Werte speichern und das Dialogfenster schlie�en
					{
						Nichtinvertierender_OP.V_0 = wert1;
						Nichtinvertierender_OP.V_0_dB = wert2;
						Nichtinvertierender_OP.U_B = wert3;
						Nichtinvertierender_OP.U_Abstand = wert4;
						if (Eingabe_Dialog.Parameter_OP&OP_GRENZFREQ_AENDERBAR)
						{
							Nichtinvertierender_OP.Grenzfrequenz[0] = wert5;
							Nichtinvertierender_OP.Grenzfrequenz[1] = wert6;
							Nichtinvertierender_OP.Grenzfrequenz[2] = wert7;
						}
						break;
					}
					case DIFFERENZIERER_OP: // Die Werte speichern und das Dialogfenster schlie�en
					{
						Differenzierer_OP.V_0 = wert1;
						Differenzierer_OP.V_0_dB = wert2;
						Differenzierer_OP.U_B = wert3;
						Differenzierer_OP.U_Abstand = wert4;
						if (Eingabe_Dialog.Parameter_OP&OP_GRENZFREQ_AENDERBAR)
						{
							Differenzierer_OP.Grenzfrequenz[0] = wert5;
							Differenzierer_OP.Grenzfrequenz[1] = wert6;
							Differenzierer_OP.Grenzfrequenz[2] = wert7;
						}
						break;
					}
					case INTEGRIERER_OP: // Die Werte speichern und das Dialogfenster schlie�en
					{
						Integrierer_OP.V_0 = wert1;
						Integrierer_OP.V_0_dB = wert2;
						Integrierer_OP.U_B = wert3;
						Integrierer_OP.U_Abstand = wert4;
						if (Eingabe_Dialog.Parameter_OP&OP_GRENZFREQ_AENDERBAR)
						{
							Integrierer_OP.Grenzfrequenz[0] = wert5;
							Integrierer_OP.Grenzfrequenz[1] = wert6;
							Integrierer_OP.Grenzfrequenz[2] = wert7;
						}
						break;
					}
					case SUMMATIONS_OP: // Die Werte speichern und das Dialogfenster schlie�en
					{
						Summations_OP.V_0 = wert1;
						Summations_OP.V_0_dB = wert2;
						Summations_OP.U_B = wert3;
						Summations_OP.U_Abstand = wert4;
						if (Eingabe_Dialog.Parameter_OP&OP_GRENZFREQ_AENDERBAR)
						{
							Summations_OP.Grenzfrequenz[0] = wert5;
							Summations_OP.Grenzfrequenz[1] = wert6;
							Summations_OP.Grenzfrequenz[2] = wert7;
						}
						break;
					}
					case OP_BODEPLOT: // Die Werte speichern und das Dialogfenster schlie�en
					{
						OP_Bode.V_0_dB = wert2;
						OP_Bode.Grenzfrequenz[0] = wert5;
						OP_Bode.Grenzfrequenz[1] = wert6;
						OP_Bode.Grenzfrequenz[2] = wert7;
						break;
					}
				}
				Daten_geaendert();
				EndDialog(hDlg, LOWORD(wParam));
			}
			break;
		}
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		case ID_NPN:
			NPN = true;
			CheckRadioButton(hDlg, ID_NPN, ID_PNP, LOWORD(wParam));
			InvalidateRect(hDlg, NULL, true);	// Erforderlich, um den Transistor neu zu zeichnen
			break;
		case ID_PNP:
			NPN = false;
			InvalidateRect(hDlg, NULL, true);	// Erforderlich, um den Transistor neu zu zeichnen
			CheckRadioButton(hDlg, ID_NPN, ID_PNP, LOWORD(wParam));
			break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of Eingabe_Operationsverst�rker

// Meldungshandler f�r GleichrichterSchaltung.
INT_PTR CALLBACK GleichrichterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	bool neuzeichnen = false;
	HICON hIcon;

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Kapazitaetsbezeichner(cText, Gleichrichter.C, 99);
		SetDlgItemText(hDlg, ID_C1, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Gleichrichter.R, 99);
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Gleichrichter.U_eff, 99);
		SetDlgItemText(hDlg, ID_UB, (LPCSTR)cText);
		Bestimme_Frequenzbezeichner(cText, Gleichrichter.f, 99);
		SetDlgItemText(hDlg, ID_FREQ, (LPSTR)cText);
		Bestimme_Bezeichner_Festspannungsregler(cText, Gleichrichter.Festspannung, Gleichrichter.positiv_regler, 99);
		SetDlgItemText(hDlg, ID_SPG_REG, (LPCSTR)cText);

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_GLEICHRICHTER), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz2, hStiftAlt;
		HBRUSH hPinselSchwarz, hPinselAlt;
		HFONT FontNeu, FontAlt;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Gleichrichterschaltung mit Widerstand, Kondensator

		// Kn�pfe und Texte verschieben
		// Widerstand und Bezeichner R verschieben
		// Button auf 920, 180, Label auf 880, 160
		MoveWindow(GetDlgItem(hDlg, ID_R1), 970, 130, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_TXT_R1), 970, 180, 20, 13, true);
		// Kondensator und Bezeichner C1 verschieben, Button auf 510, 240, Text auf 510, 220
		MoveWindow(GetDlgItem(hDlg, ID_C1), 560, 170, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_TXT_C1), 600, 220, 20, 13, true);
		// Festspannungsregler: Knopf verschieben:
		MoveWindow(GetDlgItem(hDlg, ID_SPG_REG), 742, 82, 87, 57, true);
		// Spannungsquelle und Bezeichner f�r Frequenz verschieben, Button auf 10, 180, Text auf 10, 230
		MoveWindow(GetDlgItem(hDlg, ID_UB), 20, 180, 40, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_FREQ), 20, 230, 60, 40, true);
		// Button f�r Gleichrichter
		MoveWindow(GetDlgItem(hDlg, ID_GLEICHRICHT), 230, 200, 80, 40, true);

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
		hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
		hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);
		// Zeichnen der Verbindungspunkte vorab
		// Verbindungspunkt Kondensator x: 500, y: 100
		Ellipse_BH(hdc, 545, 95, 10, 10);
		// Beschriftung erg�nzen
		// am besten in Arial
		FontNeu = CreateFont(24, // nHeight
			0,	// nWidth
			0,	// nEscapement
			0,	// nOrientation
			FW_DONTCARE, //fnWeight
			TRUE,	//fdwItalic
			FALSE,	//fdwUnderline
			FALSE,	//fdwStrikeOut
			DEFAULT_CHARSET,	//fdwCharSet
			OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
			CLIP_DEFAULT_PRECIS, //fdwClipPrecision
			CLEARTYPE_QUALITY,	//fdwQuality
			VARIABLE_PITCH,		//fdwPitchAndFamily
			(LPCSTR)("Arial"));	//lpszFace
		FontAlt = (HFONT)SelectObject(hdc, FontNeu);
		Zeichne_Text_xy(hdc, "U", 665, 140);
		Zeichne_Text_xy(hdc, "U", 885, 140);
		Zeichne_Text_xy(hdc, "U", 80, 180);
		DeleteObject(FontNeu);
		FontNeu = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, (LPCSTR)"Arial");
		FontAlt = (HFONT)SelectObject(hdc, FontNeu);
		Zeichne_Text_xy(hdc, "1", 680, 150);
		Zeichne_Text_xy(hdc, "2", 900, 150);
		Zeichne_Text_xy(hdc, "eff", 92, 190);
		DeleteObject(FontNeu);

		if (!Gleichrichter.einweg)
		{
			// F�r Br�ckengleichrichter: vier Verbindungspunkte
			Ellipse_BH(hdc, 245, 95, 10, 10);
			Ellipse_BH(hdc, 335, 5, 10, 10);
			Ellipse_BH(hdc, 335, 185, 10, 10);
			Ellipse_BH(hdc, 425, 95, 10, 10);
		}
		// Wieder auf wei�en Hintergrund umschalten
		SelectObject(hdc, hPinselAlt);		
		// Verbindung von Spannungsquelle zum Gleichrichter
		DP_Linie(hdc, 170, 300, 170, 100, 250, 100);
		// Verbindung von Gleichrichter bis Festspannungsregler (oben)
		ZP_Linie(hdc, 450, 100, 740, 100);
		// Linie unter Spannungsregler zur Masse
		ZP_Linie(hdc, 785, 140, 785, 220);
		// Linie vom Ausgang des Spannungsreglers �ber Widerstand zur Masse
		DP_Linie(hdc, 830, 100, 950, 100, 950, 220);
		// Masse unter Spannungsregler und Widerstand
		ZP_Linie(hdc, 765, 220, 805, 220);
		ZP_Linie(hdc, 930, 220, 970, 220);
		// Masse unter Messpunkte
		ZP_Linie(hdc, 870, 200, 870, 220);
		ZP_Linie(hdc, 700, 200, 700, 220);
		ZP_Linie(hdc, 850, 220, 890, 220);
		ZP_Linie(hdc, 680, 220, 720, 220);

		Zeichne_Wechselspannungsquelle(hdc, 140, 170, 60, false, 0);
		//Widerstand R Position: x=835-865, y=120-180:
		Zeichne_Widerstand(hdc, 935, 120, 30, 60);
		// Festspannungsregler: x: 690, 80, 780, 130
		// Hier wird der BUTTON passend eingesetzt
		Rechteck_BH_Rahmen(hdc, 740, 80, 90, 60);
		// Leitung f�r C Position: x: 500, y: 100-140 und 160-220
		ZP_Linie(hdc, 550, 100, 550, 140);
		ZP_Linie(hdc, 550, 160, 550, 220);
		// Kondensator C zeichen (quer) x:450-550, y: 140, 160
		Zeichne_Kondensator(hdc, 500, 140, 100, 20, C_VERTIKAL);
		// Masse unter Kondensator
		ZP_Linie(hdc, 530, 220, 570, 220);

		//Anschlusspunkte nach Kondensator und nach Spannungsregler, Positionen (Mitte): x: 310; 500; y: 100; 200
		Ellipse_BH(hdc, 690, 90, 20, 20);
		Ellipse_BH(hdc, 690, 190, 20, 20);
		Ellipse_BH(hdc, 860, 90, 20, 20);
		Ellipse_BH(hdc, 860, 190, 20, 20);
		// Pfeil f�r beide Messpunkte Position: x: 310, 500, y: 120-180
		ZP_Linie(hdc, 700, 120, 700, 180);
		DP_Linie(hdc, 690, 170, 700, 180, 710, 170);
		ZP_Linie(hdc, 870, 120, 870, 180);
		DP_Linie(hdc, 860, 170, 870, 180, 880, 170);

		if (Gleichrichter.einweg)
		{
			// Einweggleichrichter zeichnen
			// Verbindungslinie von Spannungsquelle an Kondensator
			ZP_Linie(hdc, 250, 100, 450, 100);
			if (Gleichrichter.positiv_gleichrichter)
			{
				// Diode einzeichnen
				VP_Linie(hdc, 320, 70, 380, 100, 320, 130, 320, 70);
				ZP_Linie(hdc, 380, 70, 380, 130);
			}
			else
			{
				// Diode einzeichnen
				VP_Linie(hdc, 380, 70, 320, 100, 380, 130, 380, 70);
				ZP_Linie(hdc, 320, 70, 320, 130);
			}
			// Masse unter Spannungsquelle
			ZP_Linie(hdc, 150, 300, 190, 300);
		}
		else
		{
			// Vollwellengleichrichter:
			// Zun�chst ein "Karo"
			DP_Linie(hdc, 250, 100, 340, 10, 430, 100);
			DP_Linie(hdc, 250, 100, 340, 190, 430, 100);

			if (Gleichrichter.positiv_gleichrichter)
			{
				// Diode 1: Position: x: 295, 55
				VP_Linie(hdc, 295 - 22, 55 - 7, 295 + 7, 55 + 22, 295 + 7, 55 - 7, 295 - 22, 55 - 7);
				ZP_Linie(hdc, 295 - 7, 55 - 22, 295 + 22, 55 + 7);
				// Diode 2:
				VP_Linie(hdc, 385 + 22, 55 - 7, 385 - 7, 55 + 22, 385 - 7, 55 - 7, 385 + 22, 55 - 7);
				ZP_Linie(hdc, 385 + 7, 55 - 22, 385 - 22, 55 + 7);
				// Diode 3: Position: x: 385 y: 145
				VP_Linie(hdc, 385 - 22, 145 - 7, 385 + 7, 145 + 22, 385 + 7, 145 - 7, 385 - 22, 145 - 7);
				ZP_Linie(hdc, 385 - 7, 145 - 22, 385 + 22, 145 + 7);
				// Diode 4:
				VP_Linie(hdc, 295 + 22, 145 - 7, 295 - 7, 145 + 22, 295 - 7, 145 - 7, 295 + 22, 145 - 7);
				ZP_Linie(hdc, 295 + 7, 145 - 22, 295 - 22, 145 + 7);
			}
			else
			{
				// Diode 1: Position: x: 295, 55
				VP_Linie(hdc, 295 - 7, 55 - 22, 295 + 22, 55 + 7, 295 - 7, 55 + 7, 295 - 7, 55 - 22);
				ZP_Linie(hdc, 295 - 22, 55 - 7, 295 + 7, 55 + 22);
				// Diode 2:
				VP_Linie(hdc, 385 + 7, 55 - 22, 385 - 22, 55 + 7, 385 + 7, 55 + 7, 385 + 7, 55 - 22);
				ZP_Linie(hdc, 385 + 22, 55 - 7, 385 - 7, 55 + 22);
				// Diode 3: Position: x: 385 y: 145
				VP_Linie(hdc, 385 - 7, 145 - 22, 385 + 22, 145 + 7, 385 - 7, 145 + 7, 385 - 7, 145 - 22);
				ZP_Linie(hdc, 385 - 22, 145 - 7, 385 + 7, 145 + 22);
				// Diode 4:
				VP_Linie(hdc, 295 - 22, 145 + 7, 295 + 7, 145 - 22, 295 + 7, 145 + 7, 295 - 22, 145 + 7);
				ZP_Linie(hdc, 295 - 7, 145 + 22, 295 + 22, 145 - 7);
			}
			// Linie f�r "Masse-Anschluss" der Spannungsquelle:
			DP_Linie(hdc, 170, 300, 430, 300, 430, 100);
			// Masse an unteren Anschluss des Gleichrichters
			ZP_Linie(hdc, 340, 190, 340, 230);
			ZP_Linie(hdc, 320, 230, 360, 230);
			// Oberer Anschluss des Gleichrichtes an Schaltung...
			DP_Linie(hdc, 340, 10, 450, 10, 450, 100);
		}

		SelectObject(hdc, hPinselAlt);
		DeleteObject(hPinselSchwarz);
		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz2);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_C1: 
			Eingabe_Kapazitaetswerte_Aufruf(1, 1, GLEICHRICHTER); 
			neuzeichnen = true; 
			break;
		case ID_R1: 
			Eingabe_Widerstandswerte_Aufruf(1, 1, GLEICHRICHTER); 
			neuzeichnen = true; 
			break;
		case ID_SPG_REG: 
			Eingabe_Spannungsregler(); 
			neuzeichnen = true; 
			break;
		case ID_UB: 
			Eingabe_Wechselspannung(GLEICHRICHTER, U_AC_SPANNUNG); 
			neuzeichnen = true; 
			break;
		case ID_FREQ: 
			Eingabe_Wechselspannung(GLEICHRICHTER, U_AC_FREQUENZ); 
			neuzeichnen = true;  
			break;
		case ID_GLEICHRICHT: 
			Eingabe_Gleichrichter(); 
			neuzeichnen = true; 
			break;
		case ID_CALC:
			Ergebnis_Gleichrichter(hDlg);
			break;
		case IDCANCEL:
		case ID_CLOSE:
			EndDialog(hDlg, LOWORD(wParam)); 
			break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
			InvalidateRect(hDlg, 0, true);
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of GleichrichterSchaltung

// Meldungshandler f�r ErgebnisGleichrichterSchaltung.
INT_PTR CALLBACK ErgebnisGleichrichterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];

	switch (message)
	{
	case WM_INITDIALOG:
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_GLEICHRICHTER), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		if (!Gleichrichter.Schaltung_berechenbar)
			SetDlgItemText(hDlg, ID_CAPTION, (LPCSTR)"Berechnung der Gleichrichterschaltung fehlerhaft!");
//		if (!Basis_Schaltung.NPN)
//			SetDlgItemText(hDlg, ID_NPN, (LPCSTR)"PNP");
		Bestimme_Spannungsbezeichner(cText, Gleichrichter.U_diode_sperr, 99);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Gleichrichter.U_D, 99);
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Gleichrichter.U_eff, 99);
		SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Gleichrichter.U_amplitude, 99);
		SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Gleichrichter.U_Max, 99);
		SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, (double)Gleichrichter.U_Ausgang, 99);
		SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)cText);
		Bestimme_Strombezeichner(cText, Gleichrichter.U_Ausgang / Gleichrichter.R, 99);
		SetDlgItemText(hDlg, ID_TXT7, (LPCSTR)cText);
		Bestimme_Prozentbezeichner(cText, Gleichrichter.Welligkeit, 99);
		SetDlgItemText(hDlg, ID_TXT8, (LPCSTR)cText);
		Bestimme_Leistungsbezeichner(cText, Gleichrichter.P_V, 99);
		SetDlgItemText(hDlg, ID_TXT9, (LPCSTR)cText);

		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz2, hStiftAlt;
		HBRUSH hPinselSchwarz, hPinselAlt;

		HDC hdc = BeginPaint(hDlg, &ps);

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
		hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
		hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

		// passenden Gleichrichter zeichnen
		if (Gleichrichter.einweg)
		{
			// Einweggleichrichter zeichnen
			// Verbindungslinie von Spannungsquelle an Kondensator
			ZP_Linie(hdc, 600, 100, 700, 100);
			if (Gleichrichter.positiv_gleichrichter)
			{
				// Diode einzeichnen
				VP_Linie(hdc, 620, 70, 680, 100, 620, 130, 620, 70);
				ZP_Linie(hdc, 680, 70, 680, 130);
			}
			else
			{
				// Diode einzeichnen
				VP_Linie(hdc, 680, 70, 620, 100, 680, 130, 680, 70);
				ZP_Linie(hdc, 620, 70, 620, 130);
			}
		}
		else
		{
			// Vollwellengleichrichter:
			// Zun�chst ein "Karo" alt 550, 100, 640, 10, 730, 100, 640, 190
			DP_Linie(hdc, 550, 100, 630, 20, 710, 100);
			DP_Linie(hdc, 550, 100, 630, 180, 710, 100);

			if (Gleichrichter.positiv_gleichrichter)
			{
				// Diode 1: Position: x: 295, 55    -5
				VP_Linie(hdc, 590 - 22, 60 - 7, 590 + 7, 60 + 22, 590 + 7, 60 - 7, 590 - 22, 60 - 7);
				ZP_Linie(hdc, 590 - 7, 60 - 22, 590 + 22, 60 + 7);
				// Diode 2: -15
				VP_Linie(hdc, 670 + 22, 60 - 7, 670 - 7, 60 + 22, 670 - 7, 60 - 7, 670 + 22, 60 - 7);
				ZP_Linie(hdc, 670 + 7, 60 - 22, 670 - 22, 60 + 7);
				// Diode 3: Position: x: 385 y: 145   -15
				VP_Linie(hdc, 670 - 22, 140 - 7, 670 + 7, 140 + 22, 670 + 7, 140 - 7, 670 - 22, 140 - 7);
				ZP_Linie(hdc, 670 - 7, 140 - 22, 670 + 22, 140 + 7);
				// Diode 4: -5
				VP_Linie(hdc, 590 + 22, 140 - 7, 590 - 7, 140 + 22, 590 - 7, 140 - 7, 590 + 22, 140 - 7);
				ZP_Linie(hdc, 590 + 7, 140 - 22, 590 - 22, 140 + 7);
			}
			else
			{
				// Diode 1: Position: x: 295, 55
				VP_Linie(hdc, 590 - 7, 60 - 22, 590 + 22, 60 + 7, 590 - 7, 60 + 7, 590 - 7, 60 - 22);
				ZP_Linie(hdc, 590 - 22, 60 - 7, 590 + 7, 60 + 22);
				// Diode 2:
				VP_Linie(hdc, 670 + 7, 60 - 22, 670 - 22, 60 + 7, 670 + 7, 60 + 7, 670 + 7, 60 - 22);
				ZP_Linie(hdc, 670 + 22, 60 - 7, 670 - 7, 60 + 22);
				// Diode 3: Position: x: 385 y: 145
				VP_Linie(hdc, 670 - 7, 140 - 22, 670 + 22, 140 + 7, 670 - 7, 140 + 7, 670 - 7, 140 - 22);
				ZP_Linie(hdc, 670 - 22, 140 - 7, 670 + 7, 140 + 22);
				// Diode 4:
				VP_Linie(hdc, 590 - 22, 140 + 7, 590 + 7, 140 - 22, 590 + 7, 140 + 7, 590 - 22, 140 + 7);
				ZP_Linie(hdc, 590 - 7, 140 + 22, 590 + 22, 140 - 7);
			}
		}
		SelectObject(hdc, hPinselAlt);
		DeleteObject(hPinselSchwarz);
		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz2);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_COPY_CLIPBOARD:
			Kopiere_Ergebnis_Gleichrichter(Gleichrichter, hWndElektronikMain);
			break;
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of ErgebnisGleichrichterSchaltung_Dialog

// Meldungshandler f�r ThermischerWiderstand
INT_PTR CALLBACK ThermischerWiderstand_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	HICON hIcon;
	static int Zu_Berechnen;

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Widerstandswerte und Temperaturen erg�nzen.
		Bestimme_Bezeichner(cText, R_th.Rth_JC, 99);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Bezeichner(cText, R_th.Rth_CK, 99);
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
		Bestimme_Bezeichner(cText, R_th.Rth_KA, 99);
		SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
		Bestimme_Bezeichner(cText, R_th.P_V, 99);
		SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
		Bestimme_Bezeichner(cText, R_th.T_junc, 99);
		SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
		Bestimme_Bezeichner(cText, R_th.T_max, 99);
		SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)cText);

		SendMessage(GetDlgItem(hDlg, ID_P_V), BM_SETCHECK, 1, 0);
		Zu_Berechnen = 4;
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_THERMWIDERSTAND), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		return (INT_PTR)TRUE;
	case WM_COMMAND:
		switch (wParam)
		{
		case ID_R_TH_JC: Zu_Berechnen = BERECHNE_R_TH_JC; break;
		case ID_R_TH_CK: Zu_Berechnen = BERECHNE_R_TH_CK; break;
		case ID_R_TH_KA: Zu_Berechnen = BERECHNE_R_TH_KA; break;
		case ID_P_V: Zu_Berechnen = BERECHNE_P_V; break;
		case ID_T_J: Zu_Berechnen = BERECHNE_T_J; break;
		case ID_T_MAX: Zu_Berechnen = BERECHNE_T_MAX; break;

		case ID_CALC:
		{
			// Eingabe �bernehmen
			double wert1 = 0, wert2 = 0, wert3 = 0, wert4 = 0, wert5 = 0, wert6 = 0;
			bool eingabe_ok = true;

			if (Zu_Berechnen != BERECHNE_R_TH_JC)
			{
				wert1 = Eingabe_parsen(hDlg, ID_TXT1);
				if (wert1 <= 0.0)
				{
					Warnung("Thermischer Widerstand R_th,jc muss gr��er 0K/W sein!");
					SetDlgItemText(hDlg, ID_TXT1, (LPSTR)"30");
					eingabe_ok = false;
				}
			}
			if (Zu_Berechnen != BERECHNE_R_TH_CK)
			{
				wert2 = Eingabe_parsen(hDlg, ID_TXT2);
				if (wert2 < 0.0)
				{
					Warnung("Thermischer Widerstand R_th_JC muss gr��er oder gleich 0K/W sein!");
					SetDlgItemText(hDlg, ID_TXT2, (LPSTR)"1");
					eingabe_ok = false;
				}
			}
			if (Zu_Berechnen != BERECHNE_R_TH_KA)
			{
				wert3 = Eingabe_parsen(hDlg, ID_TXT3);
				if (wert3 < 0.0)
				{
					Warnung("Thermischer Widerstand R_th_KA muss gr��er oder gleich 0K/W sein!");
					SetDlgItemText(hDlg, ID_TXT3, (LPSTR)"20");
					eingabe_ok = false;
				}
			}
			if (Zu_Berechnen != BERECHNE_P_V)
			{
				wert4 = Eingabe_parsen(hDlg, ID_TXT4);
				if (wert4 <= 0.0)
				{
					Warnung("Verlustleistung muss gr��er 0W sein!");
					SetDlgItemText(hDlg, ID_TXT4, (LPSTR)"3");
					eingabe_ok = false;
				}
			}
			if (Zu_Berechnen != BERECHNE_T_J)
			{
				wert5 = Eingabe_parsen(hDlg, ID_TXT5);
				if (wert5 <= 0.0)
				{
					Warnung("Halbleitertemperatur T_j muss gr��er 0�C sein!");
					SetDlgItemText(hDlg, ID_TXT5, (LPSTR)"150");
					eingabe_ok = false;
				}
			}
			if (Zu_Berechnen != BERECHNE_T_MAX)
			{
				wert6 = Eingabe_parsen(hDlg, ID_TXT6);
				if (wert6 <= 0.0)
				{
					Warnung("Umgebungstemperatur T_Max muss gr��er 0�C sein!");
					SetDlgItemText(hDlg, ID_TXT6, (LPSTR)"30");
					eingabe_ok = false;
				}
			}
			if (eingabe_ok)
			{
				// Eingaben speichern
				R_th.Rth_JC = wert1;
				R_th.Rth_CK = wert2;
				R_th.Rth_KA = wert3;
				R_th.P_V = wert4;
				R_th.T_junc = wert5;
				R_th.T_max = wert6;
				Ergebnis_ThermischerWiderstand(Zu_Berechnen);
				Daten_geaendert();
				// Ergebnis anzeigen
				switch (Zu_Berechnen)
				{
				case BERECHNE_R_TH_JC:
					Bestimme_Bezeichner(cText, R_th.Rth_JC, 99);
					SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
					break;
				case BERECHNE_R_TH_CK:
					Bestimme_Bezeichner(cText, R_th.Rth_CK, 99);
					SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
					break;
				case BERECHNE_R_TH_KA:
					Bestimme_Bezeichner(cText, R_th.Rth_KA, 99);
					SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
					break;
				case BERECHNE_P_V:
					Bestimme_Bezeichner(cText, R_th.P_V, 99);
					SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
					break;
				case BERECHNE_T_J:
					Bestimme_Bezeichner(cText, R_th.T_junc, 99);
					SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
					break;
				case BERECHNE_T_MAX:
					Bestimme_Bezeichner(cText, R_th.T_max, 99);
					SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)cText);
					break;
				}
			}
			break;
		}
		case ID_COPY_CLIPBOARD:
//			Kopiere_Ergebnis_Thermischer_Widerstand(R_th, hWndElektronikMain);
			break;
		case IDCANCEL:
		case ID_CLOSE:
			EndDialog(hDlg, LOWORD(wParam)); break;
		}

		break;
	}
	return (INT_PTR)FALSE;
}	// end of ThermischerWiderstand

// Meldungshandler f�r Differenzverstaerker_Bipolar
INT_PTR CALLBACK Differenzverstaerker_Bipolar_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Funktion ok
	// �nderung 19.10.2019 Eingabefelder werden neben diesem Dialog angezeigt
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	bool neuzeichnen = false;

	switch (message)
	{
	case WM_INITDIALOG:
		HICON hIcon;

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_DIFFERENZVERSTAERKER), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Widerstandsbezeichner(cText, Differenzverstaerker.R[0], 99);	// Kollektorwiderst�nde
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		SetDlgItemText(hDlg, ID_R2, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Differenzverstaerker.R[1], 99);	// Basiswiderst�nde
		SetDlgItemText(hDlg, ID_R3, (LPCSTR)cText);
		SetDlgItemText(hDlg, ID_R4, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Differenzverstaerker.R[2], 99);	// Emitterwiderst�nde
		SetDlgItemText(hDlg, ID_R5, (LPCSTR)cText);
		SetDlgItemText(hDlg, ID_R6, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Differenzverstaerker.R[3], 99);	// Emitterwiderstand Stromsenke
		SetDlgItemText(hDlg, ID_R7, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Differenzverstaerker.U_B, 99);
		SetDlgItemText(hDlg, ID_UB, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, -Differenzverstaerker.U_B, 99);
		SetDlgItemText(hDlg, ID_UB_2, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Differenzverstaerker.U_Ref, 99);
		SetDlgItemText(hDlg, ID_U_REF, (LPCSTR)cText);
		if (Differenzverstaerker.verwende_Stromquelle)
			SendMessage(GetDlgItem(hDlg, ID_CB1), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_CB1), BM_SETCHECK, 0, 0);
		if (Differenzverstaerker.r_CE_hochohmig)
			SendMessage(GetDlgItem(hDlg, ID_CB2), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_CB2), BM_SETCHECK, 0, 0);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Differenzverst�rker mit Widerst�nden, Transistoren und Spannungsquelle und Stromquelle

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		// Verschieben der Kn�pfe 
		// Widerst�nde
		MoveWindow(GetDlgItem(hDlg, ID_R1), 170, 80, 60, 40, true);  
		MoveWindow(GetDlgItem(hDlg, ID_R2), 470, 80, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R3), 70, 255, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R4), 570, 255, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R5), 270, 280, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R6), 370, 280, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R7), 270, 530, 60, 40, true);
		// Transistoren
		MoveWindow(GetDlgItem(hDlg, ID_TRANS), 250, 185, 40, 30, true);
		MoveWindow(GetDlgItem(hDlg, ID_TRANS_B), 410, 185, 40, 30, true);
		MoveWindow(GetDlgItem(hDlg, ID_TRANS_2), 352, 435, 40, 30, true);	// Diese Schaltfl�che zwei Punkte weiter nach rechts
																			// Spannungsquelle
		MoveWindow(GetDlgItem(hDlg, ID_UB), 550, 80, 40, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_UB_2), 250, 630, 40, 40, true);
		// Referenzspannung
		MoveWindow(GetDlgItem(hDlg, ID_U_REF), 130, 480, 60, 40, true);

		Zeichne_Differenzverstaerker_bipolar(Differenzverstaerker, hdc, false);

		if (Differenzverstaerker.verwende_Stromquelle)	// Transistor als Stromquelle verwenden
		{
			EnableWindow(GetDlgItem(hDlg, ID_TRANS_2), TRUE);   // Knopf f�r Transistor_2 (wieder) einschaltern
			EnableWindow(GetDlgItem(hDlg, ID_U_REF), TRUE);		// Knopf f�r U_Ref (wieder) einschaltern
		}
		else // "nur" gemeinsamer Widerstand in der gemeinsamen Leitung des Differenzverst�rkers
		{
			EnableWindow(GetDlgItem(hDlg, ID_TRANS_2), FALSE);	// Knopt f�r Transistor_2 abschaltern
			EnableWindow(GetDlgItem(hDlg, ID_U_REF), FALSE);		// Knopf f�r U_Ref abschalter
		}

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		// sorgt mit der globalen Variablen Eingabe_Dialog_Positionieren f�r eine Platzierung der Eingabe neben dem
		// aktuellen Fenster
		Eingabe_Dialog.hDlg_Aufrufer = hDlg;
		switch (wParam)
		{
		case ID_R1:
		case ID_R2: Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; Eingabe_Widerstandswerte_Aufruf(1, 4, DIFFERENZVERSTAERKER); neuzeichnen = true; break;
		case ID_R3:
		case ID_R4: Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; Eingabe_Widerstandswerte_Aufruf(2, 4, DIFFERENZVERSTAERKER); neuzeichnen = true; break;
		case ID_R5:
		case ID_R6: Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; Eingabe_Widerstandswerte_Aufruf(3, 4, DIFFERENZVERSTAERKER); neuzeichnen = true; break;
		case ID_R7:  Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;Eingabe_Widerstandswerte_Aufruf(4, 4, DIFFERENZVERSTAERKER); neuzeichnen = true; break;
		case ID_TRANS:
		case ID_TRANS_B: Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; Eingabe_BipolarTransistorwerte_Aufruf(DIFFERENZVERSTAERKER, 58); neuzeichnen = true; break;
		case ID_TRANS_2: Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; Eingabe_BipolarTransistorwerte_Aufruf(DIFFERENZVERSTAERKER_STROMQUELLE, 59); neuzeichnen = true; break;
		case ID_UB: Eingabe_Spannungswert_Aufruf(DIFFERENZVERSTAERKER, U_BETRIEB); neuzeichnen = true; break;
		case ID_U_REF: Eingabe_Spannungswert_Aufruf(DIFFERENZVERSTAERKER_STROMQUELLE, U_REFERENZ); neuzeichnen = true; break;
		case ID_CALC: Ergebnis_Differenzverstaerker_Aufruf(hDlg);  break;
		case ID_CB1:
			(IsDlgButtonChecked(hDlg, ID_CB1) == BST_CHECKED) ? Differenzverstaerker.verwende_Stromquelle = true : Differenzverstaerker.verwende_Stromquelle = false; neuzeichnen = true;
			Daten_geaendert();
			break;
		case ID_CB2:
			(IsDlgButtonChecked(hDlg, ID_CB2) == BST_CHECKED) ? Differenzverstaerker.r_CE_hochohmig = true : Differenzverstaerker.r_CE_hochohmig = false; neuzeichnen = true;
			Daten_geaendert();
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Differenzverstaerker_bipolar(Differenzverstaerker);
			break;
		case IDCANCEL:
		case ID_CLOSE: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
			InvalidateRect(hDlg, 0, true);
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of Differenzverstaerker_Bipolar

// Meldungshandler f�r ErgebnisDifferenzverstaerker
INT_PTR CALLBACK Ergebnis_Differenzverstaerker_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];

	switch (message)
	{
	case WM_INITDIALOG:
	{
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_DIFFERENZVERSTAERKER), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);

		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		if (!Differenzverstaerker.Schaltung_berechenbar)
			SetDlgItemText(hDlg, ID_CAPTION, (LPCSTR)"Berechnung des Differenzverst�rkers fehlerhaft!");
		if (Differenzverstaerker.NPN_T1)
			SetDlgItemText(hDlg, ID_NPN, (LPCSTR)"NPN");
		else
			SetDlgItemText(hDlg, ID_NPN, (LPCSTR)"PNP");
		if (Differenzverstaerker.NPN_T2)
			SetDlgItemText(hDlg, ID_NPN_T2, (LPCSTR)"NPN");
		else
			SetDlgItemText(hDlg, ID_NPN_T2, (LPCSTR)"PNP");
		Bestimme_Bezeichner(cText, Differenzverstaerker.V_U_Wechsel, 99);
		SetDlgItemText(hDlg, ID_V_U_AC, (LPCSTR)cText);
		Bestimme_Bezeichner(cText, Differenzverstaerker.V_U_Gleichtakt, 99);
		SetDlgItemText(hDlg, ID_V_U_DC, (LPCSTR)cText);
		if (Differenzverstaerker.V_U_Gleichtakt_ist_Null)
			SetDlgItemText(hDlg, ID_CMRR, (LPCSTR)"unendl.");
		else
		{
			Bestimme_Bezeichner(cText, Differenzverstaerker.CMRR, 99);
			SetDlgItemText(hDlg, ID_CMRR, (LPCSTR)cText);
		}
		Bestimme_Widerstandsbezeichner(cText, Differenzverstaerker.r_Ein_AC, 99);
		SetDlgItemText(hDlg, ID_R_EIN_AC, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Differenzverstaerker.r_Ein_DC, 99);
		SetDlgItemText(hDlg, ID_R_EIN_DC, (LPCSTR)cText);
		Bestimme_Strombezeichner(cText, Differenzverstaerker.I_B, 99);
		SetDlgItemText(hDlg, ID_I_B, (LPCSTR)cText);
		Bestimme_Strombezeichner(cText, Differenzverstaerker.I_C, 99);
		SetDlgItemText(hDlg, ID_I_C, (LPCSTR)cText);
		Bestimme_Strombezeichner(cText, Differenzverstaerker.I_E, 99);
		SetDlgItemText(hDlg, ID_I_E, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Differenzverstaerker.U_Basis, 99);
		SetDlgItemText(hDlg, ID_U_BASIS, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Differenzverstaerker.U_C, 99);
		SetDlgItemText(hDlg, ID_U_C, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Differenzverstaerker.U_E, 99);
		SetDlgItemText(hDlg, ID_U_E, (LPCSTR)cText);
		if (Differenzverstaerker.verwende_Stromquelle)
		{
			// Transistor als Stromquelle verwenden
			Bestimme_Strombezeichner(cText, Differenzverstaerker.I_B_T2, 99);
			SetDlgItemText(hDlg, ID_I_B_T3, (LPCSTR)cText);
			Bestimme_Strombezeichner(cText, Differenzverstaerker.I_C_T2, 99);
			SetDlgItemText(hDlg, ID_I_C_T3, (LPCSTR)cText);
			Bestimme_Strombezeichner(cText, Differenzverstaerker.I_E_T2, 99);
			SetDlgItemText(hDlg, ID_I_E_T3, (LPCSTR)cText);
			Bestimme_Spannungsbezeichner(cText, Differenzverstaerker.U_Basis_T2, 99);
			SetDlgItemText(hDlg, ID_U_BASIS_T3, (LPCSTR)cText);
			Bestimme_Spannungsbezeichner(cText, Differenzverstaerker.U_C_T2, 99);
			SetDlgItemText(hDlg, ID_U_C_T3, (LPCSTR)cText);
			Bestimme_Spannungsbezeichner(cText, Differenzverstaerker.U_E_T2, 99);
			SetDlgItemText(hDlg, ID_U_E_T3, (LPCSTR)cText);
		}
		else
		{
			// Im gemeinsamen Pfad ist nur ein Widerstand
			SetDlgItemText(hDlg, ID_TRANS_3, (LPCSTR)"Kein Transistor als Stromquelle verwendet.");
			SetDlgItemText(hDlg, ID_I_B_T3, (LPCSTR)"-/-");
			SetDlgItemText(hDlg, ID_I_C_T3, (LPCSTR)"-/-");
			SetDlgItemText(hDlg, ID_I_E_T3, (LPCSTR)"-/-");
			SetDlgItemText(hDlg, ID_U_BASIS_T3, (LPCSTR)"-/-");
			SetDlgItemText(hDlg, ID_U_C_T3, (LPCSTR)"-/-");
			SetDlgItemText(hDlg, ID_U_E_T3, (LPCSTR)"-/-");
		}

		return (INT_PTR)TRUE;
	}
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz2, hStiftAlt;
		HBRUSH hPinselSchwarz, hPinselAlt;

		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Transistor einzeichnen

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
		hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
		hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

		// passenden Transistor zeichnen
		Zeichne_Bipolartransistor(hdc, 600, 100, 50, 100, Differenzverstaerker.NPN_T1, 30);
		SelectObject(hdc, hPinselAlt);
		DeleteObject(hPinselSchwarz);
		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz2);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_COPY_CLIPBOARD:
			Kopiere_Ergebnis_Differenzverstaerker(Differenzverstaerker, hWndElektronikMain);
			break;
		case IDCANCEL: 
			EndDialog(hDlg, LOWORD(wParam)); 
			break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Ergebnis_Differenzverstaerker

// Meldungshandler f�r Elektrisches_Feld
INT_PTR CALLBACK Elektrisches_Feld_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	bool neuzeichnen = false;
	HICON hIcon;
	static int einrasten = 40;

	switch (message)
	{
	case WM_INITDIALOG:
	{
		sprintf_s(cText, 99, "%.3f", Ladung.Massstab);
		SetDlgItemText(hDlg, ID_MASS, (LPCSTR)cText);
		sprintf_s(cText, 99, "1m");
		SetDlgItemText(hDlg, ID_LADUNG, (LPCSTR)cText);

		switch (einrasten)
		{
			case 40: SendMessage(GetDlgItem(hDlg, ID_FANG_40), BM_SETCHECK, 1, 0); break;
			case 20: SendMessage(GetDlgItem(hDlg, ID_FANG_20), BM_SETCHECK, 1, 0); break;
			case 8: SendMessage(GetDlgItem(hDlg, ID_FANG_8), BM_SETCHECK, 1, 0); break;
			case 4: SendMessage(GetDlgItem(hDlg, ID_FANG_4), BM_SETCHECK, 1, 0); break;
		}
		// Fenster neuzeichnen und alles berechnen, falls noch Daten vorhanden sind...
		InvalidateRect(hDlg, 0, true);
		Berechne_E_Feld();
		Schreibe_neue_E_Feld_Liste(hDlg);

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_E_FELD), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		break;
	}
	case WM_LBUTTONDOWN:
		double aktuelle_Ladung;

		if (Ladung.Anzahl_Ladungen < 19)
		{
			double Pos_x, Pos_y;
			int i;
			bool Ladung_vorhanden = false;
			bool Ladung_platzierbar = true;
			char cText[100];

			// Ladung holen
			GetDlgItemText(hDlg, ID_LADUNG, (LPSTR)cText, 99);
			GetDlgItemText(hDlg, ID_LADUNG, (LPSTR)cText, 99);
//			widechar_to_char(cText, Text, 99);
			aktuelle_Ladung = Zahl_uebernehmen(cText, 99);
			// Koordinaten holen
			Pos_x = GET_X_LPARAM(lParam) - 220;
			Pos_y = 220 - GET_Y_LPARAM(lParam);
			Pos_x = einrasten * ((int)(GET_X_LPARAM(lParam) - 20 + einrasten / 2) / einrasten);
			Pos_y = einrasten * ((int)(GET_Y_LPARAM(lParam) - 20 + einrasten / 2) / einrasten);
			Pos_x -= 200;
			Pos_y = 200 - Pos_y;
			// Zul�ssiger Bereich?
			if ((Pos_x >= -200) && (Pos_x <= 200) && (Pos_y >= -200) && (Pos_y <= 200))
			{
				// Eingabe im zul�ssigen Bereich. Jetzt Umrechnung auf Meter.
				Pos_x *= Ladung.Massstab / 40.0;
				Pos_y *= Ladung.Massstab / 40.0;
				// Ist an dieser Person schon eine Sonde?
				for (i = 0; i < Ladung.Anzahl_Sonde; i++)
				{
					if ((Pos_x == Ladung.x_pos_Sonde[i]) && (Pos_y == Ladung.y_pos_Sonde[i]))
						Ladung_platzierbar = false;
					// Fehlermeldung ausgeben!!
				}

				// Gibt es diese Position schon?
				for (i = 0; i < Ladung.Anzahl_Ladungen; i++)
				{
					if ((Pos_x == Ladung.x_pos[i]) && (Pos_y == Ladung.y_pos[i]))
					{
						Ladung.Elektrische_Ladung[i] += aktuelle_Ladung;
						Ladung_vorhanden = true;
						// Ladung bei 0 Coulomb l�schen?
					}
				}
				if (!Ladung_vorhanden&&Ladung_platzierbar)	// neue Ladung platzieren
				{
					Ladung.x_pos[Ladung.Anzahl_Ladungen] = Pos_x;
					Ladung.y_pos[Ladung.Anzahl_Ladungen] = Pos_y;

					Ladung.Elektrische_Ladung[Ladung.Anzahl_Ladungen] = aktuelle_Ladung;
					Ladung.Anzahl_Ladungen++;
				}
			}
			InvalidateRect(hDlg, 0, true);
			Berechne_E_Feld();
			Schreibe_neue_E_Feld_Liste(hDlg);
		}
		sprintf_s(cText, 99, "Anzahl Ladungen: %u", Ladung.Anzahl_Ladungen);
		SetDlgItemText(hDlg, ID_ANZAHL, (LPCSTR)cText);

		return 0;
	case WM_RBUTTONDOWN:
		if (Ladung.Anzahl_Sonde < 19)
		{
			double Pos_x, Pos_y;
			bool Sonde_platzierbar = true;
			int i;

			// Koordinaten holen
			Pos_x = einrasten * ((int)(GET_X_LPARAM(lParam) - 20 + einrasten / 2) / einrasten);
			Pos_y = einrasten * ((int)(GET_Y_LPARAM(lParam) - 20 + einrasten / 2) / einrasten);
			Pos_x -= 200;
			Pos_y = 200 - Pos_y;
			// Zul�ssiger Bereich?
			if ((Pos_x >= -200) && (Pos_x <= 200) && (Pos_y >= -200) && (Pos_y <= 200))
			{
				// Eingabe im zul�ssigen Bereich. Jetzt Umrechnung auf Meter.
				Pos_x *= Ladung.Massstab / 40.0;
				Pos_y *= Ladung.Massstab / 40.0;
				// Kontrolle erg�nzen: Ist die Sonde an einem Punkt der schon durch eine Ladung belegt ist?
				for (i = 0; i < Ladung.Anzahl_Ladungen; i++)
				{
					if ((Pos_x == Ladung.x_pos[i]) && (Pos_y == Ladung.y_pos[i]))
						Sonde_platzierbar = false;
					// Fehlermeldung ausgeben!!
				}
				if (Sonde_platzierbar)
				{
					Ladung.x_pos_Sonde[Ladung.Anzahl_Sonde] = Pos_x;
					Ladung.y_pos_Sonde[Ladung.Anzahl_Sonde] = Pos_y;
					Ladung.Anzahl_Sonde++;
					Berechne_E_Feld();
					Schreibe_neue_E_Feld_Liste(hDlg);
				}
			}
			InvalidateRect(hDlg, 0, true);
		}

		return 0;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Ladungen einzeichnen
		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);

		Zeichne_Ladungen(Ladung, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_FANG_40: einrasten = 40; break;
		case ID_FANG_20: einrasten = 20; break;
		case ID_FANG_8: einrasten = 8; break;
		case ID_FANG_4: einrasten = 4; break;

		case ID_DELETE:
			// Alle Ladungen l�schen
			init_Ladungen(&Ladung);
			SendMessage(GetDlgItem(hDlg, ID_FANG_40), BM_SETCHECK, 1, 0);
			einrasten = 40;
			neuzeichnen = true;
			break;
		case ID_NEU_MASS:
		{
			char cLaenge_Text[20];

			// Massstab anpassen
			Ladung.Massstab = Eingabe_parsen(hDlg, ID_MASS);
			Bestimme_Laengenbezeichner(cLaenge_Text, Ladung.Massstab, 10);
			sprintf_s(cText, 99, "1K�stchen <> %s", cLaenge_Text);
			SetDlgItemText(hDlg, ID_MASS_TEXT, (LPCSTR)cText);
			neuzeichnen = true;

			break;
		}
		case ID_COPY_CLIPBOARD:
			Berechne_E_Feld();
			Schreibe_neue_E_Feld_Liste(hDlg);
			Kopiere_Ladungen(Ladung);	
			break;
		case IDCANCEL:
		case ID_CLOSE:
			EndDialog(hDlg, LOWORD(wParam)); break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
			InvalidateRect(hDlg, 0, true);
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of Elektrisches_Feld

// Meldungshandler f�r Infofeld.
INT_PTR CALLBACK About_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of About_Dialog

// Meldungshandler f�r Hilfeseite
INT_PTR CALLBACK Hilfe_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Hilfe_Dialog

// Meldungshandler f�r invertierenden OP-Verst�rker
INT_PTR CALLBACK Invertierender_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Funktion ok
	// �nderung 19.10.2019 Eingabefenster werden neben diesem Dialog dargestellt.
	// �nderung 19.10.2019 Dialogfenster kann erst geschlossen werden, wenn alle Eingaben beendet sind

	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	bool neuzeichnen = false;
	HICON hIcon;
	static int Anzahl_Dialoge; // Z�hlt die offenen Dialoge und erlaubt ein Schlie�en des Fensters erst, wenn alle Eingabe beendet sind

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Widerstandsbezeichner(cText, Invertierender_OP.R[R_OP_EIN], 99);
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Invertierender_OP.R[R_OP_RUECKKOPPEL], 99);
		SetDlgItemText(hDlg, ID_R2, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Invertierender_OP.U_Ein, 99);
		SetDlgItemText(hDlg, ID_U_EIN, (LPCSTR)cText);
		if (Invertierender_OP.Idealer_OP)
			SendMessage(GetDlgItem(hDlg, ID_OP_IDEAL), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_OP_IDEAL), BM_SETCHECK, 0, 0);

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OPSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		// Zu Beginn die Kn�pfe positionieren, die Daten aus der Resource-Datei weichen ab...
		// Verschieben von R1-R2:
		MoveWindow(GetDlgItem(hDlg, ID_R1), 85, 90, 60, 40, true);  // funktioniert
		MoveWindow(GetDlgItem(hDlg, ID_R2), 230, 70, 60, 40, true);
		// Verschieben des OP-Knopfs
		MoveWindow(GetDlgItem(hDlg, ID_OP), 220, 220, 60, 40, true);
		// Verschieben des U_Ein-Knopfes
		MoveWindow(GetDlgItem(hDlg, ID_U_EIN), 60, 180, 60, 40, true);

		Zeichne_Invertierenden_OP(Invertierender_OP, hdc, false);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		// sorgt mit der globalen Variablen Eingabe_Dialog_Positionieren f�r eine Platzierung der Eingabe neben dem
		// aktuellen Fenster
		Eingabe_Dialog.hDlg_Aufrufer = hDlg;
		switch (wParam)
		{
		case ID_R1:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(1, 2, INVERTIERENDER_OP);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_R2:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(2, 2, INVERTIERENDER_OP);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_U_EIN:
			Anzahl_Dialoge++;
			Eingabe_Spannungswert_Aufruf(INVERTIERENDER_OP, U_EINGANG);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_OP:
			Anzahl_Dialoge++;
			Eingabe_Operationsverstaerker_Aufruf(INVERTIERENDER_OP, OP_V_0_AENDERBAR | OP_U_B_AENDERBAR | OP_DELTA_U_AUS);
			Anzahl_Dialoge--;
			break;
		case ID_CALC:
			Ergebnis_Invertierender_OP_Aufruf(hDlg);
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Invertierenden_OP(Invertierender_OP);
			break;
		case ID_OP_IDEAL:
			(IsDlgButtonChecked(hDlg, ID_OP_IDEAL) == BST_CHECKED) ? Invertierender_OP.Idealer_OP = true : Invertierender_OP.Idealer_OP = false;
			Daten_geaendert();
			break;
		case IDCANCEL:
		case ID_CLOSE:
			if (Anzahl_Dialoge==0)
				EndDialog(hDlg, LOWORD(wParam));
			else
				Warnung( (LPSTR)"Bitte erst die Eingabefenster beenden.");
			break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
			InvalidateRect(hDlg, 0, true);
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of Invertierender_OP_Dialog

// Meldungshandler f�r Ergebnis invertierende OP-Schaltung
INT_PTR CALLBACK Ergebnis_Invertierender_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];

	switch (message)
	{
	case WM_INITDIALOG:
	{
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OPSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
		{
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		}
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		if (!Invertierender_OP.Schaltung_berechenbar)
			SetDlgItemText(hDlg, ID_CAPTION, (LPCSTR)"Berechnung des invertierenden Verst�rkers mit OP fehlerhaft!");
		if (Invertierender_OP.U_Begrenzung)
			SetDlgItemText(hDlg, ID_BEGRENZUNG, (LPCSTR)"Ausgangsspannung des OPs au�erhalb des zul�ssigen Bereiches!");
		Bestimme_Bezeichner(cText, Invertierender_OP.V_U , 99);
		SetDlgItemText(hDlg, ID_V_U, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Invertierender_OP.R_Ein, 99);
		SetDlgItemText(hDlg, ID_R_EIN, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Invertierender_OP.U_Ein, 99);
		SetDlgItemText(hDlg, ID_U_EIN, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Invertierender_OP.U_Aus, 99);
		SetDlgItemText(hDlg, ID_U_AUS, (LPCSTR)cText);
		return (INT_PTR)TRUE;
	}
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz2, hStiftAlt;
		HBRUSH hPinselSchwarz, hPinselAlt;

		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Transistor einzeichnen

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
		hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
		hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);
		SelectObject(hdc, hPinselAlt);	// Wieder wei�er Hintergrund

		// passenden OP zeichnen und Ein- und Ausgang andeuten
		Zeichne_OP(hdc, 400, 100, 100, 100, true);
		ZP_Linie(hdc, 380, 130, 400, 130);
		ZP_Linie(hdc, 380, 170, 400, 170);
		ZP_Linie(hdc, 500, 150, 520, 150);
		
		DeleteObject(hPinselSchwarz);
		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz2);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Ergebnis_Invertierender_OP_Dialog

 // Meldungshandler f�r nicht-invertierenden OP-Verst�rker
INT_PTR CALLBACK Nichtinvertierender_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Funktion ok
	// �nderung 19.10.2019 eingabefenster werden neben diesem Dialog angezeigt.
	// �nderung 19.10.2019 Dialogfenster kann erst geschlossen werden, wenn alle Eingaben beendet sind
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	bool neuzeichnen = false;
	HICON hIcon;
	static int Anzahl_Dialoge; // Z�hlt die offenen Dialoge und erlaubt ein Schlie�en des Fensters erst, wenn alle Eingabe beendet sind

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Widerstandsbezeichner(cText, Nichtinvertierender_OP.R[R_OP_EIN], 99);
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Nichtinvertierender_OP.R[R_OP_RUECKKOPPEL], 99);
		SetDlgItemText(hDlg, ID_R2, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Nichtinvertierender_OP.U_Ein, 99);
		SetDlgItemText(hDlg, ID_U_EIN, (LPCSTR)cText);
		if (Nichtinvertierender_OP.Idealer_OP)
			SendMessage(GetDlgItem(hDlg, ID_OP_IDEAL), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_OP_IDEAL), BM_SETCHECK, 0, 0);

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OPSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		// Zu Beginn die Kn�pfe positionieren, die Daten aus der Resource-Datei weichen ab...
		// Verschieben von R1-R2:
		MoveWindow(GetDlgItem(hDlg, ID_R1), 300, 100, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R2), 300, 200, 60, 40, true);
		// Verschieben der zugeh�rigen Texte R1-R2
		MoveWindow(GetDlgItem(hDlg, ID_TXT_R1), 365, 100, 20, 13, true);
		MoveWindow(GetDlgItem(hDlg, ID_TXT_R2), 365, 200, 20, 13, true);
		// Verschieben des OP-Knopfs
		MoveWindow(GetDlgItem(hDlg, ID_OP), 220, 10, 60, 40, true);
		// Verschieben des U_Ein-Knopfes
		MoveWindow(GetDlgItem(hDlg, ID_U_EIN), 60, 80, 60, 40, true);

		Zeichne_Nichtinvertierenden_OP(Nichtinvertierender_OP, hdc, false);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		// sorgt mit der globalen Variablen Eingabe_Dialog_Positionieren f�r eine Platzierung der Eingabe neben dem
		// aktuellen Fenster
		Eingabe_Dialog.hDlg_Aufrufer = hDlg;
		switch (wParam)
		{
		case ID_R1:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(1, 2, NICHTINVERTIERENDER_OP);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_R2:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(2, 2, NICHTINVERTIERENDER_OP);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_U_EIN:
			Anzahl_Dialoge++;
			Eingabe_Spannungswert_Aufruf(NICHTINVERTIERENDER_OP, U_EINGANG);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_OP:
			Anzahl_Dialoge++;
			Eingabe_Operationsverstaerker_Aufruf(NICHTINVERTIERENDER_OP, OP_V_0_AENDERBAR | OP_U_B_AENDERBAR | OP_DELTA_U_AUS);
			Anzahl_Dialoge--;
			break;
		case ID_CALC:
			Ergebnis_Nichtinvertierender_OP_Aufruf(hDlg);
			break;
		case ID_OP_IDEAL:
			(IsDlgButtonChecked(hDlg, ID_OP_IDEAL) == BST_CHECKED) ? Nichtinvertierender_OP.Idealer_OP = true : Nichtinvertierender_OP.Idealer_OP = false;
			Daten_geaendert();
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Nichtinvertierenden_OP(Nichtinvertierender_OP);
			break;
		case IDCANCEL:
		case ID_CLOSE:
			if (Anzahl_Dialoge==0)
				EndDialog(hDlg, LOWORD(wParam));
			else
				Warnung( (LPSTR)"Bitte erst die Eingabefenster beenden.");
			break;		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
			InvalidateRect(hDlg, 0, true);
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of nicht-invertierender_OP_Dialog

// Meldungshandler f�r nichtinvertierende OP-Schaltung
INT_PTR CALLBACK Ergebnis_Nichtinvertierender_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];

	switch (message)
	{
	case WM_INITDIALOG:
	{
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OPSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
		{
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		}
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		if (!Invertierender_OP.Schaltung_berechenbar)
			SetDlgItemText(hDlg, ID_CAPTION, (LPCSTR)"Berechnung des invertierenden Verst�rkers mit OP fehlerhaft!");
		if (Nichtinvertierender_OP.U_Begrenzung)
			SetDlgItemText(hDlg, ID_BEGRENZUNG, (LPCSTR)"Ausgangsspannung des OPs au�erhalb des zul�ssigen Bereiches!");
		Bestimme_Bezeichner(cText, Nichtinvertierender_OP.V_U, 99);
		SetDlgItemText(hDlg, ID_V_U, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Nichtinvertierender_OP.U_Ein, 99);
		SetDlgItemText(hDlg, ID_U_EIN, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Nichtinvertierender_OP.U_Aus, 99);
		SetDlgItemText(hDlg, ID_U_AUS, (LPCSTR)cText);
		return (INT_PTR)TRUE;
	}
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz2, hStiftAlt;
		HBRUSH hPinselSchwarz, hPinselAlt;

		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Transistor einzeichnen

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
		hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
		hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);
		// Wieder wei�er Hintergrund
		SelectObject(hdc, hPinselAlt);	
		// passenden OP zeichnen und Ein- und Ausgang andeuten
		Zeichne_OP(hdc, 400, 100, 100, 100, true);
		ZP_Linie(hdc, 380, 130, 400, 130);
		ZP_Linie(hdc, 380, 170, 400, 170);
		ZP_Linie(hdc, 500, 150, 520, 150);								

		DeleteObject(hPinselSchwarz);
		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz2);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Ergebnis_Nichtinvertierender_OP_Dialog

 // Meldungshandler f�r differenzierenden OP-Verst�rker
INT_PTR CALLBACK Differenzierer_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Funktion ok
	// �nderung 19.10.2019 Eingabefenster werden neben diesem Dialog dargestellt.
	// �nderung 19.10.2019 Dialogfenster kann erst geschlossen werden, wenn alle Eingaben beendet sind
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	bool neuzeichnen = false;
	HICON hIcon;

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Kapazitaetsbezeichner(cText, Differenzierer_OP.C, 99);
		SetDlgItemText(hDlg, ID_C1, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Differenzierer_OP.R[R_OP_DIFF], 99);
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Differenzierer_OP.U_Ein, 99);
		SetDlgItemText(hDlg, ID_U_EIN, (LPCSTR)cText);
		Bestimme_Frequenzbezeichner(cText, Differenzierer_OP.freq, 99);
		SetDlgItemText(hDlg, ID_FREQ, (LPCSTR)cText);
		if (Differenzierer_OP.Idealer_OP)
			SendMessage(GetDlgItem(hDlg, ID_OP_IDEAL), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_OP_IDEAL), BM_SETCHECK, 0, 0);

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OPSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
		{
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		}
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		// Zu Beginn die Kn�pfe positionieren, die Daten aus der Resource-Datei weichen ab...
		// Verschieben von R1-C1:
		MoveWindow(GetDlgItem(hDlg, ID_C1), 100, 50, 60, 40, true);  // funktioniert
		MoveWindow(GetDlgItem(hDlg, ID_R1), 230, 70, 60, 40, true);

		// Verschieben des OP-Knopfs
		MoveWindow(GetDlgItem(hDlg, ID_OP), 220, 220, 60, 40, true);
		// Verschieben des U_Ein-Knopfes
		MoveWindow(GetDlgItem(hDlg, ID_U_EIN), 60, 180, 60, 40, true);
		// Verschieben des Frequenz-Knopfes
		MoveWindow(GetDlgItem(hDlg, ID_FREQ), 60, 230, 60, 40, true);

		Zeichne_Differenzierenden_OP(Differenzierer_OP, hdc, false);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		// sorgt mit der globalen Variablen Eingabe_Dialog_Positionieren f�r eine Platzierung der Eingabe neben dem
		// aktuellen Fenster
		Eingabe_Dialog.hDlg_Aufrufer = hDlg;
		switch (wParam)
		{
		case ID_R1:
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(1, 1, DIFFERENZIERER_OP);
			neuzeichnen = true;
			break;
		case ID_C1:
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Kapazitaetswerte_Aufruf(1, 1, DIFFERENZIERER_OP);
			neuzeichnen = true;
			break;
		case ID_U_EIN:
			Eingabe_Wechselspannung(DIFFERENZIERER_OP, U_AC_SPANNUNG);
			neuzeichnen = true;
			break;
		case ID_FREQ:
			Eingabe_Wechselspannung(DIFFERENZIERER_OP, U_AC_FREQUENZ);
			neuzeichnen = true;
			break;
		case ID_OP:
			Eingabe_Operationsverstaerker_Aufruf(DIFFERENZIERER_OP, OP_V_0_AENDERBAR | OP_U_B_AENDERBAR | OP_DELTA_U_AUS);
			break;
		case ID_CALC:
			Ergebnis_Differenzierer_OP_Aufruf(hDlg);
			break;
		case ID_OP_IDEAL:
			(IsDlgButtonChecked(hDlg, ID_OP_IDEAL) == BST_CHECKED) ? Differenzierer_OP.Idealer_OP = true : Differenzierer_OP.Idealer_OP = false;
			Daten_geaendert();
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Differenzierenden_OP(Differenzierer_OP);
			break;
		case IDCANCEL:
		case ID_CLOSE:
			EndDialog(hDlg, LOWORD(wParam)); break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
			InvalidateRect(hDlg, 0, true);
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of Differenzierer_OP_Dialog

// Meldungshandler f�r integrierenden OP-Verst�rker
INT_PTR CALLBACK Integrierer_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Funktion OK
	// �nderung 19.10.2019 Eingabefenster werden neben diesem Dialog angezeigt
	// �nderung 19.10.2019 Dialogfenster kann erst geschlossen werden, wenn alle Eingaben beendet sind
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	bool neuzeichnen = false;
	HICON hIcon;
	static int Anzahl_Dialoge; // Z�hlt die offenen Dialoge und erlaubt ein Schlie�en des Fensters erst, wenn alle Eingabe beendet sind

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Widerstandsbezeichner(cText, Integrierer_OP.R[R_OP_EIN], 99);
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		Bestimme_Kapazitaetsbezeichner(cText, Integrierer_OP.C, 99);
		SetDlgItemText(hDlg, ID_C1, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Integrierer_OP.U_Ein, 99);
		SetDlgItemText(hDlg, ID_U_EIN, (LPCSTR)cText);
		Bestimme_Frequenzbezeichner(cText, Integrierer_OP.freq, 99);
		SetDlgItemText(hDlg, ID_FREQ, (LPCSTR)cText);
		if (Integrierer_OP.Idealer_OP)
			SendMessage(GetDlgItem(hDlg, ID_OP_IDEAL), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_OP_IDEAL), BM_SETCHECK, 0, 0);

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OPSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
		{
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		}
		Anzahl_Dialoge = 0;
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		// Zu Beginn die Kn�pfe positionieren, die Daten aus der Resource-Datei weichen ab...
		MoveWindow(GetDlgItem(hDlg, ID_R1), 85, 90, 60, 40, true);  // funktioniert
		MoveWindow(GetDlgItem(hDlg, ID_C1), 275, 70, 60, 40, true);
		// Verschieben der zugeh�rigen Texte R1-R4
		MoveWindow(GetDlgItem(hDlg, ID_TXT_R1), 85, 75, 20, 13, true);
		MoveWindow(GetDlgItem(hDlg, ID_TXT_C1), 275, 110, 20, 13, true);
		// Verschieben des OP-Knopfs
		MoveWindow(GetDlgItem(hDlg, ID_OP), 220, 220, 60, 40, true);
		// Verschieben des U_Ein-Knopfes
		MoveWindow(GetDlgItem(hDlg, ID_U_EIN), 60, 180, 60, 40, true);
		// Verschieben des Frequenz-Knopfes
		MoveWindow(GetDlgItem(hDlg, ID_FREQ), 60, 230, 60, 40, true);
		Zeichne_Integrierenden_OP(Integrierer_OP, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		// sorgt mit der globalen Variablen Eingabe_Dialog_Positionieren f�r eine Platzierung der Eingabe neben dem
		// aktuellen Fenster
		Eingabe_Dialog.hDlg_Aufrufer = hDlg;

		switch (wParam)
		{
		case ID_R1:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(1, 1, INTEGRIERER_OP);
			Anzahl_Dialoge--;
			neuzeichnen = true;
			break;
		case ID_C1:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Kapazitaetswerte_Aufruf(1, 1, INTEGRIERER_OP);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_U_EIN:
			Anzahl_Dialoge++;
			Eingabe_Wechselspannung(INTEGRIERER_OP, U_AC_SPANNUNG);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_FREQ:
			Anzahl_Dialoge++;
			Eingabe_Wechselspannung(INTEGRIERER_OP, U_AC_FREQUENZ);
			Anzahl_Dialoge--;
			neuzeichnen = true;
			break;
		case ID_OP:
			Anzahl_Dialoge++;
			Eingabe_Operationsverstaerker_Aufruf(INTEGRIERER_OP, OP_V_0_AENDERBAR | OP_U_B_AENDERBAR | OP_DELTA_U_AUS);
			Anzahl_Dialoge--;
			break;
		case ID_CALC:
			Ergebnis_Integrierer_OP_Aufruf(hDlg);
			break;
		case ID_OP_IDEAL:
			(IsDlgButtonChecked(hDlg, ID_OP_IDEAL) == BST_CHECKED) ? Integrierer_OP.Idealer_OP = true : Integrierer_OP.Idealer_OP = false;
			Daten_geaendert();
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Integrierenden_OP(Integrierer_OP);
			break;
		case IDCANCEL:
		case ID_CLOSE:
			if (Anzahl_Dialoge==0)
				EndDialog(hDlg, LOWORD(wParam));
			else
				Warnung( (LPSTR)"Bitte erst die Eingabefenster beenden.");
			break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
			InvalidateRect(hDlg, 0, true);
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of Integrierender_OP_Dialog

// Meldungshandler f�r differenzierende OP-Schaltung
INT_PTR CALLBACK Ergebnis_Differenzierer_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];

	switch (message)
	{
	case WM_INITDIALOG:
	{
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OPSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		if (!Differenzierer_OP.Schaltung_berechenbar)
			SetDlgItemText(hDlg, ID_CAPTION, (LPCSTR)"Berechnung des differenzierenden Verst�rkers mit OP fehlerhaft!");
		if (Differenzierer_OP.U_Begrenzung)
			SetDlgItemText(hDlg, ID_BEGRENZUNG, (LPCSTR)"Ausgangsspannung des OPs au�erhalb des zul�ssigen Bereiches!");
		Bestimme_Bezeichner(cText, Differenzierer_OP.V_U, 99);
		SetDlgItemText(hDlg, ID_V_U, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Differenzierer_OP.U_Ein, 99);
		SetDlgItemText(hDlg, ID_U_EIN, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Differenzierer_OP.U_Aus, 99);
		SetDlgItemText(hDlg, ID_U_AUS, (LPCSTR)cText);
		Bestimme_Frequenzbezeichner(cText, Differenzierer_OP.freq, 99);
		SetDlgItemText(hDlg, ID_FREQ, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Differenzierer_OP.R_Ein, 99);
	//	SetDlgItemText(hDlg, ID_R_EIN, (LPCWSTR)Text);
		return (INT_PTR)TRUE;
	}
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz2, hStiftAlt;
		HBRUSH hPinselSchwarz, hPinselAlt;

		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Transistor einzeichnen

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
		hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
		hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);
		// Wieder wei�er Hintergrund
		SelectObject(hdc, hPinselAlt);
		// passenden OP zeichnen und Ein- und Ausgang andeuten
		Zeichne_OP(hdc, 400, 100, 100, 100, true);
		ZP_Linie(hdc, 380, 130, 400, 130);
		ZP_Linie(hdc, 380, 170, 400, 170);
		ZP_Linie(hdc, 500, 150, 520, 150);

		DeleteObject(hPinselSchwarz);
		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz2);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Ergebnis_Differenzierenden_OP_Dialog

  // Meldungshandler f�r differenzierende OP-Schaltung
INT_PTR CALLBACK Ergebnis_Integrierer_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];

	switch (message)
	{
	case WM_INITDIALOG:
	{
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OPSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		if (!Integrierer_OP.Schaltung_berechenbar)
			SetDlgItemText(hDlg, ID_CAPTION, (LPCSTR)"Berechnung des integrierenden Verst�rkers mit OP fehlerhaft!");
		if (Invertierender_OP.U_Begrenzung)
			SetDlgItemText(hDlg, ID_BEGRENZUNG, (LPCSTR)"Ausgangsspannung des OPs au�erhalb des zul�ssigen Bereiches!");
		Bestimme_Bezeichner(cText, Differenzierer_OP.V_U, 99);
		SetDlgItemText(hDlg, ID_V_U, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Integrierer_OP.U_Ein, 99);
		SetDlgItemText(hDlg, ID_U_EIN, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Integrierer_OP.U_Aus, 99);
		SetDlgItemText(hDlg, ID_U_AUS, (LPCSTR)cText);
		Bestimme_Frequenzbezeichner(cText, Integrierer_OP.freq, 99);
		SetDlgItemText(hDlg, ID_FREQ, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Integrierer_OP.R_Ein, 99);
		SetDlgItemText(hDlg, ID_R_EIN, (LPCSTR)cText);
		return (INT_PTR)TRUE;
	}
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz2, hStiftAlt;
		HBRUSH hPinselSchwarz, hPinselAlt;

		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Transistor einzeichnen

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
		hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
		hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);
		// Wieder wei�er Hintergrund
		SelectObject(hdc, hPinselAlt);
		// passenden OP zeichnen und Ein- und Ausgang andeuten
		Zeichne_OP(hdc, 400, 100, 100, 100, true);
		ZP_Linie(hdc, 380, 130, 400, 130);
		ZP_Linie(hdc, 380, 170, 400, 170);
		ZP_Linie(hdc, 500, 150, 520, 150);

		DeleteObject(hPinselSchwarz);
		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz2);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Ergebnis_Integrierenden_OP_Dialog

// Meldungshandler f�r addierenden OP-Verst�rker
INT_PTR CALLBACK Additions_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Funktion ok
	// �nderung 19.10.2019: Eingabefenster werden neben diesem Dialog gezeigt
	// �nderung 19.10.2019 Dialogfenster kann erst geschlossen werden, wenn alle Eingaben beendet sind
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	bool neuzeichnen = false;
	HICON hIcon;
	static int Anzahl_Dialoge; // Z�hlt die offenen Dialoge und erlaubt ein Schlie�en des Fensters erst, wenn alle Eingabe beendet sind

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Widerstandsbezeichner(cText, Summations_OP.R[R_OP_EIN_1], 99);
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Summations_OP.R[R_OP_EIN_2], 99);
		SetDlgItemText(hDlg, ID_R2, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Summations_OP.R[R_OP_SUMME_RUECKKOPPEL], 99);
		SetDlgItemText(hDlg, ID_R3, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Summations_OP.U_Ein, 99);
		SetDlgItemText(hDlg, ID_U_EIN, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Summations_OP.U_Ein_2, 99);
		SetDlgItemText(hDlg, ID_U_EIN_2, (LPCSTR)cText);
		if (Summations_OP.Idealer_OP)
			SendMessage(GetDlgItem(hDlg, ID_OP_IDEAL), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_OP_IDEAL), BM_SETCHECK, 0, 0);

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OPSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		// Zu Beginn die Kn�pfe positionieren, die Daten aus der Resource-Datei weichen ab...
		// Verschieben von R1-R3:
		MoveWindow(GetDlgItem(hDlg, ID_R2), 125, 140, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R3), 270, 120, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R1), 95, 40, 60, 40, true);
		// Verschieben der zugeh�rigen Texte R1-R2
		MoveWindow(GetDlgItem(hDlg, ID_TXT_R2), 125, 125, 20, 13, true);
		MoveWindow(GetDlgItem(hDlg, ID_TXT_R3), 270, 160, 20, 13, true);
		MoveWindow(GetDlgItem(hDlg, ID_TXT_R1), 95, 25, 20, 13, true);
		// Verschieben des OP-Knopfs
		MoveWindow(GetDlgItem(hDlg, ID_OP), 260, 270, 60, 40, false);
		// Verschieben des U_Ein-Knopfes
		MoveWindow(GetDlgItem(hDlg, ID_U_EIN), 50, 130, 60, 40, true);
		// Verschieben des U_Ein-Knopfes
		MoveWindow(GetDlgItem(hDlg, ID_U_EIN_2), 100, 230, 60, 40, true);
		Zeichne_Summierenden_OP(Summations_OP, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		// sorgt mit der globalen Variablen Eingabe_Dialog_Positionieren f�r eine Platzierung der Eingabe neben dem
		// aktuellen Fenster
		Eingabe_Dialog.hDlg_Aufrufer = hDlg;
		switch (wParam)
		{
		case ID_R1:
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Anzahl_Dialoge++;
			Eingabe_Widerstandswerte_Aufruf(1, 3, SUMMATIONS_OP);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_R2:
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Anzahl_Dialoge++;
			Eingabe_Widerstandswerte_Aufruf(2, 3, SUMMATIONS_OP);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_R3:
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Anzahl_Dialoge++;
			Eingabe_Widerstandswerte_Aufruf(3, 3, SUMMATIONS_OP);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_U_EIN:
			Anzahl_Dialoge++;
			Eingabe_Spannungswert_Aufruf(SUMMATIONS_OP, U_EIN_1);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_U_EIN_2:
			Anzahl_Dialoge++;
			Eingabe_Spannungswert_Aufruf(SUMMATIONS_OP_EINGANG_2, U_EIN_2);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_OP:
			Anzahl_Dialoge++;
			Eingabe_Operationsverstaerker_Aufruf(SUMMATIONS_OP, OP_V_0_AENDERBAR|OP_U_B_AENDERBAR|OP_DELTA_U_AUS );
			Anzahl_Dialoge--;
			break;
		case ID_CALC:
			Ergebnis_Summations_OP_Aufruf(hDlg);
			break;
		case ID_OP_IDEAL:
			(IsDlgButtonChecked(hDlg, ID_OP_IDEAL) == BST_CHECKED) ? Summations_OP.Idealer_OP = true : Summations_OP.Idealer_OP = false;
			Daten_geaendert();
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Summierenden_OP(Summations_OP);
			break;
		case IDCANCEL:
		case ID_CLOSE:
			EndDialog(hDlg, LOWORD(wParam)); break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
			InvalidateRect(hDlg, 0, true);
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of Additions_OP_Dialog

// Meldungshandler f�r Ergebnis invertierende OP-Schaltung
INT_PTR CALLBACK Ergebnis_Additions_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];

	switch (message)
	{
	case WM_INITDIALOG:
	{
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OPSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
		{
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		}
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		if (!Summations_OP.Schaltung_berechenbar)
			SetDlgItemText(hDlg, ID_CAPTION, (LPCSTR)"Berechnung des addierenden Verst�rkers mit OP fehlerhaft!");
		if (Summations_OP.U_Begrenzung)
			SetDlgItemText(hDlg, ID_BEGRENZUNG, (LPCSTR)"Ausgangsspannung des OPs au�erhalb des zul�ssigen Bereiches!");
		Bestimme_Bezeichner(cText, Summations_OP.V_U, 99);
		SetDlgItemText(hDlg, ID_V_U_1, (LPCSTR)cText);
		Bestimme_Bezeichner(cText, Summations_OP.V_U_2, 99);
		SetDlgItemText(hDlg, ID_V_U_2, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Summations_OP.R_Ein, 99);
		SetDlgItemText(hDlg, ID_R_EIN_1, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Summations_OP.R_Ein_2, 99);
		SetDlgItemText(hDlg, ID_R_EIN_2, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Summations_OP.U_Ein, 99);
		SetDlgItemText(hDlg, ID_U_EIN_1, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Summations_OP.U_Ein_2, 99);
		SetDlgItemText(hDlg, ID_U_EIN_2, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Summations_OP.U_Aus, 99);
		SetDlgItemText(hDlg, ID_U_AUS, (LPCSTR)cText);
		return (INT_PTR)TRUE;
	}
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz2, hStiftAlt;
		HBRUSH hPinselSchwarz, hPinselAlt;

		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Transistor einzeichnen

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
		hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
		hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);
		SelectObject(hdc, hPinselAlt);	// Wieder wei�er Hintergrund

										// passenden OP zeichnen und Ein- und Ausgang andeuten
		Zeichne_OP(hdc, 400, 100, 100, 100, true);
		ZP_Linie(hdc, 380, 130, 400, 130);
		ZP_Linie(hdc, 380, 170, 400, 170);
		ZP_Linie(hdc, 500, 150, 520, 150);

		DeleteObject(hPinselSchwarz);
		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz2);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case IDCANCEL: 
			EndDialog(hDlg, LOWORD(wParam)); 
			break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Ergebnis_Invertierender_OP_Dialog

// Meldungshandler f�r Zeichne_OP-Bodeplot
INT_PTR CALLBACK Zeichne_OP_Bodeplot_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	bool neuzeichnen = false;
	HICON hIcon;
	bool eingabe_ok = false;

	switch (message)
	{
		case WM_INITDIALOG:
		{
			char cText[40];
			// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
	
			hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_OP_STABILITAET), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
			if (hIcon)
				SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
			// Werte f�r Amplituden- und Phasenreserve eintragen
			Bestimme_Bezeichner_wissenschaftlich(cText, OP_Bode.Amplitudenreserve, 39);
			SetDlgItemText(hDlg, ID_AMPLITUDENRESERVE, (LPCSTR)cText);
			Bestimme_Bezeichner_wissenschaftlich(cText, OP_Bode.Phasenreserve, 39);
			SetDlgItemText(hDlg, ID_PHASENRESERVE, (LPCSTR)cText);
			return (INT_PTR)TRUE;
		}
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hDlg, &ps);
	
			// Hintergrund l�schen
			FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
			SetPolyFillMode(hdc, WINDING);
			Zeichne_Bodeplot(OP_Bode, hdc, false);
	
			EndPaint(hDlg, &ps);
		}
		return TRUE;
	
		case WM_COMMAND:
		{
			double wert_Amplitudenreserve, wert_Phasenreserve;

			switch (wParam)
			{
			case ID_OP:
				Eingabe_Operationsverstaerker_Aufruf(OP_BODEPLOT, OP_V_0_DB_AENDERBAR | OP_GRENZFREQ_AENDERBAR);
				neuzeichnen = true;
				break;
			case ID_AKTUALISIEREN:
				eingabe_ok = true;
				// Eingabe holen:
				wert_Amplitudenreserve = Eingabe_parsen(hDlg, ID_AMPLITUDENRESERVE);
				if (wert_Amplitudenreserve <= 0.0)
				{
					Warnung("Wert f�r Amplitudenreserve muss gr��er 0dB sein!");
					SetDlgItemText(hDlg, ID_AMPLITUDENRESERVE, (LPSTR)"20");
					eingabe_ok = false;
				}
				if (wert_Amplitudenreserve+OP_Bode.Betrag_bei_f_Instabil > OP_Bode.V_0_dB)
				{
					Warnung("Wert f�r Amplitudenreserve plus Verst�rkung bei Instabilit�t darf nicht gr��er als Leerlaufverst�rkung sein!");
					SetDlgItemText(hDlg, ID_AMPLITUDENRESERVE, (LPSTR)"20");
					eingabe_ok = false;
				}
				wert_Phasenreserve = Eingabe_parsen(hDlg, ID_PHASENRESERVE);
				if (wert_Phasenreserve <= 0.0)
				{
					Warnung("Wert f�rPhasenreserve muss gr��er als 0� sein!");
					SetDlgItemText(hDlg, ID_PHASENRESERVE, (LPSTR)"45");
					eingabe_ok = false;
				}
				if (wert_Phasenreserve > 180.0)
				{
					Warnung("Wert f�rPhasenreserve muss kleiner als 180� sein!");
					SetDlgItemText(hDlg, ID_PHASENRESERVE, (LPSTR)"45");
					eingabe_ok = false;
				}
				neuzeichnen = true; // Immer neu zeichnen, da bei Fehlern neue Werte gesetzt werden. 
				if (eingabe_ok)
				{
					OP_Bode.Amplitudenreserve = wert_Amplitudenreserve;
					OP_Bode.Phasenreserve = wert_Phasenreserve;	
				}
				break;
			case ID_COPY_CLIPBOARD:
				// Neu berechnen
				Berechne_Bodeplot_OP(&OP_Bode);
				Kopiere_Bodeplot(OP_Bode);
				break;
			case IDOK:
				// Eingabe speichern, wenn fehlerfrei?
			case IDCANCEL:
			case ID_CLOSE:
				EndDialog(hDlg, LOWORD(wParam)); break;
			}
			if (neuzeichnen)
			{
				// Neu berechnen und zeichnen
				Berechne_Bodeplot_OP(&OP_Bode);
				InvalidateRect(hDlg, 0, true);
			}
			break;
		}
	}
	return (INT_PTR)FALSE;
}	// end of OP_Bodeplot_Dialog

