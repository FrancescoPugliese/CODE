#include "stdafx.h"
/*******************************************************************************************************************\
|																													|
| Modul Transistor-Schaltungen.cpp																					|
|																													|
| In diesem Modul sind die Funtkionen zur Berechnung der Transistorschaltungen (Differenzverst�rker, 				|
| Transistor als Schalter, ...) enthalten																			|
| - Berechne_Bipolartransistor_als_Schalter();																		|
| - Berechne_Differenzverstaerker();																				|
| - Differenzverstaerker_Bipolar_Aufruf();																			|
| - Ergebnis_Bipolartransistor_als_Schalter_Aufruf();																|
| - Ergebnis_Differenzverstaerker_Aufruf();																			|
| - init_Transistor_als_Schalter();																					|
| - init_Differenzverstaerker();																					|
| - Kopiere_Differenzverstaerker_bipolar();																			|
| - Kopiere_Ergebnis_Differenzverstaerker();																		|
| - Kopiere_Transistor_als_Schalter();																				|
| - r_Ein_Differenzverstaerker_Wechsel();																			|
| - r_Ein_Differenzverstaerker_Gleichtakt();																		|
| - Transistor_als_Schalter_Aufruf();																				|
| - V_U_Differenzverstaerker_Wechsel();																				|
| - V_U_Differenzverstaerker_Gleichtakt();																			|
| - Zeichne_Transistor_als_Schalter();																				|
| - Zeichne_Differenzverstaerker_bipolar();																			|
|  																													|
\*******************************************************************************************************************/

// Transistor als Schalter
int init_Transistor_als_Schalter(Schalter_Bipolartransistor *Schalt_Trans)
{
	Schalt_Trans->Beta = 150.0;
	Schalt_Trans->neue_Schaltung = true;
	Schalt_Trans->m = 3.0;
	Schalt_Trans->NPN = true;
	Schalt_Trans->R[0] = 1000.0;
	Schalt_Trans->R[1] = 50.0;
	Schalt_Trans->R[2] = 100000.0;
	// R[0]: Basiswiderstand in Reihe, R[1]: Lastwiderstand, R[2]: Basiswiderstand an Masse (Ableitwiderstand)
	// C: Kondensator parallel zu R[1]
	// Berechnung ohne Kapazit�t C!
	Schalt_Trans->C = 1.0e-3;
	Schalt_Trans->U_B = 12.0;
	Schalt_Trans->U_Schalt = 5.0;
	Schalt_Trans->U_BE = 0.6;
	Schalt_Trans->U_CE_Sat = 0.4;
	Schalt_Trans->I_CB_Sperr = 10.0;	// Sperrstrom in �A
	Schalt_Trans->I_B = 0.0;
	Schalt_Trans->I_C = 0.0;
	Schalt_Trans->I_E = 0.0;
	Schalt_Trans->I_Ableit = 0.0;
	Schalt_Trans->U_Basis = 0.0;
	Schalt_Trans->U_C = 0.0;
	Schalt_Trans->U_E = 0.0;
	Schalt_Trans->U_BE_Sperr = 0.0;
	Schalt_Trans->Schaltung_berechenbar = false;
	return 0;
}	// end of init_Transistor_als_Schalter

int Transistor_als_Schalter_Aufruf(HWND hDlg)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_TRANSISTOR_SCHALT), hDlg, Transistor_als_Schalter_Dialog);
	return 0;
}

int Berechne_Bipolartransistor_als_Schalter(void)
{
	// Berechnung der Schaltung: 1. Bestimmung des Laststromes, 2. Bestimmung des Stromes durch R1, Subtraktion des Ableitstromes, 3. Berechnung des �bersteuerungsfaktors m
	Bipolartransistor_als_Schalter.I_C = (Bipolartransistor_als_Schalter.U_B - Bipolartransistor_als_Schalter.U_CE_Sat) / Bipolartransistor_als_Schalter.R[1];
	Bipolartransistor_als_Schalter.I_Ableit = Bipolartransistor_als_Schalter.U_BE / Bipolartransistor_als_Schalter.R[2];
	Bipolartransistor_als_Schalter.I_B = (Bipolartransistor_als_Schalter.U_Schalt - Bipolartransistor_als_Schalter.U_BE) / Bipolartransistor_als_Schalter.R[0] - Bipolartransistor_als_Schalter.I_Ableit;
	Bipolartransistor_als_Schalter.I_E = Bipolartransistor_als_Schalter.I_C + Bipolartransistor_als_Schalter.I_B;
	Bipolartransistor_als_Schalter.U_BE_Sperr = Bipolartransistor_als_Schalter.I_CB_Sperr * 1.0e-6 * Bipolartransistor_als_Schalter.R[2]; // I_CB_Sperr in �A
	Bipolartransistor_als_Schalter.m = Bipolartransistor_als_Schalter.I_B * Bipolartransistor_als_Schalter.Beta / Bipolartransistor_als_Schalter.I_C;
	if (Bipolartransistor_als_Schalter.U_BE_Sperr > Bipolartransistor_als_Schalter.U_B)
		Bipolartransistor_als_Schalter.Schaltung_berechenbar = false;	// Basisspannung aus Sperrstrom h�her als U_B
	else
		Bipolartransistor_als_Schalter.Schaltung_berechenbar = true;
	Bipolartransistor_als_Schalter.neue_Schaltung = false;	// Schaltung berechnet

	return 0;
}

int Ergebnis_Bipolartransistor_als_Schalter_Aufruf(HWND hDlg)
{
	// Berechnung der Schaltung 
	Berechne_Bipolartransistor_als_Schalter();
	DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_TRANSISTOR_SCHALT), hDlg, Ergebnis_Bipolartransistor_als_Schalter_Dialog);


	return 0;
}	// end of Ergebnis_Bipolartransistor_als_Schalter_Aufruf

int Zeichne_Transistor_als_Schalter(Schalter_Bipolartransistor Schalt, HDC hdc, bool Kopie_Zwischenablage)
{
	UNREFERENCED_PARAMETER(Schalt);
	HPEN hStiftSchwarz2, hStiftAlt;
	HBRUSH hPinselSchwarz, hPinselAlt;
	HFONT FontNeu = NULL, FontAlt = NULL;
	char cText[100];

	// Fenster neu zeichnen: Emitterschaltung mit Widerst�nden, Transistor und Spannungsquelle

	SetPolyFillMode(hdc, WINDING);

	hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
	hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
	hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
	hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);	// F�llfarbe vorher auf Schwarz

	SetTextColor(hdc, RGB(0, 0, 0));
	if (Kopie_Zwischenablage)
	{
		// Beschriftung erg�nzen am besten in Arial
		FontNeu = CreateFont(24, // nHeight
			0,	// nWidth
			0,	// nEscapement
			0,	// nOrientation
			FW_DONTCARE, //fnWeight
			FALSE,	//fdwItalic
			FALSE,	//fdwUnderline
			FALSE,	//fdwStrikeOut
			DEFAULT_CHARSET,	//fdwCharSet
			OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
			CLIP_DEFAULT_PRECIS, //fdwClipPrecision
			CLEARTYPE_QUALITY,	//fdwQuality
			VARIABLE_PITCH,		//fdwPitchAndFamily
			TEXT("Arial"));	//lpszFace
		FontAlt = (HFONT)SelectObject(hdc, FontNeu);
		SetTextAlign(hdc, TA_LEFT);
	}

	if (Kopie_Zwischenablage)
	{ // Ausgabe Zwischenablage
		Zeichne_Text_xy(hdc, "R1", 150, 265);
		Bestimme_Widerstandsbezeichner(cText, Bipolartransistor_als_Schalter.R[0], 99);
		Zeichne_Text_xy(hdc, cText, 150, 290);
		Zeichne_Text_xy(hdc, "R3", 270, 280);
		Bestimme_Widerstandsbezeichner(cText, Bipolartransistor_als_Schalter.R[2], 99);
		Zeichne_Text_xy(hdc, cText, 270, 305);
		Zeichne_Text_xy(hdc, "C1", 190, 120);
		Zeichne_Text_xy(hdc, "T1", 400, 240);
		Zeichne_Text_xy(hdc, "U_Schalt", 55, 280);
		Bestimme_Spannungsbezeichner(cText, Bipolartransistor_als_Schalter.U_Schalt, 99);
		Zeichne_Text_xy(hdc, cText, 55, 305);
		SetTextAlign(hdc, TA_RIGHT);
		Zeichne_Text_xy(hdc, "R2", 375, 60);
		Bestimme_Widerstandsbezeichner(cText, Bipolartransistor_als_Schalter.R[1], 99);
		Zeichne_Text_xy(hdc, cText, 375, 85);
		Zeichne_Text_xy(hdc, "U_B", 490, 70);
		Bestimme_Spannungsbezeichner(cText, Bipolartransistor_als_Schalter.U_B, 99);
		Zeichne_Text_xy(hdc, cText, 490, 95);
	}
	else
	{ // Ausgabe Dialogbox
		Zeichne_Text_xy(hdc, "R1", 150, 315);
		Zeichne_Text_xy(hdc, "R2", 320, 50);
		Zeichne_Text_xy(hdc, "R3", 270, 330);
		Zeichne_Text_xy(hdc, "C1", 190, 130);
	}

	// Zeichnen der Verbindungspunkte vorab
	Ellipse_BH(hdc, 95, 245, 10, 10);
	Ellipse_BH(hdc, 245, 245, 10, 10);
	Ellipse_BH(hdc, 245, 145, 10, 10);
	Ellipse_BH(hdc, 395, 145, 10, 10);

	SelectObject(hdc, hPinselAlt);		// Wieder auf wei�en Hintergrund umschalten

										//Anschlusspunkte links zeichen, Positionen (Mitte): x: 50; y:250; 370
	Zeichne_Anschluss(hdc, 40, 240, 120);
	// Leitung f�r R1 (linke Seite) x: 60-155, y:250
	ZP_Linie(hdc, 60, 250, 155, 250);
	// Leitung f�r R1 bis Transistor x: 205-350, y: 250
	ZP_Linie(hdc, 205, 250, 350, 250);
	// Leitung f�r Kondensator C1 links x: 100-165, y: 250-150
	DP_Linie(hdc, 100, 250, 100, 150, 165, 150);
	// Leitung f�r Kondensator C1 rechts: x: 185-250, y: 150-280
	DP_Linie(hdc, 185, 150, 250, 150, 250, 280);
	// Leitung f�r Antis�ttigungsdiode x: 250-300, y: 150 und x: 340-400, y: 150
	ZP_Linie(hdc, 250, 150, 340, 150);
	ZP_Linie(hdc, 340, 150, 400, 150);
	// Schottky-Diode einzeichnen x: 300-340, y: 120-180
	VP_Linie(hdc, 340, 150, 300, 180, 300, 120, 340, 150);
	VP_Linie(hdc, 350, 120, 340, 120, 340, 180, 330, 180);
	// Leitung von Kollektor bis Lastwiderstand x: 400, y: 200-120
	ZP_Linie(hdc, 400, 200, 400, 120);
	// Spannungsquelle x: 510-570, y: 70-130
	Zeichne_Gleichspannungsquelle(hdc, 510, 70, 60, DC_QUELLE_MASSE, 30);
	// Leitung von Lastwiderstand bis Spannungsquelle x: 400-540, y: 70-30-150
	VP_Linie(hdc, 400, 70, 400, 30, 540, 30, 540, 150);
	// Emitteranschluss und Masse x: 400, y: 300-350 und x: 385-415, y: 350
	ZP_Linie(hdc, 400, 300, 400, 350);
	ZP_Linie(hdc, 385, 350, 415, 350);
	// Masse unterhalb des Ableitwiderstandes x: 250, y: 280-350 und x: 235-265, y: 350
	ZP_Linie(hdc, 250, 280, 250, 350);
	ZP_Linie(hdc, 235, 350, 265, 350);

	// Kondensator Position: x: 165, 185 y: 100-250
	Zeichne_Kondensator(hdc, 165, 100, 20, 100, C_HORIZONTAL);

	//Widerst�nde R1, R2, R3 Positionen: x=145, y=235 und x=235, y=220 und x=335, y=70
	Zeichne_Widerstand(hdc, 145, 235, 60, 30);
	Zeichne_Widerstand(hdc, 235, 270, 30, 60);
	Zeichne_Widerstand(hdc, 385, 60, 30, 60);
	SelectObject(hdc, hPinselSchwarz);
	// NPN-Transistor zeichnen
	// Transistor (NPN) Position: x: 350 (350-400) y: 200-300
	Zeichne_Bipolartransistor(hdc, 350, 200, 50, 100, NPN_TRANSISTOR, 0);
	SelectObject(hdc, hPinselAlt);		// Wieder auf wei�e Fl�che zur�ck...

	SelectObject(hdc, hPinselAlt);
	DeleteObject(hPinselSchwarz);
	SelectObject(hdc, hStiftAlt);
	DeleteObject(hStiftSchwarz2);

	if (Kopie_Zwischenablage)
	{
		SelectObject(hdc, FontAlt);
		DeleteObject(FontNeu);
	}

	return 0;
} // end of Zeichne_Transistor_als_Schalter

int Kopiere_Transistor_als_Schalter(Schalter_Bipolartransistor Schalt)
{
	HDC hdcMeta;
	HENHMETAFILE hMeta;

	hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
	// Schaltung zeichnen
	Zeichne_Transistor_als_Schalter(Schalt, hdcMeta, true);
	hMeta = CloseEnhMetaFile(hdcMeta);
	// Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
	OpenClipboard(hWndElektronikMain);
	EmptyClipboard();
	SetClipboardData(CF_ENHMETAFILE, hMeta);
	CloseClipboard();

	return 0;
} // end of Kopiere_Transistor_als_Schalter

// Differenzverst�rker bipolar
int init_Differenzverstaerker(Diff_verstaerker *Diff_V)
{
	Diff_V->neue_Schaltung = true;
	Diff_V->R[0] = 1000.0;
	Diff_V->R[1] = 500.0;
	Diff_V->R[2] = 200.0;
	Diff_V->R[3] = 5000.0;
	Diff_V->Beta_T1 = 150;
	Diff_V->Beta_T2 = 150;
	Diff_V->U_BE_T1 = 0.6;
	Diff_V->U_BE_T2 = 0.6;
	Diff_V->U_AF_T1 = 50.0;
	Diff_V->U_B = 15.0;
	Diff_V->U_Ref = -9.0;
	Diff_V->U_C = 6.0;
	Diff_V->NPN_T1 = true;
	Diff_V->NPN_T2 = true;
	Diff_V->verwende_Stromquelle = false;
	Diff_V->r_CE_hochohmig=false;
	Diff_V->I_B = 0.0;
	Diff_V->I_C = 0.0;
	Diff_V->I_E = 0.0;
	Diff_V->I_Gemeinsam = 0.0;
	Diff_V->I_B_T2 = 0.0;
	Diff_V->I_C_T2 = 0.0;
	Diff_V->I_E_T2 = 0.0;	// T2: Stromquellentransistor
	Diff_V->U_Basis = 0.0;
	Diff_V->U_C = 0.0;
	Diff_V->U_E = 0.0;
	Diff_V->U_Basis_T2;
	Diff_V->U_C_T2;
	Diff_V->U_E_T2;
	Diff_V->V_U_Wechsel = 0.0;
	Diff_V->V_U_Gleichtakt = 0.0;
	Diff_V->CMRR = 0.0;
	Diff_V->r_Ein_AC = 0.0;
	Diff_V->r_Ein_DC = 0.0;
	Diff_V->V_U_Gleichtakt_ist_Null = true;
	Diff_V->neue_Schaltung = true;
	Diff_V->Schaltung_berechenbar = false;

	return 0;
}	// end of init_Transistor_als_Schalter

int Differenzverstaerker_Bipolar_Aufruf(HWND hDlg)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_DIFFERENZVERSTAERKER), hDlg, Differenzverstaerker_Bipolar_Dialog);
	return 0;
}

int Berechne_Differenzverstaerker(struct Diff_verstaerker *Differenz_Verstaerker)
{
	Differenz_Verstaerker->Schaltung_berechenbar = true;

	// Trennung in Diff-verst�rker mit Stromsenke und ohne
	if (Differenz_Verstaerker->verwende_Stromquelle)
	{
		// mit Stromquellentransistor
		// Zuerst Berechnung des Stromquellentransistors:
		Differenz_Verstaerker->U_Basis_T2 = Differenz_Verstaerker->U_Ref;
		Differenz_Verstaerker->U_E_T2 = Differenz_Verstaerker->U_Basis_T2 - Differenz_Verstaerker->U_BE_T2;
		if (Differenz_Verstaerker->R[3] != 0.0) // R[3]: gemeinsamer Emitterwiderstand
			Differenz_Verstaerker->I_E_T2 = (Differenz_Verstaerker->U_E_T2 + Differenz_Verstaerker->U_B) / Differenz_Verstaerker->R[3];
		else
		{
			Differenz_Verstaerker->Schaltung_berechenbar = false;
			Warnung("Gemeinsamer Widerstand im Emitterpfad ist 0Ohm. Schaltung nicht berechenbar!");
			Differenz_Verstaerker->I_E_T2 = 10.0e-3;
		}
		Differenz_Verstaerker->I_B_T2 = Differenz_Verstaerker->I_E_T2 / (Differenz_Verstaerker->Beta_T2 + 1.0);
		Differenz_Verstaerker->I_C_T2 = Differenz_Verstaerker->I_B_T2 * Differenz_Verstaerker->Beta_T2;
		// Jetzt geht es hoch zum Parallelzweig:
		Differenz_Verstaerker->I_E = Differenz_Verstaerker->I_C_T2 / 2.0;
		Differenz_Verstaerker->I_B = Differenz_Verstaerker->I_E / (Differenz_Verstaerker->Beta_T1 + 1.0);
		Differenz_Verstaerker->I_C = Differenz_Verstaerker->I_B * Differenz_Verstaerker->Beta_T1;

		Differenz_Verstaerker->U_Basis = -Differenz_Verstaerker->I_B * Differenz_Verstaerker->R[1]; // R[1]: Basiswiderst�nde
		Differenz_Verstaerker->U_E = Differenz_Verstaerker->U_Basis - Differenz_Verstaerker->U_BE_T1;
		// Jetzt kann auch die Kollektorspannung von T2 bestimmt werden:
		Differenz_Verstaerker->U_C_T2 = Differenz_Verstaerker->U_E - Differenz_Verstaerker->I_E * Differenz_Verstaerker->R[2]; // R[2]: Emitterwiderstand
		// Kollektorspannung von T1:
		Differenz_Verstaerker->U_C = Differenz_Verstaerker->U_B - Differenz_Verstaerker->I_C * Differenz_Verstaerker->R[0];
		// Damit ist die Schaltung berechnet
	}
	else
	{
		// ohne Stromquelle
		// vorab werden alle Spannungen und Str�me von T2 auf 0 gesetzt
		Differenz_Verstaerker->I_B_T2 = 0.0;
		Differenz_Verstaerker->I_C_T2 = 0.0;
		Differenz_Verstaerker->I_E_T2 = 0.0;
		Differenz_Verstaerker->U_Basis_T2 = 0.0;
		Differenz_Verstaerker->U_C_T2 = 0.0;
		Differenz_Verstaerker->U_E_T2 = 0.0;

		// Berechnung des Basisstromes
		Differenz_Verstaerker->I_B = (Differenz_Verstaerker->U_B - Differenz_Verstaerker->U_BE_T1) / ( (Differenz_Verstaerker->Beta_T1 + 1.0)*(Differenz_Verstaerker->R[2] + Differenz_Verstaerker->R[3] * 2.0) + Differenz_Verstaerker->R[1]);
		// R[1]: Basiswiderst�nde, R[2]: Emitterwiderst�nde

		Differenz_Verstaerker->I_C = Differenz_Verstaerker->I_B * Differenz_Verstaerker->Beta_T1;
		Differenz_Verstaerker->I_E = Differenz_Verstaerker->I_B * (Differenz_Verstaerker->Beta_T1 + 1.0);

		Differenz_Verstaerker->U_Basis = -Differenz_Verstaerker->I_B * Differenz_Verstaerker->R[1]; // R[1]: Basiswiderst�nde
		Differenz_Verstaerker->U_E = Differenz_Verstaerker->U_Basis - Differenz_Verstaerker->U_BE_T1;
		Differenz_Verstaerker->U_C = Differenz_Verstaerker->U_B - Differenz_Verstaerker->I_C * Differenz_Verstaerker->R[0]; // R[0]: Kollektorwiderst�nde
	}

	if (Differenz_Verstaerker->verwende_Stromquelle)
	{
		if (Differenz_Verstaerker->U_C_T2 <= Differenz_Verstaerker->U_E_T2)
			Differenz_Verstaerker->Schaltung_berechenbar = false;
		if (Differenz_Verstaerker->U_Basis_T2 <= Differenz_Verstaerker->U_E_T2)
			Differenz_Verstaerker->Schaltung_berechenbar = false;
	}
	if (Differenz_Verstaerker->U_C <= Differenz_Verstaerker->U_E)
		Differenz_Verstaerker->Schaltung_berechenbar = false;

	// Berechnung der Verst�rkung
	Differenz_Verstaerker->V_U_Wechsel = V_U_Differenzverstaerker_Wechsel(*Differenz_Verstaerker);
	Differenz_Verstaerker->V_U_Gleichtakt = V_U_Differenzverstaerker_Gleichtakt(*Differenz_Verstaerker);
	if (Differenz_Verstaerker->V_U_Gleichtakt == 0.0)
		Differenz_Verstaerker->V_U_Gleichtakt_ist_Null = true;
	else
	{
		Differenz_Verstaerker->V_U_Gleichtakt_ist_Null = false;
		Differenz_Verstaerker->CMRR = Differenz_Verstaerker->V_U_Wechsel / Differenz_Verstaerker->V_U_Gleichtakt;
	}
	Differenz_Verstaerker->r_Ein_AC = r_Ein_Differenzverstaerker_Wechsel(*Differenz_Verstaerker);
	Differenz_Verstaerker->r_Ein_DC = r_Ein_Differenzverstaerker_Gleichtakt(*Differenz_Verstaerker);

	return 0;
}

int Ergebnis_Differenzverstaerker_Aufruf(HWND hDlg)
{
	// Berechnung der Schaltung 
	Berechne_Differenzverstaerker(&Differenzverstaerker);
	DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_DIFFERENZVERSTAERKER), hDlg, Ergebnis_Differenzverstaerker_Dialog);

	return 0;
}	// end of Ergebnis_Differenzverstaerker_Aufruf

double V_U_Differenzverstaerker_Wechsel( struct Diff_verstaerker Differenz_Verstaerker )
{
	double rueckgabe = 0.0;

	// Berechnung der Differenzverstaerkung:
	// ohne Emitterwiderstaende: -beta * (R_C || r_CE) / ( 2 * r_BE )
	// mit Emitterwiderstaenden: -R_C / ( 2 * R_E )

	if (Differenzverstaerker.R[2] == 0)	// R[2]: Emitterwiderst�nde
	{
		double r_CE_T1=1.0e9, r_BE_T1, U_T_T1 = 0.026;

		r_BE_T1 = r_BE(Differenz_Verstaerker.I_B, U_T_T1);
		// Bei Gelegenheit sollte hier der richtige Kleinsignalwiderstand bestimmt werden. 
		if (!Differenz_Verstaerker.r_CE_hochohmig)
			r_CE_T1 =  r_CE( Differenzverstaerker.U_C-Differenzverstaerker.U_E, Differenzverstaerker.U_AF_T1, Differenzverstaerker.I_C );
		if (r_BE_T1 == 0.0)
		{
			Warnung("Basis-Emitter-Widerstand ist 0!");
			r_BE_T1 = 1.0;
		}
		if (Differenz_Verstaerker.r_CE_hochohmig)
			rueckgabe = -Differenz_Verstaerker.Beta_T1 * Differenz_Verstaerker.R[0] / 2.0 / r_BE_T1;
		else
			rueckgabe = -Differenz_Verstaerker.Beta_T1 * Parallelschaltung(Differenz_Verstaerker.R[0], r_CE_T1) / 2.0 / r_BE_T1;
	}
	else
	{
		// Emitterwiderst�nde vorhanden:
		// R[0]: Kollektorwiderst�nde, R[2]: Emitterwiderst�nde
		rueckgabe = -Differenz_Verstaerker.R[0] / (2.0*Differenz_Verstaerker.R[2]);
	}
	return rueckgabe;
}	// end of V_U_Differenzverstaerker_Wechsel

double V_U_Differenzverstaerker_Gleichtakt(struct Diff_verstaerker Differenz_Verstaerker)
{
	double rueckgabe = 0.0;

	// Berechnung der Gleichtakt-Differenzverstaerkung:
	// ohne Stromquelle:
	// ohne Emitterwiderstaende: -R_C / ( 2 * R_0 )
	// mit Emitterwiderstaenden: -R_C / ( 2 * R_0 + R_E )
	// mit Stromquelle: 0

	if (Differenz_Verstaerker.verwende_Stromquelle)
	{
		rueckgabe = 0.0;
	}
	else
	{
		// R[0]: Kollektorwiderst�nde, R[2]: Emitterwidert�nde, R[3]: gemeinsamer Widerstand
		rueckgabe = -Differenz_Verstaerker.R[0] / (2.0 * Differenz_Verstaerker.R[3] + Differenz_Verstaerker.R[2]);
	}
	return rueckgabe;
}	// end of V_U_Differenzverstaerker_Gleichtakt

double r_Ein_Differenzverstaerker_Wechsel(struct Diff_verstaerker Differenz_Verstaerker)
{
	double rueckgabe = 0.0, U_T_T1 = 0.026;

	// Berechnung des Wechsel-Eingangswiderstands r_D:
	// ohne Emitterwiderstaende: 2.0 * r_BE
	// mit Emitterwiderstaenden: 2.0 * beta * R_E

	if (Differenz_Verstaerker.R[2] == 0)
	{
		rueckgabe = 2.0 * r_BE(Differenz_Verstaerker.I_B, U_T_T1);
	}
	else
	{
		// R[0]: Kollektorwiderst�nde, R[2]: Emitterwidert�nde, R[3]: gemeinsamer Widerstand
		rueckgabe = 2.0 * Differenz_Verstaerker.Beta_T1 * Differenz_Verstaerker.R[2];
	}
	return rueckgabe;
}	// end of r_Ein_Differenzverstaerker_Wechsel

double r_Ein_Differenzverstaerker_Gleichtakt(struct Diff_verstaerker Differenz_Verstaerker)
{
	double rueckgabe = 0.0;

	// Berechnung des Wechsel-Eingangswiderstands r_D:
	// 2.0 * beta * R_0; mit Stromquelle hochohmig??? -> nach einfacher Simulation eher umgekehrter Effekt

	if (Differenz_Verstaerker.verwende_Stromquelle)
	{
		rueckgabe = 1.0e9;  // N�herungswert: 1GOhm, vielleicht geht es auch genauer?
	}
	else
	{
		// R[0]: Kollektorwiderst�nde, R[2]: Emitterwidert�nde, R[3]: gemeinsamer Widerstand
		rueckgabe = 2.0 * Differenz_Verstaerker.Beta_T1 * Differenz_Verstaerker.R[3];
	}
	return rueckgabe;
}	// end of r_Ein_Differenzverstaerker_Gleichtakt

int Zeichne_Differenzverstaerker_bipolar(Diff_verstaerker DV, HDC hdc, bool Kopie_Zwischenablage)
{
	HPEN hStiftSchwarz2, hStiftAlt;
	HBRUSH hPinselSchwarz, hPinselAlt;
	HFONT FontNeu=NULL, FontAlt;
	char cText[100];
	int Schriftgroesse = 16;

	if (Kopie_Zwischenablage)
		Schriftgroesse = 24;

	// Beschriftung erg�nzen am besten in Arial
	FontNeu = CreateFont(Schriftgroesse, // nHeight
		0,	// nWidth
		0,	// nEscapement
		0,	// nOrientation
		FW_DONTCARE, //fnWeight
		FALSE,	//fdwItalic
		FALSE,	//fdwUnderline
		FALSE,	//fdwStrikeOut
		DEFAULT_CHARSET,	//fdwCharSet
		OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
		CLIP_DEFAULT_PRECIS, //fdwClipPrecision
		CLEARTYPE_QUALITY,	//fdwQuality
		VARIABLE_PITCH,		//fdwPitchAndFamily
		TEXT("Arial"));	//lpszFace
	FontAlt = (HFONT)SelectObject(hdc, FontNeu);
	SetTextAlign(hdc, TA_LEFT);


	// Zahlenwerte ausgeben, wenn Kopie Zwischenablage
	if (Kopie_Zwischenablage)
	{
		Zeichne_Text_xy(hdc, "R1", 270, 75);
		Zeichne_Text_xy(hdc, "R1", 470, 75);
		Zeichne_Text_xy(hdc, "R2", 160, 295);
		Zeichne_Text_xy(hdc, "R2", 560, 295);
		Zeichne_Text_xy(hdc, "R3", 270, 275);
		Zeichne_Text_xy(hdc, "R3", 470, 300);
		Zeichne_Text_xy(hdc, "R4", 370, 525);

		Bestimme_Widerstandsbezeichner(cText, DV.R[0], 99);	// Kollektorwiderst�nde
		Zeichne_Text_xy(hdc, cText, 270, 100);
		Zeichne_Text_xy(hdc, cText, 470, 100);
		Bestimme_Widerstandsbezeichner(cText, DV.R[1], 99);	// Basiswiderst�nde
		Zeichne_Text_xy(hdc, cText, 160, 330);
		Zeichne_Text_xy(hdc, cText, 560, 330);
		Bestimme_Widerstandsbezeichner(cText, DV.R[2], 99);	// Emitterwiderst�nde
		Zeichne_Text_xy(hdc, cText, 270, 300);
		Zeichne_Text_xy(hdc, cText, 470, 330);
		Bestimme_Widerstandsbezeichner(cText, DV.R[3], 99);	// Emitterwiderstand Stromsenke
		Zeichne_Text_xy(hdc, cText, 370, 550);
		SetTextAlign(hdc, TA_RIGHT);
		Bestimme_Spannungsbezeichner(cText, DV.U_B, 99);
		Zeichne_Text_xy(hdc, cText, 600, 95);
		Zeichne_Text_xy(hdc, "U_B", 600, 70);
		Bestimme_Spannungsbezeichner(cText, -DV.U_B, 99);
		Zeichne_Text_xy(hdc, cText, 300, 645);
		Zeichne_Text_xy(hdc, "-U_B", 300, 620);
		if (DV.verwende_Stromquelle)
		{
			Bestimme_Spannungsbezeichner(cText, DV.U_Ref, 99);
			Zeichne_Text_xy(hdc, cText, 190, 490);
			Zeichne_Text_xy(hdc, "U_Ref", 190, 470);
			SetTextAlign(hdc, TA_LEFT);
			Zeichne_Text_xy(hdc, "T2", 352, 435);
		}
		SetTextAlign(hdc, TA_LEFT);
		Zeichne_Text_xy(hdc, "T1a", 250, 185);
		Zeichne_Text_xy(hdc, "T1b", 410, 185);
	}
	else
	{ // Ausgabe Dialogbox
		Zeichne_Text_xy(hdc, "R1", 210, 125);
		Zeichne_Text_xy(hdc, "R1", 470, 125);
		Zeichne_Text_xy(hdc, "R2", 115, 235);
		Zeichne_Text_xy(hdc, "R2", 570, 235);
		Zeichne_Text_xy(hdc, "R3", 270, 325);
		Zeichne_Text_xy(hdc, "R3", 410, 325);
		Zeichne_Text_xy(hdc, "R4", 270, 575);
	}

	hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
	hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
	hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
	hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

	// Zeichnen der Verbindungspunkte vorab
	Ellipse_BH(hdc, 445, 45, 10, 10);
	Ellipse_BH(hdc, 145, 195, 10, 10);
	Ellipse_BH(hdc, 545, 195, 10, 10);
	Ellipse_BH(hdc, 345, 345, 10, 10);
	// Wieder auf wei�en Hintergrund umschalten
	SelectObject(hdc, hPinselAlt);

	//Anschlusspunkte links, Positionen (Mitte): x: 50; y: 200; 300
	Zeichne_Anschluss(hdc, 40, 190, 100);
	//Anschlusspunkte rechts, Positionen (Mitte): x: 650; y: 200; 300
	Zeichne_Anschluss(hdc, 640, 190, 100);
	// Verbindungslinie linker Eingang Kondensator, dann weiter zur Basis x: 60-90; 110-200; y: 200
	ZP_Linie(hdc, 60, 200, 90, 200);
	ZP_Linie(hdc, 110, 200, 200, 200);
	// Zeichnen des linken Kondensators x:90 und 110, y: 150-250
	Zeichne_Kondensator(hdc, 90, 150, 20, 100, C_HORIZONTAL);
	// Spannungsquelle (positiv) x: 620-680, y: 70-130
	Zeichne_Gleichspannungsquelle(hdc, 620, 70, 60, DC_QUELLE_MASSE, 40);
	// Spannungsquelle (negativ) x: 320-380, y: 670-680
	Zeichne_Gleichspannungsquelle(hdc, 320, 620, 60, DC_QUELLE_MASSE, 40);
	// Verbindungslinie vom Kollektor links zur Spannungsquelle x: 250, 250-650, y: 150-50, 50, 50-170
	VP_Linie(hdc, 250, 150, 250, 50, 650, 50, 650, 170);
	// Verbindungslinie zum rechten Kollektor x: 450, y: 50-150
	ZP_Linie(hdc, 450, 50, 450, 150);
	// Verbindungslinie linker Basiswiderstand x: 150, y: 200-320
	ZP_Linie(hdc, 150, 200, 150, 320);
	// Masseanschluss f�r Basis: x: 135-165, y: 320
	ZP_Linie(hdc, 135, 320, 165, 320);
	// Verbindungslinie f�r Basis rechts x: 550, y: 200-320
	ZP_Linie(hdc, 550, 200, 550, 320);
	// Masseanschluss f�r Basis: x: 535-565, y: 320
	ZP_Linie(hdc, 535, 320, 565, 320);
	// Leitung f�r Eingang rechts x: 500-590 und 610-640, y: 200
	ZP_Linie(hdc, 500, 200, 590, 200);
	ZP_Linie(hdc, 610, 200, 640, 200);
	// Zeichnen des rechten Kondensators x:590 und 610, y: 150-250
	Zeichne_Kondensator(hdc, 590, 150, 20, 100, C_HORIZONTAL);
	// Verbindungslinie v0n Emitter (rechts) �ber Emitterwiderst�nde zum Emitter (links) x: 250, 250-450, 450 y: 250-350, 350, 350-250
	VP_Linie(hdc, 250, 250, 250, 350, 450, 350, 450, 250);
	if (DV.verwende_Stromquelle)	// Transistor als Stromquelle verwenden
	{
		// Verbindungslinie gemeinsamer Anschluss bis Kollektor x: 350, y: 350-400
		ZP_Linie(hdc, 350, 350, 350, 400);
		// Verbindungslinie weiter zur Masse, �ber Spannungsquelle x: 350, y: 500-720
		ZP_Linie(hdc, 350, 500, 350, 720);
		// Unteren Referenzspannungsanschluss
		//Anschlusspunkte unten, Positionen (Mitte): x: 200; y: 450; 550
		Zeichne_Anschluss(hdc, 190, 440, 100);
		// Verbindung zur Basis unten x: 210-300, y: 450
		ZP_Linie(hdc, 210, 450, 300, 450);
	}
	else // "nur" gemeinsamer Widerstand in der gemeinsamen Leitung des Differenzverst�rkers
	{
		// Verbindungslinie gemeinsamer Anschluss bis zur Masse, �ber Spannungsquelle x: 350, y: 350-720
		ZP_Linie(hdc, 350, 350, 350, 720);
	}

	// Widerst�nde zeichnen
	// Kollektorwiderst�nde
	Zeichne_Widerstand(hdc, 235, 70, 30, 60);
	Zeichne_Widerstand(hdc, 435, 70, 30, 60);
	// Basiswiderst�nde
	Zeichne_Widerstand(hdc, 135, 230, 30, 60);
	Zeichne_Widerstand(hdc, 535, 230, 30, 60);
	// Emitterwiderst�nde
	Zeichne_Widerstand(hdc, 235, 270, 30, 60);
	Zeichne_Widerstand(hdc, 435, 270, 30, 60);
	// Gemeinsamer Widerstand
	Zeichne_Widerstand(hdc, 335, 520, 30, 60);
	// Schwarze F�llung
	SelectObject(hdc, hPinselSchwarz);
	// Transistoren zeichnen
	// Transistor (NPN, links) Position: x: 200 (200-250) y: 150-250
	Zeichne_Bipolartransistor(hdc, 200, 150, 50, 100, NPN_TRANSISTOR, 0);
	// Transistor (NPN, rechts, spiegelverkehrt) Position: x: 450 (450-500) y: 150-250
	Zeichne_Bipolartransistor(hdc, 500, 150, -50, 100, NPN_TRANSISTOR, 0);
	if (DV.verwende_Stromquelle)	// Transistor als Stromquelle verwenden
	{
		// Transistor (NPN, unten) Position: x: 300 (300-350) y: 400-500
		Zeichne_Bipolartransistor(hdc, 300, 400, 50, 100, NPN_TRANSISTOR, 0);
	}
	SelectObject(hdc, hPinselAlt);		// Wieder auf wei�e Fl�che zur�ck...

	SelectObject(hdc, hPinselAlt);
	DeleteObject(hPinselSchwarz);
	SelectObject(hdc, hStiftAlt);
	DeleteObject(hStiftSchwarz2);
	SelectObject(hdc, FontAlt);
	DeleteObject(FontNeu);

	return 0;
}

int Kopiere_Differenzverstaerker_bipolar(Diff_verstaerker DV)
{
	HDC hdcMeta;
	HENHMETAFILE hMeta;

	hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
	// Schaltung zeichnen
	Zeichne_Differenzverstaerker_bipolar(DV, hdcMeta, true);
	hMeta = CloseEnhMetaFile(hdcMeta);
	// Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
	OpenClipboard(hWndElektronikMain);
	EmptyClipboard();
	SetClipboardData(CF_ENHMETAFILE, hMeta);
	CloseClipboard();

	return 0;
} // end of Kopiere_Differenzverstaerker


int Kopiere_Ergebnis_Differenzverstaerker(struct Diff_verstaerker Diff_V, HWND hWnd)
/* Diese Funktion kopiert die Berechnungsergebnisse des Differenzverst�rkers in die Zwischenablage */
{
	HGLOBAL hGlobal;
	WCHAR *wcGlobal;
	WCHAR wcText[2001];
	char cZeile[100];
	WCHAR wcZeile[MAX_DATEINAME];
	int i, laenge = 0;

	// Der Reihe nach die Daten in den String kopieren
	wcscpy_s(wcText, 50, L"Berechnung Differenzverst�rker\n");

	// Falls die Schaltung nicht berechenbar ist, wird hier auch die Fehlermeldung kopiert.
	if (!Diff_V.Schaltung_berechenbar) 
		wcscat_s(wcText, 25, L"Berechnung fehlerhaft!\n");

	// Versorgungsspannung und Widerst�nde ausgeben
	wcscat_s(wcText, 2000, L"\nVersorgungsspannung U_B=+/-");
	Bestimme_Spannungsbezeichner( cZeile, Diff_V.U_B, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);

	// Transistordaten ausgeben
	wcscat_s(wcText, 2000, L"Bipolar-Transistoren (Parallelzweig): ");
	if (Diff_V.NPN_T1)
		wcscat_s(wcText, 2000, L"NPN, ");
	else
		wcscat_s(wcText, 2000, L"PNP, ");

	laenge = wcslen(wcText);
	//Text[laenge] = (char)(3 * 256 + 11 * 16 + 2); // beta eintragen
	wcText[laenge] = 3*256+11*16+2; //'�'; // beta eintragen
	wcText[laenge + 1] = 0;
	wcscat_s(wcText, 2000, L"=");
	Bestimme_Bezeichner_wissenschaftlich( cZeile, Diff_V.Beta_T1, (int)99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L", U_BE=");
	Bestimme_Spannungsbezeichner(cZeile, Diff_V.U_BE_T1, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L", U_AF=");
	Bestimme_Spannungsbezeichner( cZeile, Diff_V.U_AF_T1, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);

	if (Diff_V.verwende_Stromquelle)
	{
	// Transistordaten der Stromquelle ausgeben
		wcscat_s(wcText, 2000, L"gemeinsame Last: Bipolar-Transistor als Stromsenke: ");
		if (Diff_V.NPN_T2)
			wcscat_s(wcText, 2000, L"NPN, ");
		else
			wcscat_s(wcText, 2000, L"PNP, ");
		laenge = wcslen(wcText);
		//Text[laenge] = (char)(3 * 256 + 11 * 16 + 2); // beta eintragen
		wcText[laenge] = 3*256+11*16+2; //'�'; // beta eintragen
		wcText[laenge + 1] = 0;
		wcscat_s(wcText, 2000, L"=");
		Bestimme_Bezeichner_wissenschaftlich( cZeile, Diff_V.Beta_T2, (int)99);
		char_to_widechar( wcZeile, cZeile, 99);
		wcscat_s(wcText, 2000, wcZeile);
		wcscat_s(wcText, 2000, L", U_BE=");
		Bestimme_Spannungsbezeichner(cZeile, Diff_V.U_BE_T2, 99);
		char_to_widechar( wcZeile, cZeile, 99);
		wcscat_s(wcText, 2000, wcZeile);
	}
	// Widerst�nde ausgeben
	wcscat_s(wcText, 2000, L"\nWiderst�nde:");
	for (i = 0; i < 3; i++)
		{
		if (i == 0)
			swprintf_s(wcZeile, 20, L"\tR1=");
		else
			swprintf_s(wcZeile, 20, L", R%u=", i + 1);
		wcscat_s(wcText, 2000, wcZeile);
		Bestimme_Widerstandsbezeichner(cZeile, Diff_V.R[i], 99);
		char_to_widechar( wcZeile, cZeile, 99);
		wcscat_s(wcText, 2000, wcZeile);
		}
	swprintf_s(wcZeile, 100, L"\nR4(gem. Pfad)=");
	wcscat_s(wcText, 2000, wcZeile);
	Bestimme_Widerstandsbezeichner(cZeile, Diff_V.R[3], 99 );
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);

	// Arbeitspunkt ausgeben
	wcscat_s(wcText, 2000, L"\nArbeitspunkt Transistoren Parallelzweig:\nSpannungen\tU_Basis=");
	Bestimme_Spannungsbezeichner( cZeile, Diff_V.U_Basis, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L", U_C=");
	Bestimme_Spannungsbezeichner( cZeile, Diff_V.U_C, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L", U_E=");
	Bestimme_Spannungsbezeichner(cZeile, Diff_V.U_E, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L"\nStr�me\tI_Basis=");
	Bestimme_Strombezeichner(cZeile, Diff_V.I_B, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L", I_C=");
	Bestimme_Strombezeichner(cZeile, Diff_V.I_C, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L", I_E=");
	Bestimme_Strombezeichner(cZeile, Diff_V.I_E, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	// Ausgabe Transistordaten Stromsenke
	if (Diff_V.verwende_Stromquelle)
	{
		wcscat_s(wcText, 2000, L"\nArbeitspunkt Transistor Stromsenke:\nSpannungen\tU_Basis=");
		Bestimme_Spannungsbezeichner( cZeile, Diff_V.U_Basis_T2, 99);
		char_to_widechar( wcZeile, cZeile, 99);
		wcscat_s(wcText, 2000, wcZeile);
		wcscat_s(wcText, 2000, L", U_C=");
		Bestimme_Spannungsbezeichner( cZeile, Diff_V.U_C_T2, 99);
		char_to_widechar( wcZeile, cZeile, 99);
		wcscat_s(wcText, 2000, wcZeile);
		wcscat_s(wcText, 2000, L", U_E=");
		Bestimme_Spannungsbezeichner(cZeile, Diff_V.U_E_T2, 99);
		char_to_widechar( wcZeile, cZeile, 99);
		wcscat_s(wcText, 2000, wcZeile);
		wcscat_s(wcText, 2000, L"\nStr�me\tI_Basis=");
		Bestimme_Strombezeichner(cZeile, Diff_V.I_B_T2, 99);
		char_to_widechar( wcZeile, cZeile, 99);
		wcscat_s(wcText, 2000, wcZeile);
		wcscat_s(wcText, 2000, L", I_C=");
		Bestimme_Strombezeichner(cZeile, Diff_V.I_C_T2, 99);
		char_to_widechar( wcZeile, cZeile, 99);
		wcscat_s(wcText, 2000, wcZeile);
		wcscat_s(wcText, 2000, L", I_E=");
		Bestimme_Strombezeichner(cZeile, Diff_V.I_E_T2, 99);
		char_to_widechar( wcZeile, cZeile, 99);
		wcscat_s(wcText, 2000, wcZeile);
	}
	// Ausgabe Verst�rkungen
	wcscat_s(wcText, 2000, L"\nVerst�rkungen:\tDifferenzverst. V_U,Diff=");
	Bestimme_Bezeichner_wissenschaftlich(cZeile, Diff_V.V_U_Wechsel, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);

	wcscat_s(wcText, 2000, L"\nGleichtaktverst. V_U,Gleicht.=");
	Bestimme_Bezeichner_wissenschaftlich(cZeile, Diff_V.V_U_Gleichtakt, 99); 
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);

	if (Diff_V.V_U_Gleichtakt_ist_Null)
	{
		wcscat_s(wcText, 2000, L"\nGleichtaktverst�rkung ist null. Daher ist CMRR unendlich.");
		wcscat_s(wcText, 2000, wcZeile);
	}
	else
	{
		wcscat_s(wcText, 2000, L"\nGleichtaktunterdr. CMRR=");
		Bestimme_Bezeichner_wissenschaftlich(cZeile, Diff_V.CMRR, 99); 
		char_to_widechar( wcZeile, cZeile, 99);
		wcscat_s(wcText, 2000, wcZeile);
	}
	
	wcscat_s(wcText, 2000, L"\nKleinsignaldaten:\tr_Ein_AC=");
	Bestimme_Widerstandsbezeichner(cZeile, Diff_V.r_Ein_AC, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L", r_Ein_DC=");
	Bestimme_Widerstandsbezeichner(cZeile, Diff_V.r_Ein_DC, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);

	if (Datei_gespeichert)
	{
		wcscat_s(wcText, 2000, L"\nDateiname; ");
		char_to_widechar( wcZeile, Dateiname, MAX_DATEINAME);
		wcscat_s(wcText, 2000, wcZeile);
	}
	laenge = wcslen(wcText);
	//hGlobal = GlobalAlloc(GHND, (laenge + 2) * sizeof(WCHAR));
	hGlobal = GlobalAlloc( GHND, (laenge+1)*sizeof(WCHAR));
	if (hGlobal == NULL)
		return 1;
	wcGlobal = (WCHAR*)GlobalLock(hGlobal);
	
	wcscpy_s(wcGlobal, (size_t)(laenge+1), wcText);
	if (GlobalUnlock(hGlobal)!=0)
		return 2;
	if (!OpenClipboard(hWnd))
		return 3;
	EmptyClipboard();
	if (SetClipboardData(CF_UNICODETEXT, hGlobal)==NULL)
		return 4;
	CloseClipboard();

	return 0;
} // end of Kopiere_Ergebnis_Differenzverstaerker
