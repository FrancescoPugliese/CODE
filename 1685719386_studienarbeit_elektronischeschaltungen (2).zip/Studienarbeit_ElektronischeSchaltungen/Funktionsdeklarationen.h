#pragma once
#include "stdafx.h"

// Liste der Funktionsprototypen 

// Modul Funkkommunikation
int Rauschzahl_Aufruf( HWND hWnd );
int Freifelddaempfung_Aufruf( HWND hWnd );
int Robuste_Richtfunk_Aufruf( HWND hWnd );

// Funktionen des Moduls Dialoge.cpp
int Kurzhilfe_Menu(WORD Param, HWND hWndStatuszeile);		// Datei: Dialoge.cpp
int StatusMeldung_5(char *Text);							// Datei: Dialoge.cpp
int StatusMeldung_4(char *Text);							// Datei: Dialoge.cpp
int Meldung(LPSTR Meldung);									// Datei: Dialoge.cpp
int Abfrage(char *Meldung);									// Datei: Dialoge.cpp
int Warnung(LPSTR Meldung);									// Datei: Dialoge.cpp
int FehlerMeldung(LPSTR Meldung);									// Datei: Dialoge.cpp

// Funktionen des Moduls: Bipolartransistor.cpp
int Basisschaltung_Aufruf(HWND hWnd);								// Datei: Bipolartransistor.cpp
int Emitterschaltung_Aufruf(HWND hWnd);								// Datei: Bipolartransistor.cpp
int Kollektorschaltung_Aufruf(HWND HWnd);							// Datei: Bipolartransistor.cpp
int Eingabe_BipolarTransistorwerte_Aufruf(int Schaltungsauswahl, int Transistorparameter);				// Datei: Bipolartransistor.cpp
int Doppel_Emitterschaltung_Aufruf(HWND hWnd);						// Datei: Bipolartransistor.cpp
int init_Doppel_Emitterschaltung(Doppel_Bipolartransistor *Trans);	// Datei: Biplolartransistor.cpp
int Zeichne_DoppelEmitterschaltung(Doppel_Bipolartransistor ES, HDC hdc, bool Kopie_Zwischenablage); // Datei: Bipolartransistor.cpp
int Berechne_Doppel_Emitterschaltung(void);							// Datei: Bipolartransistor.cpp
int Ergebnis_Doppel_Emitterschaltung(HWND hDlg);					// Datei: Bipolartransistor.cpp
int Zeichne_Ausgabe_DoppelEmitterschaltung(Doppel_Bipolartransistor D_ES, HDC hdc, bool Kopie_Zwischenablage); // Datei: Bipolartransistor
int Kopiere_DoppelEmitterschaltung(Doppel_Bipolartransistor DES);	// Datei: Bipolartransistor.cpp
int Kopiere_Ergebnis_Doppel_Bipolar_Transistorschaltung(Doppel_Bipolartransistor D_ES, HWND hWnd, int Schaltung); // Datei: Bipolartransistor

// Funktionen des Moduls: Bauteile.cpp
int Eingabe_Kapazitaetswerte_Aufruf(int Kondensator, int Anzahl_Kondensatoren, int Schaltungsauswahl);	// Datei: Bauteile.cpp
int Eingabe_Widerstandswerte_Aufruf(int Widerstand, int Anzahl_Widerstaende, int Schaltungsauswahl);	// Datei: Bauteile.cpp
int Eingabe_Widerstandswerte_Aufruf(int Widerstand, int Anzahl_Widerstand, int Schaltungsauswahl, int Pos_links, int Pos_rechts);
int Eingabe_Spannungswert_Aufruf(int Schaltungsauswahl, int Spannungsart);								// Datei: Bauteile.cpp
int Eingabe_Leitungswiderstaende_Aufruf(int Widerstand, int Anzahl_Widerstand, int Schaltungsauswahl);	// Datei: Bauteile.cpp
int Eingabe_Laenge_Aufruf(int Schaltungsauswahl);
int Eingabe_Beta_Aufruf(int Schaltungsauswahl);
int Eingabe_Eps_R_Aufruf( int Schaltungsauswahl);
int Eingabe_kompl_Impedanz_Aufruf(int Schaltungsauswahl);												// Datei: Bauteile.cpp

// Funktionen des Moduls: Utils.cpp
int Daten_gespeichert(void);								// Datei: Utils.cpp
int Daten_geaendert(void);									// Datei: Utils.cpp
int Daten_neu(void);										// Datei: Utils.cpp
int init(void);												// Datei: Utils.cpp
int init_EingabeDialog(void);
int Bestimme_Exponent(double wert);
unsigned char Benenne_Exponent(int Exponent);
int Bestimme_Kapazitaetsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Widerstandsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_komplexen_Widerstandsbezeichner_real_imag(char *Bezeichner, complex <double> wert, int Max_Zahl_Zeichen);
int Bestimme_komplexen_Widerstandsbezeichner_Betrag_Winkel(char *Bezeichner, complex <double> wert, int Max_Zahl_Zeichen);
int Bestimme_komplexen_Bezeichner_Betrag_Winkel(char *Bezeichner, complex <double> wert, int Max_Zahl_Zeichen);
int Bestimme_komplexen_Bezeichner_real_imag(char *Bezeichner, complex <double> wert, int Max_Zahl_Zeichen);
int Bestimme_komplexen_Leitwertsbezeichner_real_imag(char *Bezeichner, complex <double> wert, int Max_Zahl_Zeichen);
int Bestimme_imaginaeren_Widerstandsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Induktivitaetsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Spannungsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Leistungsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Dezibelbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Strombezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Prozentbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Technologiebezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_Steilheit(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Frequenzbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Laengenbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_E_Feld_Bezeichner_cm(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_E_Feld_Bezeichner_m(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Ladungsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_Festspannungsregler(char *Bezeichner, int Spannung, bool Positivregler, int Max_Zahl_Zeichen);
int Bestimme_Scheinleistungsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Blindleistungsbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Winkelbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_wissenschaftlich(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_wissenschaftlich(char *Bezeichner, double wert, int Max_Zahl_Zeichen, WCHAR *Einheit, int Laenge_Einheit);
int Bestimme_Bezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Temperaturbezeichner(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_Elektronenvolt(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_Ladungsdichte_cm3(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_Beweglichkeit_cm2(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_spezifischer_Widerstand_Ohm_Meter(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_Phase(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_Wert_Smith(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_Kapazitaetsbelag(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_Induktivitaetsbelag(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_Widerstandsbelag(char *Bezeichner, double wert, int Max_Zahl_Zeichen);
int Bestimme_Bezeichner_Exponent( char *Bezeichner, double wert, int Max_Zahl_Zeichen);
double setze_Maximalwert(double wert);
double setze_Minimalwert(double wert);
int loese_kubische_Gleichung(double a_x3, double b_x2, double c_x, double d, double loesung[]);
double Phase(complex <double> komplexe_zahl);
int Berechne_Schnittpunkte_Kreise( double *loes_x1, double *loes_y1, double *loes_x2, double *loes_y2, double x1, double y1, double r1, double x2, double y2, double r2);
double Berechne_Kreiswinkel_aus_Schnittpunkt( double Mittelpunkt_x, double Mittelpunkt_y, double Schnittpunkt_x, double Schnittpunkt_y);
bool Berechne_Kreis_aus_drei_Punkten( double x1, double y1, double x2, double y2, double x3, double y3, double *Mitte_x, double *Mitte_y, double *Radius );

int a_to_hex(char zeichen);
bool widechar_to_char(char *ausgabe, WCHAR *eingabe, int max_zahl);
bool char_to_widechar(WCHAR *ausgabe, char *eingabe, int max_zahl);
bool kopiere_substring(char *ausgabe, char *eingabe, int start_pos, int anzahl_zeichen, int max_zahl);
bool lese_wert_aus_zeile(double *wert, char *zeile, char *Index_String);
double Zahl_uebernehmen(char *eingabe, int max_zahl);
bool lese_string_aus_zeile(char *ausgabe, char *eingabe, char *Index_String, unsigned int anzahl_zu_lesen);
double Eingabe_parsen(HWND hDlg, int ID);
bool String_anhaengen(int max_len, WCHAR string1[], WCHAR string2[], WCHAR string3[], WCHAR string4[], WCHAR string5[]);
bool String_anhaengen(int max_len, WCHAR string1[], WCHAR string2[], WCHAR string3[], WCHAR string4[]);
bool String_anhaengen(int max_len, WCHAR string1[], WCHAR string2[]);
bool String_anhaengen(int max_len, char string1[], char string2[], char string3[], char string4[], char string5[]);
bool String_anhaengen(int max_len, char string1[], char string2[], char string3[], char string4[]);
bool String_anhaengen(int max_len, char string1[], char string2[]);

// Bipolartransistor
int Transistorwerte_auf_Null(Bipolartransistor *Trans);
int init_Emitterschaltung(Bipolartransistor *Trans);
int init_Kollektorschaltung(Bipolartransistor *Trans);
int init_Basisschaltung(Bipolartransistor *Trans);
double Parallelschaltung(double R1, double R2);
double r_BE(double I_B, double U_T);
double r_CE(double U_CE, double U_AF, double I_C);
double U_T(double Temp, bool Naeherung_U_T);
double Basisstrom_NPN(double Basis_R1, double Basis_R2, double Emitter_R1, double Emitter_R2, double U_BE, double U_B, double Beta);
double Basisstrom_PNP(double Basis_R1, double Basis_R2, double Emitter_R1, double Emitter_R2, double U_BE, double U_B, double Beta);
double AC_Eingangswiderstand_E(double R_Basis1, double R_Basis2, double R_Emitter, double R_Kollektor, double r_BE, double r_CE, double beta, bool N�herung_r_CE);
double AC_Ausgangswiderstand_E(double R_Kollektor, double R_Emitter, double r_CE, bool N�herung_r_CE);
double V_U_DC_E(double R_Kollektor, double R_Emitter_DC, double R_Emitter_AC, double r_BE, double r_CE, double Beta, bool r_CE_hochohmig);
double V_U_AC_E(double R_Kollektor, double R_Emitter_DC, double R_Emitter_AC, double r_BE, double r_CE, double beta, bool r_CE_hochohmig);
double AC_Eingangswiderstand_C(double R_Basis1, double R_Basis2, double R_Emitter, double r_BE, double r_CE, double beta, bool N�herung_r_CE);
double AC_Ausgangswiderstand_C(double R_Emitter, double r_BE, double r_CE, double beta, bool N�herung_r_CE);
double V_U_AC_C(double R3, double r_BE, double r_CE, double beta, bool r_CE_hochohmig);
double AC_Eingangswiderstand_B(double R_Emitter, double R_Kollektor, double r_BE, double r_CE, double beta, bool N�herung_r_CE);
double AC_Ausgangswiderstand_B(double R_Kollektor, double R_Emitter, double r_BE, double r_CE, double beta, bool N�herung_r_CE);
double V_U_AC_B(double R_Kollektor, double r_BE, double r_CE, double Beta, bool N�herung_r_CE);
double Berechne_I_C(double U_BE, double U_CE, double U_T, Bipolartransistor Trans);
int Berechne_Kennlinienfeld(Bipolartransistor Trans, double U_lauf, double U_Temp, int i_max, float *U_CE, float *I_C);

int Berechne_Basisschaltung(void);
int Ergebnis_Basisschaltung(HWND hDlg);
int ESB_Basisschaltung(HWND hDlg);
int Berechne_Emitterschaltung(void);
int Berechne_Kollektorschaltung(void);
int Ergebnis_Emitterschaltung(HWND hDlg);
int ESB_Emitterschaltung(HWND hDlg);
int ESB_Kollektorschaltung(HWND hDlg);
int Ergebnis_Kollektorschaltung(HWND hDlg);
int Transistor_als_Schalter_Aufruf(HWND hDlg);
int Differenzverstaerker_Bipolar_Aufruf(HWND hDlg);
int Kennlinienfeld_Bipolar_Aufruf(HWND hWnd);
int Berechne_Parameter_Kennlinienfeld_Bipolar(Bipolartransistor *Trans);

int Zeichne_Basisschaltung(Bipolartransistor BS, HDC hdc, bool Kopie_Zwischenablage);
int Zeichne_ESB_Basisschaltung(Bipolartransistor BS, HDC hdc, bool Kopie_Zwischenablage);
int Zeichne_Emitterschaltung(Bipolartransistor ES, HDC hdc, bool Kopie_Zwischenablage);
int Zeichne_ESB_Emitterschaltung(Bipolartransistor ES, HDC hdc, bool Kopie_ZWischenablage);
int Zeichne_Kollektorschaltung(Bipolartransistor KS, HDC hdc, bool Kopie_Zwischenablage);
int Zeichne_ESB_Kollektorschaltung(Bipolartransistor KS, HDC hdc, bool Kopie_ZWischenablage);
int Zeichne_Ausgabe_Basisschaltung(Bipolartransistor BS, HDC hdc, bool Kopie_Zwischenablage);
int Zeichne_Ausgabe_Emitterschaltung(Bipolartransistor BT, HDC hdc, bool Kopie_Zwischenablage);
int Zeichne_Ausgabe_Kollektorschaltung(Bipolartransistor BT, HDC hdc, bool Kopie_Zwischenablage);

int Kopiere_Basisschaltung(Bipolartransistor BS);
int Kopiere_ESB_Basisschaltung(Bipolartransistor BS);
int Kopiere_Emitterschaltung(Bipolartransistor ES);
int Kopiere_ESB_Emitterschaltung(Bipolartransistor ES);
int Kopiere_Kollektorschaltung(Bipolartransistor KS);
int Kopiere_ESB_Kollektorschaltung(Bipolartransistor KS);
int Kopiere_Ergebnis_Bipolar_Transistorschaltung(Bipolartransistor TS, HWND hWnd, int Schaltung);

int init_Transistor_als_Schalter(Schalter_Bipolartransistor *Schalt_Trans);
int init_Differenzverstaerker(Diff_verstaerker *Diff_V);

int Zeichne_Transistor_als_Schalter(Schalter_Bipolartransistor Schalt, HDC hdc, bool Kopie_Zwischenablage);
int Kopiere_Transistor_als_Schalter(Schalter_Bipolartransistor Schalt);
int Zeichne_Differenzverstaerker_bipolar(Diff_verstaerker DV, HDC hdc, bool Kopie_Zwischenablage);
int Kopiere_Differenzverstaerker_bipolar(Diff_verstaerker DV);

// Gleichrichterschaltung
int init_Gleichrichter(Dioden_Gleichrichter *Gleich);
int Gleichrichterschaltung(HWND hWnd);
int Eingabe_Wechselspannung(int Schaltung, int Parameter);
int Eingabe_Spannungsregler(void);
int Eingabe_Gleichrichter(void);
int Ergebnis_Gleichrichter(HWND hDlg);
int Berechne_Gleichrichterschaltung(void);
int ThermischerWiderstand(HWND hWnd);
int init_ThermischerWiderstand(struct Therm_Widerstand *R_Therm);
int Ergebnis_ThermischerWiderstand(int Zu_Berechnen);
int Kopiere_Ergebnis_Gleichrichter(struct Dioden_Gleichrichter Gleichrichter, HWND hWndElektronikMain);
int Kopiere_Ergebnis_Thermischer_Widerstand(struct Therm_Widerstand R_th, HWND hWndElektronikMain);

// Transistor als Schalter, Differenzverstaerker
int Ergebnis_Bipolartransistor_als_Schalter_Aufruf(HWND hDlg);
int Ergebnis_Differenzverstaerker_Aufruf(HWND hDlg);
int Berechne_Bipolartransistor_als_Schalter(void);
int Berechne_Differenzverstaerker(struct Diff_verstaerker *Differenz_Verstaerker);
double V_U_Differenzverstaerker_Wechsel(struct Diff_verstaerker Differenz_Verstaerker);
double V_U_Differenzverstaerker_Gleichtakt(struct Diff_verstaerker Differenz_Verstaerker);
double r_Ein_Differenzverstaerker_Gleichtakt(struct Diff_verstaerker Differenz_Verstaerker);
double r_Ein_Differenzverstaerker_Wechsel(struct Diff_verstaerker Differenz_Verstaerker);
int Kopiere_Ergebnis_Differenzverstaerker(struct Diff_verstaerker Differenzverstaerker, HWND hWndElektronikMain);

// dB-Rechner
int DezibelRechner_Aufruf(void);
int Ergebnis_DezibelRechner(int Zu_Berechnen);
int init_DezibelRechner(dB_Rechner *DBR);
int dBmRechner_Aufruf(void);

// Elektrisches Feld
int Elektrisches_Feld_Aufruf(void);
int init_Ladungen(Ladungs_Struktur *Ladung);
int Berechne_E_Feld(void);
int Schreibe_neue_E_Feld_Liste(HWND hDlg);
int Kopiere_Ladungen(Ladungs_Struktur Ladung);

// Operationsverstaerker
int init_OP(Operationsverstaerker *OP);
int OP_Kontrolle_U_Aus(Operationsverstaerker *OP);
int init_OP_Integrator_Differenzierer(Operationsverstaerker *OP);
int init_OP_Summation(Operationsverstaerker *OP);
int init_OP_Bode(Operationsverstaerker *OP);
int Invertierender_OP_Aufruf(HWND hWnd);
int Nichtinvertiernder_OP_Aufruf(HWND hWnd);
int Summations_OP_Aufruf(HWND hWnd);
int Ergebnis_Summations_OP_Aufruf(HWND hDlg);
int Differenzierer_OP_Aufruf(HWND hWnd);
int Integrierer_OP_Aufruf(HWND hWnd);
int Ergebnis_Invertierender_OP_Aufruf(HWND hDlg);
int Berechne_Invertierenden_OP(void);
int Berechne_Nichtinvertierenden_OP(void);
int Ergebnis_Nichtinvertierender_OP_Aufruf(HWND hDlg);
int Ergebnis_Differenzierer_OP_Aufruf(HWND hDlg);
int Ergebnis_Integrierer_OP_Aufruf(HWND hDlg);
int Berechne_Differenzierenden_OP(void);
int Berechne_Integrierenden_OP(void);
int Berechne_Summations_OP(void);
int Eingabe_Operationsverstaerker_Aufruf(int Schaltungsauswahl, int OP_parameter);
int Zeichne_OP_Bodeplot_Aufruf(HWND hDlg);
int Berechne_Bodeplot_OP(Operationsverstaerker *OP);
double Berechne_Phase_Bodeplot(double freq, double f_grenz[3]);
double Berechne_Betrag_dB_Bodeplot(double freq, double V_0, double f_grenz[3]);
int sortiere_frequenzpunkte(double *phasen_frequenz, int max_zahl);
double Bestimme_Frequenz_aus_V(double V, double V_0, double f_grenz[3]);
int Zeichne_Invertierenden_OP(Operationsverstaerker INV_OP, HDC hdc, bool Kopie_Zwischenablage);
int Kopiere_Invertierenden_OP(Operationsverstaerker INV_OP);
int Zeichne_Nichtinvertierenden_OP(Operationsverstaerker Nicht_INV_OP, HDC hdc, bool Kopie_Zwischenablage);
int Kopiere_Nichtinvertierenden_OP(Operationsverstaerker Nicht_INV_OP);
int Zeichne_Differenzierenden_OP(Operationsverstaerker Differenzier_OP, HDC hdc, bool Kopie_Zwischenablage);
int Kopiere_Differenzierenden_OP(Operationsverstaerker Differenzier_OP);
int Zeichne_Integrierenden_OP(Operationsverstaerker Integrator_OP, HDC hdc, bool Kopie_Zwischenablage);
int Kopiere_Integrierenden_OP(Operationsverstaerker Integrator_OP);
int Zeichne_Summierenden_OP(Operationsverstaerker Summ_OP, HDC hdc, bool Kopie_Zwischenablage);
int Kopiere_Summierenden_OP(Operationsverstaerker Summ_OP);
int Zeichne_Bodeplot(Operationsverstaerker Bode_OP, HDC hdc, bool Kopie_Zwischenablage);
int Kopiere_Bodeplot(Operationsverstaerker Bode_OP);

// Zeigerdiagramm
int Zeigerdiagramm_Aufruf(void);
int Setze_Button_Beschriftung(HWND hDlg, int nummer, int modus, bool parallel);
int init_Zeigerdiagramm(Komplexer_Zeiger *ZD);
int Eingabe_Impedanz_Aufruf(int Element, int Gesamtzahl, int Schaltung);
double Berechne_C_Impedanz(double C, double Kreisfrequenz);
double Berechne_L_Impedanz(double L, double Kreisfrequenz);
complex<double> Reihenschaltung_2(complex <double> Z1, complex <double> Z2);
complex<double> Reihenschaltung_3(complex<double> Z1, complex<double> Z2, complex<double> Z3);
complex<double> Parallelschaltung_2(complex<double> Z1, complex<double> Z2);
complex<double> Parallelschaltung_3(complex<double> Z1, complex<double> Z2, complex<double> Z3);
int Komplexe_Impedanz_parallel(double R, double L, double C, unsigned short modus, double omega, complex <double> *Ergebnis);
int Berechne_Impedanzen(Komplexer_Zeiger *ZD);
int Berechne_Spannungen_und_Stroeme(complex <double> U_gesamt, Komplexer_Zeiger *ZD);
int Zeichne_Zeigerdiagramm_Aufruf(void);
double Maximale_Spannung(Komplexer_Zeiger ZD);
double Maximaler_Strom(Komplexer_Zeiger ZD);
int Ausgabe_Werte_Zeigerdiagramm_Aufruf(HWND hDlg);
int Schreibe_Tabelle_Zeigerdiagramm(HWND hDlg, Komplexer_Zeiger *ZD);
int Eingabe_Impedanz_Aufruf(HWND hDlg);
int Zeichne_Zeigerdiagramm(Komplexer_Zeiger ZD, RECT RE, HDC hdc, bool Kopie_Zwischenablage, int Auswahl_Pfeile_U, int Auswahl_Pfeile_I);
int Kopiere_Zeigerdiagramm(Komplexer_Zeiger ZD, int Auswahl_Pfeile_U, int Auswahl_Pfeile_I);

// Elektrotechnik: Reihen- und Parallelschaltung, Stern-Dreieck-Wandlung
int init_Zeigerdiagramm_S(Zeiger_S *ZD);
int Berechne_Impedanzen_Reihenschaltung(Zeiger_S *ZD);
int Berechne_Impedanzen_Parallelschaltung(Zeiger_S *ZD);
int Reihenschaltung_Aufruf(HWND hWnd);
int Parallelschaltung_Aufruf(HWND hWnd);
int init_Stern_Dreieck_Umrechnung(Zeiger_Stern_Dreieck *ZD);
int Stern_Dreieckschaltung_Aufruf(HWND hWnd);
int Eingabe_Impedanz_SternDreieck_Aufruf(int Element, int Gesamtzahl, int Schaltung);
int Setze_Button_Beschriftung_Stern_Dreieck(HWND hDlg, int nummer, int modus, bool Reihenschaltung);
int Berechne_Sternschaltung(Zeiger_Stern_Dreieck *Z_SD);
int Berechne_Dreieckschaltung(Zeiger_Stern_Dreieck *Z_SD);
int Ausgabe_Sternschaltung(HWND hDlg, Zeiger_Stern_Dreieck Z_SD);
int Ausgabe_Dreieckschaltung(HWND hDlg, Zeiger_Stern_Dreieck Z_SD);
int init_Reihen_Parallel_Schaltung(Zeiger_S *Zeiger);
complex <double> Berechne_Leitwert(double R, double C, double L, int Modus, bool Reihenschaltung, double omega);

// Hochfrequenztechnik
int SmithDiagramm_Aufruf(HWND hWnd);
int init_HF_Smith(Hochfrequenz_Impedanz *Z_HF);
int init_HF_Leitung(Uebertragungsleitung *Z_HF);
complex<double> Bestimme_Polarkoordinaten_aus_Impedanz( double real_Z, double imag_Z, double Referenzwiderstand);
complex<double> Bestimme_Polarkoordinaten_kartesisch( double x, double y);
complex<double> Bestimme_Impedanz_kartesisch( double x, double y, double Referenzwiderstand);
complex<double> Bestimme_Impedanz_aus_Gamma( double real_gamma, double imag_gamma, double Referenzwiderstand);
//complex<double> Bestimme_Impedanz( complex<double>gamma, double Referenzwiderstand);
double Bestimme_VSWR( complex<double> gamma);
double Bestimme_VSWR( double x, double y);
double Anpassung_in_dB( complex<double>gamma);
double Anpassung_in_dB( complex<double>gamma);
int Schreibe_neue_Impedanzliste( HWND hDlg );
int Loesche_Impedanzliste( void );
int Eingabe_loeschen( HWND hDlg );
int HF_Leitung_Aufruf(HWND hWnd);
int Berechne_HF_Leitung( Uebertragungsleitung *HF_Kabel );
int x_Koordinate_Impedanz( double real_Z, double imag_Z, double Referenzwiderstand );
int y_Koordinate_Impedanz( double real_Z, double imag_Z, double Referenzwiderstand );
complex<double> Drehung_lambda_durch_l( complex<double> Z, double lambda_durch_l, double Referenzwiderstand);
complex<double> Drehung_lambda_durch_l( double real_Z, double imag_Z, double lambda_durch_l, double Referenzwiderstand);
int Kopiere_HF_Leitung(void);
int Anpassung_Aufruf(HWND hWnd);
int Leitungs_ESB_Aufruf(HWND hWnd);
int init_Leitungs_ESB(Leitungs_Ersatzschaltbild *Z_Leit_ESB);
int Berechne_Leitungsdaten_aus_ESB( void );
int init_HF_Anpassung(Hochfrequenz_Impedanz *Z_HF);
int Berechne_Anpassung_C_L( int Stufen );
int Berechne_Anpassung_L_C( int Stufen );

// Zeichenfunktionen
BOOL Ellipse_BH(HDC hdc, int x, int y, int Breite, int Hoehe);
BOOL Ellipse_BH(HDC hdc, int x, int y, int Breite, int Hoehe, bool Fuellung);
BOOL Ellipsenbogen_BH_Winkel1_Winkel2(HDC hdc,  int x, int y, int Breite, int Hoehe, double alpha1, double alpha2);
BOOL Kreis_Mitte_Radius(HDC hdc, int x, int y, int Radius);
// BOOL Kreisbogen_Mitte_Radius_Winkel1_Winkel2(HDC hdc, int x, int y, int Radius, double alpha1, double alpha2); // nicht verwenden
BOOL Kreisbogen2_Mitte_Radius_Winkel1_Winkel2(HDC hdc,  int x, int y, double Radius, double alpha1, double alpha2);
BOOL Rechteck_BH_Flaeche(HDC hdc, int x, int y, int Breite, int Hoehe, HBRUSH bBrush);
int Rechteck_BH_Rahmen(HDC hdc, int x, int y, int Breite, int Hoehe);
BOOL Linien_Rechteck_BH(HDC hdc, int x, int y, int Breite, int Hoehe);
BOOL ZP_Linie(HDC hdc, int x1, int y1, int x2, int y2);
BOOL DP_Linie(HDC hdc, int x1, int y1, int x2, int y2, int x3, int y3);
BOOL VP_Linie(HDC hdc, int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4);
BOOL FillTriangle(HDC hdc, int x1, int y1, int x2, int y2, int x3, int y3);
BOOL Zeichne_Text_xy(HDC hdc, char *Text, int x, int y);
BOOL Zeichne_Sinus(HDC hdc, int x, int y, int Breite, int Hoehe);
BOOL Zeichne_Kreuz(HDC hdc, int x, int y, int laenge, BYTE rot, BYTE gruen, BYTE blau);
int Zeichne_Koordinatensystem_Ursprung_links_unten(HDC hdc, Koordinatensystem *Koord, char Beschriftung_x1[40], char Beschriftung_y1[40], char Beschriftung_x2[40], char Beschriftung_y2[40], char Ueberschrift[80], bool Kopie_Zwischenablage);
int Zeichne_Koordinatensystem_Ursprung_links_unten(HDC hdc, Koordinatensystem *Koord, char Beschriftung_x1[40], char Beschriftung_y1[40], char Beschriftung_x2[40], char Beschriftung_y2[40], char Ueberschrift[80], bool Kopie_Zwischenablage, bool Verwende_Vorsatzzeichen);
int Zeichne_Koordinatensystem_Ursprung_rechts_oben(HDC hdc, Koordinatensystem *Koord, char Beschriftung_x1[40], char Beschriftung_y1[40], char Beschriftung_x2[40], char Beschriftung_y2[40], char Ueberschrift[80], bool Kopie_Zwischenablage, bool Verwende_Vorsatzzeichen);
int Zeichne_Kurve_in_Koordinatensystem_Ursprung_links_unten(HDC hdc, Koordinatensystem *KS, float *x, float *y, int anzahl_punkte, int rot, int gruen, int blau);
int Zeichne_Kurve_mit_Spannungs_Beschriftung_in_Koordinatensystem_Ursprung_links_unten( HDC hdc, Koordinatensystem *Koord, float *x, float *y, int anzahl_punkte, char Beschriftung_Kurve[40], double Wert_Kurve, int rot, int gruen, int blau);
int Zeichne_Kurve_mit_Spannungs_Beschriftung_in_Koordinatensystem_Ursprung_rechts_oben( HDC hdc, Koordinatensystem *Koord, float *x, float *y, int anzahl_punkte, char Beschriftung_Kurve[40], double Wert_Kurve, int rot, int gruen, int blau);
int Zeichne_Kurve_in_Koordinatensystem_Ursprung_rechts_oben(HDC hdc, Koordinatensystem *Koord, float *x, float *y, int anzahl_punkte, int rot, int gruen, int blau);
int Zeichne_Anschluss(HDC hdc, int x, int y, int Abstand_Anschlusspunkte);
int Zeichne_OP(HDC hdc, int x, int y, int breite, int hoehe, bool invertierender_eingang_oben);
int Zeichne_OP_mit_Anschluessen(HDC hdc, int x, int y, int breite, int hoehe, int laenge_Eingang, int laenge_Ausgang, bool invertierender_eingang_oben);
int Zeichne_Wechselspannungsquelle(HDC hdc, int x, int y, int groesse, bool Masseanschluss, int laenge);
int Zeichne_Kondensator(HDC hdc, int x, int y, int breite, int hoehe, bool horizontal, int laenge);
int Zeichne_Kondensator(HDC hdc, int x, int y, int breite, int hoehe, bool horizontal);
int Zeichne_Widerstand(HDC hdc, int x, int y, int breite, int hoehe, int laenge);
int Zeichne_Widerstand(HDC hdc, int x, int y, int breite, int hoehe);
int Zeichne_Spule(HDC hdc, int x, int y, int breite, int laenge, bool horizontal);
int Zeichne_Gleichspannungsquelle(HDC hdc, int x, int y, int groesse, bool Masseanschluss, int laenge);
int Zeichne_Bipolartransistor(HDC hdc, int x, int y, int breite, int hoehe, bool NPN, int Basis_laenge);
int Zeichne_Feldeffekttransistor(HDC hdc, int x, int y, int breite, int hoehe, bool MOS, bool n_Kanal, double U_Th, int Gate_laenge);
int Zeichne_Koordinatensystem_Ursprung_mitte(HDC hdc, Koordinatensystem *Koord, char Beschriftung_x1[40], char Beschriftung_y1[40], char Beschriftung_x2[40], char Beschriftung_y2[40], char Ueberschrift[80], int rot1, int gruen1, int blau1, int rot2, int gruen2, int blau2, bool Kopie_Zwischenablage);
int Zeichne_Zeiger_in_Koordinatensystem_Ursprung_mitte(HDC hdc, Koordinatensystem *Koord, char Beschriftung[10], double anfang_x, double anfang_y, double ende_x, double ende_y, int rot, int gruen, int blau, bool erste_achse);
int Zeichne_Bodeplot(HDC hdc, Bodeplot_Grafik *BP, char Ueberschrift[80], Operationsverstaerker *Bode_OP, bool Kopie_Zwischenablage);
int Zeichne_OP_Kurve_in_Bodeplot(HDC hdc, Bodeplot_Grafik *Bodeplot);
int Zeichne_Ladungen(Ladungs_Struktur Ladung, HDC hdc, bool Kopie_Zwischenablage);
int Zeichne_SmithDiagramm( HDC hdc, int Mittelpunkt_x, int Mittelpunkt_y, int Radius_Smith, int Detailierung, bool Leitwert_zeichnen );
int Kopiere_SmithDiagramm( bool Leitwert_zeichnen );
int Bestimme_Koordinaten_Wert(long Koordinate_min, long Koordinate_max, double Wert_min, double Wert_max, double akt_wert, bool linear);
HFONT Erstelle_Font_Arial(HDC hdc, int Zeichenhoehe);
HFONT Erstelle_Font_Arial(HDC hdc, int Zeichenhoehe, bool kursiv);
HFONT Erstelle_Font_Symbol(HDC hdc, int Zeichenhoehe, bool kursiv);
int Zeichne_Leitung(HDC hdc, int x, int y, int breite, int hoehe, int laenge_Anschluss);
int Zeichne_HF_Leitung_mit_Spannungsverlauf( HDC hdc, bool Kopie_Zwischenablage );

// Hilfsfenster
int About_Aufruf(void);
int Hilfe_Aufruf(void);

// Funktionsprototypen f�r Dialogfenster
INT_PTR CALLBACK EingabeWiderstandswerte_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK EingabeKapazitaetswerte_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK EingabeSpannungswert_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Eingabe_BipolarTransistorwerte_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK BasisSchaltung_Dialog(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK EmitterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK KollektorSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK EingabeFreischaltcode_Dialog(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK ErgebnisBasisSchaltung_Dialog(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK ESB_BasisSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK ErgebnisEmitterSchaltung_Dialog(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK ESB_EmitterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK ErgebnisKollektorSchaltung_Dialog(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK ESB_KollektorSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Transistor_als_Schalter_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK GleichrichterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK EingabeSpannungsregler_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK EingabeWechselSpannung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK EingabeGleichrichter_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK ErgebnisGleichrichterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK ThermischerWiderstand_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Differenzverstaerker_Bipolar_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Ergebnis_Bipolartransistor_als_Schalter_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Ergebnis_Differenzverstaerker_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK pn_Uebergang_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK DezibelRechner_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Elektrisches_Feld_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK About_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Hilfe_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Invertierender_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Ergebnis_Invertierender_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Nichtinvertierender_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Ergebnis_Nichtinvertierender_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Differenzierer_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Integrierer_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Ergebnis_Integrierer_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Ergebnis_Differenzierer_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Additions_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Ergebnis_Additions_OP_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Eingabe_Operationsverstaerker_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Zeigerdiagramm_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Eingabe_Impedanz_Zeigerdiagramm_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Zeichne_Zeigerdiagramm_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Ausgabe_Werte_Zeigerdiagramm_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Eingabe_Komplexe_Spannung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Zeichne_OP_Bodeplot_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Kennlinienfeld_Bipolar_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Reihenschaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Parallelschaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Eingabe_Impedanz_Reihenschaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Eingabe_Impedanz_Parallelschaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Stern_Dreieckschaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Eingabe_Impedanz_SternDreieck_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

INT_PTR CALLBACK SmithDiagramm_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK HF_Leitung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Eingabe_Leitungswiderstand_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Eingabe_Laenge_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Eingabe_Beta_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Eingabe_kompl_Impedanz_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Anpassung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK Leitungs_ESB_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK DoppelEmitterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK ErgebnisDoppelEmitterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);