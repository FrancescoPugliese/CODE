#include "stdafx.h"
/*******************************************************************************************************************\
|																													|
| Modul Operationsverstaerker.cpp																					|
|																													|
| In diesem Modul sind die Funktionen f�r Operationsverst�rkerschaltungen und Bodeplot enthalten					|
| - Berechne_Bodeplot_OP();																							|
| - Berechne_Betrag_dB_Bodeplot();																					|
| - Berechne_Differenzierenden_OP();																				|
| - Berechne_Integrierenden_OP();																					|
| - Berechne_Invertierenden_OP();																					|
| - Berechne_Nichtinvertierenden_OP();																				|
| - Berechne_Summations_OP();																						|
| - Berechne_Phase_Bodeplot();																						|
| - Bestimme_Frequenz_aus_V();																						|
| - Differenzierer_OP_Aufruf();																						|
| - Eingabe_Operationsverstaerker_Aufruf();																			|
| - Ergebnis_Differenzierer_OP_Aufruf();																			|
| - Ergebnis_Integrierer_OP_Aufruf();																				|
| - Ergebnis_Invertierender_OP_Aufruf();																			|
| - Ergebnis_Nichtinvertierender_OP_Aufruf();																		|
| - Ergebnis_Summations_OP_Aufruf();																				|
| - init_OP();																										|
| - init_OP_Bode();																									|
| - init_OP_Integrator_Differenzierer();																			|
| - init_OP_Summation();																							|
| - Integrierer_OP_Aufruf();																						|
| - Invertierender_OP_Aufruf();																						|
| -	Kopiere_Bodeplot();																								|
| - Kopiere_Differenzierenden_OP();																					|
| - Kopiere_Integrierenden_OP();																					|
| - Kopiere_Invertierenden_OP();																					|
| - Kopiere_Nichtinvertierenden_OP();																				|
| -	Kopiere_Summierenden_OP);																						|
| - Nichtinvertiernder_OP_Aufruf();																					|
| - OP_Kontrolle_U_Aus();																							|
| - Summations_OP_Aufruf();																							|
| - Zeichne_Bodeplot();																								|
| - Zeichne_Differenzierenden_OP();																					|
| - Zeichne_Integrierenden_OP();																					|
| - Zeichne_Invertierenden_OP();																					|
| - Zeichne_Nichtinvertierenden_OP();																				|
| - Zeichne_OP_Bodeplot_Aufruf();																					|
| - Zeichne_Summierenden_OP();																						|
|  																													|
\*******************************************************************************************************************/

int init_OP(Operationsverstaerker *OP)
// Initialisierung der Variablen f�r eine OP-Schaltung
{
	int i;

	for (i=0; i<3; i++)
		OP->Grenzfrequenz[i] = 1000.0;
	for (i = 0; i<5; i++)
		OP->R[i] = 0.0;
	OP->C = 0.0;
	OP->R[0] = 1000.0;
	OP->R[1] = 1000.0;
	OP->R_Max = 2;
	OP->Slewrate = 1000.0;
	OP->V_0_dB = 120.0;
	OP->V_0 = 1.0e6;
	OP->U_B = 15.0;
	OP->R_Ein = 0.0;
	OP->R_Ein_2 = 0.0;
	OP->V_U = 0.0;
	OP->V_U_2 = 0.0;
	OP->R_Aus = 0.0;
	OP->U_Ein = 1.0;
	OP->U_Ein_2 = 0.0;
	OP->U_Aus = 0.0;
	OP->freq = 0.0;
	OP->Idealer_OP = true;
	OP->U_Abstand = 2.0; 
	OP->Amplitudenreserve = 20.0;
	OP->Phasenreserve = 45.0;
	OP->neue_Schaltung = true;
	OP->U_Begrenzung = false;

	return 0;
}	// end of init_OP

int OP_Kontrolle_U_Aus(Operationsverstaerker *OP)
// Die Funktion kontrolliert, ob die Ausgangsspannung des OPs im zul�ssigen Bereich ist.
{
	if (abs(OP->U_Aus) >= (OP->U_B - OP->U_Abstand))
		OP->U_Begrenzung = true;
	else 
		OP->U_Begrenzung = false;

	return 0;
}

int init_OP_Integrator_Differenzierer(Operationsverstaerker *OP)
// Initialisierung der Variablen f�r den Differenzierer und Integrierer
{
	init_OP(OP);
	OP->C = 1.0e-9;
	OP->R[1] = 0.0;
	OP->R_Max = 1;
	OP->freq = 1.0e3;

	return 0;
} // end of init_OP_Integrator_Differenzierer

int init_OP_Summation(Operationsverstaerker *OP)
{
	init_OP(OP);
	OP->R[2] = 1000.0;
	OP->U_Ein_2 = 0.5;
	OP->R_Max = 3;

	return 0;
}

int init_OP_Bode(Operationsverstaerker *OP)
{
	init_OP(OP);
	OP->Grenzfrequenz[0] = 1000.0;
	OP->Grenzfrequenz[1] = 100000.0;
	OP->Grenzfrequenz[2] = 1.0e6;
	OP->Amplitudenreserve = 20.0;
	OP->Phasenreserve = 45.0;
	OP->Frequenz_Instabilitaet = 0.0;
	OP->Frequenz_minus_60dB = 0.0;
	OP->OP_Stabil = false;

	return 0;
}

int Invertierender_OP_Aufruf(HWND hWnd)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_INVERTIERENDER_OP), hWnd, Invertierender_OP_Dialog);

	return 0;
}	// end of Invertierender_OP_Aufruf

int Nichtinvertiernder_OP_Aufruf(HWND hWnd)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_NICHTINVERTIERENDER_OP), hWnd, Nichtinvertierender_OP_Dialog);
	return 0;
}	// end of Nichtinvertiernder_OP_Aufruf

int Summations_OP_Aufruf(HWND hWnd)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_ADDITIONS_OP), hWnd, Additions_OP_Dialog);
	return 0;
}	// end of Summations_OP_Aufruf

int Ergebnis_Summations_OP_Aufruf(HWND hDlg)
{
	// Berechnung der OP-Schaltung als Summations-Verst�rker
	Berechne_Summations_OP();
	DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_ADDITIONS_OP), hDlg, Ergebnis_Additions_OP_Dialog);
	return 0;
}	// end of Ergebnis_Summations_OP_Aufruf

int Differenzierer_OP_Aufruf(HWND hWnd)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_DIFFERENZIERER_OP), hWnd, Differenzierer_OP_Dialog);

	return 0;
}	// end of Differenzierer_OP_Aufruf

int Integrierer_OP_Aufruf(HWND hWnd)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_INTEGRIERER_OP), hWnd, Integrierer_OP_Dialog);

	return 0;
}	// end of Integrierer_OP_Aufruf

int Ergebnis_Invertierender_OP_Aufruf(HWND hDlg)
{
	// Berechnung der OP-Schaltung als invertierender Verst�rker
	Berechne_Invertierenden_OP();
	DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_INV_OP), hDlg, Ergebnis_Invertierender_OP_Dialog);

	return 0;
}	// end of Ergebnis_Invertierender_OP_Aufruf

int Berechne_Invertierenden_OP(void)
{
	// Generell treten erst einmal keine Fehler auf:
	Invertierender_OP.Schaltung_berechenbar = true;
	Invertierender_OP.R_Ein = Invertierender_OP.R[R_OP_EIN];

	if (Invertierender_OP.R[R_OP_EIN] != 0.0)
	{
		Invertierender_OP.V_U = -Invertierender_OP.R[R_OP_RUECKKOPPEL] / Invertierender_OP.R[R_OP_EIN];
		Invertierender_OP.U_Aus = Invertierender_OP.U_Ein * Invertierender_OP.V_U;
	}
	else
	{
		Invertierender_OP.V_U = 1.0;
		Invertierender_OP.U_Aus = 0.0;
		Invertierender_OP.Schaltung_berechenbar = false;
	}
	// Kontrolle ob U_Aus im zul�ssigen Bereich ist
	OP_Kontrolle_U_Aus(&Invertierender_OP);

	return 0;
}	// end of Berechne_Invertierenden_OP

int Ergebnis_Nichtinvertierender_OP_Aufruf(HWND hDlg)
{
	// Berechnung der OP-Schaltung als nicht-invertierender Verst�rker
	Berechne_Nichtinvertierenden_OP();
	DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_NONINV_OP), hDlg, Ergebnis_Nichtinvertierender_OP_Dialog);

	return 0;
}	// end of Ergebnis_Invertierender_OP_Aufruf

int Berechne_Nichtinvertierenden_OP(void)
{
	// Generell treten erst einmal keine Fehler auf:
	Nichtinvertierender_OP.Schaltung_berechenbar = true;

	if (Nichtinvertierender_OP.R[R_OP_RUECKKOPPEL] != 0.0)
	{
		Nichtinvertierender_OP.V_U = 1.0 + Nichtinvertierender_OP.R[R_OP_RUECK_MASSE] / Nichtinvertierender_OP.R[R_OP_RUECKKOPPEL];
		Nichtinvertierender_OP.U_Aus = Nichtinvertierender_OP.V_U * Nichtinvertierender_OP.U_Ein;
	}
	else
	{
		Nichtinvertierender_OP.V_U = 0.0;
		Nichtinvertierender_OP.U_Aus = 0.0;
		Nichtinvertierender_OP.Schaltung_berechenbar = false;
	}
	// Kontrolle ob U_Aus im zul�ssigen Bereich ist
	OP_Kontrolle_U_Aus(&Nichtinvertierender_OP);

	return 0;
}	// end of Berechne_NichtInvertierenden_OP

int Ergebnis_Differenzierer_OP_Aufruf(HWND hDlg)
{
	// Berechnung der OP-Schaltung als invertierender Verst�rker
	Berechne_Differenzierenden_OP();
	DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_DIFF_OP), hDlg, Ergebnis_Differenzierer_OP_Dialog);

	return 0;
}	// end of Ergebnis_Differenzierer_OP_Aufruf

int Ergebnis_Integrierer_OP_Aufruf(HWND hDlg)
{
	// Berechnung der OP-Schaltung als invertierender Verst�rker
	Berechne_Integrierenden_OP();
	DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_INTEGR_OP), hDlg, Ergebnis_Integrierer_OP_Dialog);

	return 0;
}	// end of Ergebnis_Differenzierer_OP_Aufruf

int Berechne_Differenzierenden_OP(void)
{
	// Generell treten erst einmal keine Fehler auf:
	Differenzierer_OP.Schaltung_berechenbar = true;

	// "Verst�rkung:" V_U = - 1 / (omega*C ) / R_1 = - 1 / (R_1 * 2 * pi * f * C)
	Differenzierer_OP.V_U = -Differenzierer_OP.R[R_OP_DIFF] * 2.0 * pi * Differenzierer_OP.freq * Differenzierer_OP.C;
	if (Differenzierer_OP.freq * Differenzierer_OP.C != 0.0)
	{
		// Eingangswiderstand falsch??
		Differenzierer_OP.R_Ein = 1.0 / (2.0 * pi * Differenzierer_OP.freq * Differenzierer_OP.C);
	}
	else
	{
		Differenzierer_OP.R_Ein = 0.0;
		Differenzierer_OP.Schaltung_berechenbar = false;
	}
	Differenzierer_OP.U_Aus = Differenzierer_OP.U_Ein * Differenzierer_OP.V_U;
	// Kontrolle ob U_Aus im zul�ssigen Bereich ist
	OP_Kontrolle_U_Aus(&Differenzierer_OP);

	return 0;
}	// end of Berechne_Differenzierenden_OP

int Berechne_Integrierenden_OP(void)
{
	double nenner;

	// Generell treten erst einmal keine Fehler auf:
	Integrierer_OP.Schaltung_berechenbar = true;

	nenner = -Integrierer_OP.R[R_OP_INTEGR] * 2.0 * pi * Integrierer_OP.freq * Integrierer_OP.C;
	if (nenner != 0.0)
	{
		Integrierer_OP.V_U = 1.0 / nenner;
	}
	else
		Integrierer_OP.V_U = 0.0;
	Integrierer_OP.R_Ein = Integrierer_OP.R[R_OP_INTEGR];
	Integrierer_OP.U_Aus = Integrierer_OP.U_Ein * Integrierer_OP.V_U;
	// Kontrolle ob U_Aus im zul�ssigen Bereich ist
	OP_Kontrolle_U_Aus(&Integrierer_OP);

	return 0;
}	// end of Berechne_Integrierenden_OP

int Berechne_Summations_OP(void)
{
	// Generell treten erst einmal keine Fehler auf:
	Summations_OP.Schaltung_berechenbar = true;
	Summations_OP.R_Ein = Summations_OP.R[R_OP_EIN_1];
	Summations_OP.R_Ein_2 = Summations_OP.R[R_OP_EIN_2];

	if (Summations_OP.R[R_OP_EIN_1] != 0.0)
	{
		Summations_OP.V_U = -Summations_OP.R[R_OP_SUMME_RUECKKOPPEL] / Summations_OP.R[R_OP_EIN_1];
		Summations_OP.U_Aus = Summations_OP.U_Ein * Summations_OP.V_U;
	}
	else
	{
		Summations_OP.V_U = 1.0;
		Summations_OP.U_Aus = 0.0;
		Summations_OP.Schaltung_berechenbar = false;
	}
	if (Summations_OP.R[R_OP_EIN_2] != 0.0)
	{
		Summations_OP.V_U_2 = -Summations_OP.R[R_OP_SUMME_RUECKKOPPEL] / Summations_OP.R[R_OP_EIN_2];
		Summations_OP.U_Aus += Summations_OP.U_Ein_2 * Summations_OP.V_U_2;
	}
	else
	{
		Summations_OP.V_U_2 = 1.0;
		Summations_OP.U_Aus = 0.0;
		Summations_OP.Schaltung_berechenbar = false;
	}
	// Kontrolle ob U_Aus im zul�ssigen Bereich ist
	OP_Kontrolle_U_Aus(&Summations_OP);

	return 0;
}	// end of Berechne_Summations_OP

int Berechne_Bodeplot_OP(Operationsverstaerker *OP)
{
	double f_instabil, phase_phasenreserve, frequenz_phasenreserve, V_U_Amplitudenreserve;

	// Funktion bestimmt Transitfrequenz, Amplituden und Phasenreserve aus den OP-Daten
	// Au�erdem bestimmt die Funktion die Frequenz f�r eine minimale Verst�rkung von -60dB.

	OP->Transitfrequenz = pow(10.0, OP->V_0_dB / 60.0 - log10(OP->Grenzfrequenz[1] / OP->Grenzfrequenz[0]) / 3.0 - 2.0*log10(OP->Grenzfrequenz[2] / OP->Grenzfrequenz[1]) / 3.0)*OP->Grenzfrequenz[2];
	OP->Frequenz_minus_60dB = pow(10.0, (OP->V_0_dB + 60.0) / 60.0 - log10(OP->Grenzfrequenz[1] / OP->Grenzfrequenz[0]) / 3.0 - 2.0*log10(OP->Grenzfrequenz[2] / OP->Grenzfrequenz[1]) / 3.0)*OP->Grenzfrequenz[2];
	// Berechne Frequenz f�r Instabilit�t, dazu muss festgestellt werden, bei welcher Frequenz die Phase -180� ist. 
	f_instabil = 1 / 10.0*pow(10.0, 1.0 + (log10(OP->Grenzfrequenz[1]) + log10(OP->Grenzfrequenz[2])) / 2.0);
	// Ist die berechnete Frequenz um den Faktor 10 h�her als die zweite Grenzfrequenz? Dann ist die Frequenz f�r die Phasendrehung von -180� das 
	// zehnfache der zweiten Grenzfrequenz (keine �berlappung der Phasendrehungen)
	if (f_instabil >= 10.0*OP->Grenzfrequenz[1])
		f_instabil = 10.0*OP->Grenzfrequenz[1];
	else
	{
		if (f_instabil < 10.0*OP->Grenzfrequenz[0])
			// Grenzfrequenz ist niedriger als das zehnfache der niedrigsten Grenzfrequenz, d.h. alle drei Grenzfrequenzen fallen zusammen.
			f_instabil = 1 / 10.0*pow(10.0, (4.0 + log10(OP->Grenzfrequenz[0]) + log10(OP->Grenzfrequenz[1]) + log10(OP->Grenzfrequenz[2])) / 3.0);
	}
	// Eintragen des Wertes in die Struktur
	OP->Frequenz_Instabilitaet = f_instabil;
	OP->Betrag_bei_f_Instabil = Berechne_Betrag_dB_Bodeplot(f_instabil, OP->V_0_dB, OP->Grenzfrequenz);

	frequenz_phasenreserve = -1.0; // Der Wert sollte unten gesetzt werden, falls nicht, liegt ein Fehler vor!
	// Bestimmung der Frequenz f�r die Phasenreserve
	phase_phasenreserve = -180.0 + OP->Phasenreserve;
	// Fallunterscheidung: Wenn die "Rest-Phase" 0� ist, ist die frequenz durch ein Zehntel der untersten Grenzfrequenz gegeben
	if (phase_phasenreserve == 0.0)
		frequenz_phasenreserve = 0.1*OP->Grenzfrequenz[0];
	// Fallunterscheidung: Ist die "Rest-Phase" (Variable phase_phasenreserve) im Bereich von 0� bis -90�?
	if ((phase_phasenreserve < 0.0) && (phase_phasenreserve >= -90.0))
	{
		// Fallunterscheidung nach Lage der Grenzgrefrequenzen bzw. Polstellen
		// Erster Fall: Alle drei Grenzfrequenzen �berlappen sich
		if ((0.1*OP->Grenzfrequenz[1] < 10.0*OP->Grenzfrequenz[0]) && (0.1*OP->Grenzfrequenz[2] < 10.0*OP->Grenzfrequenz[0]))
		{
			frequenz_phasenreserve = 0.1*pow(10.0, ((phase_phasenreserve / -45.0 + log10(OP->Grenzfrequenz[0] * OP->Grenzfrequenz[1] * OP->Grenzfrequenz[2]))/3.0));
			// Kontrolle: Wenn die berechnete Frequenz jetzt niedriger als ein Zehntel der dritten Grenzfrequenz ist, spielt die dritte Grenzfrequenz hier keine Rolle
			if (frequenz_phasenreserve < 0.1*OP->Grenzfrequenz[2])
				frequenz_phasenreserve = 0.1*pow(10.0, ((phase_phasenreserve / -45.0 + log10(OP->Grenzfrequenz[0] * OP->Grenzfrequenz[1]))/2.0));
		}
		// Zweiter Fall: Die dritte Grenzfrequenz �berlappt sich nicht mit der ersten Grenzfrequenz
		if ((0.1*OP->Grenzfrequenz[1] < 10.0*OP->Grenzfrequenz[0]) && (0.1*OP->Grenzfrequenz[2] >= 10.0*OP->Grenzfrequenz[0]))
		{
			frequenz_phasenreserve = 0.1*pow(10.0, ((phase_phasenreserve / -45.0 + log10(OP->Grenzfrequenz[0] * OP->Grenzfrequenz[1]))/2.0));
			// Kontrolle: Wenn die berechnete Frequenz jetzt niedriger als ein Zehntel der zweiten Grenzfrequenz ist, spielt die zweite Grenzfrequenz hier keine Rolle
			if (frequenz_phasenreserve < 0.1*OP->Grenzfrequenz[1])
				frequenz_phasenreserve = 0.1*pow(10.0, (phase_phasenreserve / -45.0 + log10(OP->Grenzfrequenz[0])));
		}
		// Dritter Fall: Die zweite (und auch die dritte Grenzfrequenz) �berlappt die erste Grenzfrequenz nicht
		if (0.1*OP->Grenzfrequenz[1] >= 10.0*OP->Grenzfrequenz[0])
		{
			frequenz_phasenreserve = 0.1*pow(10.0, (phase_phasenreserve / -45.0 + log10(OP->Grenzfrequenz[0])));
			// Hier gibt es keine weitere Auswahl
		}
	}
	// Fallunterscheidung: Ist die "Rest-Phase" (Variable phase_phasenreserve) im Bereich v0n -90� bis -180�?
	if ((phase_phasenreserve < -90.0) && (phase_phasenreserve >= -180.0))
	{
		// Fallunterscheidung nach Lage der Grenzgrefrequenzen bzw. Polstellen
		// Erster Fall: Alle drei Grenzfrequenzen �berlappen sich
		if ((0.1*OP->Grenzfrequenz[1] < 10.0*OP->Grenzfrequenz[0]) && (0.1*OP->Grenzfrequenz[2] < 10.0*OP->Grenzfrequenz[0]))
		{
			frequenz_phasenreserve = 0.1*pow(10.0, ((phase_phasenreserve / -45.0 + log10(OP->Grenzfrequenz[0] * OP->Grenzfrequenz[1] * OP->Grenzfrequenz[2]))/3.0));
			// Kontrolle: Wenn die berechnete Frequenz jetzt niedriger als ein Zehntel der dritten Grenzfrequenz ist, spielt die dritte Grenzfrequenz hier keine Rolle
			if (frequenz_phasenreserve < 0.1*OP->Grenzfrequenz[2])
				frequenz_phasenreserve = 0.1*pow(10.0, ((phase_phasenreserve / -45.0 + log10(OP->Grenzfrequenz[0] * OP->Grenzfrequenz[1]))/2.0));
		}
		// Zweiter Fall: Die dritte Grenzfrequenz �berlappt sich nicht mit der ersten Grenzfrequenz
		if ((0.1*OP->Grenzfrequenz[1] < 10.0*OP->Grenzfrequenz[0]) && (0.1*OP->Grenzfrequenz[2] >= 10.0*OP->Grenzfrequenz[0]))
		{
			frequenz_phasenreserve = 0.1*pow(10.0, ( (phase_phasenreserve / -45.0 + log10(OP->Grenzfrequenz[0] * OP->Grenzfrequenz[1]))/2.0));
			// Hier muss die Frequenz im Bereich des zweiten Tiefpasses sein
			if (frequenz_phasenreserve > 10 * OP->Grenzfrequenz[0])
				frequenz_phasenreserve = 0.1*pow( 10.0, (( (phase_phasenreserve+90.0) / -45.0) + log10(OP->Grenzfrequenz[1])) );
		}
		// Dritter Fall: Die zweite (und auch die dritte Grenzfrequenz) �berlappt die erste Grenzfrequenz nicht, zweite und dritte Grenzfrequenz �berlappen nicht
		if ((0.1*OP->Grenzfrequenz[1] >= 10.0*OP->Grenzfrequenz[0]) && (10.0*OP->Grenzfrequenz[1] < 0.1*OP->Grenzfrequenz[2]))
		{
			frequenz_phasenreserve = 0.1*pow(10.0, ((phase_phasenreserve + 90) / -45.0 + log10(OP->Grenzfrequenz[1])));
			// Hier gibt es keine weitere Auswahl
		}
		// Vierter Fall: Die zweite (und auch die dritte Grenzfrequenz) �berlappt die erste Grenzfrequenz nicht, aber zweite und dritte Grenzfrequenz �berlappen
		if ((0.1*OP->Grenzfrequenz[1] >= 10.0*OP->Grenzfrequenz[0]) && (10.0*OP->Grenzfrequenz[1] >= 0.1*OP->Grenzfrequenz[2]))
		{
			frequenz_phasenreserve = 0.1*pow(10.0, ((phase_phasenreserve + 90.0) / -45.0 + log10(OP->Grenzfrequenz[1]*OP->Grenzfrequenz[2]))/2.0);
			// Kontrolle: Wenn die berechnete Frequenz jetzt niedriger als ein Zehntel der dritten Grenzfrequenz ist, spielt die dritte Grenzfrequenz hier keine Rolle
			if (frequenz_phasenreserve < 0.1*OP->Grenzfrequenz[2])
				frequenz_phasenreserve = 0.1*pow(10.0, ((phase_phasenreserve +90.0) / -45.0 + log10(OP->Grenzfrequenz[1])));
		}
	}
	if (frequenz_phasenreserve == -1.0)
		OP->Schaltung_berechenbar = false;

	OP->Frequenz_Phasenreserve = frequenz_phasenreserve;

	// Kontrolle auf Stabilit�t
//	OP->Betrag_bei_f_Instabil = Berechne_Betrag_dB_Bodeplot(frequenz_phasenreserve, OP->V_0_dB, OP->Grenzfrequenz);
	if (OP->Betrag_bei_f_Instabil < 0.0)
		OP->OP_Stabil = true;
	else
		OP->OP_Stabil = false;

	// Amplitudenreserve bestimmen
	// Zun�chst Verst�rkung bei Instabilit�tsfrequenz bestimmen
	V_U_Amplitudenreserve = Berechne_Betrag_dB_Bodeplot(OP->Frequenz_Instabilitaet, OP->V_0_dB, OP->Grenzfrequenz) + OP->Amplitudenreserve;
	// Jetzt die Frequenz bestimmen
	OP->Frequenz_Amplitudenreserve = Bestimme_Frequenz_aus_V(V_U_Amplitudenreserve, OP->V_0_dB, OP->Grenzfrequenz);

	return 0;
}

double Berechne_Betrag_dB_Bodeplot(double freq, double V_0, double f_grenz[3])
{
	double rueckgabe;

	rueckgabe = V_0;

	if (freq > f_grenz[0])
		rueckgabe -= 20.0*log10(freq / f_grenz[0]);
	if (freq > f_grenz[1])
		rueckgabe -= 20.0*log10(freq / f_grenz[1]);
	if (freq > f_grenz[2])
		rueckgabe -= 20.0*log10(freq / f_grenz[2]);

	return rueckgabe;
}

double Berechne_Phase_Bodeplot(double freq, double f_grenz[3])
{
	double rueckgabe, phase;

	rueckgabe = 0.0;
	phase = 0.0;
	// Erste Grenzfrequenz
	if ((freq > 0.1*f_grenz[0]) && (freq < 10.0 * f_grenz[0]))
		rueckgabe = -45.0*log10(10.0*freq / f_grenz[0]);
	if (freq >= 10.0*f_grenz[0])
		rueckgabe = -90.0;
	// Zweite Grenzfrequenz
	if ((freq > 0.1*f_grenz[1]) && (freq < 10.0 * f_grenz[1]))
		phase = -45.0*log10(10.0*freq / f_grenz[1]);
	if (freq >= 10.0*f_grenz[1])
		phase = -90.0;
	rueckgabe += phase;
	phase = 0.0;
	// Dritte Grenzfrequenz
	if ((freq > 0.1*f_grenz[2]) && (freq < 10.0 * f_grenz[2]))
		phase = -45.0*log10(10.0*freq / f_grenz[2]);
	if (freq >= 10.0*f_grenz[2])
		phase = -90.0;
	rueckgabe += phase;
	
	return rueckgabe;
}

double Bestimme_Frequenz_aus_V(double V, double V_0, double f_grenz[3])
{
	double frequenz = 0.0;

	if (V > V_0)
		// Falls die Verst�rkung gr��er der Leerlaufverst�rkung ist, kann die Frequenz nicht bestimmt werden
		frequenz = -1.0;
	if (V == V_0)
		// Falls die Verst�rkung genauso gro� ist, wie die Leerlaufverst�rkung, ist die unterste Grenzfrequenz der gesuchte Wert
		frequenz = f_grenz[0];
	if (V < V_0)
	{
		// Falls die Frequenz niedriger als die Leerlaufverst�rkung ist, kann die zugeh�rige Frequenz bestimmt werden. 
		frequenz = f_grenz[0] * pow(10.0, (V_0 - V) / 20.0);
		if (frequenz > f_grenz[1])
			frequenz = f_grenz[1] * pow(10.0, (Berechne_Betrag_dB_Bodeplot(f_grenz[1], V_0, f_grenz) - V) / 40.0);
		if (frequenz > f_grenz[2])
			frequenz = f_grenz[2] * pow(10.0, (Berechne_Betrag_dB_Bodeplot(f_grenz[2], V_0, f_grenz) - V) / 40.0);
	}
	return frequenz;
}

int Zeichne_OP_Bodeplot_Aufruf(HWND hDlg)
{
	// Berechnung und Zeichnung des Bodeplots
	Berechne_Bodeplot_OP(&OP_Bode);
	DialogBox(hInst, MAKEINTRESOURCE(IDD_ZEICHNE_BODEPLOT), hDlg, Zeichne_OP_Bodeplot_Dialog);

	return 0;
}	// end of Zeichne_OP_Bodeplot_Aufruf

int Eingabe_Operationsverstaerker_Aufruf(int Schaltungsauswahl, int OP_parameter)
/*	Funktion wird verwendet, um Daten des Operationsverst�rkers einzugeben.
�bergabeparameter:	Schaltungsauswahl: Nummer der aufrufenden Schaltung - 1: Basis, 2: Emitter, 3: Kollektor, 8: Bipolartransistor als Schalter
10: Differenzverst�rker Parallelzweig (T1), 11: Differenzverst�rker Stromquelle (T2)
OP_parameter:  0: alle Parameter �nderbar, 1: nur V_0 (kein V_0 in dB), 2: nur V_0_dB (kein V_0), 4: Grenzfrequenzen, 
R�ckgabewert: 0		*/
{
	if (!Eingabe_Dialog.Eingabe_OP)
	{
		Eingabe_Dialog.Eingabe_OP = true;
		Eingabe_Dialog.Auswahl_Schaltung = Schaltungsauswahl;
		Eingabe_Dialog.Parameter_OP = OP_parameter;
		DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABE_OP), hWndElektronikMain, Eingabe_Operationsverstaerker_Dialog);
		Eingabe_Dialog.Eingabe_OP = false;
	}

	return 0;
}	// end of Eingabe_Operationsverstaerker_Aufruf

int Zeichne_Invertierenden_OP(Operationsverstaerker INV_OP, HDC hdc, bool Kopie_Zwischenablage)
{
	HPEN hStiftSchwarz2, hStiftAlt;
	HBRUSH hPinselSchwarz, hPinselAlt;
	HFONT FontNeu, FontAlt;
	char cText[100];
	int Schriftgroesse = 16;

	if (Kopie_Zwischenablage)
		Schriftgroesse = 24;

	hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
	hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
	hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
	hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

	// Beschriftung erg�nzen
	// am besten in Arial
	FontNeu = CreateFont(Schriftgroesse, // nHeight
		0,	// nWidth
		0,	// nEscapement
		0,	// nOrientation
		FW_DONTCARE, //fnWeight
		FALSE,	//fdwItalic
		FALSE,	//fdwUnderline
		FALSE,	//fdwStrikeOut
		DEFAULT_CHARSET,	//fdwCharSet
		OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
		CLIP_DEFAULT_PRECIS, //fdwClipPrecision
		CLEARTYPE_QUALITY,	//fdwQuality
		VARIABLE_PITCH,		//fdwPitchAndFamily
		TEXT("Arial"));	//lpszFace
	FontAlt = (HFONT)SelectObject(hdc, FontNeu);

	if (Kopie_Zwischenablage)
	{
		Zeichne_Text_xy(hdc, "R1", 85, 75);
		Zeichne_Text_xy(hdc, "R2", 230, 70);
		Bestimme_Widerstandsbezeichner(cText, INV_OP.R[R_OP_EIN], 99);
		Zeichne_Text_xy(hdc, cText, 85, 100 );
		Bestimme_Widerstandsbezeichner(cText, INV_OP.R[R_OP_RUECKKOPPEL], 99);
		Zeichne_Text_xy(hdc, cText, 230, 95);
		Bestimme_Spannungsbezeichner(cText, INV_OP.U_Ein, 99);
		Zeichne_Text_xy(hdc, cText, 60, 200);
		Zeichne_Text_xy(hdc, "U_E", 60, 175);
		Zeichne_Text_xy(hdc, "U_A", 390, 200);
	}
	else
	{
		Zeichne_Text_xy(hdc, "R1", 85, 75);
		Zeichne_Text_xy(hdc, "R2", 230, 110);
	}

	// Zeichnen der Verbindungspunkte vorab
	Ellipse_BH(hdc, 165, 145, 10, 10);
	Ellipse_BH(hdc, 325, 165, 10, 10);
	// Wieder auf wei�en Hintergrund umschalten
	SelectObject(hdc, hPinselAlt);
	// Anschluss links zeichnen
	Zeichne_Anschluss(hdc, 40, 140, 100);
	// Anschluss rechts zeichnen
	Zeichne_Anschluss(hdc, 370, 160, 100);
	// Leitung f�r R1
	ZP_Linie(hdc, 60, 150, 200, 150);
	// Leitung f�r R2
	VP_Linie(hdc, 170, 150, 170, 50, 330, 50, 330, 170);
	//Widerst�nde R1, R2 Positionen: x=185, y=50, x=185, y=370:
	Zeichne_Widerstand(hdc, 85, 135, 60, 30);
	Zeichne_Widerstand(hdc, 230, 35, 60, 30);
	// Zeichne OP
	Zeichne_OP(hdc, 200, 120, 100, 100, true);
	// Masseanschluss f�r OP Position: x: , y: 480
	DP_Linie(hdc, 200, 190, 170, 190, 170, 220);
	ZP_Linie(hdc, 155, 220, 185, 220);
	// Ausgangsleitung des OPs
	ZP_Linie(hdc, 300, 170, 370, 170);

	SelectObject(hdc, hPinselAlt);
	DeleteObject(hPinselSchwarz);
	SelectObject(hdc, hStiftAlt);
	DeleteObject(hStiftSchwarz2);
	SelectObject(hdc, FontAlt);
	DeleteObject(FontNeu);

	return 0;
}

int Kopiere_Invertierenden_OP(Operationsverstaerker INV_OP)
{
	HDC hdcMeta;
	HENHMETAFILE hMeta;

	hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
	// OP-schaltung zeichnen
	Zeichne_Invertierenden_OP(INV_OP, hdcMeta, true);
	hMeta = CloseEnhMetaFile(hdcMeta);
	// Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
	OpenClipboard(hWndElektronikMain);
	EmptyClipboard();
	SetClipboardData(CF_ENHMETAFILE, hMeta);
	CloseClipboard();

	return 0;
} // end of Kopiere_Invertierenden_OP

int Zeichne_Nichtinvertierenden_OP(Operationsverstaerker Nicht_INV_OP, HDC hdc, bool Kopie_Zwischenablage)
{
	UNREFERENCED_PARAMETER( Nicht_INV_OP );
	HPEN hStiftSchwarz2, hStiftAlt;
	HBRUSH hPinselSchwarz, hPinselAlt, hPinselWeiss;
	HFONT FontNeu, FontAlt;
	char cText[100];
	int Schriftgroesse = 16;

	if (Kopie_Zwischenablage)
		Schriftgroesse = 24;

	hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
	hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
	hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
	hPinselWeiss = CreateSolidBrush( RGB(255,255,255) );
	hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

	// Beschriftung erg�nzen am besten in Arial
	FontNeu = CreateFont(Schriftgroesse, // nHeight
		0,	// nWidth
		0,	// nEscapement
		0,	// nOrientation
		FW_DONTCARE, //fnWeight
		FALSE,	//fdwItalic
		FALSE,	//fdwUnderline
		FALSE,	//fdwStrikeOut
		DEFAULT_CHARSET,	//fdwCharSet
		OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
		CLIP_DEFAULT_PRECIS, //fdwClipPrecision
		CLEARTYPE_QUALITY,	//fdwQuality
		VARIABLE_PITCH,		//fdwPitchAndFamily
		TEXT("Arial"));	//lpszFace
	FontAlt = (HFONT)SelectObject(hdc, FontNeu);

	if (Kopie_Zwischenablage)
	{
		Bestimme_Widerstandsbezeichner(cText, Nichtinvertierender_OP.R[R_OP_EIN], 99);
		Zeichne_Text_xy(hdc, cText, 300, 120);
		Zeichne_Text_xy(hdc, "R1", 300, 95);
		Bestimme_Widerstandsbezeichner(cText, Nichtinvertierender_OP.R[R_OP_RUECKKOPPEL], 99);
		Zeichne_Text_xy(hdc, cText, 300, 220);
		Zeichne_Text_xy(hdc, "R2", 300, 195);
		Bestimme_Spannungsbezeichner(cText, Nichtinvertierender_OP.U_Ein, 99);
		Zeichne_Text_xy(hdc, cText, 60, 95);
		Zeichne_Text_xy(hdc, "U_E", 60, 70);
		Zeichne_Text_xy(hdc, "U_A", 420, 110);
	}
	else
	{
		Zeichne_Text_xy(hdc, "R1", 365, 100);
		Zeichne_Text_xy(hdc, "R2", 365, 200);
	}

	hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
	hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
	hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
	hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

	// Zeichnen der Verbindungspunkte vorab
	Ellipse_BH(hdc, 275, 165, 10, 10);
	Ellipse_BH(hdc, 275, 65, 10, 10);
	// Wieder auf wei�en Hintergrund umschalten
	SelectObject(hdc, hPinselWeiss);
	// Anschluss links zeichnen
	Zeichne_Anschluss(hdc, 40, 40, 100);
	// Anschluss rechts zeichnen
	Zeichne_Anschluss(hdc, 400, 60, 100);
	// Leitung f�r Eingang
	ZP_Linie(hdc, 60, 50, 150, 50);
	// Zeichne OP
	Zeichne_OP(hdc, 150, 20, 100, 100, false);
	// R�ckkopplung
	VP_Linie(hdc, 150, 90, 125, 90, 125, 170, 280, 170);
	// Leitung f�r R1 und R2
	DP_Linie(hdc, 250, 70, 280, 70, 280, 270);
	//Widerst�nde R1, R2 Positionen: x=185, y=50, x=185, y=370:
	Zeichne_Widerstand(hdc, 265, 90, 30, 60);
	Zeichne_Widerstand(hdc, 265, 190, 30, 60);

	// Masseanschluss f�r OP Position: x: , y: 480
	ZP_Linie(hdc, 265, 270, 295, 270);
	// Ausgangsleitung des OPs
	ZP_Linie(hdc, 280, 70, 400, 70);

	SelectObject(hdc, hPinselAlt);
	DeleteObject(hPinselSchwarz);
	DeleteObject(hPinselWeiss);
	SelectObject(hdc, hStiftAlt);
	DeleteObject(hStiftSchwarz2);
	SelectObject(hdc, FontAlt);
	DeleteObject(FontNeu);

	return 0;
} // end of Zeichne_Nichtinvertierenden_OP

int Kopiere_Nichtinvertierenden_OP(Operationsverstaerker Nicht_INV_OP)
{
	HDC hdcMeta;
	HENHMETAFILE hMeta;

	hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
	// OP-schaltung zeichnen
	Zeichne_Nichtinvertierenden_OP(Nicht_INV_OP, hdcMeta, true);
	hMeta = CloseEnhMetaFile(hdcMeta);
	// Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
	OpenClipboard(hWndElektronikMain);
	EmptyClipboard();
	SetClipboardData(CF_ENHMETAFILE, hMeta);
	CloseClipboard();

	return 0;
} // end of Kopiere_Nichtinvertierenden_OP

int Zeichne_Differenzierenden_OP(Operationsverstaerker Diff_OP, HDC hdc, bool Kopie_Zwischenablage)
{
	HPEN hStiftSchwarz2, hStiftAlt;
	HBRUSH hPinselSchwarz, hPinselAlt, hPinselWeiss;
	HFONT FontNeu, FontAlt;
	char cText[100];
	int Schriftgroesse = 16;

	if (Kopie_Zwischenablage)
		Schriftgroesse = 24;

	hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
	hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
	hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
	hPinselWeiss = CreateSolidBrush(RGB(255, 255, 255));
	hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

	// Beschriftung erg�nzen am besten in Arial
	FontNeu = CreateFont(Schriftgroesse, // nHeight
		0,	// nWidth
		0,	// nEscapement
		0,	// nOrientation
		FW_DONTCARE, //fnWeight
		FALSE,	//fdwItalic
		FALSE,	//fdwUnderline
		FALSE,	//fdwStrikeOut
		DEFAULT_CHARSET,	//fdwCharSet
		OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
		CLIP_DEFAULT_PRECIS, //fdwClipPrecision
		CLEARTYPE_QUALITY,	//fdwQuality
		VARIABLE_PITCH,		//fdwPitchAndFamily
		TEXT("Arial"));	//lpszFace
	FontAlt = (HFONT)SelectObject(hdc, FontNeu);

	if (Kopie_Zwischenablage)
	{
		Zeichne_Text_xy(hdc, "R1", 230, 70);
		Bestimme_Widerstandsbezeichner(cText, Diff_OP.R[R_OP_DIFF], 99);
		Zeichne_Text_xy(hdc, cText, 230, 95);
		SetTextAlign(hdc, TA_RIGHT);
		Zeichne_Text_xy(hdc, "C1", 115, 120);
		Bestimme_Kapazitaetsbezeichner(cText, Diff_OP.C, 99);
		Zeichne_Text_xy(hdc, cText, 115, 95);
		SetTextAlign(hdc, TA_LEFT);
		Zeichne_Text_xy(hdc, "U_E", 60, 190);
		Bestimme_Spannungsbezeichner(cText, Diff_OP.U_Ein, 99);
		Zeichne_Text_xy(hdc, cText, 60,215);
		Bestimme_Frequenzbezeichner(cText, Diff_OP.freq, 99);
		Zeichne_Text_xy(hdc, cText, 60, 240);
		Zeichne_Text_xy(hdc, "U_A", 390, 205);
	}
	else
	{ // Ausgabe Dialogbox
		Zeichne_Text_xy(hdc, "R1", 230, 110);
		Zeichne_Text_xy(hdc, "C1", 100, 32);
	}
	// Zeichnen der Verbindungspunkte vorab
	Ellipse_BH(hdc, 165, 145, 10, 10);
	Ellipse_BH(hdc, 325, 165, 10, 10);
	// Wieder auf wei�en Hintergrund umschalten
	SelectObject(hdc, hPinselWeiss);
	// Anschluss links zeichnen
	Zeichne_Anschluss(hdc, 40, 140, 160);
	// Anschluss rechts zeichnen
	Zeichne_Anschluss(hdc, 370, 160, 100);
	// Leitung f�r C1
	ZP_Linie(hdc, 60, 150, 122, 150);
	ZP_Linie(hdc, 145, 150, 200, 150);
	// Leitung f�r R1
	VP_Linie(hdc, 170, 150, 170, 50, 330, 50, 330, 170);
	//Widerstand R1 
	Zeichne_Widerstand(hdc, 230, 35, 60, 30);
	// Einkoppelkondensator
	Zeichne_Kondensator(hdc, 125, 100, 20, 100, C_HORIZONTAL);
	// Zeichne OP
	Zeichne_OP(hdc, 200, 120, 100, 100, true);
	// Masseanschluss f�r OP Position: x: , y: 480
	DP_Linie(hdc, 200, 190, 170, 190, 170, 220);
	ZP_Linie(hdc, 155, 220, 185, 220);
	// Ausgangsleitung des OPs
	ZP_Linie(hdc, 300, 170, 370, 170);

	SelectObject(hdc, hPinselAlt);
	DeleteObject(hPinselSchwarz);
	SelectObject(hdc, hStiftAlt);
	DeleteObject(hStiftSchwarz2);
	SelectObject(hdc, FontAlt);
	DeleteObject(FontNeu);

	return 0;
} // end of Zeichne_Differenzierenden_OP

int Kopiere_Differenzierenden_OP(Operationsverstaerker Diff_OP)
{
	HDC hdcMeta;
	HENHMETAFILE hMeta;

	hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
	// OP-schaltung zeichnen
	Zeichne_Differenzierenden_OP(Diff_OP, hdcMeta, true);
	hMeta = CloseEnhMetaFile(hdcMeta);
	// Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
	OpenClipboard(hWndElektronikMain);
	EmptyClipboard();
	SetClipboardData(CF_ENHMETAFILE, hMeta);
	CloseClipboard();

	return 0;
} // end of Kopiere_Differenzierenden_OP

int Zeichne_Integrierenden_OP(Operationsverstaerker Integral_OP, HDC hdc, bool Kopie_Zwischenablage)
{
	HPEN hStiftSchwarz2, hStiftAlt;
	HBRUSH hPinselSchwarz, hPinselAlt, hPinselWeiss;
	HFONT FontNeu, FontAlt;
	char cText[100];
	int Schriftgroesse = 16;

	if (Kopie_Zwischenablage)
		Schriftgroesse = 24;

	hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
	hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
	hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
	hPinselWeiss = CreateSolidBrush(RGB(255, 255, 255));
	hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

	// Beschriftung erg�nzen am besten in Arial
	FontNeu = CreateFont(Schriftgroesse, // nHeight
		0,	// nWidth
		0,	// nEscapement
		0,	// nOrientation
		FW_DONTCARE, //fnWeight
		FALSE,	//fdwItalic
		FALSE,	//fdwUnderline
		FALSE,	//fdwStrikeOut
		DEFAULT_CHARSET,	//fdwCharSet
		OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
		CLIP_DEFAULT_PRECIS, //fdwClipPrecision
		CLEARTYPE_QUALITY,	//fdwQuality
		VARIABLE_PITCH,		//fdwPitchAndFamily
		TEXT("Arial"));	//lpszFace
	FontAlt = (HFONT)SelectObject(hdc, FontNeu);

	if (Kopie_Zwischenablage)
	{
		Bestimme_Widerstandsbezeichner(cText, Integral_OP.R[R_OP_EIN], 99);
		Zeichne_Text_xy(hdc, cText, 85, 110); 
		Zeichne_Text_xy(hdc, "R1", 85, 85);
		Bestimme_Kapazitaetsbezeichner(cText, Integral_OP.C, 99);
		Zeichne_Text_xy(hdc, cText, 275, 80);
		Zeichne_Text_xy(hdc, "C1", 275, 55);
		Bestimme_Spannungsbezeichner(cText, Integral_OP.U_Ein, 99);
		Zeichne_Text_xy(hdc, cText, 60, 210);
		Bestimme_Frequenzbezeichner(cText, Integral_OP.freq, 99);
		Zeichne_Text_xy(hdc, cText, 60, 235);
		Zeichne_Text_xy(hdc, "U_E", 60, 185);
		Zeichne_Text_xy(hdc, "U_A", 400, 205);
	}
	else
	{ // Ausgabe Dialogbox
		Zeichne_Text_xy(hdc, "R1", 85, 75);
		Zeichne_Text_xy(hdc, "C1", 275, 110);
	}

	// Zeichnen der Verbindungspunkte vorab
	Ellipse_BH(hdc, 165, 145, 10, 10);
	Ellipse_BH(hdc, 345, 165, 10, 10);
	// Wieder auf wei�en Hintergrund umschalten
	SelectObject(hdc, hPinselWeiss);
	// Anschluss links zeichnen
	Zeichne_Anschluss(hdc, 40, 140, 160);
	// Anschluss rechts zeichnen
	Zeichne_Anschluss(hdc, 380, 160, 100);
	// Leitung f�r R1
	ZP_Linie(hdc, 60, 150, 200, 150);
	// Leitung f�r R2
	DP_Linie(hdc, 170, 150, 170, 50, 250, 50);
	DP_Linie(hdc, 270, 50, 350, 50, 350, 170);
	//Widerstand R1
	Zeichne_Widerstand(hdc, 85, 135, 60, 30);
	// Kondensator
	Zeichne_Kondensator(hdc, 250, 0, 20, 100, C_HORIZONTAL);
	// Zeichne OP
	Zeichne_OP(hdc, 200, 120, 100, 100, true);
	// Masseanschluss f�r OP Position: x: , y: 480
	DP_Linie(hdc, 200, 190, 170, 190, 170, 220);
	ZP_Linie(hdc, 155, 220, 185, 220);
	// Ausgangsleitung des OPs
	ZP_Linie(hdc, 300, 170, 380, 170);

	SelectObject(hdc, hPinselAlt);
	DeleteObject(hPinselSchwarz);
	DeleteObject(hPinselWeiss);
	SelectObject(hdc, hStiftAlt);
	DeleteObject(hStiftSchwarz2);
	SelectObject(hdc, FontAlt);
	DeleteObject(FontNeu);

	return 0;
} // end of Zeichne_Integrierenden_OP

int Kopiere_Integrierenden_OP(Operationsverstaerker Integrator_OP )
{
	HDC hdcMeta;
	HENHMETAFILE hMeta;

	hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
	// OP-schaltung zeichnen
	Zeichne_Integrierenden_OP(Integrator_OP, hdcMeta, true);
	hMeta = CloseEnhMetaFile(hdcMeta);
	// Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
	OpenClipboard(hWndElektronikMain);
	EmptyClipboard();
	SetClipboardData(CF_ENHMETAFILE, hMeta);
	CloseClipboard();

	return 0;
} // end of Kopiere_Integrierenden_OP

int Zeichne_Summierenden_OP(Operationsverstaerker Summ_OP, HDC hdc, bool Kopie_Zwischenablage)
{
	HPEN hStiftSchwarz2, hStiftAlt;
	HBRUSH hPinselSchwarz, hPinselAlt, hPinselWeiss;
	HFONT FontNeu, FontAlt;
	char cText[100];
	int Schriftgroesse = 16;

	if (Kopie_Zwischenablage)
		Schriftgroesse = 24;

	hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
	hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
	hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
	hPinselWeiss = CreateSolidBrush(RGB(255, 255, 255));
	hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

	// Beschriftung erg�nzen am besten in Arial
	FontNeu = CreateFont(Schriftgroesse, // nHeight
		0,	// nWidth
		0,	// nEscapement
		0,	// nOrientation
		FW_DONTCARE, //fnWeight
		FALSE,	//fdwItalic
		FALSE,	//fdwUnderline
		FALSE,	//fdwStrikeOut
		DEFAULT_CHARSET,	//fdwCharSet
		OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
		CLIP_DEFAULT_PRECIS, //fdwClipPrecision
		CLEARTYPE_QUALITY,	//fdwQuality
		VARIABLE_PITCH,		//fdwPitchAndFamily
		TEXT("Arial"));	//lpszFace
	FontAlt = (HFONT)SelectObject(hdc, FontNeu);

	if (Kopie_Zwischenablage)
	{
		Zeichne_Text_xy(hdc, "R1", 95, 30);
		Zeichne_Text_xy(hdc, "R2", 125, 130);
		Zeichne_Text_xy(hdc, "R3", 270, 120);
		Bestimme_Widerstandsbezeichner(cText, Summ_OP.R[R_OP_EIN_1], 99);
		Zeichne_Text_xy(hdc, cText, 95, 55);
		Bestimme_Widerstandsbezeichner(cText, Summ_OP.R[R_OP_EIN_2], 99);
		Zeichne_Text_xy(hdc, cText, 125, 155);
		Bestimme_Widerstandsbezeichner(cText, Summ_OP.R[R_OP_SUMME_RUECKKOPPEL], 99);
		Zeichne_Text_xy(hdc, cText, 270, 145);
		Bestimme_Spannungsbezeichner(cText, Summ_OP.U_Ein, 99);
		Zeichne_Text_xy(hdc, cText, 50, 150);
		Zeichne_Text_xy(hdc, "U_E1", 50, 125);
		Bestimme_Spannungsbezeichner(cText, Summ_OP.U_Ein_2, 99);
		Zeichne_Text_xy(hdc, cText, 100, 245);
		Zeichne_Text_xy(hdc, "U_E2", 100, 220);
		Zeichne_Text_xy(hdc, "U_A", 430, 250);
	}
	else
	{ // Ausgabe Dialogbox
		Zeichne_Text_xy(hdc, "R1", 95, 25);
		Zeichne_Text_xy(hdc, "R2", 125, 125);
		Zeichne_Text_xy(hdc, "R3", 270, 160);
	}
	// Zeichnen der Verbindungspunkte vorab
	Ellipse_BH(hdc, 205, 195, 10, 10);
	Ellipse_BH(hdc, 365, 215, 10, 10);
	Ellipse_BH(hdc, 205, 95, 10, 10);
	// Wieder auf wei�en Hintergrund umschalten
	SelectObject(hdc, hPinselAlt);
	// Ersten Anschluss links zeichnen
	Zeichne_Anschluss(hdc, 80, 190, 100);
	// Zweiten Anschluss links
	Zeichne_Anschluss(hdc, 30, 90, 100);
	// Anschluss rechts zeichnen
	Zeichne_Anschluss(hdc, 410, 210, 100);
	// Leitung f�r R1
	ZP_Linie(hdc, 50, 100, 210, 100);
	// Leitung f�r R2
	ZP_Linie(hdc, 100, 200, 240, 200);
	// Leitung f�r R3
	VP_Linie(hdc, 210, 200, 210, 100, 370, 100, 370, 220);
	//Widerst�nde R1, R2, R3 Positionen: x=185, y=50, x=185, y=370:
	Zeichne_Widerstand(hdc, 125, 185, 60, 30);
	Zeichne_Widerstand(hdc, 270, 85, 60, 30);
	Zeichne_Widerstand(hdc, 95, 85, 60, 30);

	// Zeichne OP
	Zeichne_OP(hdc, 240, 170, 100, 100, true);
	// Masseanschluss f�r OP Position: x: , y: 480
	DP_Linie(hdc, 240, 240, 210, 240, 210, 270);
	ZP_Linie(hdc, 195, 270, 225, 270);
	// Ausgangsleitung des OPs
	ZP_Linie(hdc, 340, 220, 410, 220);

	SelectObject(hdc, hPinselAlt);
	DeleteObject(hPinselSchwarz);
	DeleteObject(hPinselWeiss);
	SelectObject(hdc, hStiftAlt);
	DeleteObject(hStiftSchwarz2);
	SelectObject(hdc, FontAlt);
	DeleteObject(FontNeu);

	return 0;
} // end of Zeichne_Summierenden_OP

int Kopiere_Summierenden_OP(Operationsverstaerker Summ_OP)
{
	HDC hdcMeta;
	HENHMETAFILE hMeta;

	hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
	// OP-schaltung zeichnen
	Zeichne_Summierenden_OP(Summ_OP, hdcMeta, true);
	hMeta = CloseEnhMetaFile(hdcMeta);
	// Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
	OpenClipboard(hWndElektronikMain);
	EmptyClipboard();
	SetClipboardData(CF_ENHMETAFILE, hMeta);
	CloseClipboard();

	return 0;
} // end of Kopiere_Summier_OP

int Zeichne_Bodeplot(Operationsverstaerker Bode_OP, HDC hdc, bool Kopie_Zwischenablage)
{
	Bodeplot_Grafik Bode;

	Bode.f_min = 1;
	Bode.f_max = OP_Bode.Frequenz_minus_60dB;
	Bode.V_U_min_dB = -60;
	Bode.V_U_max_dB = (int)OP_Bode.V_0_dB;
	Bode.y_min2 = 0;
	Bode.y_max2 = -270;
	Bode.Rand_x_min = 10;
	Bode.Rand_x_max = 510;
	Bode.Rand_y_min = 10;
	Bode.Rand_y_max = 660;
	Bode.Grafik_x_max = 0;
	Zeichne_Bodeplot(hdc, &Bode, "Bodeplot", &Bode_OP, Kopie_Zwischenablage );
	Zeichne_OP_Kurve_in_Bodeplot(hdc, &Bode);

	return 0;
} // end of Zeichne_Bodeplot

int Kopiere_Bodeplot(Operationsverstaerker Bode_OP)
{
	HDC hdcMeta;
	HENHMETAFILE hMeta;

	hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
	Zeichne_Bodeplot(Bode_OP, hdcMeta, true);
	hMeta = CloseEnhMetaFile(hdcMeta);
	// Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
	OpenClipboard(hWndElektronikMain);
	EmptyClipboard();
	SetClipboardData(CF_ENHMETAFILE, hMeta);
	CloseClipboard();

	return 0;
} // end of Kopiere_Bodeplot