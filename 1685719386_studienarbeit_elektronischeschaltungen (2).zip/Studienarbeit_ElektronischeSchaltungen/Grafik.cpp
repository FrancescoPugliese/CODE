#include "stdafx.h"
/*******************************************************************************************************************\
|																													|
| Modul Grafik.cpp																									|
|																													|
| In diesem Modul sind verschiedene Funktionen zur grafischen Darstellung u.a. Zeichnen von Koordinatensystemen		|
| enthalten																											|
| - DP_Linie();																										|
| - Ellipse_BH();																									|
| - Erstelle_Font_Arial();																							|
| - FillTriangle();																									|
| - Linien_Rechteck_BH();																							|
| - Rechteck_BH_Flaeche();																							|
| - Rechteck_BH_Rahmen();																							|
| - VP_Linie();																										|
| - Zeichne_Anschluss();																							|
| - Zeichne_Bipolartransistor();																					|
| - Zeichne_Bodeplot();																								|
| - Zeichne_Feldeffekttransistor();																					|
| - Zeichne_Gleichspannungsquelle();																				|
| - Zeichne_Kondensator();																							|
| - Zeichne_Koordinatensystem_Ursprung_links_unten();																|
| - Zeichne_Koordinatensystem_Ursprung_mitte();																		|
| - Zeichne_Kurve_in_Koordinatensystem_Ursprung_links_unten();														|
| - Zeichne_OP();																									|
| - Zeichne_OP_Kurve_in_Bodeplot();																					|
| - Zeichne_OP_mit_Anschluessen();																					|
| - Zeichne_Sinus();																								|
| - Zeichne_Text_xy();																								|
| - Zeichne_Wechselspannungsquelle();																				|
| - Zeichne_Widerstand();																							|
| - Zeichne_Zeiger_in_Koordinatensystem_Ursprung_mitte();															|
| - ZP_Linie();																										|
|  																													|
\*******************************************************************************************************************/
// Hilfsfunktionen f�r GDI-Ausgabe
BOOL Ellipse_BH(HDC hdc, int x, int y, int Breite, int Hoehe)
// Zeichnet eine Ellipse mit der angegebenen Breite und H�he
{
	return Ellipse(hdc, x, y, x + Breite, y + Hoehe);
}
BOOL Ellipse_BH(HDC hdc, int x, int y, int Breite, int Hoehe, bool Fuellung)
// Zeichnet eine Ellipse mit der angegebenen Breite und H�he
{
	if (Fuellung)
	  return Ellipse(hdc, x, y, x + Breite, y + Hoehe);
	else 
		return Arc( hdc, x, y, x + Breite, y + Hoehe, x, y, x, y);
}
BOOL Ellipsenbogen_BH_Winkel1_Winkel2(HDC hdc,  int x, int y, int Breite, int Hoehe, double alpha1, double alpha2)
// Zeichnet eine Ellipse mit dem Mittelpunkt x,y und dem angegebenen Radius vom Winkel alpha1 bis zum Winkel alpha2
// 270� ist unten, 90� ist oben
{
	int rueckgabe;

	rueckgabe = Arc( hdc, x, y, x+Breite, y+Hoehe,(int)(x+Breite/2+Breite/2*cos(alpha1*pi/180.0)+0.5), (int)(y+Hoehe/2-Hoehe/2*sin(alpha1*pi/180.0)+0.5), (int)(x+Breite/2+Breite/2*cos(alpha2*pi/180.0)+0.5), (int)(y+Hoehe/2-Hoehe/2*sin(alpha2*pi/180.0)+0.5) );

	return 0; 
}
BOOL Kreis_Mitte_Radius(HDC hdc, int x, int y, int Radius)
// Zeichnet einen Kreis mit dem Mittelpunkt x,y und dem angegebenen Radius
{
	return Ellipse(hdc, x-Radius, y-Radius, x+Radius, y+Radius);
}
BOOL Kreisbogen_Mitte_Radius_Winkel1_Winkel2(HDC hdc,  int x, int y, int Radius, double alpha1, double alpha2)
// Zeichnet einen Kreis mit dem Mittelpunkt x,y und dem angegebenen Radius vom Winkel alpha1 bis zum Winkel alpha2
{
	int rueckgabe;
	// AngleArc zeichnet eine Linie vom aktuellen Punkt (wo immer der Cursor gerade sein mag) zum Anfangspunkt. 
	// Das wird mit dem MoveToEx-Befehlt zur Bewegung des Cursors auf den Startpunkt vermieden.
	rueckgabe = MoveToEx( hdc, (int)(x+Radius*cos(alpha1*pi/180.0)), (int)(y-Radius*sin(alpha1*pi/180.0)),(LPPOINT) NULL );
	//hilf_x=x+Radius*cos(alpha1*pi/180.0);
	//hilf_y=y-Radius*sin(alpha1*pi/180.0);
	// Die Funktion AngleArc erwartet als letzten Parameter den "Winkel�nderungswert".
	AngleArc(hdc, x, y, (DWORD)Radius, (float)alpha1, (float)(alpha2-alpha1));
	return 0; 
}

BOOL Kreisbogen2_Mitte_Radius_Winkel1_Winkel2(HDC hdc,  int x, int y, double Radius, double alpha1, double alpha2)
// Zeichnet einen Kreis mit dem Mittelpunkt x,y und dem angegebenen Radius vom Winkel alpha1 bis zum Winkel alpha2
// Funktion in Ordnung. 28.7.2019 M. Alles
{
	int rueckgabe;

	// Wechsel auf Arc-Funktion. Damit kann der MoveTo-Befehl entfallen, die Koordinatenberechnung ist jetzt eher aufwendig.
	// So entfallen aber die Kreisbogensegmente bei der Kopie in die Zwischenablage. 28.7.2019 M. Alles
	rueckgabe = Arc( hdc, (int)(x-Radius), (int)(y-Radius), (int)(x+Radius), (int)(y+Radius),(int)(x+Radius*cos(alpha1*pi/180.0)+0.5), (int)(y-Radius*sin(alpha1*pi/180.0)+0.5), (int)(x+Radius*cos(alpha2*pi/180.0)+0.5), (int)(y-Radius*sin(alpha2*pi/180.0)+0.5) );

	return 0; 
}

BOOL Zeichne_Kreuz(HDC hdc, int x, int y, int laenge, BYTE rot, BYTE gruen, BYTE blau)
// Zeichnet ein Kreuz an der angegebenen Position. Laenge ist dabei die Kantenl�nge des umschreibenden Quadrates. 
// Verwendet wird die angegeben Farbe
{
	BOOL rueckgabe1, rueckgabe2;
	HPEN hStift, hStiftAlt;

	hStift = CreatePen(PS_SOLID, 2, RGB( rot, gruen, blau));
	hStiftAlt = (HPEN)SelectObject(hdc, hStift);
	rueckgabe1=ZP_Linie( hdc, (int)(x-laenge/2.0), (int)(y-laenge/2.0), (int)(x+laenge/2.0), (int)(y+laenge/2.0) );
	rueckgabe2=ZP_Linie( hdc, (int)(x+laenge/2.0), (int)(y-laenge/2.0), (int)(x-laenge/2.0), (int)(y+laenge/2.0) );

	SelectObject(hdc, hStiftAlt);
	DeleteObject(hStift);
	return rueckgabe2; // (rueckgabe1&&rueckgabe2);
} // end of Zeichne_Kreuz

int Rechteck_BH_Flaeche(HDC hdc, int x, int y, int Breite, int Hoehe, HBRUSH hBrush)
// Zeichnet ein Rechteck mit der angegebenen Breite und H�he
{
	RECT Rechteck;

	SetRect(&Rechteck, x, y, x + Breite, y + Hoehe);
	return FillRect(hdc, &Rechteck, hBrush);
}

BOOL Rechteck_BH_Rahmen(HDC hdc, int x, int y, int Breite, int Hoehe)
// Zeichnet ein Rechteck mit der angegebenen Breite und H�he
{
	return Rectangle(hdc, x, y, x + Breite, y + Hoehe);
}

BOOL Linien_Rechteck_BH(HDC hdc, int x, int y, int Breite, int Hoehe)
// Zeichnet ein Rechteck mit der angegebenen Breite und H�he
{
	POINT Punkt[5];

	Punkt[0].x = x;
	Punkt[0].y = y;
	Punkt[1] = Punkt[0];
	Punkt[1].x += Breite;
	Punkt[2] = Punkt[1];
	Punkt[2].y += Hoehe;
	Punkt[4] = Punkt[0];
	Punkt[3] = Punkt[0];
	Punkt[3].y += Hoehe;

	return Polyline(hdc, Punkt, 5);
}

BOOL ZP_Linie(HDC hdc, int x1, int y1, int x2, int y2)
// Zeichnet eine Linie von Punkt x1 zu Punkt x2 "Zwei-Punkte-Linie"
{
	POINT Punkt2[2];

	Punkt2[0].x = x1;
	Punkt2[0].y = y1;
	Punkt2[1].x = x2;
	Punkt2[1].y = y2;
	return Polyline(hdc, Punkt2, 2);
} // end of ZP_Linie

BOOL DP_Linie(HDC hdc, int x1, int y1, int x2, int y2, int x3, int y3)
// Zeichnet eine Linie von Punkt 1 zu Punkt 3 "Drei-Punkte-Linie"
{
	POINT Punkt3[3];

	Punkt3[0].x = x1;
	Punkt3[0].y = y1;
	Punkt3[1].x = x2;
	Punkt3[1].y = y2;
	Punkt3[2].x = x3;
	Punkt3[2].y = y3;
	return Polyline(hdc, Punkt3, 3);
}

BOOL VP_Linie(HDC hdc, int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4)
// Zeichnet eine Linie von Punkt 1 zu Punkt 3 "Drei-Punkte-Linie"
{
	POINT Punkt4[4];

	Punkt4[0].x = x1;
	Punkt4[0].y = y1;
	Punkt4[1].x = x2;
	Punkt4[1].y = y2;
	Punkt4[2].x = x3;
	Punkt4[2].y = y3;
	Punkt4[3].x = x4;
	Punkt4[3].y = y4;
	return Polyline(hdc, Punkt4, 4);
}

BOOL FillTriangle(HDC hdc, int x1, int y1, int x2, int y2, int x3, int y3)
// Zeichnet eine Linie von Punkt 1 zu Punkt 3 "Drei-Punkte-Linie"
{
	POINT Punkt3[3];

	Punkt3[0].x = x1;
	Punkt3[0].y = y1;
	Punkt3[1].x = x2;
	Punkt3[1].y = y2;
	Punkt3[2].x = x3;
	Punkt3[2].y = y3;
	return Polygon(hdc, Punkt3, 3);
}

BOOL Zeichne_Text_xy(HDC hdc, char *Text, int x, int y)
{
	BOOL rueckgabe;

	SetBkMode(hdc, TRANSPARENT);
	rueckgabe = ExtTextOut(hdc, x, y, 0, NULL, Text, strnlen(Text, 99), NULL);

	return rueckgabe;
}

BOOL Zeichne_Sinus(HDC hdc, int x, int y, int Breite, int Hoehe)
// Zeichnet eine Sinuskurve, beginnend bei der Position x,y mit der angegebenen Breite und H�he
{
	POINT Punkt7[7];

	Punkt7[0].x = x;
	Punkt7[0].y = y;
	Punkt7[1].x = (long)(x + Breite / 6.0);
	Punkt7[1].y = (long)(y - Hoehe / 2.0 * sin(pi / 3.0));
	Punkt7[2].x = (long)(x + Breite * 2.0 / 6.0);
	Punkt7[2].y = (long)(y - Hoehe / 2.0 * sin(2.0* pi / 3.0));
	Punkt7[3].x = (long)(x + Breite / 2.0);
	Punkt7[3].y = y;
	Punkt7[4].x = (long)(x + Breite * 4.0 / 6.0);
	Punkt7[4].y = (long)(y + Hoehe / 2.0 * sin(pi / 3.0));
	Punkt7[5].x = (long)(x + Breite * 5.0 / 6.0);
	Punkt7[5].y = (long)(y + Hoehe / 2.0 * sin(pi / 3.0));
	Punkt7[6].x = (long)(x + Breite);
	Punkt7[6].y = y;

	return PolyBezier(hdc, Punkt7, 7);
}

int Zeichne_Koordinatensystem_Ursprung_links_unten(HDC hdc, Koordinatensystem *Koord, char Beschriftung_x1[40], char Beschriftung_y1[40], char Beschriftung_x2[40], char Beschriftung_y2[40], char Ueberschrift[80], bool Kopie_Zwischenablage)
{	// �berladene Funktion mit den "alten" Parametern, verweist auf die passende "neue" Funktion, mit der die Auswahl zwischen wissenschaftlicher Zahlendarstellung und Vorsatzzeichen m�glich ist.
	return Zeichne_Koordinatensystem_Ursprung_links_unten(hdc, Koord, Beschriftung_x1, Beschriftung_y1, Beschriftung_x2, Beschriftung_y2, Ueberschrift, Kopie_Zwischenablage, true);
} // end of Zeichne_Koordinatensystem_Ursprung_links_unten

int Zeichne_Koordinatensystem_Ursprung_links_unten(HDC hdc, Koordinatensystem *Koord, char Beschriftung_x1[40], char Beschriftung_y1[40], char Beschriftung_x2[40], char Beschriftung_y2[40], char Ueberschrift[80], bool Kopie_Zwischenablage, bool Verwende_Vorsatzzeichen)
/*******************************************************************************************************************\
| Funktion zur Zeichnung eines Koordinatensystems mit Beschriftung													|
| 26.10.2014 M.Alles																								|
| 30.03.2018 M.Alles �nderung: Nulllinien werden nur im Zeichenbereich gezeichnet									|
| Eingabeparameter: HDC hdc: Handle auf den DeviceContext															|
|					Struktur Koordinatensystem mit																	|
|						int Rand_x_min: Linker Rand des Koordinatensystems											|
|						int Rand_x_max: Rechter Rand des Koordinatensystems											|
|						int Rand_y_min: Oberer Rand des Koordinatensystems											|
|						int Rand_y_max: Unterer Rand des Koordinatensystems											|
|						double minimalwert_x: Beschriftungswert														|
|						double maximalwert_x: Beschriftungswert														|
|						double minimalwert_y: Beschriftungswert														|
|						double maximalwert_y: Beschriftungswert														|
|						char Beschriftung_x[40]:	Bezeichner f�r die x-Achse										|
|						char Beschriftung_y[40]:	Bezeichner f�r die y-Achse										|
|						char Ueberschrift[80];	Titel der Grafik													|
|						int pfeilspitze:	Ma� f�r die Pfeilspitzen												|
|						int skalenstrich:	Ma� f�r die L�nge der Skalenstriche										|
|						int delta_min:		Abstand vom Grafikrand (links, oben) f�r Beschriftung					|
|						int delta_max:		Abstand vom Grafikrand (unten, rechts) f�r Beschriftung					|
| R�ckgabewert:		int Fehler (0: kein Fehler)																		|
|																													|
|						int Grafik_x_min: Linker Rand des Koordinatensystems										|
|						int Grafik_x_max: Rechter Rand des Koordinatensystems										|
|						int Grafik_y_min: Oberer Rand des Koordinatensystems										|
|						int Grafik_y_max: Unterer Rand des Koordinatensystems										|
| Die Funktion zeichnet ein Koordinatensystem mit Skalenteilung (jeweils 10 Werte) und Beschriftung.				|
| Die Koordinaten werden als Zeiger �bernommen und in der Funktion "nach innen" geschoben, um Platz f�r die			|
| Beschriftung zu geben. Die Verschiebung erfolgt �ber "#define"-Werte.												|
| Bedingung f�r das Zeichnen der x- und y-Achse ge�ndert auf Grafik->x/y_min.										|
\*******************************************************************************************************************/
{
	UNREFERENCED_PARAMETER(Beschriftung_y2);
	UNREFERENCED_PARAMETER(Beschriftung_x2);

	POINT Punkt[3];
	char cText[200];

	LOGFONT lf;
	HPEN hPen, hPenPrev;
	HFONT hFontGerade, hFontGedreht, hFontSystem;
	RECT Diagrammbereich;

	// Zu Beginn wird ein graues Rechteck gezeichnet, um den Hintergrund l�schen
	Diagrammbereich.left = Koord->Rand_x_min;
	Diagrammbereich.right = Koord->Rand_x_max;
	Diagrammbereich.top = Koord->Rand_y_min;
	Diagrammbereich.bottom = Koord->Rand_y_max;
	if (!Kopie_Zwischenablage)
		FillRect(hdc, &Diagrammbereich, (HBRUSH)COLOR_WINDOW);

	// Hintergrund auf grau setzen
	SetBkColor(hdc, GetSysColor(COLOR_WINDOW));
	SetBkMode(hdc, TRANSPARENT);

	// Neue Grenzen setzen: oben und rechts vom Rand 30 Punkte nach innen, unten und links jeweils 50 Punkte
	Koord->Grafik_y_min = Koord->Rand_y_min + Koord->delta_min;
	Koord->Grafik_y_max = Koord->Rand_y_max - Koord->delta_max;
	Koord->Grafik_x_min = Koord->Rand_x_min + Koord->delta_min;
	Koord->Grafik_x_max = Koord->Rand_x_max - Koord->delta_max;

	// Die x- und y-Achse werden mit einem breiteren Stift gezeichnet
	hPen = CreatePen(PS_SOLID, 2, (COLORREF)RGB(0, 0, 0));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);

	//x-Achse
	Punkt[0].x = Koord->Grafik_x_min;
	Punkt[0].y = Koord->Grafik_y_max;
	Punkt[1].x = Koord->Grafik_x_max + 3 * Koord->pfeilspitze;
	Punkt[1].y = Koord->Grafik_y_max;
	Polyline(hdc, Punkt, 2);
	Punkt[0].x = Koord->Grafik_x_max + Koord->pfeilspitze;
	Punkt[0].y = Koord->Grafik_y_max + Koord->pfeilspitze;
	Punkt[2].x = Koord->Grafik_x_max + Koord->pfeilspitze;
	Punkt[2].y = Koord->Grafik_y_max - Koord->pfeilspitze;
	Polyline(hdc, Punkt, 3);

	// Schmalen Stift wieder aktivieren
	SelectObject(hdc, hPenPrev);
	//Skalenstriche
	for (int i = 0; i<11; i++)
	{
		Punkt[0].x = (int)(Koord->Grafik_x_min + (Koord->Grafik_x_max - Koord->Grafik_x_min)*i / 10.0);
		Punkt[0].y = Koord->Grafik_y_max;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Punkt[0].y + Koord->skalenstrich;
		Polyline(hdc, Punkt, 2);
	}
	// Wieder auf den breiten Stift wechseln
	SelectObject(hdc, hPen);
	//y-Achse
	Punkt[0].x = Koord->Grafik_x_min;
	Punkt[0].y = Koord->Grafik_y_max;
	Punkt[1].x = Koord->Grafik_x_min;
	Punkt[1].y = Koord->Grafik_y_min - 3 * Koord->pfeilspitze;
	Polyline(hdc, Punkt, 2);
	Punkt[0].x -= Koord->pfeilspitze;
	Punkt[0].y = Koord->Grafik_y_min - Koord->pfeilspitze;
	Punkt[2].x = Koord->Grafik_x_min + Koord->pfeilspitze;
	Punkt[2].y = Punkt[0].y;
	Polyline(hdc, Punkt, 3);
	// Und wieder zur�ck auf den schmalen Stift
	SelectObject(hdc, hPenPrev);
	// den alten Stift jetzt l�schen
	DeleteObject(hPen);

	//Skalenstriche
	for (int i = 0; i<11; i++)
	{
		Punkt[0].x = Koord->Grafik_x_min;
		Punkt[0].y = (int)(Koord->Grafik_y_min + (Koord->Grafik_y_max - Koord->Grafik_y_min)*i / 10);
		Punkt[1].x = Koord->Grafik_x_min - Koord->skalenstrich;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
	}
	// F�r die Ablesbarkeit wird ein graues Gitter hinterlegt
	hPen = CreatePen(PS_DOT, 1, (COLORREF)RGB(180, 180, 180));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);
	//Gitterstriche in x-Richtung
	for (int i = 0; i<10; i++)
	{
		Punkt[0].x = Koord->Grafik_x_min;
		Punkt[0].y = (int)(Koord->Grafik_y_min + (Koord->Grafik_y_max - Koord->Grafik_y_min)*i / 10);
		Punkt[1].x = Koord->Grafik_x_max;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
	}
	//Gitterstriche in y-Richtung
	for (int i = 1; i<11; i++)
	{
		Punkt[0].x = (int)(Koord->Grafik_x_min + (Koord->Grafik_x_max - Koord->Grafik_x_min)*i / 10.0);
		Punkt[0].y = Koord->Grafik_y_min;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Koord->Grafik_y_max;
		Polyline(hdc, Punkt, 2);
	}
	SelectObject(hdc, hPenPrev);	// alten Stift wieder ausw�hlen
	DeleteObject(hPen); // Stift wieder l�schen
	hPen = CreatePen(PS_SOLID, 1, (COLORREF)RGB(90, 90, 90));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);
	// Au�erdem wird die Null-Linie in grau markiert, wenn sie nicht identisch mit der x- oder y-Achse ist
	if (Koord->y_min1 != 0.0)
	{
		Punkt[0].x = Koord->Grafik_x_min;
		Punkt[0].y = (long)(Koord->Grafik_y_max - (-Koord->y_min1) / (Koord->y_max1 - Koord->y_min1)*(Koord->Grafik_y_max - Koord->Grafik_y_min));
		Punkt[1].x = Koord->Grafik_x_max;
		Punkt[1].y = Punkt[0].y;
		// Die Null_linie wird nur gezeichnet, wenn sie im Zeichenbereich liegt
		if ((Punkt[0].y >= Koord->Grafik_y_min)&&(Punkt[0].y <= Koord->Grafik_y_max))
			Polyline(hdc, Punkt, 2);
	}
	if (Koord->x_min1 != 0.0)
	{
		Punkt[0].x = (long)((-Koord->x_min1) / (Koord->x_max1 - Koord->x_min1)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
		Punkt[0].y = Koord->Grafik_y_min;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Koord->Grafik_y_max;
		// Die Null-Linie wird nur gezeichnet, wenn sie im Zeichenbereich liegt
		if ((Punkt[0].x >= Koord->Grafik_x_min)&&(Punkt[0].x <= Koord->Grafik_x_max))
			Polyline(hdc, Punkt, 2);
	}

	SelectObject(hdc, hPenPrev);	// alten Stift wieder ausw�hlen
	DeleteObject(hPen); // Stift wieder l�schen
	// Vor der ersten Beschriftung muss die Schriftart auf Arial ge�ndert werden
	hFontGerade = CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH, (LPCSTR)"ARIAL");
	hFontSystem = (HFONT)SelectObject(hdc, hFontGerade);
	SetTextAlign(hdc, TA_CENTER | TA_TOP);
	// �berschrift
	TextOut(hdc, (Koord->Grafik_x_min + Koord->Grafik_x_max) / 2, Koord->Grafik_y_min - 20, (LPCSTR)Ueberschrift, strlen(Ueberschrift));
	
	// Beschriftung der x-Achse (x_Min unf x_Max)
	if (Verwende_Vorsatzzeichen)
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->x_max1, 199);
	else
		Bestimme_Bezeichner(cText, Koord->x_max1, 199);
	TextOut(hdc, Koord->Grafik_x_max, Koord->Grafik_y_max + 10, (LPCSTR)cText, strlen(cText));
	if (Verwende_Vorsatzzeichen)
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->x_min1, 199);
	else
		Bestimme_Bezeichner(cText, Koord->x_min1, 199);
	TextOut(hdc, Koord->Grafik_x_min, Koord->Grafik_y_max + 10, (LPCSTR)cText, strlen(cText));
	// Beschriftung der x-Achse (Bezeichner)
	TextOut(hdc, (Koord->Grafik_x_min + Koord->Grafik_x_max) / 2, Koord->Grafik_y_max + 10, (LPCSTR)Beschriftung_x1, strlen(Beschriftung_x1));
	// Beschriftung der y-Achse
	SetTextAlign(hdc, TA_RIGHT | TA_TOP);
	if (Verwende_Vorsatzzeichen)
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->y_min1, 199);
	else
		Bestimme_Bezeichner(cText, Koord->y_min1, 199);
	TextOut(hdc, Koord->Grafik_x_min - 10, Koord->Grafik_y_max - 6, (LPCSTR)cText, strlen(cText));
	if (Verwende_Vorsatzzeichen)
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->y_max1, 199);
	else
		Bestimme_Bezeichner(cText, Koord->y_max1, 199);
	TextOut(hdc, Koord->Grafik_x_min - 10, Koord->Grafik_y_min - 6, (LPCSTR)cText, strlen(cText));
	// Beschriftung der y-Achse vertikal
	// Dazu zun�chste den aktuellen Font holen
	GetObject(hFontGerade, sizeof(LOGFONT), &lf);
	// Drehung um 90�
	lf.lfEscapement = 900;
	lf.lfOrientation = 900;
	hFontGedreht = CreateFontIndirect(&lf);
	SelectObject(hdc, hFontGedreht);
	SetTextAlign(hdc, TA_CENTER | TA_BOTTOM);
	// Beschriftung der y-Achse
//	mbstowcs_s(&zeichen, text, (size_t)199, Beschriftung_y1, (size_t)(100 - 1));
	TextOut(hdc, Koord->Grafik_x_min - 20, (Koord->Grafik_y_min + Koord->Grafik_y_max) / 2, (LPCSTR)Beschriftung_y1, strlen(Beschriftung_y1));
	SelectObject(hdc, hFontGerade);
	DeleteObject(hFontGedreht);
	// Benutzten Font freigeben
	SelectObject(hdc, hFontSystem);
	DeleteObject(hFontGerade);

	return 0;
}	// end of Zeichne_Koordinatensystem
int Zeichne_Koordinatensystem_Ursprung_rechts_oben(HDC hdc, Koordinatensystem *Koord, char Beschriftung_x1[40], char Beschriftung_y1[40], char Beschriftung_x2[40], char Beschriftung_y2[40], char Ueberschrift[80], bool Kopie_Zwischenablage, bool Verwende_Vorsatzzeichen)
/*******************************************************************************************************************\
| Funktion zur Zeichnung eines Koordinatensystems mit Beschriftung													|
| 21.04.2019 M.Alles Erstellt aus Zeichne_Koordinatensystem_Ursprung_rechts_oben									|
| Eingabeparameter: HDC hdc: Handle auf den DeviceContext															|
|					Struktur Koordinatensystem mit																	|
|						int Rand_x_min: Linker Rand des Koordinatensystems											|
|						int Rand_x_max: Rechter Rand des Koordinatensystems											|
|						int Rand_y_min: Oberer Rand des Koordinatensystems											|
|						int Rand_y_max: Unterer Rand des Koordinatensystems											|
|						double minimalwert_x: Beschriftungswert														|
|						double maximalwert_x: Beschriftungswert														|
|						double minimalwert_y: Beschriftungswert														|
|						double maximalwert_y: Beschriftungswert														|
|						char Beschriftung_x[40]:	Bezeichner f�r die x-Achse										|
|						char Beschriftung_y[40]:	Bezeichner f�r die y-Achse										|
|						char Ueberschrift[80];	Titel der Grafik													|
|						int pfeilspitze:	Ma� f�r die Pfeilspitzen												|
|						int skalenstrich:	Ma� f�r die L�nge der Skalenstriche										|
|						int delta_min:		Abstand vom Grafikrand (links, oben) f�r Beschriftung					|
|						int delta_max:		Abstand vom Grafikrand (unten, rechts) f�r Beschriftung					|
| R�ckgabewert:		int Fehler (0: kein Fehler)																		|
|																													|
|						int Grafik_x_min: Linker Rand des Koordinatensystems										|
|						int Grafik_x_max: Rechter Rand des Koordinatensystems										|
|						int Grafik_y_min: Oberer Rand des Koordinatensystems										|
|						int Grafik_y_max: Unterer Rand des Koordinatensystems										|
| Die Funktion zeichnet ein Koordinatensystem mit Skalenteilung (jeweils 10 Werte) und Beschriftung.				|
| Die Koordinaten werden als Zeiger �bernommen und in der Funktion "nach innen" geschoben, um Platz f�r die			|
| Beschriftung zu geben. Die Verschiebung erfolgt �ber "#define"-Werte.												|
| Bedingung f�r das Zeichnen der x- und y-Achse ge�ndert auf Grafik->x/y_min.										|
\*******************************************************************************************************************/
{
	UNREFERENCED_PARAMETER(Beschriftung_y2);
	UNREFERENCED_PARAMETER(Beschriftung_x2);

	POINT Punkt[3];
	char cText[200];

	LOGFONT lf;
	HPEN hPen, hPenPrev;
	HFONT hFontGerade, hFontGedreht, hFontSystem;
	RECT Diagrammbereich;

	// Zu Beginn wird ein graues Rechteck gezeichnet, um den Hintergrund l�schen
	Diagrammbereich.left = Koord->Rand_x_min;
	Diagrammbereich.right = Koord->Rand_x_max;
	Diagrammbereich.top = Koord->Rand_y_min;
	Diagrammbereich.bottom = Koord->Rand_y_max;
	if (!Kopie_Zwischenablage)
		FillRect(hdc, &Diagrammbereich, (HBRUSH)COLOR_WINDOW);

	// Hintergrund auf grau setzen
	SetBkColor(hdc, GetSysColor(COLOR_WINDOW));
	SetBkMode(hdc, TRANSPARENT);

	// Neue Grenzen setzen: oben und rechts vom Rand 30 Punkte nach innen, unten und links jeweils 50 Punkte
	Koord->Grafik_y_min = Koord->Rand_y_min + Koord->delta_min;
	Koord->Grafik_y_max = Koord->Rand_y_max - Koord->delta_max;
	Koord->Grafik_x_min = Koord->Rand_x_min + Koord->delta_min;
	Koord->Grafik_x_max = Koord->Rand_x_max - Koord->delta_max;

	// Die x- und y-Achse werden mit einem breiteren Stift gezeichnet
	hPen = CreatePen(PS_SOLID, 2, (COLORREF)RGB(0, 0, 0));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);

	//x-Achse
	Punkt[0].x = Koord->Grafik_x_max;
	Punkt[0].y = Koord->Grafik_y_max;
	Punkt[1].x = Koord->Grafik_x_min - 3 * Koord->pfeilspitze;
	Punkt[1].y = Koord->Grafik_y_max;
	Polyline(hdc, Punkt, 2);
	Punkt[0].x = Koord->Grafik_x_min - Koord->pfeilspitze;
	Punkt[0].y = Koord->Grafik_y_max + Koord->pfeilspitze;
	Punkt[2].x = Koord->Grafik_x_min - Koord->pfeilspitze;
	Punkt[2].y = Koord->Grafik_y_max - Koord->pfeilspitze;
	Polyline(hdc, Punkt, 3);

	// Schmalen Stift wieder aktivieren
	SelectObject(hdc, hPenPrev);
	//Skalenstriche hier jetzt von rechts nach links
	for (int i = 0; i<11; i++)
	{
		Punkt[0].x = (int)(Koord->Grafik_x_max - (Koord->Grafik_x_max - Koord->Grafik_x_min)*i / 10.0);
		Punkt[0].y = Koord->Grafik_y_max;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Punkt[0].y + Koord->skalenstrich;
		Polyline(hdc, Punkt, 2);
	}
	// Wieder auf den breiten Stift wechseln
	SelectObject(hdc, hPen);
	//y-Achse
	Punkt[0].x = Koord->Grafik_x_min;
	Punkt[0].y = Koord->Grafik_y_min;
	Punkt[1].x = Koord->Grafik_x_min;
	Punkt[1].y = Koord->Grafik_y_max + 3 * Koord->pfeilspitze;
	Polyline(hdc, Punkt, 2);
	Punkt[0].x += Koord->pfeilspitze;
	Punkt[0].y = Koord->Grafik_y_max + Koord->pfeilspitze;
	Punkt[2].x = Koord->Grafik_x_min - Koord->pfeilspitze;
	Punkt[2].y = Punkt[0].y;
	Polyline(hdc, Punkt, 3);
	// Und wieder zur�ck auf den schmalen Stift
	SelectObject(hdc, hPenPrev);
	// den alten Stift jetzt l�schen
	DeleteObject(hPen);

	//Skalenstriche von oben nach unten
	for (int i = 0; i<11; i++)
	{
		Punkt[0].x = Koord->Grafik_x_min;
		Punkt[0].y = (int)(Koord->Grafik_y_max - (Koord->Grafik_y_max - Koord->Grafik_y_min)*i / 10);
		Punkt[1].x = Koord->Grafik_x_min - Koord->skalenstrich;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
	}
	// F�r die Ablesbarkeit wird ein graues Gitter hinterlegt
	hPen = CreatePen(PS_DOT, 1, (COLORREF)RGB(180, 180, 180));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);
	//Gitterstriche in x-Richtung
	for (int i = 1; i<11; i++)
	{
		Punkt[0].x = Koord->Grafik_x_min;
		Punkt[0].y = (int)(Koord->Grafik_y_max - (Koord->Grafik_y_max - Koord->Grafik_y_min)*i / 10);
		Punkt[1].x = Koord->Grafik_x_max;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
	}
	//Gitterstriche in y-Richtung
	for (int i = 0; i<10; i++)
	{
		Punkt[0].x = (int)(Koord->Grafik_x_max - (Koord->Grafik_x_max - Koord->Grafik_x_min)*i / 10.0);
		Punkt[0].y = Koord->Grafik_y_min;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Koord->Grafik_y_max;
		Polyline(hdc, Punkt, 2);
	}
	SelectObject(hdc, hPenPrev);	// alten Stift wieder ausw�hlen
	DeleteObject(hPen); // Stift wieder l�schen
	hPen = CreatePen(PS_SOLID, 1, (COLORREF)RGB(90, 90, 90));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);
	// Au�erdem wird die Null-Linie in grau markiert, wenn sie nicht identisch mit der x- oder y-Achse ist
	if (Koord->y_max1 != 0.0)
	{
		Punkt[0].x = Koord->Grafik_x_min;
		Punkt[0].y = (long)(Koord->Grafik_y_max - (-Koord->y_min1) / (Koord->y_max1 - Koord->y_min1)*(Koord->Grafik_y_max - Koord->Grafik_y_min));
		Punkt[1].x = Koord->Grafik_x_max;
		Punkt[1].y = Punkt[0].y;
		// Die Null_linie wird nur gezeichnet, wenn sie im Zeichenbereich liegt
		if ((Punkt[0].y >= Koord->Grafik_y_min)&&(Punkt[0].y <= Koord->Grafik_y_max))
			Polyline(hdc, Punkt, 2);
	}
	if (Koord->x_max1 != 0.0)
	{
		Punkt[0].x = (long)((-Koord->x_min1) / (Koord->x_max1 - Koord->x_min1)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
		Punkt[0].y = Koord->Grafik_y_min;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Koord->Grafik_y_max;
		// Die Null-Linie wird nur gezeichnet, wenn sie im Zeichenbereich liegt
		if ((Punkt[0].x >= Koord->Grafik_x_min)&&(Punkt[0].x <= Koord->Grafik_x_max))
			Polyline(hdc, Punkt, 2);
	}

	SelectObject(hdc, hPenPrev);	// alten Stift wieder ausw�hlen
	DeleteObject(hPen); // Stift wieder l�schen
	// Vor der ersten Beschriftung muss die Schriftart auf Arial ge�ndert werden
	hFontGerade = CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH, (LPCSTR)"ARIAL");
	hFontSystem = (HFONT)SelectObject(hdc, hFontGerade);
	SetTextAlign(hdc, TA_CENTER | TA_TOP);
	// �berschrift
	TextOut(hdc, (Koord->Grafik_x_min + Koord->Grafik_x_max) / 2, Koord->Grafik_y_min - 20, (LPCSTR)Ueberschrift, strlen(Ueberschrift));
	
	// Beschriftung der x-Achse (x_Min und x_Max)
	if (Verwende_Vorsatzzeichen)
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->x_max1, 199);
	else
		Bestimme_Bezeichner(cText, Koord->x_max1, 199);
	TextOut(hdc, Koord->Grafik_x_max, Koord->Grafik_y_max + 10 + 3*Koord->pfeilspitze, (LPCSTR)cText, strlen(cText));
	if (Verwende_Vorsatzzeichen)
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->x_min1, 199);
	else
		Bestimme_Bezeichner(cText, Koord->x_min1, 199);
	TextOut(hdc, Koord->Grafik_x_min, Koord->Grafik_y_max + 10 + 3*Koord->pfeilspitze, (LPCSTR)cText, strlen(cText));
	// Beschriftung der x-Achse (Bezeichner)
	TextOut(hdc, (Koord->Grafik_x_min + Koord->Grafik_x_max) / 2, Koord->Grafik_y_max + 10, (LPCSTR)Beschriftung_x1, strlen(Beschriftung_x1));
	// Beschriftung der y-Achse
	SetTextAlign(hdc, TA_RIGHT | TA_TOP);
	if (Verwende_Vorsatzzeichen)
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->y_min1, 199);
	else
		Bestimme_Bezeichner(cText, Koord->y_min1, 199);
	TextOut(hdc, Koord->Grafik_x_min - 10 - 3*Koord->pfeilspitze, Koord->Grafik_y_max - 6, (LPCSTR)cText, strlen(cText));
	if (Verwende_Vorsatzzeichen)
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->y_max1, 199);
	else
		Bestimme_Bezeichner(cText, Koord->y_max1, 199);
	TextOut(hdc, Koord->Grafik_x_min - 10 - 3*Koord->pfeilspitze, Koord->Grafik_y_min - 6, (LPCSTR)cText, strlen(cText));
	// Beschriftung der y-Achse vertikal
	// Dazu zun�chste den aktuellen Font holen
	GetObject(hFontGerade, sizeof(LOGFONT), &lf);
	// Drehung um 90�
	lf.lfEscapement = 900;
	lf.lfOrientation = 900;
	hFontGedreht = CreateFontIndirect(&lf);
	SelectObject(hdc, hFontGedreht);
	SetTextAlign(hdc, TA_CENTER | TA_BOTTOM);
	// Beschriftung der y-Achse
	TextOut(hdc, Koord->Grafik_x_min - 20, (Koord->Grafik_y_min + Koord->Grafik_y_max) / 2, (LPCSTR)Beschriftung_y1, strlen(Beschriftung_y1));
	SelectObject(hdc, hFontGerade);
	DeleteObject(hFontGedreht);
	// Benutzten Font freigeben
	SelectObject(hdc, hFontSystem);
	DeleteObject(hFontGerade);

	return 0;
}	// end of Zeichne_Koordinatensystem_Ursprung_rechts_oben
int Zeichne_Kurve_in_Koordinatensystem_Ursprung_links_unten(HDC hdc, Koordinatensystem *Koord, float *x, float *y, int anzahl_punkte, int rot, int gruen, int blau)
/*******************************************************************************************************************\
| Funktion zur Zeichnung einer Kurve in ein Koordinatensystem														|
| Eingabeparameter: HDC hdc: Handle auf den DeviceContext															|
|					Struktur Koordinatensystem mit																	|
|						int Rand_x_min: Linker Rand des Koordinatensystems											|
|						int Rand_x_max: Rechter Rand des Koordinatensystems											|
|						int Rand_y_min: Oberer Rand des Koordinatensystems											|
|						int Rand_y_max: Unterer Rand des Koordinatensystems											|
|						double minimalwert_x: Beschriftungswert														|
|						double maximalwert_x: Beschriftungswert														|
|						double minimalwert_y: Beschriftungswert														|
|						double maximalwert_y: Beschriftungswert														|
|					char Beschriftung_x[40]:	Bezeichner f�r die x-Achse											|
|					char Beschriftung_y[40]:	Bezeichner f�r die y-Achse											|
|					char Ueberschrift[80]:	Titel der Grafik														|
|					int rot:	Farbanteil rot																		|
|					int gruen:	Farbanteil gruen																	|
|					int blau:	Farbanteil blau																		|
| R�ckgabewert:		int Fehler (0: kein Fehler)																		|
| Die Funktion zeichnet eine Kurve in das Koordinatensystem mit Skalenteilung (jeweils 10 Werte) und Beschriftung.	|
\*******************************************************************************************************************/
{
	POINT Punkt[2];
	HPEN hPen, hPenPrev;
	int i;

	// Die x- und y-Achse werden mit einem breiteren Stift gezeichnet
	hPen = CreatePen(PS_SOLID, 2, RGB(rot, gruen, blau));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);

	// ersten Punkt bestimmen:
	Punkt[0].x = (long)((x[0] - Koord->x_min1) / (Koord->x_max1 - Koord->x_min1)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
	Punkt[0].y = (long)(Koord->Grafik_y_max - (y[0] - Koord->y_min1) / (Koord->y_max1 - Koord->y_min1)*(Koord->Grafik_y_max - Koord->Grafik_y_min));
	for (i = 1; i < anzahl_punkte; i++)
	{
		Punkt[1].x = (long)((x[i] - Koord->x_min1) / (Koord->x_max1 - Koord->x_min1)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
		Punkt[1].y = (long)(Koord->Grafik_y_max - (y[i] - Koord->y_min1) / (Koord->y_max1 - Koord->y_min1)*(Koord->Grafik_y_max - Koord->Grafik_y_min));
		Polyline(hdc, Punkt, 2);
		// Punkt umkopieren
		Punkt[0] = Punkt[1];
	}
	// Schmalen Stift wieder aktivieren
	SelectObject(hdc, hPenPrev);
	// den alten Stift jetzt l�schen
	DeleteObject(hPen);

	return 0;
} // end of Zeichne_Kurve_in_Koordinatensystem_Ursprung_links_unten
int Zeichne_Kurve_mit_Spannungs_Beschriftung_in_Koordinatensystem_Ursprung_links_unten( HDC hdc, Koordinatensystem *Koord, float *x, float *y, int anzahl_punkte, char Beschriftung_Kurve[40], double Wert_Kurve, int rot, int gruen, int blau)
/*******************************************************************************************************************\
| Funktion zur Zeichnung einer Kurve mit Werteangaben in ein Koordinatensystem										|
| Eingabeparameter: HDC hdc: Handle auf den DeviceContext															|
|					Struktur Koordinatensystem mit																	|
|						int Rand_x_min: Linker Rand des Koordinatensystems											|
|						int Rand_x_max: Rechter Rand des Koordinatensystems											|
|						int Rand_y_min: Oberer Rand des Koordinatensystems											|
|						int Rand_y_max: Unterer Rand des Koordinatensystems											|
|						double minimalwert_x: Beschriftungswert														|
|						double maximalwert_x: Beschriftungswert														|
|						double minimalwert_y: Beschriftungswert														|
|						double maximalwert_y: Beschriftungswert														|
|					float *x:	Zeiger auf ein eindimensionales Feld mit x-Werten									|
|					float *y:	Zeiger auf ein zweidimensionales Feld mit den y-Werten								|
|					int anzahl_punkte:	Gibt die Anzahl der x- und y-Werte an.										|
|					char Beschriftung_Kurve[40]:	Bezeichner f�r die gemeinsame Beschriftung der Kurvenschar		|
|					float Wert_Kurve:	Zahlenwert f�r die Kurve													|
|					int rot:	Farbe, hier rot																		|
|					int gruen:	Farbe, hier gruen																	|
|					int blau:	Farbe, hier blau																	|
| R�ckgabewert:		int Fehler (0: kein Fehler)																		|
| Die Funktion zeichnet eine Kurve in das Koordinatensystem mit Skalenteilung (jeweils 10 Werte) und Beschriftung.	|
\*******************************************************************************************************************/
{
	long pos_x, pos_y;
	char ausgabe[100], ausgabe_spg[40];
	HFONT hFontGerade, hFontSystem;

	// Kurve zeichnen
	Zeichne_Kurve_in_Koordinatensystem_Ursprung_links_unten( hdc, Koord, x, y, anzahl_punkte, rot, gruen, blau );
	// Letzten Punkt passend umrechnen:
	pos_x = (long)((x[anzahl_punkte-1] - Koord->x_min1) / (Koord->x_max1 - Koord->x_min1)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
	pos_y = (long)(Koord->Grafik_y_max - (y[anzahl_punkte-1] - Koord->y_min1) / (Koord->y_max1 - Koord->y_min1)*(Koord->Grafik_y_max - Koord->Grafik_y_min));

	strcpy_s( ausgabe, 40, Beschriftung_Kurve);
	Bestimme_Spannungsbezeichner( ausgabe_spg, (double)Wert_Kurve, 40);
	String_anhaengen( 100, ausgabe, ausgabe_spg);
	// Vor der ersten Beschriftung muss die Schriftart auf Arial ge�ndert werden
	hFontGerade = CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH, (LPCSTR)"ARIAL");
	hFontSystem = (HFONT)SelectObject(hdc, hFontGerade);
	SetTextAlign(hdc, TA_LEFT | TA_BASELINE);
	// Farbe auf die Farbe der Kurve �ndern
	SetTextColor(hdc, (COLORREF)RGB(rot, gruen, blau));
	TextOut(hdc, pos_x+5, pos_y, (LPCSTR)ausgabe, strlen(ausgabe)); // Verschiebung um f�nf Punkte nach rechts
	// Benutzten Font freigeben
	SelectObject(hdc, hFontSystem);
	DeleteObject(hFontGerade);

	return 0;
}

int Zeichne_Kurve_mit_Spannungs_Beschriftung_in_Koordinatensystem_Ursprung_rechts_oben( HDC hdc, Koordinatensystem *Koord, float *x, float *y, int anzahl_punkte, char Beschriftung_Kurve[40], double Wert_Kurve, int rot, int gruen, int blau)
/*******************************************************************************************************************\
| Funktion zur Zeichnung einer Kurve mit Werteangaben in ein Koordinatensystem										|
| Eingabeparameter: HDC hdc: Handle auf den DeviceContext															|
|					Struktur Koordinatensystem mit																	|
|						int Rand_x_min: Linker Rand des Koordinatensystems											|
|						int Rand_x_max: Rechter Rand des Koordinatensystems											|
|						int Rand_y_min: Oberer Rand des Koordinatensystems											|
|						int Rand_y_max: Unterer Rand des Koordinatensystems											|
|						double minimalwert_x: Beschriftungswert														|
|						double maximalwert_x: Beschriftungswert														|
|						double minimalwert_y: Beschriftungswert														|
|						double maximalwert_y: Beschriftungswert														|
|					float *x:	Zeiger auf ein eindimensionales Feld mit x-Werten									|
|					float *y:	Zeiger auf ein zweidimensionales Feld mit den y-Werten								|
|					int anzahl_punkte:	Gibt die Anzahl der x- und y-Werte an.										|
|					char Beschriftung_Kurve[40]:	Bezeichner f�r die gemeinsame Beschriftung der Kurvenschar		|
|					float Wert_Kurve:	Zahlenwert f�r die Kurve													|
|					int rot:	Farbe, hier rot																		|
|					int gruen:	Farbe, hier gruen																	|
|					int blau:	Farbe, hier blau																	|
| R�ckgabewert:		int Fehler (0: kein Fehler)																		|
| Die Funktion zeichnet eine Kurve in das Koordinatensystem mit Skalenteilung (jeweils 10 Werte) und Beschriftung.	|
\*******************************************************************************************************************/
{
	long pos_x, pos_y;
	char ausgabe[100], ausgabe_spg[40];
	HFONT hFontGerade, hFontSystem;

	// Kurve zeichnen
	Zeichne_Kurve_in_Koordinatensystem_Ursprung_rechts_oben( hdc, Koord, x, y, anzahl_punkte, rot, gruen, blau );
	// Letzten Punkt passend umrechnen:
	pos_x = (long)((x[anzahl_punkte-1] - Koord->x_min1) / (Koord->x_max1 - Koord->x_min1)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
	pos_y = (long)(Koord->Grafik_y_max - (y[anzahl_punkte-1] - Koord->y_min1) / (Koord->y_max1 - Koord->y_min1)*(Koord->Grafik_y_max - Koord->Grafik_y_min));

	strcpy_s( ausgabe, 40, Beschriftung_Kurve);
	Bestimme_Spannungsbezeichner( ausgabe_spg, (double)Wert_Kurve, 40);
	String_anhaengen( 100, ausgabe, ausgabe_spg);
	// Vor der ersten Beschriftung muss die Schriftart auf Arial ge�ndert werden
	hFontGerade = CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH, (LPCSTR)"ARIAL");
	hFontSystem = (HFONT)SelectObject(hdc, hFontGerade);
	SetTextAlign(hdc, TA_LEFT | TA_TOP);
	// Farbe auf die Farbe der Kurve �ndern
	SetTextColor(hdc, (COLORREF)RGB(rot, gruen, blau));
	TextOut(hdc, pos_x+5, pos_y+5, (LPCSTR)ausgabe, strlen(ausgabe)); // Verschiebung um f�nf Punkte nach oben und rechts
	// Benutzten Font freigeben
	SelectObject(hdc, hFontSystem);
	DeleteObject(hFontGerade);

	return 0;
}


int Zeichne_Kurve_in_Koordinatensystem_Ursprung_rechts_oben(HDC hdc, Koordinatensystem *Koord, float *x, float *y, int anzahl_punkte, int rot, int gruen, int blau)
/*******************************************************************************************************************\
| Funktion zur Zeichnung einer Kurve in ein Koordinatensystem														|
| Eingabeparameter: HDC hdc: Handle auf den DeviceContext															|
|					Struktur Koordinatensystem mit																	|
|						int Rand_x_min: Linker Rand des Koordinatensystems											|
|						int Rand_x_max: Rechter Rand des Koordinatensystems											|
|						int Rand_y_min: Oberer Rand des Koordinatensystems											|
|						int Rand_y_max: Unterer Rand des Koordinatensystems											|
|						double minimalwert_x: Beschriftungswert														|
|						double maximalwert_x: Beschriftungswert														|
|						double minimalwert_y: Beschriftungswert														|
|						double maximalwert_y: Beschriftungswert														|
|					char Beschriftung_x[40]:	Bezeichner f�r die x-Achse											|
|					char Beschriftung_y[40]:	Bezeichner f�r die y-Achse											|
|					char Ueberschrift[80];	Titel der Grafik														|
| R�ckgabewert:		int Fehler (0: kein Fehler)																		|
| Die Funktion zeichnet eine Kurve in das Koordinatensystem mit Skalenteilung (jeweils 10 Werte) und Beschriftung.	|
\*******************************************************************************************************************/
{
	POINT Punkt[2];
	HPEN hPen, hPenPrev;
	int i;

	// Die x- und y-Achse werden mit einem breiteren Stift gezeichnet
	hPen = CreatePen(PS_SOLID, 2, RGB(rot, gruen, blau));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);

	// ersten Punkt bestimmen:
	Punkt[0].x = (long)((x[0] - Koord->x_min1) / (Koord->x_max1 - Koord->x_min1)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
	Punkt[0].y = (long)(Koord->Grafik_y_max - (y[0] - Koord->y_min1) / (Koord->y_max1 - Koord->y_min1)*(Koord->Grafik_y_max - Koord->Grafik_y_min));
	for (i = 1; i < anzahl_punkte; i++)
	{
		Punkt[1].x = (long)((x[i] - Koord->x_min1) / (Koord->x_max1 - Koord->x_min1)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
		Punkt[1].y = (long)(Koord->Grafik_y_max - (y[i] - Koord->y_min1) / (Koord->y_max1 - Koord->y_min1)*(Koord->Grafik_y_max - Koord->Grafik_y_min));
		Polyline(hdc, Punkt, 2);
		// Punkt umkopieren
		Punkt[0] = Punkt[1];
	}
	// Schmalen Stift wieder aktivieren
	SelectObject(hdc, hPenPrev);
	// den alten Stift jetzt l�schen
	DeleteObject(hPen);

	return 0;
} // end of Zeichne_Kurve_in_Koordinatensystem_Ursprung_recht_oben
int Zeichne_Anschluss(HDC hdc, int x, int y, int Abstand_Anschlusspunkte)
{
	// Zeichnet einen kompletten Anschluss mit zwei Kreisen, Spannungspfeil und Masseanschluss
	// 40: x, y: 140, Anschlusspunkte: 100
	Ellipse_BH(hdc, x, y, 20, 20);
	Ellipse_BH(hdc, x, y + Abstand_Anschlusspunkte, 20, 20);
	ZP_Linie(hdc, x + 10, y + 30, x + 10, y + Abstand_Anschlusspunkte - 10);
	DP_Linie(hdc, x, y + Abstand_Anschlusspunkte - 20, x + 10, y + Abstand_Anschlusspunkte - 10, x + 20, y + Abstand_Anschlusspunkte - 20);
	ZP_Linie(hdc, x + 10, y + Abstand_Anschlusspunkte + 20, x + 10, y + Abstand_Anschlusspunkte + 40);
	ZP_Linie(hdc, x - 5, y + Abstand_Anschlusspunkte + 40, x + 25, y + Abstand_Anschlusspunkte + 40);

	return 0;
}

int Zeichne_OP(HDC hdc, int x, int y, int breite, int hoehe, bool invertierender_eingang_oben)
{
	// Zeichnet einen Operationsverst�rker mit Eing�ngen links und Ausg�nge rechts. 
	// Der Ausgang liegt bei der Koordinate x+breite, y+hoehe/2.0.
	// Die Eing�nge sind bei den Koordinaten x, y+hoehe*0.3 und x, y+hoehe*0.7
	// Die Variable invertierender_eingang_oben legt fest ob der invertierende Eingang oben oder unten ist. 
	POINT Punkt[3];

	// Zeichne OP x=200, y=120, breite: 100, hoehe: 100
	SetPolyFillMode(hdc, WINDING);
	Punkt[0].x = x;
	Punkt[0].y = y;
	Punkt[1].x = x;
	Punkt[1].y = y + hoehe;
	Punkt[2].x = x + breite;
	Punkt[2].y = (long int)(y + hoehe / 2.0);
	Polygon(hdc, Punkt, 3);
	ZP_Linie(hdc, (int)(x + breite*0.1), (int)(y + hoehe*0.3), (int)(x + breite*0.3), (int)(y + hoehe*0.3));
	ZP_Linie(hdc, (int)(x + breite*0.1), (int)(y + hoehe*0.7), (int)(x + breite*0.3), (int)(y + hoehe*0.7));
	if (invertierender_eingang_oben)
		ZP_Linie(hdc, (int)(x + breite*0.2), (int)(y + hoehe*0.6), (int)(x + breite*0.2), (int)(y + hoehe*0.8));
	else
		ZP_Linie(hdc, (int)(x + breite*0.2), (int)(y + hoehe*0.2), (int)(x + breite*0.2), (int)(y + hoehe*0.4));

	return 0;
}

int Zeichne_OP_mit_Anschluessen(HDC hdc, int x, int y, int breite, int hoehe, int laenge_Eingang, int laenge_Ausgang, bool invertierender_eingang_oben)
{
	// Zeichnet einen Operationsverst�rker mit Eing�ngen links und Ausg�nge rechts. 
	// Der Ausgang liegt bei der Koordinate x+breite, y+hoehe/2.0.
	// Die Eing�nge sind bei den Koordinaten x, y+hoehe*0.3 und x, y+hoehe*0.7
	// Die Variable invertierender_eingang_oben legt fest ob der invertierende Eingang oben oder unten ist. 

	// Zeichne OP x=200, y=120, breite: 100, hoehe: 100
	Zeichne_OP(hdc, x, y, breite, hoehe, invertierender_eingang_oben);
	ZP_Linie(hdc, x - laenge_Eingang, (int)(y + hoehe*0.3), x, (int)(y + hoehe*0.3));
	ZP_Linie(hdc, x - laenge_Eingang, (int)(y + hoehe*0.7), x, (int)(y + hoehe*0.7));
	ZP_Linie(hdc, x + breite, (int)(y + hoehe*0.5), x + breite + laenge_Ausgang, (int)(y + hoehe*0.5));

	return 0;
}

int Zeichne_Wechselspannungsquelle(HDC hdc, int x, int y, int groesse, bool Masseanschluss, int laenge)
// Zeichnet eine Wechselspannungsquelle mit Spannungspfeil. Angegeben wird die Koordinate des Quadrates, in dem der Kreis liegt. 
// Masseanschluss gibt an, ob die Masse unterhalb gezeichnet werden soll. 
// laenge gibt an, wie weit die Masse entfernt sein soll, oder, wenn keine Masse gezeichnet wird, wie lange die Anschl�sse oben und unten sein sollen
{
	// Kreis f�r Spannungsquelle: 
	Ellipse_BH(hdc, x, y, groesse, groesse);
	// Sinuslinie zeichnen
	Zeichne_Sinus(hdc, (int)(x + groesse/6.0), (int)(y + groesse*0.5), (int)(groesse*2.0/3.0), (int)(groesse*2.0 / 3.0) );
	// Pfeil f�r Spannungsquelle:
	ZP_Linie(hdc, (int)(x - groesse / 6.0), (int)(y - 20), (int)(x - groesse / 6.0), (int)(y + groesse*4.0/3.0) );
	DP_Linie(hdc, (int)(x - groesse/3.0), (int)(y + groesse*7.0 / 6.0), (int)(x - groesse / 6.0), (int)(y + groesse*4.0 / 3.0), x, (int)(y + groesse*7.0/6.0) );

	if (Masseanschluss)
	{
		ZP_Linie(hdc, (int)(x + groesse*0.5), y + groesse, (int)(x + groesse*0.5), y + groesse + laenge);
		ZP_Linie(hdc, (int)(x + groesse / 6.0), y + groesse+laenge, (int)(x + groesse*5.0 / 6.0), y + groesse+laenge);
	}
	else
	{
		if (laenge > 0)
		{
			ZP_Linie( hdc, (int)(x + groesse*0.5), y + groesse, (int)(x + groesse*0.5), y + groesse +laenge);
			ZP_Linie( hdc, (int)(x + groesse*0.5), y, (int)(x + groesse*0.5), y - laenge);
		}
	}
	return 0;
}

int Zeichne_Kondensator(HDC hdc, int x, int y, int breite, int hoehe, bool horizontal, int laenge)
{
	// Zeichnet einen Kondensator in den Bereich x bis x+breite und y bis y+hoehe.
	// laenge legt ggf. die Anschlussdr�hte fest, die �ber den Bereich hinausgehen.
	// Horizontal bedeutet: Der Kondensator liegt: ---||---

	if (horizontal)
	{
		ZP_Linie(hdc, x, y, x, y + hoehe);
		ZP_Linie(hdc, x + breite, y, x + breite, y + hoehe);
		if (laenge > 0)
		{
			ZP_Linie(hdc, x - laenge, (int)(y + hoehe * 0.5), x, (int)(y + hoehe*0.5));
			ZP_Linie(hdc, x + breite, (int)(y + hoehe * 0.5), x + breite + laenge, (int)(y + hoehe*0.5) );
		}
	}
	else // Kondensator vertikal, d.h. die Platten sind waagerecht
	{
		ZP_Linie(hdc, x, y, x+breite, y);
		ZP_Linie(hdc, x, y + hoehe, x + breite, y + hoehe);
		if (laenge > 0)
		{
			ZP_Linie(hdc, (int)(x+breite*0.5), y-laenge, (int)(x + breite*0.5), y);
			ZP_Linie(hdc, (int)(x + breite*0.5), y+hoehe, (int)(x + breite*0.5), y+hoehe+laenge);
		}
	}
	return 0;
} // end of Zeichne_Kondensator
int Zeichne_Kondensator(HDC hdc, int x, int y, int breite, int hoehe, bool horizontal)
{
	// Zeichnet einen Kondensator in den Bereich x bis x+breite und y bis y+hoehe.
	// laenge legt ggf. die Anschlussdr�hte fest, die �ber den Bereich hinausgehen.
	// Horizontal bedeutet: Der Kondensator liegt: ---||---

	if (horizontal)
	{
		ZP_Linie(hdc, x, y, x, y + hoehe);
		ZP_Linie(hdc, x + breite, y, x + breite, y + hoehe);
	}
	else // Kondensator vertikal, d.h. die Platten sind waagerecht
	{
		ZP_Linie(hdc, x, y, x + breite, y);
		ZP_Linie(hdc, x, y + hoehe, x + breite, y + hoehe);
	}
	return 0;
} // end of Zeichne_Kondensator

int Zeichne_Widerstand(HDC hdc, int x, int y, int breite, int hoehe, int laenge)
{
	// Zeichnet einen Widerstand in den Bereich x bis x+breite und y bis y+hoehe.
	// laenge legt ggf. die Anschlussdr�hte fest, die �ber den Bereich hinausgehen.
	// Horizontal bedeutet: Der Widerstand liegt

	Rechteck_BH_Flaeche(hdc, x, y, breite, hoehe, (HBRUSH)WHITE_BRUSH);
	Rechteck_BH_Rahmen(hdc, x, y, breite, hoehe);
	if (breite>hoehe)	// Der Widerstand liegt horizontal
	{
		if (laenge > 0)
		{
			ZP_Linie(hdc, x - laenge, (int)(y + hoehe * 0.5), x, (int)(y + hoehe*0.5));
			ZP_Linie(hdc, x + breite, (int)(y + hoehe * 0.5), x + breite + laenge, (int)(y + hoehe*0.5));
		}
	}
	else // Widerstand ist vertikal
	{
		if (laenge > 0)
		{
			ZP_Linie(hdc, (int)(x + breite*0.5), y - laenge, (int)(x + breite*0.5), y);
			ZP_Linie(hdc, (int)(x + breite*0.5), y + hoehe, (int)(x + breite*0.5), y + hoehe + laenge);
		}
	}
	return 0;
} // end of Zeichne_Widerstand
int Zeichne_Widerstand(HDC hdc, int x, int y, int breite, int hoehe)
{
	// Zeichnet einen Widerstand in den Bereich x bis x+breite und y bis y+hoehe.
	// laenge legt ggf. die Anschlussdr�hte fest, die �ber den Bereich hinausgehen.
	// Horizontal bedeutet: Der Widerstand liegt

	Rechteck_BH_Flaeche(hdc, x, y, breite, hoehe, (HBRUSH)WHITE_BRUSH);
	Rechteck_BH_Rahmen(hdc, x, y, breite, hoehe);

	return 0;
} // end of Zeichne_Widerstand

int Zeichne_Spule(HDC hdc, int x, int y, int breite, int laenge, bool horizontal)
{
	// Zeichnet eine waagerechte Spule in den Bereich x bis x+breite und y bis y+hoehe.
	// laenge legt ggf. die Anschlussdr�hte fest, die �ber den Bereich hinausgehen.
	// Horizontal bedeutet: Die Spule liegt
	// Funktion i.O. 9.11.2019
	int i;

	if (horizontal) // Spule waagerecht zeichnen
	{
		for (i=0; i<4; i++)
			Kreisbogen2_Mitte_Radius_Winkel1_Winkel2( hdc, x+breite/8+i*breite/4, y, breite/8, 0, 180 );

		if (laenge > 0)
		{
			ZP_Linie(hdc, x - laenge, y, x, y);
			ZP_Linie(hdc, x + breite, y, x + breite + laenge, y);
		}
	}
	else
	{ // Spule senkrecht zeichnen
		for (i=0; i<4; i++)
			Kreisbogen2_Mitte_Radius_Winkel1_Winkel2( hdc, x, y+breite/8+i*breite/4, breite/8, 270, 90 );

		if (laenge > 0)
		{
			ZP_Linie(hdc, x, y - laenge, x, y);
			ZP_Linie(hdc, x, y + breite, x, y + breite + laenge);
		}
	}
	return 0;
} // end of Zeichne_Spule
int Zeichne_Gleichspannungsquelle(HDC hdc, int x, int y, int groesse, bool Masseanschluss, int laenge)
// Zeichnet eine Gleichspannungsquelle mit Spannungspfeil. Angegeben wird die Koordinate des Quadrates, in dem der Kreis liegt. 
// Masseanschluss gibt an, ob die Masse unterhalb gezeichnet werden soll. 
// laenge gibt an, wie weit die Masse entfernt sein soll, oder, wenn keine Masse gezeichnet wird, wie lange die Anschl�sse oben und unten sein sollen
{
	// Kreis f�r Spannungsquelle: 
	Ellipse_BH(hdc, x, y, groesse, groesse);
	// Pfeil f�r Spannungsquelle:
	ZP_Linie(hdc, (int)(x - groesse / 6.0), (int)(y), (int)(x - groesse / 6.0), (int)(y + groesse));
	DP_Linie(hdc, (int)(x - groesse / 3.0), (int)(y + groesse*5.0 / 6.0), (int)(x - groesse / 6.0), (int)(y + groesse), x, (int)(y + groesse*5.0 / 6.0));

	if (Masseanschluss)
	{
		// Linie f�r Masse geht durch die Spannungsquelle durch
		ZP_Linie(hdc, (int)(x + groesse*0.5), y, (int)(x + groesse*0.5), y + groesse + laenge);
		ZP_Linie(hdc, (int)(x + groesse / 6.0), y + groesse + laenge, (int)(x + groesse*5.0 / 6.0), y + groesse + laenge);
	}
	else
	{
		if (laenge > 0)
			ZP_Linie(hdc, (int)(x + groesse*0.5), y -laenge, (int)(x + groesse*0.5), y + groesse + laenge);
	}
	return 0;
}

int Zeichne_Bipolartransistor(HDC hdc, int x, int y, int breite, int hoehe, bool NPN, int Basis_laenge)
{
	// Die Funktion zeichnet eine Bipolartransistor ausgehend vom Startpunkt x,y. Die Breite ist typischerweise die H�lfte der H�he (50, 100). 
	// Der Parameter NPN gibt an, ob ein NPN-Transistor (true) oder ein PNP-Transistor (false) gezeichnet wird.
	// Mit dem Parameter Basis_laenge kann ein Basisanschluss gezeichnet werden, der nach links �ber die Grenze x hinausgeht.
	// Transistor (NPN) Position: x: 250 (250-300) y: 300-400
	if (Basis_laenge > 0)
		ZP_Linie(hdc, x-Basis_laenge, (int)(y+hoehe*0.5), x, (int)(y+hoehe*0.5) );

	ZP_Linie(hdc, x, y, x, y+hoehe);
	DP_Linie(hdc, x+breite, y, x, (int)(y+hoehe*0.5), x+breite, y+hoehe);

	if (NPN)
	{
		// NPN-Pfeilspitze
		FillTriangle(hdc, x+breite, y+hoehe, (int)(x+breite*0.6), y+hoehe, x+breite, (int)(y+hoehe*0.8) );
	}
	else
	{
		// PNP-Pfeilspitze
		FillTriangle(hdc, x, (int)(y+hoehe*0.5), x, (int)(y+hoehe*0.3), (int)(x+breite*0.4), (int)(y+hoehe*0.5) );
	}
	return 0;
}

int Zeichne_Feldeffekttransistor(HDC hdc, int x, int y, int breite, int hoehe, bool MOS, bool n_Kanal, double U_Th, int Gate_laenge)
{
// Funktion zeichnet einen Feldeffekttransistor an die durch x,y angegebene Stelle mit der Breite breite und der H�he hoehe.
// �blicherweise ist die H�he das doppelte der Breite, wenn der Transistor senkrecht steht.
// Die Parameter MOS (true = MOS-FET; false = JFET) und n-Kanal (true: n-Kanal Fet, false: p-Kanal Fet) und die Thresholdspannung
// U_th legen das Schaltsymbol fest. Mit dem Parameter Gate_laenge kann ein Gateanschluss gezeichnet werden, der nach links �ber 
// den Wert x hinausgeht. 
// F�r die Verbindungspunkte wird ein Radius von 5 verwendet.
	const int radius = 5;

	// Der Parameter Gate_laenge hat mindestens die halbe Breite
	if (Gate_laenge < breite / 2.0)
		Gate_laenge = (int)(breite / 2.0);

	// x: 50-100, y: 300-400						x: 50 y: 300 breite: 50 hoehe: 100 Gate_laenge: 30
	if (MOS)
		Ellipse_BH(hdc, x+breite-radius, (int)(y+hoehe*0.88-radius), radius*2, radius*2);
	if (n_Kanal&&MOS) //NMOS
	{ // NMOS-Transistor zeichnen
		ZP_Linie(hdc, x, y, x, y+hoehe);
		if (U_Th >= 0.0)
		{
			//Anreicherungstyp, also gestricheltes Gate
			ZP_Linie(hdc, (int)(x+0.3*breite), y, (int)(x + 0.3*breite), (int)(y+0.25*hoehe) );
			ZP_Linie(hdc, (int)(x + 0.3*breite), (int)(y+0.37*hoehe), (int)(x + 0.3*breite), (int)(y+0.63*hoehe) );
			ZP_Linie(hdc, (int)(x + 0.3*breite), (int)(y+0.75*hoehe), (int)(x + 0.3*breite), y+hoehe);
		}
		else
			// Verarmungstyp, also durchgezogene Linie
			ZP_Linie(hdc, (int)(x + 0.3*breite), y, (int)(x + 0.3*breite), y+hoehe);
		// Pfeil im Transistorsymbol (NMOS zeigt zum Gate)
		DP_Linie(hdc, (int)(x+breite*0.7), (int)(y+0.4*hoehe), (int)(x+breite*0.5), (int)(y+hoehe*0.5), (int)(x+breite*0.7), (int)(y+hoehe*0.6));
		// Leitungen zu den Anschlu�punkten und Bulkanschluss
		DP_Linie(hdc, (int)(x + 0.3*breite), (int)(y+0.12*hoehe), x+breite, (int)(y + 0.12*hoehe), x + breite, y);
		DP_Linie(hdc, (int)(x + 0.3*breite), (int)(y+0.5*hoehe), x + breite, (int)(y + 0.5*hoehe), x + breite, y+hoehe);
		ZP_Linie(hdc, (int)(x + 0.3*breite), (int)(y + 0.88*hoehe), x + breite, (int)(y + 0.88*hoehe) );
		ZP_Linie(hdc, x-Gate_laenge, (int)(y + hoehe*0.5), x, (int)(y + hoehe*0.5));
	}
	// PMOS-Transistor zeichnen
	if (MOS && !n_Kanal) //PMOS
	{ // PMOS-Transistor zeichnen
	  // Transistor (PMOS) Position: x: 50 (50-100) y: 300-400
		ZP_Linie(hdc, x, y, x, y+hoehe);
		if (U_Th <= 0.0)
		{
			//Anreicherungstyp, also gestricheltes Gate
			ZP_Linie(hdc, (int)(x + 0.3*breite), y, (int)(x + 0.3*breite), (int)(y+0.25*hoehe) );
			ZP_Linie(hdc, (int)(x + 0.3*breite), (int)(y+0.37*hoehe), (int)(x + 0.3*breite), (int)(y+0.63*hoehe) );
			ZP_Linie(hdc, (int)(x + 0.3*breite), (int)(y+0.75*hoehe), (int)(x + 0.3*breite), y+hoehe);
		}
		else
			// Verarmungstyp, also durchgezogene Linie
			ZP_Linie(hdc, (int)(x + 0.3*breite), y, (int)(x + 0.3*breite), y+hoehe);
		// Pfeil im Transistorsymbol (PMOS zeigt vom Gate weg)
		DP_Linie(hdc, (int)(x+breite*0.5), (int)(y+hoehe*0.4), (int)(x+breite*0.7), (int)(y+hoehe*0.5), (int)(x+breite*0.5), (int)(y+hoehe*0.6) );
		// Leitungen zu den Anschlu�punkten und Bulkanschluss
		DP_Linie(hdc, (int)(x + 0.3*breite), (int)(y + 0.12*hoehe), x + breite, (int)(y + 0.12*hoehe), x + breite, y);
		DP_Linie(hdc, (int)(x + 0.3*breite), (int)(y + 0.5*hoehe), x + breite, (int)(y + 0.5*hoehe), x + breite, y+hoehe);
		ZP_Linie(hdc, (int)(x + 0.3*breite), (int)(y+0.88*hoehe), x + breite, (int)(y + 0.88*hoehe) );
		ZP_Linie(hdc, x-Gate_laenge, (int)(y+hoehe*0.5), x, (int)(y+hoehe*0.5) );
	}
	if (n_Kanal && !MOS)
	{
		// n-Kanal-JFET-Transistor zeichnen, nur mit einer senkrechten Linie f�r das Gate
		// JFET ist immer Verarmungstyp, also durchgezogene Linie
		ZP_Linie(hdc, (int)(x + 0.3*breite), y, (int)(x + 0.3*breite), y+hoehe);
		// Pfeil im Transistorsymbol (n-Kanal zeigt zum Gate )
		DP_Linie(hdc, x, (int)(y+hoehe*0.4), (int)(x+0.3*breite), (int)(y+hoehe*0.5), x, (int)(y+hoehe*0.6) );
		// Leitungen zu den Anschlu�punkten und Bulkanschluss
		DP_Linie(hdc, (int)(x + 0.3*breite), (int)(y + 0.12*hoehe), x + breite, (int)(y + 0.12*hoehe), x + breite, y);
		DP_Linie(hdc, (int)(x + 0.3*breite), (int)(y + 0.88*hoehe), x + breite, (int)(y + 0.88*hoehe), x + breite, y+hoehe);
		ZP_Linie(hdc, x-Gate_laenge, (int)(y+hoehe*0.5), (int)(x+0.3*breite), (int)(y+hoehe*0.5));
	}
	if (!n_Kanal && !MOS)	// p-Kanal-JFET-Transistor zeichnen
	{
//		ZP_Linie(hdc, x, y, x, y+hoehe);
		// JFET ist immer Verarmungstyp, also durchgezogene Linie
		ZP_Linie(hdc, (int)(x + 0.3*breite), y, (int)(x + 0.3*breite), y+hoehe);
		// Pfeil im Transistorsymbol (p-Kanal zeigt vom Gate weg )
		DP_Linie(hdc, (int)(x-0.0*breite), (int)(y+0.4*hoehe), (int)(x-breite*0.2), (int)(y+0.5*hoehe), (int)(x-breite*0.0), (int)(y+hoehe*0.6));
		// Leitungen zu den Anschlu�punkten und Bulkanschluss
		DP_Linie(hdc, (int)(x + 0.3*breite), (int)(y + 0.12*hoehe), x + breite, (int)(y + 0.12*hoehe), x + breite, y);
		DP_Linie(hdc, (int)(x + 0.3*breite), (int)(y + 0.88*hoehe), x + breite, (int)(y + 0.88*hoehe), x + breite, y+hoehe);
		ZP_Linie(hdc, x-Gate_laenge, (int)(y+hoehe*0.5), (int)(x + 0.3*breite), (int)(y+hoehe*0.5));
	}
	return 0;
}

int Zeichne_Koordinatensystem_Ursprung_mitte(HDC hdc, Koordinatensystem *Koord, char Beschriftung_x1[40], char Beschriftung_y1[40], char Beschriftung_x2[40], char Beschriftung_y2[40], char Ueberschrift[80], int rot1, int gruen1, int blau1, int rot2, int gruen2, int blau2, bool Kopie_Zwischenablage)
/*******************************************************************************************************************\
| Funktion zur Zeichnung eines Koordinatensystems f�r ein Zeigerdiagramm mit Beschriftung							|
| 3.1.2016 M.Alles																									|
| Eingabeparameter: HDC hdc: Handle auf den DeviceContext															|
|					Struktur Koordinatensystem mit																	|
|						int Rand_x_min: Linker Rand des Koordinatensystems											|
|						int Rand_x_max: Rechter Rand des Koordinatensystems											|
|						int Rand_y_min: Oberer Rand des Koordinatensystems											|
|						int Rand_y_max: Unterer Rand des Koordinatensystems											|
|						double minimalwert_x1: Beschriftungswert	erste Achse										|
|						double maximalwert_x1: Beschrfitungswert	erste Achse										|
|						double minimalwert_y1: Beschriftungswert	erste Achse										|
|						double maximalwert_y1: Beschriftungswert	erste Achse										|
|						double minimalwert_x2: Beschriftungswert	zweite Achse									|
|						double maximalwert_x2: Beschrfitungswert	zweite Achse									|
|						double minimalwert_y2: Beschriftungswert	zweite Achse									|
|						double maximalwert_y2: Beschriftungswert	zweite Achse									|
|						char Beschriftung_x1[40]:	Bezeichner f�r die erste x-Achse								|
|						char Beschriftung_y1[40]:	Bezeichner f�r die erste y-Achse								|
|						char Beschriftung_x1[40]:	Bezeichner f�r die zweite x-Achse								|
|						char Beschriftung_y1[40]:	Bezeichner f�r die zweite y-Achse								|
|						int pfeilspitze:	Ma� f�r die Pfeilspitzen												|
|						int skalenstrich:	Ma� f�r die L�nge der Skalenstriche										|
|						int delta_min:		Abstand vom Grafikrand (links, oben) f�r Beschriftung					|
|						int delta_max:		Abstand vom Grafikrand (unten, rechts) f�r Beschriftung					|
|						char Ueberschrift[80];	Titel der Grafik													|
| R�ckgabewert:		int Fehler (0: kein Fehler)																		|
|																													|
|						int Grafik_x_min: Linker Rand des Koordinatensystems										|
|						int Grafik_x_max: Rechter Rand des Koordinatensystems										|
|						int Grafik_y_min: Oberer Rand des Koordinatensystems										|
|						int Grafik_y_max: Unterer Rand des Koordinatensystems										|
| Die Funktion zeichnet ein Koordinatensystem f�r ein Zeigerdiagramm mit Skalenteilung (jeweils 10 Werte)			|
| und Beschriftung.																									|
| Die Koordinaten werden als Zeiger �bernommen und in der Funktion "nach innen" geschoben, um Platz f�r die			|
| Beschriftung zu geben. Die Verschiebung erfolgt �ber "#define"-Werte.												|
| Das Koordinatensystem wird mit zwei Werten gezeichnet, z.B. Spannungen und Str�men. Wird nur ein Wert angegeben,  |
| wird auch nur eine Beschriftung gezeichnet. Dabei spielt es keine Rolle, ob der erste oder zweite Wert verwendet  |
| wird. Zur Kennzeichnung, dass ein Wert nicht verwendet wird, wird die Beschriftung_x1="" oder die Beschriftung_y1 |
| ="" �bergeben.																									|
\*******************************************************************************************************************/
{
	POINT Punkt[3];
	char cText[200];
	LOGFONT lf;
	HPEN hPen, hPenPrev;
	HFONT hFontGerade, hFontGedreht, hFontSystem;
	RECT Diagrammbereich;
	int X_Achse_0, Y_Achse_0, i, X_Koordinate, Y_Koordinate;

	// Zu Beginn wird ein graues Rechteck gezeichnet
	// um den Hintergrund l�schen
	Diagrammbereich.left = Koord->Rand_x_min;
	Diagrammbereich.right = Koord->Rand_x_max;
	Diagrammbereich.top = Koord->Rand_y_min;
	Diagrammbereich.bottom = Koord->Rand_y_max;
	if (!Kopie_Zwischenablage)
	{
		FillRect(hdc, &Diagrammbereich, (HBRUSH)COLOR_WINDOW);
		// Hintergrund auf grau setzen
		SetBkColor(hdc, GetSysColor(COLOR_WINDOW));
	}
	SetBkMode(hdc, TRANSPARENT);

	// Neue Grenzen setzen: oben und rechts vom Rand 30 Punkte nach innen, unten und links jeweils 50 Punkte
	Koord->Grafik_y_min = Koord->Rand_y_min + Koord->delta_min;
	Koord->Grafik_y_max = Koord->Rand_y_max - Koord->delta_max;
	Koord->Grafik_x_min = Koord->Rand_x_min + Koord->delta_min;
	Koord->Grafik_x_max = Koord->Rand_x_max - Koord->delta_max;

	// Berechnung der Nulllinie
	X_Achse_0 = (int)(Koord->Grafik_x_min + (Koord->Grafik_x_max - Koord->Grafik_x_min)*(-Koord->x_min1) / (Koord->x_max1 - Koord->x_min1));
	Y_Achse_0 = (int)(Koord->Grafik_y_min + (Koord->Grafik_y_max - Koord->Grafik_y_min)*(-Koord->y_min1) / (Koord->y_max1 - Koord->y_min1));

	// F�r die Ablesbarkeit wird ein graues Gitter hinterlegt
	hPen = CreatePen(PS_DOT, 1, (COLORREF)RGB(180, 180, 180));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);

	//Gitterstriche in x-Richtung
	for (i = 1; i<6; i++)
	{
		Punkt[0].x = Koord->Grafik_x_min;
		Punkt[0].y = (int)(Y_Achse_0 + (Koord->Grafik_y_max - Koord->Grafik_y_min)*i / 10);
		Punkt[1].x = Koord->Grafik_x_max;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
		Punkt[0].x = Koord->Grafik_x_min;
		Punkt[0].y = (int)(Y_Achse_0 - (Koord->Grafik_y_max - Koord->Grafik_y_min)*i / 10);
		Punkt[1].x = Koord->Grafik_x_max;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
	}
	//Gitterstriche in y-Richtung
	for (i = 1; i<6; i++)
	{
		Punkt[0].x = (int)(X_Achse_0 + (Koord->Grafik_x_max - Koord->Grafik_x_min)*i / 10.0);
		Punkt[0].y = Koord->Grafik_y_min;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Koord->Grafik_y_max;
		Polyline(hdc, Punkt, 2);
		Punkt[0].x = (int)(X_Achse_0 - (Koord->Grafik_x_max - Koord->Grafik_x_min)*i / 10.0);
		Punkt[0].y = Koord->Grafik_y_min;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Koord->Grafik_y_max;
		Polyline(hdc, Punkt, 2);
	}
	SelectObject(hdc, hPenPrev);	// alten Stift wieder ausw�hlen
	DeleteObject(hPen); // Stift wieder l�schen

	// Die x- und y-Achse werden mit einem breiteren Stift gezeichnet
	hPen = CreatePen(PS_SOLID, 2, (COLORREF)RGB(0, 0, 0));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);

	//x-Achse in die Mitte
	Punkt[0].x = Koord->Grafik_x_min;
	Punkt[0].y = Y_Achse_0;
	Punkt[1].x = Koord->Grafik_x_max + 3 * Koord->pfeilspitze;
	Punkt[1].y = Punkt[0].y;
	Polyline(hdc, Punkt, 2);
	Punkt[0].x = Koord->Grafik_x_max + Koord->pfeilspitze;
	Punkt[0].y += Koord->pfeilspitze;
	Punkt[2].x = Koord->Grafik_x_max + Koord->pfeilspitze;
	Punkt[2].y = Punkt[1].y - Koord->pfeilspitze;
	Polyline(hdc, Punkt, 3);

	// Schmalen Stift wieder aktivieren
	SelectObject(hdc, hPenPrev);
	//Skalenstriche
	for (i = 1; i<6; i++)
	{
		Punkt[0].x = (int)(X_Achse_0 + (Koord->Grafik_x_max - Koord->Grafik_x_min)*i / 10.0);
		Punkt[0].y = Y_Achse_0;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Punkt[0].y + Koord->skalenstrich;
		Polyline(hdc, Punkt, 2);
		Punkt[0].x = (int)(X_Achse_0 - (Koord->Grafik_x_max - Koord->Grafik_x_min)*i / 10.0);
		Punkt[0].y = Y_Achse_0;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Punkt[0].y + Koord->skalenstrich;
		Polyline(hdc, Punkt, 2);
	}
	// Wieder auf den breiten Stift wechseln
	SelectObject(hdc, hPen);
	//y-Achse
	Punkt[0].x = X_Achse_0;
	Punkt[0].y = Koord->Grafik_y_max;
	Punkt[1].x = X_Achse_0;
	Punkt[1].y = Koord->Grafik_y_min - 3 * Koord->pfeilspitze;
	Polyline(hdc, Punkt, 2);
	Punkt[0].x -= Koord->pfeilspitze;
	Punkt[0].y = Koord->Grafik_y_min - Koord->pfeilspitze;
	Punkt[2].x = X_Achse_0+Koord->pfeilspitze;
	Punkt[2].y = Punkt[0].y;
	Polyline(hdc, Punkt, 3);
	// Und wieder zur�ck auf den schmalen Stift
	SelectObject(hdc, hPenPrev);
	// den alten Stift jetzt l�schen
	DeleteObject(hPen);

	//Skalenstriche
	for (i = 1; i<6; i++)
	{
		Punkt[0].x = X_Achse_0;
		Punkt[0].y = (int)(Y_Achse_0 + (Koord->Grafik_y_max - Koord->Grafik_y_min)*i / 10);
		Punkt[1].x = X_Achse_0 - Koord->skalenstrich;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
		Punkt[0].x = X_Achse_0;
		Punkt[0].y = (int)(Y_Achse_0 - (Koord->Grafik_y_max - Koord->Grafik_y_min)*i / 10);
		Punkt[1].x = X_Achse_0 - Koord->skalenstrich;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
	}
	hPen = CreatePen(PS_SOLID, 1, (COLORREF)RGB(90, 90, 90));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);
	SelectObject(hdc, hPenPrev);	// alten Stift wieder ausw�hlen
	DeleteObject(hPen); // Stift wieder l�schen
	
	// Vor der ersten Beschriftung muss die Schriftart auf Arial ge�ndert werden
	hFontGerade = CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH, (LPCSTR)"ARIAL");
	hFontSystem = (HFONT)SelectObject(hdc, hFontGerade);
	SetTextAlign(hdc, TA_CENTER | TA_TOP);

	// �berschrift
	TextOut(hdc, (int)((Koord->Grafik_x_min + Koord->Grafik_x_max) / 2), (int)(Koord->Grafik_y_min - Koord->delta_max - 3.0*Koord->pfeilspitze), (LPCSTR)Ueberschrift, strlen(Ueberschrift));
	// Zwischenspeichern der y-Koordinaten f�r die Ausgabe
	Y_Koordinate = Y_Achse_0 - 7;
	// Beschriftung der x-Achse, falls erforderlich
	if (strlen(Beschriftung_x1) > 0)
	{
		SetTextColor(hdc, (COLORREF)RGB(rot1, gruen1, blau1));
		Y_Koordinate += 17;
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->x_max1, 199);
		TextOut(hdc, Koord->Grafik_x_max, Y_Koordinate, (LPCSTR)cText, strlen(cText));
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->x_min1, 199);
		TextOut(hdc, Koord->Grafik_x_min, Y_Koordinate, (LPCSTR)cText, strlen(cText));
	}
	// Beschriftung mit zweiten Werten, falls erforderlich
	if (strlen(Beschriftung_x2) > 0)
	{
		SetTextColor(hdc, (COLORREF)RGB(rot2, gruen2, blau2));
		Y_Koordinate += 17;
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->x_max2, 199);
		TextOut(hdc, Koord->Grafik_x_max, Y_Koordinate, (LPCSTR)cText, strlen(cText));
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->x_min2, 199);
		TextOut(hdc, Koord->Grafik_x_min, Y_Koordinate, (LPCSTR)cText, strlen(cText));
	}
	// Beschriftung der x-Aches
	Y_Koordinate = Koord->Grafik_y_max - 7;
	// Beschriftung der x-Achse, falls erforderlich
	if (strlen(Beschriftung_x1) > 0)
	{
		SetTextColor(hdc, (COLORREF)RGB(rot1, gruen1, blau1));
		Y_Koordinate += 17;
		TextOut(hdc, (Koord->Grafik_x_min + Koord->Grafik_x_max) / 2, Y_Koordinate, (LPCSTR)Beschriftung_x1, strlen(Beschriftung_x1));
	}
	// Beschriftung mit zweiten Werten, falls erforderlich
	if (strlen(Beschriftung_x2) > 0)
	{
		SetTextColor(hdc, RGB(rot2, gruen2, blau2));
		Y_Koordinate += 17;
		// Beschriftung der x-Achse
		TextOut(hdc, (Koord->Grafik_x_min + Koord->Grafik_x_max) / 2, Y_Koordinate, (LPCSTR)Beschriftung_x2, strlen(Beschriftung_x2));
	}
	// Beschriftung der y-Achse
	// X-Koordinaten zwischenspeichern
	X_Koordinate = Koord->Grafik_x_min - 10;
	SetTextAlign(hdc, TA_RIGHT | TA_TOP);
	// Jeweils oberer Wert
	Y_Koordinate = Koord->Grafik_y_max - 6;
	if (strlen(Beschriftung_x1) > 0)
	{
		SetTextColor(hdc, (COLORREF)RGB(rot1, gruen1, blau1));
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->y_min1, 199);
		TextOut(hdc, X_Koordinate, Y_Koordinate, (LPCSTR)cText, strlen(cText));
		Y_Koordinate += 17;
	}
	if (strlen(Beschriftung_x2) > 0)
	{
		SetTextColor(hdc, (COLORREF)RGB(rot2, gruen2, blau2));
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->y_min2, 199);
		TextOut(hdc, X_Koordinate, Y_Koordinate, (LPCSTR)cText, strlen(cText));
	}
	// Jeweils unterer Wert
	Y_Koordinate = Koord->Grafik_y_min - 6;
	if (strlen(Beschriftung_x1) > 0)
	{
		SetTextColor(hdc, (COLORREF)RGB(rot1, gruen1, blau1));
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->y_max1, 199);
		TextOut(hdc, X_Koordinate, Y_Koordinate, (LPCSTR)cText, strlen(cText));
		Y_Koordinate += 17;
	}
	if (strlen(Beschriftung_x2) > 0)
	{
		SetTextColor(hdc, (COLORREF)RGB(rot2, gruen2, blau2));
		Bestimme_Bezeichner_wissenschaftlich(cText, Koord->y_max2, 199);
		TextOut(hdc, X_Koordinate, Y_Koordinate, (LPCSTR)cText, strlen(cText));
	}
	// Beschriftung der y-Achse vertikal
	// Dazu zun�chste den aktuellen Font holen
	GetObject(hFontGerade, sizeof(LOGFONT), &lf);
	// Drehung um 90�
	lf.lfEscapement = 900;
	lf.lfOrientation = 900;
	hFontGedreht = CreateFontIndirect(&lf);
	SelectObject(hdc, hFontGedreht);
	SetTextAlign(hdc, TA_CENTER | TA_BOTTOM);
	// Beschriftung der y-Achse
	X_Koordinate = Koord->Grafik_x_min - 20;
	if (strlen(Beschriftung_x1) > 0)
	{
		SetTextColor(hdc, (COLORREF)RGB(rot1, gruen1, blau1));
		TextOut(hdc, X_Koordinate, (Koord->Grafik_y_min + Koord->Grafik_y_max) / 2, (LPCSTR)Beschriftung_y1, strlen(Beschriftung_y1));
		X_Koordinate -= 17;
	}
	if (strlen(Beschriftung_x2) > 0) // Zweite Beschriftung f�r die y-Achse
	{
		SetTextColor(hdc, (COLORREF)RGB(rot2, gruen2, blau2));
		// Beschriftung der x-Aches
		TextOut(hdc, X_Koordinate, (Koord->Grafik_y_min + Koord->Grafik_y_max) / 2, (LPCSTR)Beschriftung_y2, strlen(Beschriftung_y2));
	}
	SetTextColor(hdc, (COLORREF)RGB(0, 0, 0));
	SelectObject(hdc, hFontGerade);
	DeleteObject(hFontGedreht);
	// Benutzten Font freigeben
	SelectObject(hdc, hFontSystem);
	DeleteObject(hFontGerade);

	return 0;
}	// end of Zeichne_Koordinatensystem_Ursprung_mitte

int Zeichne_Zeiger_in_Koordinatensystem_Ursprung_mitte(HDC hdc, Koordinatensystem *Koord, char Beschriftung[10], double anfang_x, double anfang_y, double ende_x, double ende_y, int rot, int gruen, int blau, bool erste_achse)
/*******************************************************************************************************************\
| Funktion zur Zeichnung einer Kurve in ein Koordinatensystem														|
| Eingabeparameter: HDC hdc: Handle auf den DeviceContext															|
|					Struktur Koordinatensystem mit																	|
|						int Rand_x_min: Linker Rand des Koordinatensystems											|
|						int Rand_x_max: Rechter Rand des Koordinatensystems											|
|						int Rand_y_min: Oberer Rand des Koordinatensystems											|
|						int Rand_y_max: Unterer Rand des Koordinatensystems											|
|						double minimalwert_x: Beschriftungswert														|
|						double maximalwert_x: Beschriftungswert														|
|						double minimalwert_y: Beschriftungswert														|
|						double maximalwert_y: Beschriftungswert														|
|					char Beschriftung_x[40]:	Bezeichner f�r die x-Achse											|
|					char Beschriftung_y[40]:	Bezeichner f�r die y-Achse											|
|					char Ueberschrift[80];	Titel der Grafik														|
| R�ckgabewert:		int Fehler (0: kein Fehler)																		|
| Die Funktion zeichnet eine Kurve in das Koordinatensystem mit Skalenteilung (jeweils 10 Werte) und Beschriftung.	|
\*******************************************************************************************************************/
{
	UNREFERENCED_PARAMETER( Beschriftung );
	POINT Punkt[2], Pfeilspitze[3];
	HPEN hPen, hPenPrev;
	HFONT hFontGerade, hFontSystem;
	int pfeilspitze = 10;
	double winkel;

	// Die x- und y-Achse werden mit einem breiteren Stift gezeichnet
	hPen = CreatePen(PS_SOLID, 2, RGB(rot, gruen, blau));
	hPenPrev = (HPEN)SelectObject(hdc, hPen);

	if (erste_achse)
	{
		// ersten Punkt bestimmen:
		Punkt[0].x = (long)((anfang_x - Koord->x_min1) / (Koord->x_max1 - Koord->x_min1)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
		Punkt[0].y = (long)(Koord->Grafik_y_max - (anfang_y - Koord->y_min1) / (Koord->y_max1 - Koord->y_min1)*(Koord->Grafik_y_max - Koord->Grafik_y_min));

		Punkt[1].x = (long)((ende_x - Koord->x_min1) / (Koord->x_max1 - Koord->x_min1)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
		Punkt[1].y = (long)(Koord->Grafik_y_max - (ende_y - Koord->y_min1) / (Koord->y_max1 - Koord->y_min1)*(Koord->Grafik_y_max - Koord->Grafik_y_min));
	}
	else
	{
		// ersten Punkt bestimmen:
		Punkt[0].x = (long)((anfang_x - Koord->x_min2) / (Koord->x_max2 - Koord->x_min2)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
		Punkt[0].y = (long)(Koord->Grafik_y_max - (anfang_y - Koord->y_min2) / (Koord->y_max2 - Koord->y_min2)*(Koord->Grafik_y_max - Koord->Grafik_y_min));

		Punkt[1].x = (long)((ende_x - Koord->x_min2) / (Koord->x_max2 - Koord->x_min2)*(Koord->Grafik_x_max - Koord->Grafik_x_min) + Koord->Grafik_x_min);
		Punkt[1].y = (long)(Koord->Grafik_y_max - (ende_y - Koord->y_min2) / (Koord->y_max2 - Koord->y_min2)*(Koord->Grafik_y_max - Koord->Grafik_y_min));
	}
	Polyline(hdc, Punkt, 2);
	// Den Winkel mit den (umgerechneten) Bildschirmkoordinaten bestimmen
	winkel = atan2((double)(Punkt[1].y - Punkt[0].y), (double)(Punkt[1].x - Punkt[0].x));
	Pfeilspitze[0].x = Punkt[1].x + (long)(-2 * 10 *cos(winkel) + 10*sin(winkel)); 
	Pfeilspitze[0].y = Punkt[1].y + (long)(-10*cos(winkel) - 2 * 10*sin(winkel)); 
	Pfeilspitze[1] = Punkt[1];
	Pfeilspitze[2].x = Punkt[1].x + (long)(-2 * 10*cos(winkel) - 10*sin(winkel));
	Pfeilspitze[2].y = Punkt[1].y + (long)(10*cos(winkel) - 2 * 10*sin(winkel));

	Polyline(hdc, Pfeilspitze, 3);

	// Beschriftung erg�nzen:
	// Vor der ersten Beschriftung muss die Schriftart auf Arial ge�ndert werden
	hFontGerade = CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH, (LPCSTR)"ARIAL");
	hFontSystem = (HFONT)SelectObject(hdc, hFontGerade);
	SetTextAlign(hdc, TA_CENTER | TA_TOP);
	SetTextColor( hdc, RGB(rot, gruen, blau));
	if (erste_achse)
		TextOut(hdc, (int)(Punkt[0].x*0.2+Punkt[1].x*0.8+pfeilspitze), (int)(Punkt[0].y*0.2+Punkt[1].y*0.8+pfeilspitze), (LPCSTR)Beschriftung, strlen(Beschriftung));
	else // zweite Ausgabe rutscht nach unten
		TextOut(hdc, (int)(Punkt[0].x*0.2 + Punkt[1].x*0.8 + pfeilspitze), (int)(Punkt[0].y*0.2 + Punkt[1].y*0.8 + pfeilspitze + 15), (LPCSTR)Beschriftung, strlen(Beschriftung));
	
	SetTextColor(hdc, RGB(0, 0, 0));
	// Benutzten Font freigeben
	SelectObject(hdc, hFontSystem);
	DeleteObject(hFontGerade);
	// Schmalen Stift wieder aktivieren
	SelectObject(hdc, hPenPrev);
	// den alten Stift jetzt l�schen
	DeleteObject(hPen);

	return 0;
} // end of Zeichne_Zeiger_in_Koordinatensystem_Ursprung_mitte

int Zeichne_Bodeplot(HDC hdc, Bodeplot_Grafik *BP, char Ueberschrift[80], Operationsverstaerker *Bode_OP, bool Kopie_Zwischenablage)
{
	/*******************************************************************************************************************\
	| Funktion zur Zeichnung eines Bodeplots f�r Operationsverst�rker													|
	| 3.1.2016 M.Alles																									|
	| Eingabeparameter: HDC hdc: Handle auf den DeviceContext															|
	|					Struktur Bodeplot_Grafik mit																	|
	|						int Rand_x_min: Linker Rand des Koordinatensystems											|
	|						int Rand_x_max: Rechter Rand des Koordinatensystems											|
	|						int Rand_y_min: Oberer Rand des Koordinatensystems											|
	|						int Rand_y_max: Unterer Rand des Koordinatensystems											|
	|						double minimalwert_x1: Beschriftungswert	erste Achse										|
	|						double maximalwert_x1: Beschriftungswert	erste Achse										|
	|						double minimalwert_y1: Beschriftungswert	erste Achse										|
	|						double maximalwert_y1: Beschriftungswert	erste Achse										|
	|						double minimalwert_x2: Beschriftungswert	zweite Achse									|
	|						double maximalwert_x2: Beschriftungswert	zweite Achse									|
	|						double minimalwert_y2: Beschriftungswert	zweite Achse									|
	|						double maximalwert_y2: Beschriftungswert	zweite Achse									|
	|						int anzahl_graphen: Anzahl der �bereinander zu zeichnenden Graphen							|
	|						double abstand_graphen: Abstand zwischen den Graphen										|
	|						char Beschriftung_x1[40]:	Bezeichner f�r die erste x-Achse								|
	|						char Beschriftung_y1[40]:	Bezeichner f�r die erste y-Achse								|
	|						char Beschriftung_x1[40]:	Bezeichner f�r die zweite x-Achse								|
	|						char Beschriftung_y1[40]:	Bezeichner f�r die zweite y-Achse								|
	|						int pfeilspitze:	Ma� f�r die Pfeilspitzen												|
	|						int skalenstrich:	Ma� f�r die L�nge der Skalenstriche										|
	|						int delta_min:		Abstand vom Grafikrand (links, oben) f�r Beschriftung					|
	|						int delta_max:		Abstand vom Grafikrand (unten, rechts) f�r Beschriftung					|
	|						char Ueberschrift[80];	Titel der Grafik													|
	| R�ckgabewert:		int Fehler (0: kein Fehler)																		|
	|																													|
	|						int Grafik_x_min: Linker Rand des Koordinatensystems										|
	|						int Grafik_x_max: Rechter Rand des Koordinatensystems										|
	|						int Grafik_y_min: Oberer Rand des Koordinatensystems										|
	|						int Grafik_y_max: Unterer Rand des Koordinatensystems										|
	| Die Funktion zeichnet ein Koordinatensystem f�r ein Zeigerdiagramm mit Skalenteilung (jeweils 10 Werte)			|
	| und Beschriftung.																									|
	| Die Koordinaten werden als Zeiger �bernommen und in der Funktion "nach innen" geschoben, um Platz f�r die			|
	| Beschriftung zu geben. Die Verschiebung erfolgt �ber "#define"-Werte.												|
	\*******************************************************************************************************************/
	UNREFERENCED_PARAMETER(Ueberschrift);

	POINT Punkt[3];
	char cText[200];
	LOGFONT lf;
	HPEN hPenSchwarz2, hPenGrau1, hPenSchwarz1, hPenAlt; // hStiftSchwarz, hStiftAlt;
	HFONT hFontGerade, hFontGedreht, hFontSystem;
	RECT Diagrammbereich;
	int i, j;

	// Zu Beginn wird ein graues Rechteck gezeichnet
	// um den Hintergrund l�schen
	Diagrammbereich.left = BP->Rand_x_min;
	Diagrammbereich.right = BP->Rand_x_max;
	Diagrammbereich.top = BP->Rand_y_min;
	Diagrammbereich.bottom = BP->Rand_y_max;
	if (!Kopie_Zwischenablage)
		FillRect(hdc, &Diagrammbereich, (HBRUSH)COLOR_WINDOW);
	// Hintergrund auf grau setzen
	SetBkColor(hdc, GetSysColor(COLOR_WINDOW));
	SetBkMode(hdc, TRANSPARENT);

	// L�nge der Pfeilspitze usw. setzen: int pfeilspitze = 5, skalenstrich = 4, delta_min = 50, delta_max = 30;
	BP->pfeilspitze = 5;
	BP->skalenstrich = 4;
	BP->delta_min = 50;
	BP->delta_max = 30;
	// Neue Grenzen setzen: oben und rechts vom Rand 30 Punkte nach innen, unten und links jeweils 50 Punkte
	BP->Grafik_y_min = BP->Rand_y_min + BP->delta_min;
	BP->Grafik_y_max = BP->Rand_y_max - BP->delta_max;
	BP->Grafik_x_min = BP->Rand_x_min + BP->delta_min;
	BP->Grafik_x_max = BP->Rand_x_max - BP->delta_max;

	// Y-Bereich in zwei Diagramme aufteilen
	BP->Grafik_y_max_oben = (int)((BP->Grafik_y_max - BP->Grafik_y_min - 10) / 2.0 + BP->Grafik_y_min-BP->delta_min);
	BP->Grafik_y_min_unten = (int)(BP->Grafik_y_max_oben + 10 + BP->delta_max + BP->delta_min);

	// Maximalwerte bestimmen:
	if (BP->f_min > Bode_OP->Grenzfrequenz[0] / 10.0)
		BP->f_min = Bode_OP->Grenzfrequenz[0] / 10.0;
	if (BP->f_max < Bode_OP->Grenzfrequenz[2] * 10.0)
		BP->f_max = Bode_OP->Grenzfrequenz[2] * 10.0;

	// Anzahl der Skalenstriche bestimmen
	BP->f_max_dB = (int)(log10( BP->f_max)+0.99);
	// Das Betragsdiagramm geht bis -60dB: 60dB / 20dB = 3 -> daher kommt die "3" von 3.99!
	//	BP->V_U_min_dB = -60; // wird in der aufrufenden Funktion gesetzt
	if (BP->f_max_dB < 6)
		BP->f_max_dB = 6;
	BP->f_min_dB = (int)(log10(BP->f_min));
	// Jetzt auch die neuen Frequenzwerte speichern
	BP->f_min = pow(10.0, BP->f_min_dB);
	BP->f_max = pow(10.0, BP->f_max_dB);
	if (BP->V_U_max_dB < 120)
		BP->V_U_max_dB = 120;
	BP->V_U_delta_dB = BP->V_U_max_dB - BP->V_U_min_dB;

	BP->Phase_min = 0.0;
	BP->Phase_max = -270.0;
	BP->Phase_Teilung = -30.0;

	// Die x- und y-Achse werden mit einem breiteren Stift gezeichnet, diese Stifte hier erzeugen.
	hPenSchwarz2 = CreatePen(PS_SOLID, 2, (COLORREF)RGB(0, 0, 0));
	hPenSchwarz1 = CreatePen(PS_SOLID, 1, (COLORREF)RGB(0, 0, 0));
	hPenGrau1 = CreatePen(PS_SOLID, 1, (COLORREF)RGB(127, 127, 127));
	hPenAlt = (HPEN)SelectObject(hdc, hPenSchwarz2);

	//x-Achse
	Punkt[0].x = BP->Grafik_x_min;
	Punkt[0].y = BP->Grafik_y_max_oben;
	Punkt[1].x = BP->Grafik_x_max + 3 * BP->pfeilspitze;
	Punkt[1].y = BP->Grafik_y_max_oben;
	Polyline(hdc, Punkt, 2);
	Punkt[0].x = BP->Grafik_x_max + BP->pfeilspitze;
	Punkt[0].y = BP->Grafik_y_max_oben + BP->pfeilspitze;
	Punkt[2].x = BP->Grafik_x_max + BP->pfeilspitze;
	Punkt[2].y = BP->Grafik_y_max_oben - BP->pfeilspitze;
	Polyline(hdc, Punkt, 3);

	// Schmalen Stift wieder aktivieren
	SelectObject(hdc, hPenSchwarz2);
	//Skalenstriche
	j = 0;
	for (i = BP->f_min_dB; i<=BP->f_max_dB; i++)
	{
		Punkt[0].x = (int)(BP->Grafik_x_min + (BP->Grafik_x_max - BP->Grafik_x_min)*j / (BP->f_max_dB-BP->f_min_dB));
		Punkt[0].y = BP->Grafik_y_max_oben;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Punkt[0].y + BP->skalenstrich;
		Polyline(hdc, Punkt, 2);
		j++;
	}
	// Skalenstriche in grau im ganzen Diagramm, hier f�r die Frequenz
	j = 0;
	SelectObject(hdc, hPenGrau1);
	for (i = BP->f_min_dB; i <= BP->f_max_dB; i++)
	{
		Punkt[0].x = (int)(BP->Grafik_x_min + (BP->Grafik_x_max - BP->Grafik_x_min)*j / (BP->f_max_dB - BP->f_min_dB));
		Punkt[0].y = BP->Grafik_y_max_oben;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = BP->Grafik_y_min;
		Polyline(hdc, Punkt, 2);
		j++;
	}

	// Wieder auf den breiten Stift wechseln
	SelectObject(hdc, hPenSchwarz2);
	//y-Achse
	Punkt[0].x = BP->Grafik_x_min;
	Punkt[0].y = BP->Grafik_y_max_oben;
	Punkt[1].x = BP->Grafik_x_min;
	Punkt[1].y = BP->Grafik_y_min - 3 * BP->pfeilspitze;
	Polyline(hdc, Punkt, 2);
	Punkt[0].x -= BP->pfeilspitze;
	Punkt[0].y = BP->Grafik_y_min - BP->pfeilspitze;
	Punkt[2].x = BP->Grafik_x_min + BP->pfeilspitze;
	Punkt[2].y = Punkt[0].y;
	Polyline(hdc, Punkt, 3);

	//Skalenstriche
	for (i = 0; i<= BP->V_U_delta_dB; i+=20)
	{
		Punkt[0].x = BP->Grafik_x_min;
		Punkt[0].y = (int)(BP->Grafik_y_min + (BP->Grafik_y_max_oben - BP->Grafik_y_min)*i / BP->V_U_delta_dB);
		Punkt[1].x = BP->Grafik_x_min - BP->skalenstrich;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
	}
	SelectObject(hdc, hPenGrau1);
	//Skalenstriche in grau, hier f�r den Betrag
	for (i = 0; i <= BP->V_U_delta_dB; i+=20)
	{
		Punkt[0].x = BP->Grafik_x_min;
		Punkt[0].y = (int)(BP->Grafik_y_min + (BP->Grafik_y_max_oben - BP->Grafik_y_min)*i / BP->V_U_delta_dB);
		Punkt[1].x = BP->Grafik_x_max;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
	}

	// Vor der ersten Beschriftung muss die Schriftart auf Arial ge�ndert werden
	hFontGerade = CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH, (LPCSTR)"ARIAL");
	hFontSystem = (HFONT)SelectObject(hdc, hFontGerade);
	SetTextAlign(hdc, TA_CENTER | TA_TOP);
	// �berschrift
	TextOut(hdc, (BP->Grafik_x_min + BP->Grafik_x_max) / 2, BP->Grafik_y_min - 20, (LPCSTR)"Betrag", 6);
	// Beschriftung der x-Achse
	j = 0;
	for (i = BP->f_min_dB; i <= BP->f_max_dB; i+=2)
	{
		sprintf_s(cText, 199, "%.4g", pow(10.0, i));
		TextOut(hdc, (int)(BP->Grafik_x_min + (BP->Grafik_x_max - BP->Grafik_x_min)*j / (BP->f_max_dB-BP->f_min_dB)), BP->Grafik_y_max_oben + 10, (LPCSTR)cText, strlen(cText));
		j += 2;
	}
	// Beschriftung der x-Achse
	TextOut(hdc, (BP->Grafik_x_min + BP->Grafik_x_max) / 2, BP->Grafik_y_max_oben + 30, (LPCSTR)"f in Hz", 7);
	// Beschriftung der y-Achse
	SetTextAlign(hdc, TA_RIGHT | TA_TOP);
	for (i = 0; i <= BP->V_U_delta_dB; i+=20)
	{
		sprintf_s(cText, 199, "%d", (BP->V_U_max_dB-i) );	//Schrittweite 20dB
		TextOut(hdc, BP->Grafik_x_min - 10, (int)(BP->Grafik_y_min + (BP->Grafik_y_max_oben - BP->Grafik_y_min)*i / BP->V_U_delta_dB)-10, (LPCSTR)cText, strlen(cText));
	}
	// Beschriftung der y-Achse vertikal
	// Dazu zun�chste den aktuellen Font holen
	GetObject(hFontGerade, sizeof(LOGFONT), &lf);
	// Drehung um 90�
	lf.lfEscapement = 900;
	lf.lfOrientation = 900;
	hFontGedreht = CreateFontIndirect(&lf);
	SelectObject(hdc, hFontGedreht);
	SetTextAlign(hdc, TA_CENTER | TA_BOTTOM);
	// Beschriftung der y-Achse
	TextOut(hdc, BP->Grafik_x_min - 40, (BP->Grafik_y_min + BP->Grafik_y_max_oben) / 2, (LPCSTR)"V_0 in dB", 9);
	SelectObject(hdc, hFontGerade);
	DeleteObject(hFontGedreht);
	// Benutzten Font freigeben
	SelectObject(hdc, hFontSystem);
	DeleteObject(hFontGerade);
	// Koordinatensystem f�r Verst�rkung gezeichnet

	// Jetzt muss das Phasendiagramm gezeichnet werden
	// Die x- und y-Achse werden mit einem breiteren Stift gezeichnet
	SelectObject(hdc, hPenSchwarz2);

	//x-Achse
	Punkt[0].x = BP->Grafik_x_min;
	Punkt[0].y = BP->Grafik_y_max;
	Punkt[1].x = BP->Grafik_x_max + 3 * BP->pfeilspitze;
	Punkt[1].y = BP->Grafik_y_max;
	Polyline(hdc, Punkt, 2);
	Punkt[0].x = BP->Grafik_x_max + BP->pfeilspitze;
	Punkt[0].y = BP->Grafik_y_max + BP->pfeilspitze;
	Punkt[2].x = BP->Grafik_x_max + BP->pfeilspitze;
	Punkt[2].y = BP->Grafik_y_max - BP->pfeilspitze;
	Polyline(hdc, Punkt, 3);

	//Skalenstriche
	j = 0;
	for (i = BP->f_min_dB; i <= BP->f_max_dB; i++)
	{
		Punkt[0].x = (int)(BP->Grafik_x_min + (BP->Grafik_x_max - BP->Grafik_x_min)*j / (BP->f_max_dB-BP->f_min_dB));
		Punkt[0].y = BP->Grafik_y_max;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = Punkt[0].y + BP->skalenstrich;
		Polyline(hdc, Punkt, 2);
		j++;
	}
	// Striche in grau im kompletten Diagramm
	j = 0;
	SelectObject(hdc, hPenGrau1);
	for (i = BP->f_min_dB; i <= BP->f_max_dB; i++)
	{
		Punkt[0].x = (int)(BP->Grafik_x_min + (BP->Grafik_x_max - BP->Grafik_x_min)*j / (BP->f_max_dB-BP->f_min_dB));
		Punkt[0].y = BP->Grafik_y_max;
		Punkt[1].x = Punkt[0].x;
		Punkt[1].y = BP->Grafik_y_min_unten;
		Polyline(hdc, Punkt, 2);
		j++;
	}
	// Wieder auf den breiten Stift wechseln
	SelectObject(hdc, hPenSchwarz2);
	//y-Achse
	Punkt[0].x = BP->Grafik_x_min;
	Punkt[0].y = BP->Grafik_y_max;
	Punkt[1].x = BP->Grafik_x_min;
	Punkt[1].y = BP->Grafik_y_min_unten - 3 * BP->pfeilspitze;
	Polyline(hdc, Punkt, 2);
	Punkt[0].x -= BP->pfeilspitze;
	Punkt[0].y = BP->Grafik_y_min_unten - BP->pfeilspitze;
	Punkt[2].x = BP->Grafik_x_min + BP->pfeilspitze;
	Punkt[2].y = Punkt[0].y;
	Polyline(hdc, Punkt, 3);

	//Skalenstriche
	for (i = 0; i <= BP->Phase_max / BP->Phase_Teilung; i++)
	{
		Punkt[0].x = BP->Grafik_x_min;
		Punkt[0].y = (int)(BP->Grafik_y_min_unten + (BP->Grafik_y_max - BP->Grafik_y_min_unten)*i / 9);
		Punkt[1].x = BP->Grafik_x_min - BP->skalenstrich;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
	}
	// Diagrammlinien in grauer Farbe
	SelectObject(hdc, hPenGrau1);	
	for (i = 0; i <= BP->Phase_max / BP->Phase_Teilung; i++)
	{
		Punkt[0].x = BP->Grafik_x_min;
		Punkt[0].y = (int)(BP->Grafik_y_min_unten + (BP->Grafik_y_max - BP->Grafik_y_min_unten)*i / 9);
		Punkt[1].x = BP->Grafik_x_max;
		Punkt[1].y = Punkt[0].y;
		Polyline(hdc, Punkt, 2);
	}

	// Vor der ersten Beschriftung muss die Schriftart auf Arial ge�ndert werden
	hFontGerade = CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH, (LPCSTR)"ARIAL");
	hFontSystem = (HFONT)SelectObject(hdc, hFontGerade);
	SetTextAlign(hdc, TA_CENTER | TA_TOP);
	// �berschrift
	TextOut(hdc, (BP->Grafik_x_min + BP->Grafik_x_max) / 2, BP->Grafik_y_min_unten - 20, (LPCSTR)"Phase", 5);
	// Beschriftung der x-Achse
	j = 0;
	for (i = BP->f_min_dB; i <= BP->f_max_dB; i += 2)
	{
		sprintf_s(cText, 199, "%.4g", pow(10.0, i));
		TextOut(hdc, (int)(BP->Grafik_x_min + (BP->Grafik_x_max - BP->Grafik_x_min)*j / (BP->f_max_dB-BP->f_min_dB)), BP->Grafik_y_max + 10, (LPCSTR)cText, strlen(cText));
		j += 2;
	}
	// Beschriftung der x-Achse
	TextOut(hdc, (BP->Grafik_x_min + BP->Grafik_x_max) / 2, BP->Grafik_y_max + 30, (LPCSTR)"f in Hz", 7);
	// Beschriftung der y-Achse
	SetTextAlign(hdc, TA_RIGHT | TA_TOP);
	for (i = 0; i <= 9; i++)
	{
		if (i==0)
			sprintf_s(cText, 199, "%d", 0);
		else
		sprintf_s(cText, 199, "%.4g", -30.0 * (double)i);	//Schrittweite 30�
		TextOut(hdc, BP->Grafik_x_min - 10, (int)(BP->Grafik_y_min_unten + (BP->Grafik_y_max - BP->Grafik_y_min_unten)*i / 9) - 10, (LPCSTR)cText, strlen(cText));
	}
	// Beschriftung der y-Achse vertikal
	// Dazu zun�chste den aktuellen Font holen
	GetObject(hFontGerade, sizeof(LOGFONT), &lf);
	// Drehung um 90�
	lf.lfEscapement = 900;
	lf.lfOrientation = 900;
	hFontGedreht = CreateFontIndirect(&lf);
	SelectObject(hdc, hFontGedreht);
	SetTextAlign(hdc, TA_CENTER | TA_BOTTOM);
	// Beschriftung der y-Achse
//	mbstowcs_s(&zeichen, text, (size_t)199, "phi in �", (size_t)(99));
	TextOut(hdc, BP->Grafik_x_min - 40, (BP->Grafik_y_min_unten + BP->Grafik_y_max) / 2, (LPCSTR)"phi in �", 8);
	SelectObject(hdc, hFontGerade);
	DeleteObject(hFontGedreht);
	// Benutzten Font freigeben
	SelectObject(hdc, hFontSystem);
	DeleteObject(hFontGerade);

	// Stifte l�schen
	SelectObject(hdc, hPenAlt);
	// den alten Stift jetzt l�schen
	DeleteObject(hPenSchwarz1);
	DeleteObject(hPenSchwarz2);
	DeleteObject(hPenGrau1);

	return 0;
}

int Zeichne_OP_Kurve_in_Bodeplot(HDC hdc, Bodeplot_Grafik *BP)
{
	/*******************************************************************************************************************\
	| Funktion zur Zeichnung einer OP-Kurve in einen vorhandenen Bodeplots f�r Operationsverst�rker						|
	| 2.2.2017 M.Alles																									|
	| Eingabeparameter: HDC hdc: Handle auf den DeviceContext															|
	|					Struktur Koordinatensystem mit																	|
	|						int Rand_x_min: Linker Rand des Koordinatensystems											|
	|						int Rand_x_max: Rechter Rand des Koordinatensystems											|
	|						int Rand_y_min: Oberer Rand des Koordinatensystems											|
	|						int Rand_y_max: Unterer Rand des Koordinatensystems											|
	|						double minimalwert_x1: Beschriftungswert	erste Achse										|
	|						double maximalwert_x1: Beschriftungswert	erste Achse										|
	|						double minimalwert_y1: Beschriftungswert	erste Achse										|
	|						double maximalwert_y1: Beschriftungswert	erste Achse										|
	|						double minimalwert_x2: Beschriftungswert	zweite Achse									|
	|						double maximalwert_x2: Beschriftungswert	zweite Achse									|
	|						double minimalwert_y2: Beschriftungswert	zweite Achse									|
	|						double maximalwert_y2: Beschriftungswert	zweite Achse									|
	|						int anzahl_graphen: Anzahl der �bereinander zu zeichnenden Graphen							|
	|						double abstand_graphen: Abstand zwischen den Graphen										|
	|						char Beschriftung_x1[40]:	Bezeichner f�r die erste x-Achse								|
	|						char Beschriftung_y1[40]:	Bezeichner f�r die erste y-Achse								|
	|						char Beschriftung_x1[40]:	Bezeichner f�r die zweite x-Achse								|
	|						char Beschriftung_y1[40]:	Bezeichner f�r die zweite y-Achse								|
	|						int pfeilspitze:	Ma� f�r die Pfeilspitzen												|
	|						int skalenstrich:	Ma� f�r die L�nge der Skalenstriche										|
	|						int delta_min:		Abstand vom Grafikrand (links, oben) f�r Beschriftung					|
	|						int delta_max:		Abstand vom Grafikrand (unten, rechts) f�r Beschriftung					|
	|						char Ueberschrift[80];	Titel der Grafik													|
	| R�ckgabewert:		int Fehler (0: kein Fehler)																		|
	|																													|
	|						int Grafik_x_min: Linker Rand des Koordinatensystems										|
	|						int Grafik_x_max: Rechter Rand des Koordinatensystems										|
	|						int Grafik_y_min: Oberer Rand des Koordinatensystems										|
	|						int Grafik_y_max: Unterer Rand des Koordinatensystems										|
	| Die Funktion zeichnet die Verst�rkungs- und Phasenkurve f�r einen OP in das Bodediagramm und zeichnet 			|
	| Instabilit�t, Amplituden- und Phasenreserve ein. Die berechneten Werte werden ausgegeben.							|
	\*******************************************************************************************************************/
	POINT Punkt[8];
	char cText[200];
//	LOGFONT lf;
	HFONT hFontGerade, hFontSystem;
	HPEN hPenAlt, hPenViolett2, hPenOcker2, hPenBlau2, hPenRot2, hPenRot1; // hStiftSchwarz, hStiftAlt;
//	double phase_min, phase_max; // , phase_phasenreserve;
	double phasen_frequenz[8];
	int anzahl_phasen_punkte, i;
	double hilf, V_U_Amplitudenreserve, Frequenz_Amplitudenreserve;

	SetBkMode(hdc, TRANSPARENT);
	SetBkColor(hdc, GetSysColor(COLOR_WINDOW));

	// Grenzen und Maximalwerte sind aus der Funktion "Zeichne_Bodeplot" bekannt.
	// Vor der ersten Beschriftung muss die Schriftart auf Arial ge�ndert werden
	hFontGerade = CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH, (LPCSTR)L"ARIAL");
	hFontSystem = (HFONT)SelectObject(hdc, hFontGerade);
	SetTextAlign(hdc, TA_LEFT | TA_TOP);

	//Zeichnen der Verst�rkungskurve. Es geht los am linken Rand mit der Leerlaufverst�rkung
	// Beginn am linken Rand
	Punkt[0].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, BP->f_min, false);
	// Wert f�r Leerlaufverst�rkung bestimmen
	Punkt[0].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min, BP->Grafik_y_max_oben, BP->V_U_max_dB, BP->V_U_min_dB, OP_Bode.V_0_dB, true);
	// Dieser y-Wert gilt auch f�r den zweiten Punkt
	Punkt[1].y = Punkt[0].y;
	// Wert f�r erste Grenzfrequenz bestimmen
	Punkt[1].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, OP_Bode.Grenzfrequenz[0], false);

	// Dritter Punkt f�r zweite Grenzfrequenz
	Punkt[2].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, OP_Bode.Grenzfrequenz[1], false);
	hilf = Berechne_Betrag_dB_Bodeplot(OP_Bode.Grenzfrequenz[1], OP_Bode.V_0_dB, OP_Bode.Grenzfrequenz);
	Punkt[2].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min, BP->Grafik_y_max_oben, BP->V_U_max_dB, BP->V_U_min_dB, hilf, true);

	// Vierter Punkt f�r dritte Grenzfrequenz
	Punkt[3].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, OP_Bode.Grenzfrequenz[2], false);
	hilf = Berechne_Betrag_dB_Bodeplot(OP_Bode.Grenzfrequenz[2], OP_Bode.V_0_dB, OP_Bode.Grenzfrequenz);
	Punkt[3].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min, BP->Grafik_y_max_oben, BP->V_U_max_dB, BP->V_U_min_dB, hilf, true);

	// F�nfter Punkt: Verst�rkung -60dB
	Punkt[4].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, OP_Bode.Frequenz_minus_60dB, false);
	hilf = Berechne_Betrag_dB_Bodeplot(OP_Bode.Frequenz_minus_60dB, OP_Bode.V_0_dB, OP_Bode.Grenzfrequenz);
	Punkt[4].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min, BP->Grafik_y_max_oben, BP->V_U_max_dB, BP->V_U_min_dB, hilf, true);

	// Zeichnung des Betragsdiagramms. Dazu erst einen violetten Stift erzeugen
	hPenViolett2 = CreatePen(PS_SOLID, 2, RGB(153, 50, 204));
	hPenAlt = (HPEN)SelectObject(hdc, hPenViolett2);
	Polyline(hdc, Punkt, 5);

	// Zeichnung des Phasendiagramms, im allgemeinen mit acht Punkten
	// Speicherung der acht Frequenzen in einen Feld
	phasen_frequenz[0] = BP->f_min;
	phasen_frequenz[1] = OP_Bode.Grenzfrequenz[0] / 10.0;
	phasen_frequenz[2] = OP_Bode.Grenzfrequenz[0] * 10.0;
	phasen_frequenz[3] = OP_Bode.Grenzfrequenz[1] / 10.0;
	phasen_frequenz[4] = OP_Bode.Grenzfrequenz[1] * 10.0;
	phasen_frequenz[5] = OP_Bode.Grenzfrequenz[2] / 10.0;
	phasen_frequenz[6] = OP_Bode.Grenzfrequenz[2] * 10.0;
	phasen_frequenz[7] = BP->f_max;

	// Sortieren, doppelte Eintr�ge l�schen...
	anzahl_phasen_punkte = sortiere_frequenzpunkte(phasen_frequenz, 8);
	// Es geht los am linken Rand mit Phase 0�.
	Punkt[0].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, BP->f_min, false);
	Punkt[0].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min_unten, BP->Grafik_y_max, BP->Phase_min, BP->Phase_max, 0, false);

	// Die weiteren Punkte bestimmen
	for (i = 0; i < anzahl_phasen_punkte; i++)
	{
		// N�chster Punkt
		Punkt[i].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, phasen_frequenz[i], false);
		hilf = Berechne_Phase_Bodeplot(phasen_frequenz[i], OP_Bode.Grenzfrequenz);
		Punkt[i].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min_unten, BP->Grafik_y_max, BP->Phase_min, BP->Phase_max, hilf, true);
	}
	// Phasenverlauf zeichnen
	Polyline(hdc, Punkt, anzahl_phasen_punkte);

	// m�gliche Instabilit�t einzeichnen, Betrags- und Phasendiagramm
	Punkt[0].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, BP->f_min, false);
	hilf = Berechne_Betrag_dB_Bodeplot(OP_Bode.Frequenz_Instabilitaet, OP_Bode.V_0_dB, OP_Bode.Grenzfrequenz);
	Punkt[0].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min, BP->Grafik_y_max_oben, BP->V_U_max_dB, BP->V_U_min_dB, hilf, true);
	Punkt[1].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, OP_Bode.Frequenz_Instabilitaet, false);
	Punkt[1].y = Punkt[0].y;
	Punkt[2].x = Punkt[1].x;
	Punkt[2].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min_unten, BP->Grafik_y_max, BP->Phase_min, BP->Phase_max, -360.0, true);
	// Farbe ocker
	hPenOcker2 = CreatePen(PS_SOLID, 2, RGB(255, 165, 0));
	SelectObject(hdc, hPenOcker2);
	Polyline(hdc, Punkt, 3);
	// Zeichne Rechteck als Rahmen f�r die Ausgabe der m�glichen Instabilit�t
	Linien_Rechteck_BH(hdc, BP->Grafik_x_max + 30, BP->Grafik_y_min, 200, 100);
	// Ausgabe dazu
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 10, (LPCSTR)"m�gl. Instabilit�t:", 19);
	Bestimme_Frequenzbezeichner(cText, OP_Bode.Frequenz_Instabilitaet, 99);
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 30, (LPCSTR)cText, strlen(cText));
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 50, (LPCSTR)"Verst�rkung bei f_instabil:", 19);
	// Die Variable "hilf" hat hier noch den Wert der Verst�rkung bei der Instabilit�tsfrequenz
	sprintf_s(cText, 199, "V_0: %.4gdB", hilf);
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 70, (LPCSTR)cText, strlen(cText));
	SelectObject(hdc, hPenAlt);

	// Stift wieder l�schen
	DeleteObject(hPenOcker2);

	// Zeichnen der Phasenreserve mit blauem Stift
	hPenBlau2 = CreatePen(PS_SOLID, 2, RGB(0, 0, 255));
	SelectObject(hdc, hPenBlau2);
	Punkt[0].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, BP->f_min, false);
	hilf = Berechne_Betrag_dB_Bodeplot(OP_Bode.Frequenz_Phasenreserve, OP_Bode.V_0_dB, OP_Bode.Grenzfrequenz);
	Punkt[0].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min, BP->Grafik_y_max_oben, BP->V_U_max_dB, BP->V_U_min_dB, hilf, true);
	Punkt[1].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, OP_Bode.Frequenz_Phasenreserve, false);
	Punkt[1].y = Punkt[0].y;
	Punkt[2].x = Punkt[1].x;
	Punkt[2].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min_unten, BP->Grafik_y_max, BP->Phase_min, BP->Phase_max, -360.0, true);
	Polyline(hdc, Punkt, 3);
	// Zeichne Rechteck als Rahmen f�r die Ausgabe der m�glichen Instabilit�t
	Linien_Rechteck_BH(hdc, BP->Grafik_x_max + 30, BP->Grafik_y_min + 120, 200, 100);
	// Ausgabe dazu
	sprintf_s(cText, 199, "Phasenreserve: %.4g� bei", OP_Bode.Phasenreserve);
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 130, (LPCSTR)cText, strlen(cText));
	Bestimme_Frequenzbezeichner(cText, OP_Bode.Frequenz_Phasenreserve, 99);
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 150, (LPCSTR)cText, strlen(cText));
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 170, (LPCSTR)"erforderl. Verst�rkung", 22);
	// Bestimmung der Verst�rkung bei der Frequenz f�r die vorgegebene Phasenreserve
	hilf = Berechne_Betrag_dB_Bodeplot(OP_Bode.Frequenz_Phasenreserve, OP_Bode.V_0_dB, OP_Bode.Grenzfrequenz);
	sprintf_s(cText, 199, "V_U: %.4gdB", hilf);
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 190, (LPCSTR)cText, strlen(cText));
	SelectObject(hdc, hPenAlt);
	// Stift wieder l�schen
	DeleteObject(hPenBlau2);

	// Amplitudenreserve bestimmen und einzeichnen
	// Zun�chst Verst�rkung bei Instabilit�tsfrequenz bestimmen
	V_U_Amplitudenreserve = Berechne_Betrag_dB_Bodeplot(OP_Bode.Frequenz_Instabilitaet, OP_Bode.V_0_dB, OP_Bode.Grenzfrequenz) + OP_Bode.Amplitudenreserve;
	// Jetzt die Frequenz bestimmen
	Frequenz_Amplitudenreserve = Bestimme_Frequenz_aus_V(V_U_Amplitudenreserve, OP_Bode.V_0_dB, OP_Bode.Grenzfrequenz);
	// roten Stift erstellen
	hPenRot1 = CreatePen(PS_DOT, 1, RGB(255, 0, 0));
	hPenRot2 = CreatePen(PS_SOLID, 2, RGB(255, 0, 0));
	SelectObject(hdc, hPenRot1);
	Punkt[0].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, BP->f_min, false);
	Punkt[0].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min, BP->Grafik_y_max_oben, BP->V_U_max_dB, BP->V_U_min_dB, V_U_Amplitudenreserve, true);
	Punkt[1].x = Bestimme_Koordinaten_Wert(BP->Grafik_x_min, BP->Grafik_x_max, BP->f_min, BP->f_max, Frequenz_Amplitudenreserve, false);
	Punkt[1].y = Punkt[0].y;
	Punkt[2].x = Punkt[1].x;
	Punkt[2].y = Bestimme_Koordinaten_Wert(BP->Grafik_y_min_unten, BP->Grafik_y_max, BP->Phase_min, BP->Phase_max, -360.0, true);
	Polyline(hdc, Punkt, 3);
	Punkt[0].y++;
	Punkt[1].x++;
	Punkt[1].y++;
	Punkt[2].x++;
	Polyline(hdc, Punkt, 3);
	// Durchgezogene Linie einstelle
	SelectObject(hdc, hPenRot2);
	// Zeichne Rechteck als Rahmen f�r die Ausgabe der m�glichen Instabilit�t
	Linien_Rechteck_BH(hdc, BP->Grafik_x_max + 30, BP->Grafik_y_min + 240, 200, 100);
	// Ausgabe dazu
	sprintf_s(cText, 199, "Amplitudenres.: %.4gdB bei", OP_Bode.Amplitudenreserve);
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 250, (LPCSTR)cText, strlen(cText));
	Bestimme_Frequenzbezeichner(cText, Frequenz_Amplitudenreserve, 99);
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 270, (LPCSTR)cText, strlen(cText));
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 290, (LPCSTR)"erforderl. Verst�rkung", 22);
	sprintf_s(cText, 199, "V_U: %.4gdB", V_U_Amplitudenreserve);
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 310, (LPCSTR)cText, strlen(cText));
	SelectObject(hdc, hPenAlt);
	// Stift wieder l�schen
	DeleteObject(hPenRot2);
	DeleteObject(hPenRot1);

	if (OP_Bode.OP_Stabil)
		TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 350, (LPCSTR)"OP stabil", 9);
	else
	{
		if (OP_Bode.Betrag_bei_f_Instabil == 0.0)
			TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 350, (LPCSTR)"OP grenzstabil", 14);
		else
			TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 350, (LPCSTR)"OP instabil", 11);
	}
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 370, (LPCSTR)"f�r V_U beliebig", 16);
	TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 390, (LPCSTR)"Grenzfrequenzen:", 16);
	for (i = 0; i < 3; i++)
	{
		Bestimme_Frequenzbezeichner(cText, OP_Bode.Grenzfrequenz[i], 99);
		TextOut(hdc, BP->Grafik_x_max + 40, BP->Grafik_y_min + 410 + i * 20, (LPCSTR)cText, strlen(cText));
	}
	// Benutzten Font freigeben
	SelectObject(hdc, hFontSystem);
	DeleteObject(hFontGerade);

	return 0;
}

HFONT Erstelle_Font_Arial(HDC hdc, int Zeichenhoehe)
{
	HFONT rueckgabe;

	rueckgabe = CreateFont(Zeichenhoehe, // nHeight
		0,	// nWidth
		0,	// nEscapement
		0,	// nOrientation
		FW_DONTCARE, //fnWeight
		FALSE,	//fdwItalic
		FALSE,	//fdwUnderline
		FALSE,	//fdwStrikeOut
		DEFAULT_CHARSET,	//fdwCharSet
		OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
		CLIP_DEFAULT_PRECIS, //fdwClipPrecision
		CLEARTYPE_QUALITY,	//fdwQuality
		VARIABLE_PITCH,		//fdwPitchAndFamily
		TEXT("Arial"));	//lpszFace
	SetBkMode(hdc, TRANSPARENT);

	return rueckgabe;
}
HFONT Erstelle_Font_Arial(HDC hdc, int Zeichenhoehe, bool kursiv)
{
	HFONT rueckgabe;

	rueckgabe = CreateFont(Zeichenhoehe, // nHeight
		0,	// nWidth
		0,	// nEscapement
		0,	// nOrientation
		FW_DONTCARE, //fnWeight
		kursiv,	//fdwItalic
		FALSE,	//fdwUnderline
		FALSE,	//fdwStrikeOut
		DEFAULT_CHARSET,	//fdwCharSet
		OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
		CLIP_DEFAULT_PRECIS, //fdwClipPrecision
		CLEARTYPE_QUALITY,	//fdwQuality
		VARIABLE_PITCH,		//fdwPitchAndFamily
		TEXT("Arial"));	//lpszFace
	SetBkMode(hdc, TRANSPARENT);

	return rueckgabe;
}
HFONT Erstelle_Font_Symbol(HDC hdc, int Zeichenhoehe, bool kursiv)
{
	HFONT rueckgabe;

	rueckgabe = CreateFont(Zeichenhoehe, // nHeight
		0,	// nWidth
		0,	// nEscapement
		0,	// nOrientation
		FW_DONTCARE, //fnWeight
		kursiv,	//fdwItalic
		FALSE,	//fdwUnderline
		FALSE,	//fdwStrikeOut
		DEFAULT_CHARSET,	//fdwCharSet
		OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
		CLIP_DEFAULT_PRECIS, //fdwClipPrecision
		CLEARTYPE_QUALITY,	//fdwQuality
		VARIABLE_PITCH,		//fdwPitchAndFamily
		TEXT("Symbol"));	//lpszFace
	SetBkMode(hdc, TRANSPARENT);

	return rueckgabe;
}
int Zeichne_Leitung(HDC hdc, int x, int y, int breite, int hoehe, int laenge_Anschluss)
{
	// Zeichnet eine Leitung in den Bereich x bis x+breite und y bis y+hoehe.
	// laenge_anschluss legt ggf. die Anschlussdr�hte fest, die �ber den Bereich hinausgehen.

	// Linie oben und unten
	ZP_Linie(hdc, x+hoehe/4, y, x+breite-hoehe/4, y);
	ZP_Linie(hdc, x+hoehe/4, y+hoehe, x+breite-hoehe/4, y+hoehe);
	// Ellipse vorne, also links
	Ellipse_BH( hdc, x, y, hoehe/2, hoehe );
	// halbe Ellipse hinten, also rechts
	Ellipsenbogen_BH_Winkel1_Winkel2( hdc, x+breite-hoehe/2, y, hoehe/2, hoehe, 270, 90 );
	// Massesymbol am rechten Ende
	ZP_Linie(hdc, x+breite-hoehe/4, y+hoehe, x+breite-hoehe/4, y+hoehe+20 );
	ZP_Linie(hdc, x+breite-hoehe/4-8, y+hoehe+20, x+breite-hoehe/4+8, y+hoehe+20 );

	if (laenge_Anschluss > 0)
	{
		ZP_Linie(hdc, x - laenge_Anschluss, (int)(y + hoehe * 0.5), x, (int)(y + hoehe*0.5));
		ZP_Linie(hdc, x + breite, (int)(y + hoehe * 0.5), x + breite + laenge_Anschluss, (int)(y + hoehe*0.5) );
	}
	return 0;
} // end of Zeichne_Leitung
int Zeichne_HF_Leitung_mit_Spannungsverlauf( HDC hdc, bool Kopie_Zwischenablage )
{
	HPEN hStiftSchwarz2, hStiftAlt;
	HBRUSH hPinselSchwarz, hPinselAlt;
	HFONT FontNeu, FontAlt;
	struct Koordinatensystem KS;

	// Fenster neu zeichnen: HF_Leitung

	SetPolyFillMode(hdc, WINDING);

	hStiftSchwarz2 = CreatePen(PS_SOLID, 2, BLACK_PEN);
	hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
	hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
	hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);
	// Wieder wei�er Hintergrund
	SelectObject(hdc, hPinselAlt);

	// Spannungsquelle zeichnen
	Zeichne_Wechselspannungsquelle( hdc, 50, 100, 60, true, 20);
	// Verbindungslinie als Leitung zeichnen
	DP_Linie( hdc, 80, 100, 80, 50, 100, 50);
	DP_Linie( hdc, 750, 50, 800, 50, 800, 220 );
	// HF-Leitung zeichnen
	Zeichne_Leitung( hdc, 130, 30, 600, 40, 40 );
	// Masse rechts zeichnen
	ZP_Linie( hdc, 770, 220, 830, 220 );
	// Widerstand zeichnen
	Zeichne_Widerstand( hdc, 780, 100, 40, 80);
		
	// Spannungsverl�ufe zeichnen
	// Standardwerte f�r Koordinatensystem
	KS.pfeilspitze=5;
	KS.skalenstrich=4;
	KS.delta_min=50;
	KS.delta_max=30;

	KS.x_min1 = -HF_Leitung.Laenge;
	KS.x_max1 = 0.0;
	KS.y_min1 = 0.0;
	KS.y_max1 = setze_Maximalwert( HF_Leitung.U_Max );
	KS.Rand_x_min = 100;
	KS.Rand_x_max = 750;
	KS.Rand_y_min = 150;
	KS.Rand_y_max = 500;
	KS.Grafik_x_max = 0;
	KS.anzahl_graphen = 1;
	
	Zeichne_Koordinatensystem_Ursprung_links_unten( hdc, &KS, "l /m", "|U| /V", "", "", "Betrag Spannung", Kopie_Zwischenablage );
	// Daten f�r die Lage des Koordinatensystems in den globalen Variablen speichern
	HF_Leitung.Koord_Pos_x_max=KS.Rand_x_max - KS.delta_max;
	HF_Leitung.Koord_Pos_x_min=KS.Rand_x_min + KS.delta_min;
	HF_Leitung.Koord_Pos_y_max=KS.Rand_y_max - KS.delta_max;
	HF_Leitung.Koord_Pos_y_min=KS.Rand_y_min + KS.delta_min;

	HF_Leitung.Koord_x_min = KS.x_min1;
	HF_Leitung.Koord_y_max = KS.y_max1;
	// Spannungskurve in das Koordinatensystem einzeichnen.
	Zeichne_Kurve_in_Koordinatensystem_Ursprung_links_unten(hdc, &KS, HF_Leitung.Ort, HF_Leitung.U_Ges, 200, 0, 0, 255);
	if (Kopie_Zwischenablage)
	{
		FontNeu = Erstelle_Font_Arial( hdc, 16 );
		FontAlt = (HFONT)SelectObject(hdc, FontNeu);
		SetTextAlign(hdc, TA_LEFT);
		// Werte f�r Spannung, Widerst�nde etc. erg�nzen
		Zeichne_Text_xy( hdc, "Z=50Ohm", 410, 90 );

		// Schrift wieder l�schen
		SelectObject(hdc, FontAlt);
		DeleteObject(FontNeu);
	}
	
	DeleteObject(hPinselSchwarz);
	SelectObject(hdc, hStiftAlt);
	DeleteObject(hStiftSchwarz2);
	return 0;
}