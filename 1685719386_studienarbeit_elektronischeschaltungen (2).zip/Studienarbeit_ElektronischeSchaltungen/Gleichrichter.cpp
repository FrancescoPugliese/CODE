#include "stdafx.h"
/*******************************************************************************************************************\
|																													|
| Modul Gleichrichter.cpp																							|
|																													|
| In diesem Modul sind die Funktionen und Berechnungen f�r Gleichrichterschaltungen, Festspannungsregler und		|
| thermische Widerst�nde enthalten																					|	
| - Berechne_Gleichrichterschaltung();																				|
| - Eingabe_Gleichrichter();																						|
| - Eingabe_Spannungsregler();																						|
| - Eingabe_Wechselspannung();																						|
| - Ergebnis_Gleichrichter();																						|
| - Ergebnis_ThermischerWiderstand();																				|
| - Gleichrichterschaltung();																						|
| - ThermischerWiderstand();																						|
|  																													|
\*******************************************************************************************************************/
int Gleichrichterschaltung(HWND hWnd)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_GLEICHRICHTER), hWnd, GleichrichterSchaltung_Dialog);
	// Warnung("Nach DialogBox");

	return 0;
}	// end of Gleichrichterschaltung


int Eingabe_Wechselspannung(int Schaltung, int Parameter)
/* Funktion zur Eingabe der Spannung und der Frequenz */
// Schaltung: Schaltungsart: integer-Konstante der Schaltung, Parameter: U_AC_SPANNUNG oder U_AC_FREQUENZ
{
	if (!Eingabe_Dialog.Eingabe_Wechselspannung)
	{
		Eingabe_Dialog.Eingabe_Wechselspannung = true;
		Eingabe_Dialog.Auswahl_Schaltung = Schaltung;
		Eingabe_Dialog.Auswahl_Parameter_Wechselspg = Parameter;
		DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABEWECHSELSPANNUNG), hWndElektronikMain, EingabeWechselSpannung_Dialog);
		Eingabe_Dialog.Eingabe_Wechselspannung = false;
	}
	return 0;
}	// end of Eingabe_Wechselspannung

int Eingabe_Spannungsregler(void)
{
	/*	Funktion wird verwendet, um Daten des Festspannungsreglers einzugeben.
	�bergabeparameter:	keiner, Aufruf nur von Gleichrichterschaltung = 7
	R�ckgabewert:		0 */

	if (!Eingabe_Dialog.Eingabe_Spannungsregler)
	{
		Eingabe_Dialog.Eingabe_Spannungsregler = true;
		Eingabe_Dialog.Auswahl_Schaltung = 7;
		DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABESPANNUNGSREGLER), hWndElektronikMain, EingabeSpannungsregler_Dialog);
		Eingabe_Dialog.Eingabe_Spannungsregler = false;
	}
	return 0;
}	// end of Eingabe_Spannungsregler

int Eingabe_Gleichrichter(void)
// Funktion zur Eingabe des Gleichrichters
{
	if (!Eingabe_Dialog.Eingabe_Gleichrichter)
	{
		Eingabe_Dialog.Eingabe_Gleichrichter = true;
		DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABEGLEICHRICHTER), hWndElektronikMain, EingabeGleichrichter_Dialog);
		Eingabe_Dialog.Eingabe_Gleichrichter = false;
	}
	return 0;
}	// end of Eingabe_Gleichrichter

int Ergebnis_Gleichrichter(HWND hDlg)
{
	// Berechnung der Gleichrichterschaltung
	Berechne_Gleichrichterschaltung();
	DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_GLEICHRICHTER), hDlg, ErgebnisGleichrichterSchaltung_Dialog);


	return 0;
}	// end of Ergebnis_Basisschaltung

int Berechne_Gleichrichterschaltung(void)
{
	// Berechnung der Spannungamplitude
	Gleichrichter.U_amplitude = Gleichrichter.U_eff * sqrt(2.0);
	Gleichrichter.Schaltung_berechenbar = true;
	// Berechnung der Sperrspannung der Dioden, die Flussspannung ist durch U_D gegeben

	if (Gleichrichter.einweg)
	{
		Gleichrichter.U_diode_sperr = 2.0*Gleichrichter.U_amplitude - Gleichrichter.U_D;
		Gleichrichter.U_Max = Gleichrichter.U_amplitude - Gleichrichter.U_D;
		if (Gleichrichter.R*Gleichrichter.f*Gleichrichter.U_Max*Gleichrichter.C != 0.0)
			Gleichrichter.Welligkeit = Gleichrichter.Festspannung / Gleichrichter.R / Gleichrichter.f / Gleichrichter.U_Max / Gleichrichter.C;
		else
			Gleichrichter.Schaltung_berechenbar = false;
	}
	else
	{
		Gleichrichter.U_diode_sperr = Gleichrichter.U_amplitude - Gleichrichter.U_D;
		Gleichrichter.U_Max = Gleichrichter.U_amplitude - 2.0*Gleichrichter.U_D;
		if (Gleichrichter.R*Gleichrichter.f*Gleichrichter.U_Max*Gleichrichter.C != 0.0)
			Gleichrichter.Welligkeit = Gleichrichter.Festspannung / Gleichrichter.R / Gleichrichter.f / Gleichrichter.U_Max / Gleichrichter.C / 2.0;
		else
			Gleichrichter.Schaltung_berechenbar = false;
	}
	Gleichrichter.Welligkeit = fabs(Gleichrichter.Welligkeit);
	if (!Gleichrichter.positiv_gleichrichter)
		Gleichrichter.U_Max = -Gleichrichter.U_Max;
	if (Gleichrichter.positiv_gleichrichter&&Gleichrichter.positiv_regler)
	{
		if (Gleichrichter.U_Max - Gleichrichter.U_Drop > Gleichrichter.Festspannung)
			Gleichrichter.U_Ausgang = Gleichrichter.Festspannung;
		else
			Gleichrichter.U_Ausgang = Gleichrichter.U_Max - Gleichrichter.U_Drop;
	}
	if (!Gleichrichter.positiv_gleichrichter&&!Gleichrichter.positiv_regler)
	{
		if (Gleichrichter.U_Max + Gleichrichter.U_Drop < Gleichrichter.Festspannung)
			Gleichrichter.U_Ausgang = Gleichrichter.Festspannung;
		else
			Gleichrichter.U_Ausgang = Gleichrichter.U_Max + Gleichrichter.U_Drop;
	}
	Gleichrichter.P_V = fabs( (Gleichrichter.U_Max - Gleichrichter.U_Ausgang)*Gleichrichter.U_Ausgang / Gleichrichter.R );
	if (Gleichrichter.positiv_gleichrichter != Gleichrichter.positiv_regler)
		Gleichrichter.Schaltung_berechenbar = false;

	return 0;
}

int ThermischerWiderstand(HWND hDlg)
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_THERMISCHERWIDERSTAND), hDlg, ThermischerWiderstand_Dialog);
	
	return 0;
}	// end of ThermischerWiderstand

int Ergebnis_ThermischerWiderstand(int Zu_Berechnen)
// OK, MA, 23.8.2016
{
	// Berechnung des fehlenden Parameters
	switch (Zu_Berechnen)
	{
	case 1: 
		// Berechnung des thermischen Widerstands R_th,jc:
		R_th.Rth_JC = (R_th.T_junc - R_th.T_max) / R_th.P_V - R_th.Rth_CK - R_th.Rth_KA;
		break;
	case 2: 
		// Berechnung des thermischen Widerstands R_th,ck:
		R_th.Rth_CK = (R_th.T_junc - R_th.T_max) / R_th.P_V - R_th.Rth_JC - R_th.Rth_KA;
		break;
	case 3: 
		// Berechnung des thermischen Widerstands R_th,ka:
		R_th.Rth_KA = (R_th.T_junc - R_th.T_max) / R_th.P_V - R_th.Rth_CK - R_th.Rth_JC;
		break;
	case 4: 
		// Beechnung der Verlustleistung P_V:
		R_th.P_V = (R_th.T_junc - R_th.T_max) / (R_th.Rth_JC + R_th.Rth_CK + R_th.Rth_KA);
		break;
	case 5: 
		// Berechnung von T_J:
		R_th.T_junc = R_th.P_V * (R_th.Rth_JC + R_th.Rth_CK + R_th.Rth_KA) + R_th.T_max;
		break;
	case 6: 
		// Berechnung von T_Max:
		R_th.T_max = R_th.T_junc - R_th.P_V * (R_th.Rth_JC + R_th.Rth_CK + R_th.Rth_KA);
		break;
	default:
		Warnung("Fehler bei der Auswahl des zu berechnenden Elementes bei thermischen Widerst�nden");
	}
	return 0;
}	// end of Ergebnis_ThermischerWiderstand

int Kopiere_Ergebnis_Gleichrichter(Dioden_Gleichrichter Gleichr, HWND hWnd)
/* Diese Funktion kopiert die Berechnungsergebnisse des Differenzverst�rkers in die Zwischenablage */
{
	HGLOBAL hGlobal;
	WCHAR *wcGlobal;
	WCHAR wcText[2001];
	char cZeile[100];
	WCHAR wcZeile[MAX_DATEINAME];
	int laenge = 0;

	// Der Reihe nach die Daten in den String kopieren
	wcscpy_s(wcText, 50, L"Berechnung Gleichrichter\n");

	// Falls die Schaltung nicht berechenbar ist, wird hier auch die Fehlermeldung kopiert.
	if (!Gleichr.Schaltung_berechenbar) 
		wcscat_s(wcText, 25, L"Berechnung fehlerhaft!\n");

	// Versorgungsspannung und Widerst�nde ausgeben
	wcscat_s(wcText, 2000, L"\nEingangsspannung U_Eff=");
	Bestimme_Spannungsbezeichner( cZeile, Gleichr.U_eff, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L"\tEingangsspannung U_Amp=");
	Bestimme_Spannungsbezeichner( cZeile, Gleichr.U_amplitude, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	// Gleichrichterdaten ausgeben
	wcscat_s(wcText, 2000, L"\nGleichrichter: ");
	if (Gleichr.einweg)
		wcscat_s(wcText, 2000, L"Einweggleichrichter, ");
	else
		wcscat_s(wcText, 2000, L"Br�cken-, Vollwellengleichrichter");
	if (Gleichr.positiv_regler)
		wcscat_s(wcText, 2000, L" (positiv)");
	else
		wcscat_s(wcText, 2000, L" (negativ)");
	wcscat_s(wcText, 2000, L"\nDiodenspannung: U_D=");
	Bestimme_Spannungsbezeichner( cZeile, Gleichr.U_D, (int)99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L"\nSperrspannung: U_Sperr=");
	Bestimme_Spannungsbezeichner( cZeile, Gleichr.U_diode_sperr, (int)99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);

	wcscat_s(wcText, 2000, L"\nFestspannungsregler");
	if (Gleichr.positiv_regler)
		wcscat_s(wcText, 2000, L" (positiv): ");
	else
		wcscat_s(wcText, 2000, L" (negativ): ");

	Bestimme_Bezeichner_Festspannungsregler(cZeile, Gleichr.Festspannung, Gleichr.positiv_regler, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);

	wcscat_s(wcText, 2000, L"\nSpannung zw. Gleichrichter und Regler: ");
	Bestimme_Spannungsbezeichner( cZeile, Gleichr.U_Max, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);

	wcscat_s(wcText, 2000, L"\nSollspannung nach Festspannungsregler: ");
	Bestimme_Spannungsbezeichner( cZeile, (double)Gleichr.Festspannung, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);

	wcscat_s(wcText, 2000, L"\nSpannung nach Festspannungsregler: ");
	Bestimme_Spannungsbezeichner( cZeile, Gleichr.U_Ausgang, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);


	// Daten Gl�ttung ausgeben
	wcscat_s(wcText, 2000, L"\nWelligkeit: ");
	Bestimme_Prozentbezeichner( cZeile, Gleichr.Welligkeit, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L",\tKapazit�t=");
	Bestimme_Kapazitaetsbezeichner( cZeile, Gleichr.C, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L",\tWiderstand=");
	Bestimme_Widerstandsbezeichner(cZeile, Gleichr.R, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L",\tFrequenz=");
	Bestimme_Frequenzbezeichner(cZeile, Gleichr.f, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);

	if (Datei_gespeichert)
	{
		wcscat_s(wcText, 2000, L"\nDateiname; ");
		char_to_widechar( wcZeile, Dateiname, MAX_DATEINAME);
		wcscat_s(wcText, 2000, wcZeile);
	}
	laenge = wcslen(wcText);
	//hGlobal = GlobalAlloc(GHND, (laenge + 2) * sizeof(WCHAR));
	hGlobal = GlobalAlloc( GHND, (laenge+1)*sizeof(WCHAR));
	if (hGlobal == NULL)
		return 1;
	wcGlobal = (WCHAR*)GlobalLock(hGlobal);
	
	wcscpy_s(wcGlobal, (size_t)(laenge+1), wcText);
	if (GlobalUnlock(hGlobal)!=0)
		return 2;
	if (!OpenClipboard(hWnd))
		return 3;
	EmptyClipboard();
	if (SetClipboardData(CF_UNICODETEXT, hGlobal)==NULL)
		return 4;
	CloseClipboard();

	return 0;
} // end of Kopiere_Ergebnis_Gleichrichter
