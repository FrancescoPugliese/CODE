#include "stdafx.h"

/*******************************************************************************************************************\
|                                                                                                                   |
| Modul Bauteile.cpp                                                                                                |
|                                                                                                                   |
| In diesem Modul sind Funktionen zur Eingabe von Widerständen, Kondensatoren und Spulen enthalten                    |
| Außerdem sind Funktionen zur Eingabe von Spannungs- und dB-Werten und die Berechnung der dB/dBm-Werte enthalten     |
| - Eingabe_Kapazitaetswerte_Aufruf();                                                                              |
| - Eingabe_Widerstandswerte_Aufruf();                                                                              |
| - Eingabe_Laenge_Aufruf();                                                                                        |
| - Eingabe_Leitungswiderstaende_Aufruf();                                                                          |
| - Eingabe_Spannungswert_Aufruf();                                                                                 |
| - DezibelRechner_Aufruf();                                                                                        |
| - Ergebnis_DezibelRechner();                                                                                      |
| - dBmRechner_Aufruf(void)();                                                                                      |
| - Eingabe_Beta_Aufruf();                                                                                          |
| - Eingabe_Eps_R_Aufruf();                                                                                         |
| - Eingabe_kompl_Impedanz_Aufruf();                                                                                |
|                                                                                                                   |
\*******************************************************************************************************************/

// Function to display the dialogs for all subfunctions and perform the tasks for the dialogs
void DisplaySubfunctionDialogs()
{
    // Call the dialog for entering capacitor values
    int Kondensator = 0; // provide the appropriate value
    int Anzahl_Kondensatoren = 0; // provide the appropriate value
    int Schaltungsauswahl = 0; // provide the appropriate value
    Eingabe_Kapazitaetswerte_Aufruf(Kondensator, Anzahl_Kondensatoren, Schaltungsauswahl);

    // Call the dialog for entering resistor values
    int Widerstand = 0; // provide the appropriate value
    int Anzahl_Widerstand = 0; // provide the appropriate value
    Schaltungsauswahl = 0; // provide the appropriate value
    Eingabe_Widerstandswerte_Aufruf(Widerstand, Anzahl_Widerstand, Schaltungsauswahl);

    // Call the dialog for entering length values
    Schaltungsauswahl = 0; // provide the appropriate value
    Eingabe_Laenge_Aufruf(Schaltungsauswahl);

    // Call the dialog for entering transmission line resistance values
    Widerstand = 0; // provide the appropriate value
    Anzahl_Widerstand = 0; // provide the appropriate value
    Schaltungsauswahl = 0; // provide the appropriate value
    Eingabe_Leitungswiderstaende_Aufruf(Widerstand, Anzahl_Widerstand, Schaltungsauswahl);

    // Call the dialog for entering voltage values
    Schaltungsauswahl = 0; // provide the appropriate value
    int Spannungsart = 0; // provide the appropriate value
    Eingabe_Spannungswert_Aufruf(Schaltungsauswahl, Spannungsart);

    // Call the dB calculator dialog
    DezibelRechner_Aufruf();

    // Call the dBm calculator dialog
    dBmRechner_Aufruf();

    // Call the dialog for entering beta values
    Schaltungsauswahl = 0; // provide the appropriate value
    Eingabe_Beta_Aufruf(Schaltungsauswahl);

    // Call the dialog for entering Eps_R values
    Schaltungsauswahl = 0; // provide the appropriate value
    Eingabe_Eps_R_Aufruf(Schaltungsauswahl);

    // Call the dialog for entering complex impedance values
    Schaltungsauswahl = 0; // provide the appropriate value
    Eingabe_kompl_Impedanz_Aufruf(Schaltungsauswahl);
}

int Eingabe_Kapazitaetswerte_Aufruf(int Kondensator, int Anzahl_Kondensatoren, int Schaltungsauswahl)
{
    if (!Eingabe_Dialog.Eingabe_Kondensator)
    {
        Eingabe_Dialog.Eingabe_Kondensator = true;
        Eingabe_Dialog.Auswahl_Kondensator = Kondensator;
        Eingabe_Dialog.Anzahl_Kondensator = Anzahl_Kondensatoren;
        Eingabe_Dialog.Auswahl_Schaltung = Schaltungsauswahl;
        DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABEKAPAZITAET), hWndElektronikMain, EingabeKapazitaetswerte_Dialog);
        Eingabe_Dialog.Eingabe_Kondensator = false;
    }

    return 0;
}

int Eingabe_Widerstandswerte_Aufruf(int Widerstand, int Anzahl_Widerstand, int Schaltungsauswahl, int Pos_links, int Pos_rechts)
{
    if (!Eingabe_Dialog.Eingabe_Widerstand)
    {
        Eingabe_Dialog.x_max = Pos_rechts;
        Eingabe_Dialog.x_min = Pos_links;
        Eingabe_Widerstandswerte_Aufruf(Widerstand, Anzahl_Widerstand, Schaltungsauswahl);
    }
    return 0;
}

int Eingabe_Widerstandswerte_Aufruf(int Widerstand, int Anzahl_Widerstand, int Schaltungsauswahl)
{
    if (!Eingabe_Dialog.Eingabe_Widerstand)
    {
        Eingabe_Dialog.Eingabe_Widerstand = true;
        Eingabe_Dialog.Auswahl_Widerstand = Widerstand;
        Eingabe_Dialog.Anzahl_Widerstand = Anzahl_Widerstand;
        Eingabe_Dialog.Auswahl_Schaltung = Schaltungsauswahl;
        DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABEWIDERSTAND), hWndElektronikMain, EingabeWiderstandswerte_Dialog);
        Eingabe_Dialog.Eingabe_Widerstand = false;
        Eingabe_Dialog.x_max = 0;
        Eingabe_Dialog.x_min = 0;
    }

    return 0;
}

int Eingabe_Leitungswiderstaende_Aufruf(int Widerstand, int Anzahl_Widerstand, int Schaltungsauswahl)
{
    UNREFERENCED_PARAMETER(Anzahl_Widerstand);
    if (!Eingabe_Dialog.Eingabe_Widerstand)
    {
        Eingabe_Dialog.Eingabe_Leitungswiderstand = true;
        Eingabe_Dialog.Auswahl_Leitungswiderstand = Widerstand;
        Eingabe_Dialog.Auswahl_Schaltung = Schaltungsauswahl;
        DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABELEITUNGSWIDERSTAND), hWndElektronikMain, Eingabe_Leitungswiderstand_Dialog);
        Eingabe_Dialog.Eingabe_Leitungswiderstand = false;
        Eingabe_Dialog.x_max = 0;
        Eingabe_Dialog.x_min = 0;
    }

    return 0;
}

int Eingabe_Spannungswert_Aufruf(int Schaltungsauswahl, int Spannungsart)
{
    if (!Eingabe_Dialog.Eingabe_Spannung)
    {
        Eingabe_Dialog.Eingabe_Spannung = true;
        Eingabe_Dialog.Auswahl_Schaltung = Schaltungsauswahl;
        Eingabe_Dialog.Auswahl_Spannung = Spannungsart;
        DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABESPANNUNG), hWndElektronikMain, EingabeSpannungswert_Dialog);
        Eingabe_Dialog.Eingabe_Spannung = false;
    }

    return 0;
}

int DezibelRechner_Aufruf(void)
{
    if (!Eingabe_Dialog.Dezibel_Rechner)
    {
        Eingabe_Dialog.Dezibel_Rechner = true;
        Eingabe_Dialog.Auswahl_dB = true;
        DialogBox(hInst, MAKEINTRESOURCE(IDD_DB_RECHNER), hWndElektronikMain, DezibelRechner_Dialog);
        Eingabe_Dialog.Dezibel_Rechner = false;
    }

    return 0;
}

int Ergebnis_DezibelRechner(int Zu_Berechnen)
{
    double faktor;

    switch (Zu_Berechnen)
    {
    case U1_P1_AUS_DB: // Spannung U_1 und Leistung P_1 bestimmen
        faktor = pow(10.0, DezibelRechner.dB_Wert / 10.0);
        DezibelRechner.P_1 = DezibelRechner.P_0 * faktor;
        faktor = pow(10.0, DezibelRechner.dB_Wert / 20.0);
        DezibelRechner.U_1 = DezibelRechner.U_0 * faktor;
        break;
    case U0_P0_AUS_DB: // Spannung U_0 und Leistung P_0 bestimmen
        faktor = pow(10.0, DezibelRechner.dB_Wert / 10.0);
        DezibelRechner.P_0 = DezibelRechner.P_1 / faktor;
        faktor = pow(10.0, DezibelRechner.dB_Wert / 20.0);
        DezibelRechner.U_0 = DezibelRechner.U_1 / faktor;
        break;
    case DB_AUS_U: // dB-Wert aus Spannung bestimmen
        DezibelRechner.dB_Wert = 20.0 * log10(DezibelRechner.U_1 / DezibelRechner.U_0);
        break;
    case DB_AUS_P: // dB-Wert aus Leistung bestimmen
        DezibelRechner.dB_Wert = 10.0 * log10(DezibelRechner.P_1 / DezibelRechner.P_0);
        break;
    }

    return 0;
}

int dBmRechner_Aufruf(void)
{
    if (!Eingabe_Dialog.Dezibel_Rechner)
    {
        Eingabe_Dialog.Dezibel_Rechner = true;
        Eingabe_Dialog.Auswahl_dB = false;
        DialogBox(hInst, MAKEINTRESOURCE(IDD_DB_RECHNER), hWndElektronikMain, DezibelRechner_Dialog);
        Eingabe_Dialog.Dezibel_Rechner = false;
    }

    return 0;
}

int Eingabe_Laenge_Aufruf(int Schaltungsauswahl)
{
    if (!Eingabe_Dialog.Eingabe_Laenge)
    {
        Eingabe_Dialog.Eingabe_Laenge = true;
        Eingabe_Dialog.Auswahl_Schaltung = Schaltungsauswahl;
        DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABELAENGE), hWndElektronikMain, Eingabe_Laenge_Dialog);
        Eingabe_Dialog.Eingabe_Laenge = false;
    }

    return 0;
}

int Eingabe_Beta_Aufruf(int Schaltungsauswahl)
{
    if (!Eingabe_Dialog.Eingabe_Beta)
    {
        Eingabe_Dialog.Eingabe_Beta = true;
        Eingabe_Dialog.Auswahl_Beta = 1;
        Eingabe_Dialog.Auswahl_Schaltung = Schaltungsauswahl;
        DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABEBETA), hWndElektronikMain, Eingabe_Beta_Dialog);
        Eingabe_Dialog.Eingabe_Beta = false;
    }

    return 0;
}

int Eingabe_Eps_R_Aufruf(int Schaltungsauswahl)
{
    if (!Eingabe_Dialog.Eingabe_Beta)
    {
        Eingabe_Dialog.Eingabe_Beta = true;
        Eingabe_Dialog.Auswahl_Beta = 0;
        Eingabe_Dialog.Auswahl_Schaltung = Schaltungsauswahl;
        DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABEBETA), hWndElektronikMain, Eingabe_Beta_Dialog);
        Eingabe_Dialog.Eingabe_Beta = false;
    }

    return 0;
}

int Eingabe_kompl_Impedanz_Aufruf(int Schaltungsauswahl)
{
    if (!Eingabe_Dialog.Eingabe_Impedanz)
    {
        Eingabe_Dialog.Eingabe_kompl_Impedanz = true;
        Eingabe_Dialog.Auswahl_Schaltung = Schaltungsauswahl;
        DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABE_KOMPLEXE_IMPEDANZ), hWndElektronikMain, Eingabe_kompl_Impedanz_Dialog);
        Eingabe_Dialog.Eingabe_kompl_Impedanz = false;
    }

    return 0;
}
