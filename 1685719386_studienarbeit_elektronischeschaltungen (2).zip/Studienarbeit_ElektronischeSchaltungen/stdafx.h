// stdafx.h: Includedatei f�r Standardsystem-Includedateien
// oder h�ufig verwendete projektspezifische Includedateien,
// die nur in unregelm��igen Abst�nden ge�ndert werden.
//

#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Selten verwendete Komponenten aus Windows-Headern ausschlie�en
// Windows-Headerdateien:
#include <windows.h>
#include <Windowsx.h>
#include <CommCtrl.h>
#include <commdlg.h>

// C RunTime-Headerdateien
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <complex>
#include <shellapi.h>

// TODO: Hier auf zus�tzliche Header, die das Programm erfordert, verweisen.
#include "common.h"
#include "Funktionsdeklarationen.h"
#include "Texte.h"
#include "Resource.h"
