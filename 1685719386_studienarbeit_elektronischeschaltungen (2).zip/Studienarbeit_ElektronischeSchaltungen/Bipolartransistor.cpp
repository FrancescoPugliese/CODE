#include "stdafx.h"

/*******************************************************************************************************************\
|																													|
| Modul Bipolartransistor.cpp																						|
|																													|
| In diesem Modul sind Funktionen zur Eingabe, Bearbeitung und Berechnung von Bipolartransistorschaltungen			|
| enthalten																											|
| - AC_Ausgangswiderstand_B();																						|
| - AC_Ausgangswiderstand_C();																						|
| - AC_Ausgangswiderstand_E();																						|
| - AC_Eingangswiderstand_B();																						|
| - AC_Eingangswiderstand_C();																						|
| - AC_Eingangswiderstand_E();																						|
| - Basisschaltung_Aufruf();																						|
| - Basisstrom_NPN();																								|
| - Basisstrom_PNP();																								|
| - Berechne_Basisschaltung();																						|
| - Berechne_Emitterschaltung();																					|
| - Berechne_Kollektorschaltung();																					|
| - Berechne_I_C();																									|
| - Berechne_Kennlinienfeld();																						|
| - Berechne_Parameter_Kennlinienfeld_Bipolar();																	|
| - Ergebnis_Basisschaltung();																						|
| - Ergebnis_Emitterschaltung();																					|
| - Ergebnis_Kollektorschaltung();																					|
| - ESB_Basisschaltung();																							|
| - ESB_Emitterschaltung();																							|
| - ESB_Kollektorschaltung();																						|
| -	init_Emitterschaltung();																						|
| - init_Kollektorschaltung();																						|
| -	init_Basisschaltung();																							|
| -	Eingabe_BipolarTransistorwerte_Aufruf();																		|
| - Emitterschaltung_Aufruf();																						|
| - Kennlinienfeld_Bipolar_Aufruf();																				|
| - Kollektorschaltung_Aufruf();																					|
| - Kopiere_Basisschaltung();																						|
| - Kopiere_Emitterschaltung();																						|
| - Kopiere_Ergebnis_Bipolar_Transistorschaltung();																	|
| - Kopiere_ESB_Basisschaltung();																					|
| - Kopiere_ESB_Kollektorschaltung();																				|
| - Kopiere_ESB_Emitterschaltung();																					|
| - Kopiere_Kollektorschaltung();																					|
| - r_BE();																											|
| - r_CE();																											|
| - Transistorwerte_auf_Null();																						|
| - U_T();																											|
| - V_U_AC_C();																										|
| - V_U_DC_E();																										|
| - V_U_AC_E();																										|
| - Zeichne_Ausgabe_Basisschaltung();																				|
| - Zeichne_Ausgabe_Emitterschaltung();																				|
| - Zeichne_Ausgabe_Kollektorschaltung();																			|
| - Zeichne_Basisschaltung();																						|
| - Zeichne_Emitterschaltung();																						|
| - Zeichne_ESB_Basisschaltung();																					|
| - Zeichne_ESB_Emitterschaltung();																					|
| - Zeichne_ESB_Kollektorschaltung();																				|
| - Zeichne_Kollektorschaltung();																					|
|  																													|
\*******************************************************************************************************************/

int Transistorwerte_auf_Null(Bipolartransistor *Trans)
// Initialisierung der Variablen f�r eine Emitterschaltung
// Funktion in Ordnung, M. Alles, 21.4.2016
{
  int i;

  for (i = 0; i<5; i++)
	Trans->R[i] = 0.0;
  for (i = 0; i<3; i++)
	Trans->C[i] = 0.0;
  Trans->R_Max = 3;
  Trans->C_Max = 3;
  Trans->U_B = 0.0;

  Trans->Beta = 0.0;		// Beta
  Trans->U_AF = 0.0;		// Early-Spannung
  Trans->U_BE = 0.0;		// Basis-Emitter-Spannung
  Trans->NPN = true;		// NPN-Transistor
  Trans->T = 0.0;		// Temperatur
  Trans->neue_Schaltung = true;
  Trans->Naeherung_r_CE = false;
  Trans->Naeherung_U_T = true;				// true: Es wird U_T=26mV verwendet, false: U_T wird berechnet.
  Trans->I_B = 0.0;
  Trans->I_C = 0.0;
  Trans->I_E = 0.0;
  Trans->U_Basis = 0.0;
  Trans->U_C = 0.0;
  Trans->U_E = 0.0;
  Trans->r_BE = 0.0;
  Trans->r_CE = 0.0;								// Kleinsignalwiderst�nde (berechnet)
  Trans->r_Ein_AC = 0.0;
  Trans->r_Aus_AC = 0.0;
  Trans->V_U_AC = 0.0;
  Trans->V_U_DC = 0.0;		// Ein- und Ausgangswiderstand, Verst�rkungswerte (berechnet)
  Trans->A_N = 0, 0;			// Daten f�r Kennlinienfeld
  Trans->Delta_U_BE = 0.0;
  Trans->U_BE_max = 0.0;
  Trans->U_BE_min = 0.0;
  Trans->U_CE_Max = 0.0;
  Trans->I_ES = 0.0;
  Trans->I_CS = 0.0;
  Trans->Schaltung_berechenbar = false;

  return 0;
}	// end of Transistorwerte_auf_Null

int init_Emitterschaltung(Bipolartransistor *Trans)
// Initialisierung der Variablen f�r eine Emitterschaltung
// Funktion in Ordnung, M. Alles, 21.4.2016
{
  int i;

  // vorab alle Werte auf Null
  Transistorwerte_auf_Null(Trans);
  // R[0]: Basiswiderstand an U_B, R[1]: Basiswiderstand an GND, R[2]: Kollektorwiderstand, R[3]: Emitterwiderstand, R[4]: additiver Emitterwiderstand bei Emitterschaltung
  // C[0]: Koppelkondensator Eingang, C[1]: Koppelkondensator Ausgang, C[2]: Gegenkopplungskondensator f�r Emitterschaltung
  for (i = 0; i<5; i++)
	Trans->R[i] = 1000.0;
  for (i = 0; i<3; i++)
	Trans->C[i] = 1000.0e-6;
  Trans->R_Max = 5;
  Trans->C_Max = 3;
  Trans->U_B = 5.0;

  Trans->Beta = 200.0;		// Beta
  Trans->U_AF = 80.0;		// Early-Spannung
  Trans->U_BE = 0.6;		// Basis-Emitter-Spannung
  Trans->NPN = true;		// NPN-Transistor
  Trans->T = 300.0;		// Temperatur
  Trans->U_BE_min = 0.5;
  Trans->U_BE_max = 0.7;
  Trans->Delta_U_BE = 0.05;
  Trans->U_CE_Max = 10.0;
  Trans->neue_Schaltung = true;
  Trans->Naeherung_r_CE = false;
  Trans->Naeherung_U_T = true;				// true: Es wird U_T=26mV verwendet, false: U_T wird berechnet.
  return 0;
}	// end of init_Emitterschaltung

int init_Kollektorschaltung(Bipolartransistor *Trans)
// Initialisierung der globalen Variablen f�r die Kollektorschaltung
// Funktion i.O. 24.4.2016 M. Alles
{
  int i;

  // vorab alle Werte auf Null
  Transistorwerte_auf_Null(Trans);

  for (i = 0; i<3; i++)
	Kollektor_Schaltung.R[i] = 1000.0;
  Kollektor_Schaltung.R[3] = 0.0;	// nicht verwendete Widerst�nde m�ssen auf alle F�lle auf 0 gesetzt sein.
  Kollektor_Schaltung.R[4] = 0.0;
  for (i = 0; i<2; i++)
	Kollektor_Schaltung.C[i] = 1000.0e-6;
  Kollektor_Schaltung.C[2] = 0.0;	// nicht verwendete Kondensatoren m�ssen auf alle F�lle auf 0 gesetzt sein.
  Kollektor_Schaltung.R_Max = 3;
  Kollektor_Schaltung.C_Max = 2;
  Kollektor_Schaltung.U_B = 5.0;

  Kollektor_Schaltung.Beta = 200;		// Beta
  Kollektor_Schaltung.U_AF = 80;		// Early-Spannung
  Kollektor_Schaltung.U_BE = 0.6;		// Basis-Emitter-Spannung
  Kollektor_Schaltung.NPN = true;		// NPN-Transistor
  Kollektor_Schaltung.T = 300;		// Temperatur
  Kollektor_Schaltung.neue_Schaltung = true;
  Kollektor_Schaltung.Naeherung_r_CE = false;
  Kollektor_Schaltung.Naeherung_U_T = true;

  return 0;
}	// end of init_Kollektorschaltung

int init_Basisschaltung(Bipolartransistor *Trans)
// Initialisierung der globalen Variablen f�r die Basisschaltung
{
  int i;

  // vorab alle Werte auf Null
  Transistorwerte_auf_Null(Trans);

  for (i = 0; i<4; i++)
	Basis_Schaltung.R[i] = 1000.0;
  Basis_Schaltung.R[4] = 0.0;	// nicht verwendete Widerst�nde m�ssen auf alle F�lle auf 0 gesetzt sein. 
  for (i = 0; i<3; i++)
	Basis_Schaltung.C[i] = 1000.0e-6;
  Basis_Schaltung.R_Max = 4;
  Basis_Schaltung.C_Max = 2;
  Basis_Schaltung.U_B = 5.0;

  Basis_Schaltung.Beta = 200;
  Basis_Schaltung.U_AF = 80;
  Basis_Schaltung.U_BE = 0.6;
  Basis_Schaltung.NPN = true;
  Basis_Schaltung.T = 300;
  Basis_Schaltung.neue_Schaltung = true;
  Basis_Schaltung.Naeherung_r_CE = false;
  Basis_Schaltung.Naeherung_U_T = true;
  return 0;
}	//end of init_Basisschaltung



int init_Doppel_Emitterschaltung(Doppel_Bipolartransistor *Trans)
// Initialisierung der Variablen f�r eine doppelte Emitterschaltung
// Funktion in Ordnung, M. Alles, 20.02.2020
{
  int i;

  // Spannungen und Str�me auf Null setzen
  Trans->I_B_T1 = 0.0;
  Trans->I_B_T2 = 0.0;
  Trans->I_C_T1 = 0.0;
  Trans->I_C_T2 = 0.0;
  Trans->I_E_T1 = 0.0;
  Trans->I_E_T2 = 0.0;
  Trans->U_Basis_T1 = 0.0;
  Trans->U_Basis_T2 = 0.0;
  Trans->U_C_T1 = 0.0;
  Trans->U_C_T2 = 0.0;
  Trans->U_E_T1 = 0.0;
  Trans->U_E_T2 = 0.0;
  Trans->V_U_AC_T1 = 0.0;
  Trans->V_U_AC_T2 = 0.0;
  Trans->V_U_AC_Ges = 0.0;
  Trans->V_U_DC_T1 = 0.0;
  Trans->V_U_DC_T2 = 0.0;
  Trans->V_U_DC_Ges = 0.0;
  // R[0]: Basiswiderstand an U_B, R[1]: Basiswiderstand an GND, R[2]: Kollektorwiderstand, R[3]: Emitterwiderstand, R[4]: additiver Emitterwiderstand bei Emitterschaltung
  // C[0]: Koppelkondensator Eingang, C[1]: Koppelkondensator Ausgang, C[2]: Gegenkopplungskondensator f�r Emitterschaltung
  for (i = 0; i<8; i++)
	Trans->R[i] = 1000.0;
  for (i = 0; i<4; i++)
	Trans->C[i] = 1000.0e-6;
  Trans->R_Max = 8;
  Trans->C_Max = 4;
  Trans->U_B = 9.0;

  Trans->Beta_T1 = 200.0;	// Beta 1
  Trans->Beta_T2 = 200.0;	// Beta 2
  Trans->U_AF_T1 = 80.0;	// Early-Spannung 1
  Trans->U_AF_T2 = 80.0;	// Early-Spannung 2
  Trans->U_BE_T1 = 0.6;	// Basis-Emitter-Spannung 1
  Trans->U_BE_T2 = 0.6;	// Basis-Emitter-Spannung 2
  Trans->NPN_T1 = true;	// NPN-Transistor 1
  Trans->NPN_T2 = true;	// NPN-Transistor 2
  Trans->T = 300.0;		// Temperatur

  Trans->neue_Schaltung = true;
  Trans->Naeherung_r_CE = false;
  Trans->Naeherung_U_T = true;				// true: Es wird U_T=26mV verwendet, false: U_T wird berechnet.
  return 0;
}	// end of init_Doppel_Emitterschaltung

// Funktionen zur Berechnung der Emitterschaltung 
// April 2016, M. Alles

int Zeichne_Emitterschaltung(Bipolartransistor ES, HDC hdc, bool Kopie_Zwischenablage)
{
  UNREFERENCED_PARAMETER(Kopie_Zwischenablage);

  HPEN hStiftSchwarz2, hStiftAlt;
  HBRUSH hPinselSchwarz, hPinselAlt;
  HFONT FontNeu = NULL, FontAlt = NULL;
  char cText[100];

  SetTextColor(hdc, RGB(0, 0, 0));
  if (Kopie_Zwischenablage)
  {
	// Beschriftung erg�nzen am besten in Arial
	FontNeu = CreateFont(24, // nHeight
	  0,	// nWidth
	  0,	// nEscapement
	  0,	// nOrientation
	  FW_DONTCARE, //fnWeight
	  FALSE,	//fdwItalic
	  FALSE,	//fdwUnderline
	  FALSE,	//fdwStrikeOut
	  DEFAULT_CHARSET,	//fdwCharSet
	  OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
	  CLIP_DEFAULT_PRECIS, //fdwClipPrecision
	  CLEARTYPE_QUALITY,	//fdwQuality
	  VARIABLE_PITCH,		//fdwPitchAndFamily
	  TEXT("Arial"));	//lpszFace
	FontAlt = (HFONT)SelectObject(hdc, FontNeu);
	SetTextAlign(hdc, TA_LEFT);
  }

  if (Kopie_Zwischenablage)
  {	// Ausgabe Zwischenablage
	// Zeichnen der zugeh�rigen Texte R1-R3 und R5, C1, U_Ein und U_B
	SetTextAlign(hdc, TA_RIGHT);
	Zeichne_Text_xy(hdc, "R1", 180, 50);
	Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[R_BASIS_UB], 99);
	Zeichne_Text_xy(hdc, cText, 180, 75);
	Zeichne_Text_xy(hdc, "R2", 180, 325);
	Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[R_BASIS_GND], 99);
	Zeichne_Text_xy(hdc, cText, 180, 350);
	Zeichne_Text_xy(hdc, "R5", 280, 405);
	Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[4], 99);
	Zeichne_Text_xy(hdc, cText, 280, 430);
	// Text f�r C1
	Zeichne_Text_xy(hdc, "C1", 95, 225);
	Bestimme_Kapazitaetsbezeichner(cText, Emitter_Schaltung.C[C_EIN], 99);
	Zeichne_Text_xy(hdc, cText, 95, 200);
	// Text f�r U_B
	Zeichne_Text_xy(hdc, "U_B", 575, 50);
	Bestimme_Spannungsbezeichner(cText, Emitter_Schaltung.U_B, 99);
	Zeichne_Text_xy(hdc, cText, 575, 75);
	SetTextAlign(hdc, TA_LEFT);
	// Text f�r U_Ein
	Zeichne_Text_xy(hdc, "U_Ein", 50, 305);
  }
  else
  {	// Ausgabe Dialogbox
	// Zeichnen der zugeh�rigen Texte R1-R3 und R5
	Zeichne_Text_xy(hdc, "R1", 159, 50);
	Zeichne_Text_xy(hdc, "R2", 159, 320);
	Zeichne_Text_xy(hdc, "R3", 259, 35);
	Zeichne_Text_xy(hdc, "R5", 259, 400);
	// Text f�r C1
	Zeichne_Text_xy(hdc, "C1", 80, 230);
  }

  // Fenster neu zeichnen: Emitterschaltung mit Widerst�nden, Transistor und Spannungsquelle

  SetPolyFillMode(hdc, WINDING);

  hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);	// F�llfarbe vorher auf Schwarz
  // Zeichnen der Verbindungspunkte vorab
  Ellipse_BH(hdc, 195, 245, 10, 10);
  Ellipse_BH(hdc, 295, 5, 10, 10);
  // Wieder auf wei�en Hintergrund umschalten
  SelectObject(hdc, hPinselAlt);

  //Anschlusspunkte links und rechts zeichen, Positionen (Mitte): x: 45; 710; y:250; 400
  Zeichne_Anschluss(hdc, 35, 240, 150);
  // Leitung f�r Kondensator C_Ein Position: x: 55-100 und 120-250, y: 250
  ZP_Linie(hdc, 55, 250, 100, 250);
  ZP_Linie(hdc, 120, 250, 250, 250);
  // Eingangskondensator Position: x: 100, 120 y: 200-300
  Zeichne_Kondensator(hdc, 100, 200, 20, 100, C_HORIZONTAL);
  Zeichne_Gleichspannungsquelle(hdc, 590, 50, 60, true, 40);
  // Leitung f�r R1, R2 und U_B:
  VP_Linie(hdc, 200, 430, 200, 10, 620, 10, 620, 150);
  // Masse f�r R2
  ZP_Linie(hdc, 185, 430, 215, 430);
  //Widerst�nde R1, R2 Positionen: x=185, y=50, 320:
  Zeichne_Widerstand(hdc, 185, 50, 30, 60);
  Zeichne_Widerstand(hdc, 185, 320, 30, 60);
  // Leitung f�r R3 Postion: x: 300; y: 10-200
  ZP_Linie(hdc, 300, 10, 300, 200);
  // Leitung f�r R4, R5 Position: x: 300, y: 300-480
  ZP_Linie(hdc, 300, 300, 300, 480);
  // Masseanschluss f�r R5 Position: x: 285-315, y: 480
  ZP_Linie(hdc, 285, 480, 315, 480);
  if (ES.NPN)  //NPN-Transistor
  {
	// Zeichnen der Verbindungspunkte und des Transistors
	SelectObject(hdc, hPinselSchwarz);
	Zeichne_Bipolartransistor(hdc, 250, 200, 50, 100, Emitter_Schaltung.NPN, 0);
	// Verbindungspunkte
	Ellipse_BH(hdc, 295, 380, 10, 10);
	Ellipse_BH(hdc, 295, 195, 10, 10);
	// Wieder auf wei�e Fl�che zur�ck...
	SelectObject(hdc, hPinselAlt);

	if (Kopie_Zwischenablage)
	{ // Ausgabe Zwischenablage
	  // Beschriftung T1, U_Aus, R4, C2 und C3
	  Zeichne_Text_xy(hdc, "R3", 320, 35);
	  Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[2], 99);
	  Zeichne_Text_xy(hdc, cText, 320, 60);
	  Zeichne_Text_xy(hdc, "T1", 300, 240);
	  Zeichne_Text_xy(hdc, "U_Aus", 435, 255);
	  Zeichne_Text_xy(hdc, "R4", 320, 315);
	  Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[3], 99);
	  Zeichne_Text_xy(hdc, cText, 320, 340);
	  Zeichne_Text_xy(hdc, "C2", 375, 210);
	  Bestimme_Kapazitaetsbezeichner(cText, Emitter_Schaltung.C[C_AUS], 99);
	  Zeichne_Text_xy(hdc, cText, 375, 235);
	  Zeichne_Text_xy(hdc, "C3", 410, 380);
	  Bestimme_Kapazitaetsbezeichner(cText, Emitter_Schaltung.C[2], 99);
	  Zeichne_Text_xy(hdc, cText, 410, 402);
	}
	else
	{ // Ausgabe Dialogbox
	  // Beschriftung R4, C2 und C3
	  Zeichne_Text_xy(hdc, "R4", 259, 315);
	  Zeichne_Text_xy(hdc, "C2", 325, 210);
	  Zeichne_Text_xy(hdc, "C3", 410, 405);
	}

	// Widerstand R4 Position: x=285, y= 310
	Zeichne_Widerstand(hdc, 285, 310, 30, 60);
	// Leitung f�r Ausgangskondensator x: 300-350 und 370-420, y: 200
	ZP_Linie(hdc, 300, 200, 350, 200);
	ZP_Linie(hdc, 370, 200, 420, 200);
	// Ausgangskondensator zeichnen x: 350, 370, y: 150-250
	Zeichne_Kondensator(hdc, 350, 150, 20, 100, true);
	// Ausgangsanschluss mit Verbindungspunkt x: 420-440, y: 190-210 bzw. y: 340-360
	Zeichne_Anschluss(hdc, 420, 190, 150);
	// Leitung f�r C2 (parallel zu R5) Position: x: 300-400, y: 385-425
	DP_Linie(hdc, 300, 385, 400, 385, 400, 425);
	// Zweite Leitung f�r C2: x: 400, y: 445-480
	ZP_Linie(hdc, 400, 445, 400, 480);
	// Kondensator C2 zeichen (quer) x:350-450, y: 425, 445
	Zeichne_Kondensator(hdc, 350, 425, 100, 20, false);
	// Masseanschluss f�r C2 Position: x: 385-415, y: 480
	ZP_Linie(hdc, 385, 480, 415, 480);

  }
  else // PNP-Transistor zeichnen
  {
	// Zeichnen der Verbindungspunkte und des Transistors
	SelectObject(hdc, hPinselSchwarz);
	// Verbindungspunkte
	Ellipse_BH(hdc, 295, 100, 10, 10);
	// Verbindungspunkt
	Ellipse_BH(hdc, 295, 295, 10, 10);
	// Verbindungspunkt f�r C2 Position: x: 395-405, y: 5-15
	Ellipse_BH(hdc, 395, 5, 10, 10);
	Zeichne_Bipolartransistor(hdc, 250, 200, 50, 100, Emitter_Schaltung.NPN, 0);
	SelectObject(hdc, hPinselAlt);

	if (Kopie_Zwischenablage)
	{ // Ausgabe Zwischenablage
	  // Beschriftung T1, U_Aus, R4, C2 und C3
	  SetTextAlign(hdc, TA_RIGHT);
	  Zeichne_Text_xy(hdc, "R3", 280, 35);
	  Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[2], 99);
	  Zeichne_Text_xy(hdc, cText, 280, 60);
	  SetTextAlign(hdc, TA_LEFT);
	  Zeichne_Text_xy(hdc, "T1", 300, 240);
	  Zeichne_Text_xy(hdc, "U_Aus", 435, 355);
	  Zeichne_Text_xy(hdc, "R4", 320, 125);
	  Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[3], 99);
	  Zeichne_Text_xy(hdc, cText, 320, 150);
	  Zeichne_Text_xy(hdc, "C2", 380, 275);
	  Bestimme_Kapazitaetsbezeichner(cText, Emitter_Schaltung.C[C_AUS], 99);
	  Zeichne_Text_xy(hdc, cText, 375, 250);
	  Zeichne_Text_xy(hdc, "C3", 410, 70);
	  Bestimme_Kapazitaetsbezeichner(cText, Emitter_Schaltung.C[2], 99);
	  Zeichne_Text_xy(hdc, cText, 410, 95);
	}
	else
	{ // Ausgabe Dialogbox
	  // Beschriftung von R4, C2 und C3
	  Zeichne_Text_xy(hdc, "R4", 259, 125);
	  Zeichne_Text_xy(hdc, "C2", 325, 310);
	  Zeichne_Text_xy(hdc, "C3", 410, 25);
	}
	// Widerstand R4 Position: x=285, y= 120 : Verschiebung um ?190 in y?Richtung
	Zeichne_Widerstand(hdc, 285, 120, 30, 60);
	// Leitung f�r Ausgangskondensator x: 300-350 und 370-420, y: 300
	ZP_Linie(hdc, 300, 300, 350, 300);
	ZP_Linie(hdc, 370, 300, 420, 300);
	// Ausgangskondensator zeichnen x: 350, 370, y: 250-350
	Zeichne_Kondensator(hdc, 350, 250, 20, 100, true);
	// Ausgangsanschluss  x: 420-440, y: 290-310 bzw. y: 440-460
	Zeichne_Anschluss(hdc, 420, 290, 150);
	// Leitung f�r C2 (parallel zu R3) Position: x: 300-400, y: 10-105
	DP_Linie(hdc, 300, 105, 400, 105, 400, 65);
	// Zweite Leitung f�r C2: x: 400, y: 45-10
	ZP_Linie(hdc, 400, 45, 400, 10);
	// Kondensator C2 zeichen (quer) x:350-450, y: 65, 45
	Zeichne_Kondensator(hdc, 350, 45, 100, 20, false);
  }
  //Widerst�nde R3, R5 Positionen: x=285, y=30, 400
  Zeichne_Widerstand(hdc, 285, 30, 30, 60, 0);
  Zeichne_Widerstand(hdc, 285, 400, 30, 60, 0);

  if (Kopie_Zwischenablage)
  {
	SelectObject(hdc, FontAlt);
	DeleteObject(FontNeu);
  }

  SelectObject(hdc, hPinselAlt);
  DeleteObject(hPinselSchwarz);
  SelectObject(hdc, hStiftAlt);
  DeleteObject(hStiftSchwarz2);

  return 0;
} // end of Zeichne_Emitterschaltung

int Zeichne_ESB_Emitterschaltung(Bipolartransistor ES, HDC hdc, bool Kopie_Zwischenablage)
{
  UNREFERENCED_PARAMETER(Kopie_Zwischenablage);

  HPEN hStiftSchwarz2, hStiftAlt;
  HBRUSH hPinselSchwarz, hPinselAlt;
  HFONT FontNeu, FontAlt;

  SetBkColor(hdc, GetSysColor(COLOR_WINDOW));
  //SetPolyFillMode(hdc, WINDING);
  SetTextColor(hdc, RGB(0, 0, 0));
  hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);

  //Anschlusspunkte links und rechts, Positionen (Mitte): x: 100, 580; y: 100 - 260; 260 - 420
  Zeichne_Anschluss(hdc, 90, 90, 160);
  Zeichne_Anschluss(hdc, 750, 90, 160);
  // Leitung f�r R1 Position: x: 180, y: 100-260
  ZP_Linie(hdc, 180, 100, 180, 260);
  // Leitung f�r R2 Position: x: 260, y: 100-260
  ZP_Linie(hdc, 260, 100, 260, 260);
  // Leitung vom Eingang zum Widerstand r_BE Position: x: 110-340, y: 100; 100-260
  ZP_Linie(hdc, 110, 100, 340, 100);
  ZP_Linie(hdc, 340, 100, 340, 260);
  // Leitung weiter bis zum Widerstand r_CE Position x: 340-600, y: 260
  ZP_Linie(hdc, 340, 260, 600, 260);
  // Leitung f�r r_CE Position: x: 600, y: 100-260
  ZP_Linie(hdc, 600, 100, 600, 260);
  // Leitung weiter bis zum Ausgang Position: x: 420-750, y: 100
  ZP_Linie(hdc, 420, 100, 750, 100);
  // Leitung f�r R3 Position: x: 680, y: 100-260
  ZP_Linie(hdc, 680, 100, 680, 260);
  // Leitung f�r R4 Position: x: 420, y: 260-320, falls R3 oder R4 nicht gezeichnet wurde
  if (ES.R[3] != 0)
  {
	// Masse f�r R4 Position x: 405-435, y: 420
	ZP_Linie(hdc, 405, 420, 435, 420);
	// Leitung f�r R4 Position: x: 420, y: 260-420
	ZP_Linie(hdc, 420, 260, 420, 420);
  }
  else
  {
	// Masse f�r R4 Position x: 405-435, y: 320
	ZP_Linie(hdc, 420, 260, 420, 320);
	// Masse f�r R4 Position x: 405-435, y: 320
	ZP_Linie(hdc, 405, 320, 435, 320);
  }

  // Widerstand R1 Position: x: 160-200, y: 140-220
  Zeichne_Widerstand(hdc, 160, 140, 40, 80);
  // Widerstand R2 Position: x: 240-280, y: 140-220
  Zeichne_Widerstand(hdc, 240, 140, 40, 80);
  // Widerstand r_BE Position: x: 320-360, y: 140-220
  Zeichne_Widerstand(hdc, 320, 140, 40, 80);
  if (ES.R[3] != 0)
  {
	// Widerstand R4 Position: x: 400-440, y: 300-380
	Zeichne_Widerstand(hdc, 400, 300, 40, 80);
  }
  // Widerstand r_CE Position: x: 580-620, y: 140-220
  Zeichne_Widerstand(hdc, 580, 140, 40, 80);
  // Widerstand R3 Position: x: 660-700, y: 140-220
  Zeichne_Widerstand(hdc, 660, 140, 40, 80);

  // Masseanschl�sse
  // Masse f�r R1 Position x: 165-195, y: 260
  ZP_Linie(hdc, 165, 260, 195, 260);
  // Masse f�r R2 Position x: 245-275, y: 260
  ZP_Linie(hdc, 245, 260, 275, 260);

  // Masse f�r R3 Position x: 665-695, y: 260
  ZP_Linie(hdc, 665, 260, 695, 260);
  // Zeichnen der Stromquelle Position x: 420, y: 100-260
  ZP_Linie(hdc, 420, 100, 420, 260);
  Ellipse_BH(hdc, 390, 150, 60, 60);
  ZP_Linie(hdc, 390, 180, 450, 180);
  // Beschriftung erg�nzen
  // am besten in Arial
  FontNeu = CreateFont(24, // nHeight
	0,	// nWidth
	0,	// nEscapement
	0,	// nOrientation
	FW_DONTCARE, //fnWeight
	TRUE,	//fdwItalic
	FALSE,	//fdwUnderline
	FALSE,	//fdwStrikeOut
	DEFAULT_CHARSET,	//fdwCharSet
	OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
	CLIP_DEFAULT_PRECIS, //fdwClipPrecision
	CLEARTYPE_QUALITY,	//fdwQuality
	VARIABLE_PITCH,		//fdwPitchAndFamily
	TEXT("Arial"));	//lpszFace
  FontAlt = (HFONT)SelectObject(hdc, FontNeu);
  Zeichne_Text_xy(hdc, "R", 205, 170);
  Zeichne_Text_xy(hdc, "R", 285, 170);
  Zeichne_Text_xy(hdc, "R", 705, 170);
  if ((Emitter_Schaltung.NPN&&Emitter_Schaltung.R[3] != 0) || (!Emitter_Schaltung.NPN&&Emitter_Schaltung.R[2] != 0))
	Zeichne_Text_xy(hdc, "R", 445, 330);
  Zeichne_Text_xy(hdc, "r", 345, 220);
  Zeichne_Text_xy(hdc, "r", 605, 220);
  Zeichne_Text_xy(hdc, "u", 105, 170);
  Zeichne_Text_xy(hdc, "u", 765, 170);
  Zeichne_Text_xy(hdc, "i", 290, 60);
  Zeichne_Text_xy(hdc, "i", 491, 170);
  DeleteObject(FontNeu);
  // auf Symbolschriftart
  FontNeu = CreateFont(24, 0, 0, 0, FW_DONTCARE, TRUE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Symbol"));
  SelectObject(hdc, FontNeu);
  Zeichne_Text_xy(hdc, "b", 470, 166);
  DeleteObject(FontNeu);
  FontNeu = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Arial"));
  SelectObject(hdc, FontNeu);
  // Beschriftung f�r r_BE
  Zeichne_Text_xy(hdc, "1", 219, 180);
  Zeichne_Text_xy(hdc, "2", 299, 180);
  Zeichne_Text_xy(hdc, "BE", 355, 230);
  Zeichne_Text_xy(hdc, "CE", 615, 230);
  Zeichne_Text_xy(hdc, "Ein", 119, 180);
  Zeichne_Text_xy(hdc, "Aus", 779, 180);
  Zeichne_Text_xy(hdc, "B", 300, 70);

  Zeichne_Text_xy(hdc, "*", 485, 170);
  Zeichne_Text_xy(hdc, "B", 505, 176);
  if (ES.NPN) // NPN-Schaltung
  {
	// Pfeil f�r i_B x: 275-285, y: 90-110
	DP_Linie(hdc, 295, 90, 305, 100, 295, 110);
	// Pfeil f�r Stromquelle Position x: 460, y: 140-220
	ZP_Linie(hdc, 460, 140, 460, 220);
	DP_Linie(hdc, 450, 210, 460, 220, 470, 210);
	// Beschriftung f�r R3 und R4 vervollst�ndigen
	Zeichne_Text_xy(hdc, "3", 719, 180);
	if (Emitter_Schaltung.R[3] != 0)
	  Zeichne_Text_xy(hdc, "4", 459, 340);
	// Unterschrift
	Zeichne_Text_xy(hdc, "NPN-Emitterschaltung: Kleinsignal-Ersatzschaltbild", 130, 430);
  }
  else
  {	// PNP-Schaltung
	// Pfeil f�r i_B x: 275-285, y: 90-110 //umgekehrt zur NPN?Schaltung
	DP_Linie(hdc, 305, 90, 295, 100, 305, 110);
	// Pfeil f�r Stromquelle Position x: 460, y: 140-220 // umgekehrt zur NPNSchaltung
	ZP_Linie(hdc, 460, 140, 460, 220);
	DP_Linie(hdc, 450, 150, 460, 140, 470, 150);
	// Beschriftung f�r R3 und R4 vervollst�ndigen
	Zeichne_Text_xy(hdc, "5", 719, 180);
	if (Emitter_Schaltung.R[3] != 0)
	  Zeichne_Text_xy(hdc, "4", 459, 340);
	// Unterschrift
	Zeichne_Text_xy(hdc, "PNP-Emitterschaltung: Kleinsignal-Ersatzschaltbild", 130, 430);
  }
  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

  // Verbindungspunkte: Positionen: 180, 100; 260, 100; 420, 260; 600, 100; 680, 100
  Ellipse_BH(hdc, 175, 95, 10, 10);
  Ellipse_BH(hdc, 255, 95, 10, 10);
  Ellipse_BH(hdc, 415, 255, 10, 10);
  Ellipse_BH(hdc, 595, 95, 10, 10);
  Ellipse_BH(hdc, 675, 95, 10, 10);

  SelectObject(hdc, FontAlt);
  DeleteObject(FontNeu);
  SelectObject(hdc, hPinselAlt);
  DeleteObject(hPinselSchwarz);
  SelectObject(hdc, hStiftAlt);
  DeleteObject(hStiftSchwarz2);

  return 0;
} // Zeichne_ESB_Emitterschaltung

int Emitterschaltung_Aufruf(HWND hWnd)
{
  DialogBox(hInst, MAKEINTRESOURCE(IDD_EMITTERSCHALTUNG), hWnd, EmitterSchaltung_Dialog);
  return 0;
}	// end of Emitterschaltung
int Berechne_Emitterschaltung(void)
{
  // DC Ein- und Ausgangswiderstand ist generell unendlich und muss nicht gespeichert werden.

  // Generell ist die Schaltung ersteinmal berechenbar:
  Emitter_Schaltung.Schaltung_berechenbar = true;
  // Berechnung NPN-Transistor
  if (Emitter_Schaltung.NPN) //NPN-Typ
  {
	// Basisstrom f�r NPN-Transistor berechnen
	Emitter_Schaltung.I_B = Basisstrom_NPN(Emitter_Schaltung.R[R_BASIS_UB], Emitter_Schaltung.R[R_BASIS_GND], Emitter_Schaltung.R[R_EMITTER_DC_ES], Emitter_Schaltung.R[R_EMITTER_AC_ES_NPN],
	  Emitter_Schaltung.U_BE, Emitter_Schaltung.U_B, Emitter_Schaltung.Beta);
	if (Emitter_Schaltung.I_B < 0)
	{
	  // Falls der Basisstrom negativ ist, sind auch Kollektor? und Emitterstrom nicht bestimmbar.Das Gleiche gilt f�r die Spannungen...
	  Emitter_Schaltung.Schaltung_berechenbar = false;
	}
	else
	{
	  // Kollektorstrom berechnen
	  Emitter_Schaltung.I_C = Emitter_Schaltung.Beta * Emitter_Schaltung.I_B;
	  // Emitterstrom berechnen
	  Emitter_Schaltung.I_E = (Emitter_Schaltung.Beta + 1.0) * Emitter_Schaltung.I_B;
	  // Kollektorspannung
	  Emitter_Schaltung.U_C = Emitter_Schaltung.U_B - Emitter_Schaltung.I_C * Emitter_Schaltung.R[R_KOLLEKTOR_ES_NPN];
	  // Emitterspannung NPN
	  Emitter_Schaltung.U_E = Emitter_Schaltung.I_E * (Emitter_Schaltung.R[R_EMITTER_DC_ES] + Emitter_Schaltung.R[R_EMITTER_AC_ES_NPN]);
	  // Kontrolle: Kollektorspannung muss h�her als Emitterspannung sein, falls nicht, stimmt die L�sung nicht
	  if (Emitter_Schaltung.U_E > Emitter_Schaltung.U_C)
		Emitter_Schaltung.Schaltung_berechenbar = false;
	  // Basisspannung NPN
	  Emitter_Schaltung.U_Basis = Emitter_Schaltung.U_E + Emitter_Schaltung.U_BE;
	  // Kleinsignalwiderst�nde
	  Emitter_Schaltung.r_BE = r_BE(Emitter_Schaltung.I_B, U_T(Emitter_Schaltung.T, Emitter_Schaltung.Naeherung_U_T));
	  Emitter_Schaltung.r_CE = r_CE(Emitter_Schaltung.U_C - Emitter_Schaltung.U_E, Emitter_Schaltung.U_AF, Emitter_Schaltung.I_C);
	  // DC-Verst�rkung
	  Emitter_Schaltung.V_U_DC = V_U_DC_E(Emitter_Schaltung.R[R_KOLLEKTOR_ES_NPN], Emitter_Schaltung.R[R_EMITTER_DC_ES], Emitter_Schaltung.R[R_EMITTER_AC_ES_NPN], Emitter_Schaltung.r_BE, Emitter_Schaltung.r_CE, Emitter_Schaltung.Beta, Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Verst�rkung
	  Emitter_Schaltung.V_U_AC = V_U_AC_E(Emitter_Schaltung.R[R_KOLLEKTOR_ES_NPN], Emitter_Schaltung.R[R_EMITTER_DC_ES], Emitter_Schaltung.R[R_EMITTER_AC_ES_NPN], Emitter_Schaltung.r_BE, Emitter_Schaltung.r_CE, Emitter_Schaltung.Beta, Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Ausgangswiderstand
	  Emitter_Schaltung.r_Aus_AC = AC_Ausgangswiderstand_E(Emitter_Schaltung.R[R_KOLLEKTOR_ES_NPN], Emitter_Schaltung.R[R_EMITTER_DC_ES], Emitter_Schaltung.r_CE, Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Eingangswiderstand
	  Emitter_Schaltung.r_Ein_AC = AC_Eingangswiderstand_E(Emitter_Schaltung.R[R_BASIS_UB], Emitter_Schaltung.R[R_BASIS_GND], Emitter_Schaltung.R[R_EMITTER_DC_ES], Emitter_Schaltung.R[R_KOLLEKTOR_ES_NPN], Emitter_Schaltung.r_BE, Emitter_Schaltung.r_CE, Emitter_Schaltung.Beta, Emitter_Schaltung.Naeherung_r_CE);
	}
  }
  if (!Emitter_Schaltung.NPN)	// Berechnung f�r PNP-Transistor
  {
	// Basisstrom f�r PNP-Transistor berechnen
	Emitter_Schaltung.I_B = Basisstrom_PNP(Emitter_Schaltung.R[R_BASIS_UB], Emitter_Schaltung.R[R_BASIS_GND], Emitter_Schaltung.R[R_EMITTER_DC_ES], Emitter_Schaltung.R[R_EMITTER_AC_ES_PNP], Emitter_Schaltung.U_BE, Emitter_Schaltung.U_B, Emitter_Schaltung.Beta);
	if (Emitter_Schaltung.I_B < 0)
	{
	  // Basisstrom negativ, also nicht berechenbar.
	  Emitter_Schaltung.Schaltung_berechenbar = false;
	}
	else
	{
	  // Kollektorstrom
	  Emitter_Schaltung.I_C = Emitter_Schaltung.I_B * Emitter_Schaltung.Beta;
	  // Emitterstrom
	  Emitter_Schaltung.I_E = Emitter_Schaltung.I_B * (Emitter_Schaltung.Beta + 1.0);
	  // Kollektorspannung PNP
	  Emitter_Schaltung.U_C = Emitter_Schaltung.I_C * Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP];
	  // Emitterspannung PNP
	  Emitter_Schaltung.U_E = Emitter_Schaltung.U_B - Emitter_Schaltung.I_E * (Emitter_Schaltung.R[R_EMITTER_AC_ES_PNP] + Emitter_Schaltung.R[R_EMITTER_DC_ES]);
	  // Kontrolle: Hier muss die Kollektorspannung niedriger als die Emitterspannung sein, falls nicht, liegt ein Fehler vor
	  if (Emitter_Schaltung.U_E < Emitter_Schaltung.U_C)
		Emitter_Schaltung.Schaltung_berechenbar = false;
	  // Basisspannung
	  Emitter_Schaltung.U_Basis = Emitter_Schaltung.U_E - Emitter_Schaltung.U_BE;
	  // Kleinsignalwiderst�nde berechnen
	  Emitter_Schaltung.r_BE = r_BE(Emitter_Schaltung.I_B, U_T(Emitter_Schaltung.T, Emitter_Schaltung.Naeherung_U_T));
	  Emitter_Schaltung.r_CE = r_CE(Emitter_Schaltung.U_E - Emitter_Schaltung.U_C, Emitter_Schaltung.U_AF, Emitter_Schaltung.I_C);
	  // DC-Verst�rkung berechnen
	  Emitter_Schaltung.V_U_DC = V_U_DC_E(Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP], Emitter_Schaltung.R[R_EMITTER_DC_ES], Emitter_Schaltung.R[R_EMITTER_AC_ES_PNP], Emitter_Schaltung.r_BE, Emitter_Schaltung.r_CE, Emitter_Schaltung.Beta, Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Verst�rkung
	  Emitter_Schaltung.V_U_AC = V_U_AC_E(Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP], Emitter_Schaltung.R[R_EMITTER_DC_ES], Emitter_Schaltung.R[R_EMITTER_AC_ES_PNP], Emitter_Schaltung.r_BE, Emitter_Schaltung.r_CE, Emitter_Schaltung.Beta, Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Eingangswiderstand
	  Emitter_Schaltung.r_Ein_AC = AC_Eingangswiderstand_E(Emitter_Schaltung.R[R_BASIS_UB], Emitter_Schaltung.R[R_BASIS_GND], Emitter_Schaltung.R[R_EMITTER_DC_ES], Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP], Emitter_Schaltung.r_BE, Emitter_Schaltung.r_CE, Emitter_Schaltung.Beta, Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Ausgangswiderstand
	  Emitter_Schaltung.r_Aus_AC = AC_Ausgangswiderstand_E(Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP], Emitter_Schaltung.R[R_EMITTER_AC_ES_PNP], Emitter_Schaltung.r_CE, Emitter_Schaltung.Naeherung_r_CE);
	}
  }
  if (Emitter_Schaltung.I_B<0.0)
	Emitter_Schaltung.Schaltung_berechenbar=false;
  return 0;
}	// end of Berechne_Emitterschaltung

int Zeichne_Ausgabe_Emitterschaltung(Bipolartransistor ES, HDC hdc, bool Kopie_Zwischenablage)
{
  UNREFERENCED_PARAMETER(Kopie_Zwischenablage);

  HPEN hStiftSchwarz2, hStiftAlt;
  HBRUSH hPinselSchwarz, hPinselAlt;
  HFONT hFontAlt, hFont;
  int zeilennummer = 2, tabulator[5];
  char cText[100], cAusgabe[255], cWert1[100], cWert2[100];

  hFont = Erstelle_Font_Arial(hdc, 20);
  hFontAlt = (HFONT)SelectObject(hdc, hFont);
  tabulator[0] = 200;
  tabulator[1] = 300;
  tabulator[2] = 500;
  tabulator[3] = 600;

  SetPolyFillMode(hdc, WINDING);

  hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

  // passenden Transistor zeichnen
  Zeichne_Bipolartransistor(hdc, 600, 50, 50, 100, ES.NPN, 20);
  // Ausgabe der Ergebnisse
  // Ausgabe der Ergebnisse.
  if (ES.Schaltung_berechenbar)
	TabbedTextOut(hdc, 10, 20, (LPCSTR)"\tBerechnung der Emitterschaltung:", 33, 4, tabulator, 10);
  else
	TabbedTextOut(hdc, 10, 20, (LPCSTR)"\tBerechnung der Emitterschaltung fehlerhaft!", 45, 4, tabulator, 10);
  // N�chste Zeile, also eine Art �berschrift
  if (ES.NPN)
	sprintf_s(cAusgabe, 255, "NPN\tDC\tAC");
  else
	sprintf_s(cAusgabe, 255, "PNP\tDC\tAC");
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);

  // Ausgabe der Eingangswiderst�nde
  zeilennummer++;
  Bestimme_Widerstandsbezeichner(cWert1, ES.r_Ein_AC, 99);
  sprintf_s(cAusgabe, 255, "Eingangswiderstand:\tunendlich\t");
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  Bestimme_Widerstandsbezeichner( cWert1, ES.r_Aus_AC, 99);
  // printf mit Argument "%s" funktioniert nicht. Am besten eigene Funktion, die zwei Strings einf�gen kann.
  sprintf_s( cAusgabe, 255, "Ausgangswiderstand:\tunendlich\t");
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // Ausgabe der Verst�rkung
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Verst�rkung:\t");
  sprintf_s(cText, 100, "*\t");
  Bestimme_Bezeichner(cWert1, ES.V_U_DC, 99);
  Bestimme_Bezeichner(cWert2, ES.V_U_AC, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "\t(* ohne C1, C2)");
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // Jetzt Str�me und Spannungen, vorher eine weitere Leerzeile. 
  zeilennummer += 3;
  sprintf_s(cAusgabe, 255, "Basisstrom I_B:\t");
  sprintf_s(cText, 100, "\tBasisspannung U_Basis:\t");
  Bestimme_Strombezeichner(cWert1, ES.I_B, 99);
  Bestimme_Spannungsbezeichner(cWert2, ES.U_Basis, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Kollektorstrom I_C:\t");
  sprintf_s(cText, 100, "\tKollektorspannung U_C:\t");
  Bestimme_Strombezeichner(cWert1, ES.I_C, 99);
  Bestimme_Spannungsbezeichner(cWert2, ES.U_C, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Emitterstrom I_E:\t");
  sprintf_s(cText, 100, "\tEmitterspannung U_E:\t");
  Bestimme_Strombezeichner(cWert1, ES.I_E, 99);
  Bestimme_Spannungsbezeichner(cWert2, ES.U_E, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // die weiteren Werte nach einer Leerzeile ausgeben
  zeilennummer += 2;
  sprintf_s(cAusgabe, 255, "KS-Widerstand r_BE:\t");
  Bestimme_Widerstandsbezeichner(cWert1, ES.r_BE, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "KS-Widerstand r_CE:\t");
  Bestimme_Widerstandsbezeichner(cWert1, ES.r_CE, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);

  SelectObject(hdc, hPinselAlt);
  DeleteObject(hPinselSchwarz);
  SelectObject(hdc, hStiftAlt);
  DeleteObject(hStiftSchwarz2);
  SelectObject(hdc, hFontAlt);
  DeleteObject(hFont);

  return 0;
}

int Ergebnis_Emitterschaltung(HWND hDlg)
{
  // Berechnung der Emitterschaltung
  Berechne_Emitterschaltung();
  DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_BIPOLARSCHALTUNG), hDlg, ErgebnisEmitterSchaltung_Dialog);

  return 0;
}	// end of Ergebnis_Emitterschaltung

int ESB_Emitterschaltung(HWND hDlg)
{
  DialogBox(hInst, MAKEINTRESOURCE(IDD_ESB_BIPOLARSCHALTUNG), hDlg, ESB_EmitterSchaltung_Dialog);

  return 0;
}	// end of ESB_Emitterschaltung

int Kopiere_Emitterschaltung(Bipolartransistor ES)
{
  HDC hdcMeta;
  HENHMETAFILE hMeta;

  hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
  // Emitterschaltung zeichnen
  Zeichne_Emitterschaltung(ES, hdcMeta, true);
  hMeta = CloseEnhMetaFile(hdcMeta);
  // Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
  OpenClipboard(hWndElektronikMain);
  EmptyClipboard();
  SetClipboardData(CF_ENHMETAFILE, hMeta);
  CloseClipboard();

  return 0;
} // end of Kopiere_Emitterschaltung

int Kopiere_ESB_Emitterschaltung(Bipolartransistor ES)
{
  HDC hdcMeta;
  HENHMETAFILE hMeta;

  hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
  // ESB-Emitterschaltung zeichnen
  Zeichne_ESB_Emitterschaltung(ES, hdcMeta, true);
  hMeta = CloseEnhMetaFile(hdcMeta);
  // Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
  OpenClipboard(hWndElektronikMain);
  EmptyClipboard();
  SetClipboardData(CF_ENHMETAFILE, hMeta);
  CloseClipboard();

  return 0;
} // end of Kopiere_ESB_Emitterschaltung

double AC_Eingangswiderstand_E(double R_Basis1, double R_Basis2, double R_Emitter, double R_Kollektor, double r_BE, double r_CE, double beta, bool N�herung_r_CE)
{
  // Berechnung des Kleinsignal-Eingangswiderstandes f�r eine unendliche hohe Frequenz
  // Eingabeparameter: Widerstandswerte des Basisspannungsteilers R1 und R2,
  // Basisstrom IB, Emitterwiderstand, Stromverst�rkung und Temperaturspannung

  double ergebnis, hilfs_widerstand;

  if (N�herung_r_CE)
  {
	ergebnis = 1.0 / R_Basis1 + 1.0 / R_Basis2;
	hilfs_widerstand = r_BE + (beta + 1)*R_Emitter;
	ergebnis += 1.0 / hilfs_widerstand;	// Hier sind jetzt die drei Leitwerte addiert
	ergebnis = 1.0 / ergebnis;			// Kehrwert...
  }
  else
  {
	ergebnis = 1.0 / R_Basis1 + 1.0 / R_Basis2;
	hilfs_widerstand = r_BE + (beta + 1)*Parallelschaltung(R_Emitter, r_CE + R_Kollektor);
	ergebnis += 1.0 / hilfs_widerstand;	// Hier sind jetzt die drei Leitwerte addiert
	ergebnis = 1.0 / ergebnis;			// Kehrwert...
  }

  return ergebnis;
} // end of AC_Eingangswiderstand_E

double AC_Ausgangswiderstand_E(double R_Kollektor, double R_Emitter, double r_CE, bool N�herung_r_CE)
{
  // Berechnung des NF-Eingangswiderstands bei der Frequenz f mit Ber�cksichtigung der Impedanz der Eingangskapazit�t
  // Funktion in Ordnung, M. Alles, 21.4.2016

  double ergebnis;

  if (N�herung_r_CE)
	ergebnis = R_Kollektor;
  else
  {
	ergebnis = 1.0 / R_Kollektor + 1.0 / (r_CE + R_Emitter);  // mit Parallelschaltung R3||(r_CE+R4)
	ergebnis = 1.0 / ergebnis;
  }

  return ergebnis;
} // end of AC_Ausgangswiderstand_E

double V_U_DC_E(double R_Kollektor, double R_Emitter_DC, double R_Emitter_AC, double r_BE, double r_CE, double Beta, bool r_CE_hochohmig)
{
  //Berechnung der DC-Verst�rkung
  //Fallunterscheidung: Falls R4+R5=0 ist die DC-Verst�rkung gleich der AC-Verst�rkung...
  // Funktion in Ordnung, M. Alles, 21.4.2016
  // Funktion war fehlerhaft, da r_CE nicht ber�cksichtigt wurde.
  // �nderung 22.2.2020, k�nnte jetzt stimmen
  double ergebnis;

  if ((R_Emitter_DC + R_Emitter_AC) == 0)
	ergebnis = V_U_AC_E(R_Kollektor, R_Emitter_DC, R_Emitter_AC, r_BE, r_CE, Beta, r_CE_hochohmig);
  else
  {
	if (r_CE_hochohmig)
	  ergebnis = -R_Kollektor / (R_Emitter_DC + R_Emitter_AC);
	else
	  ergebnis = (R_Kollektor*(R_Emitter_DC+R_Emitter_AC) - R_Kollektor*r_CE*Beta) / (r_BE*(R_Kollektor + (R_Emitter_DC+R_Emitter_AC) + r_CE) + (R_Emitter_DC+R_Emitter_AC)*(R_Kollektor + (Beta + 1.0)*r_CE));
  }

  return ergebnis;
} // end of V_U_DC_E

double V_U_AC_E(double R_Kollektor, double R_Emitter_DC, double R_Emitter_AC, double r_BE, double r_CE, double beta, bool r_CE_hochohmig)
{
  //Berechnung der AC-Verst�rkung
  //Fallunterscheidung: Falls R4!=0 ist, kann die AC-Verst�rkung �ber die Widerst�nde bestimmt werden
  // Funktion in Ordnung, M. Alles, 21.4.2016
  // �nderung am 9.5.2016
  // �nderung am 20.2.2020 - Funktion war fehlerhaft, Vergleich nach r_CE hochohmig war falsch, k�nnte jetzt stimmen
  double ergebnis;

  if (r_CE_hochohmig)
  {
	// N�herung: r_CE ist hochohmig und wird vernachl�ssigt. 
	if (R_Emitter_AC == 0.0)
	{
	  // R_Emitter besteht nur aus einem Widerstand ohne parallelgeschaltete Kapazit�t
	  ergebnis = -R_Kollektor / (R_Emitter_DC + R_Emitter_AC);
	  // alte Formel (woher?)
	  // ergebnis = -(beta*R_Kollektor) / (r_BE + beta*(R_Emitter_DC+R_Emitter_AC) );
	}
	else
	  ergebnis = -beta*R_Kollektor / r_BE; // -�*R_C/r_BE; Hier k�nnte noch die Parallelschaltung mit r_CE erg�nzt werden
  }
  else
  {
	// r_CE wird nicht vernachl�ssigt
	if (R_Emitter_AC == 0.0)
	{
	  ergebnis = (R_Kollektor*(R_Emitter_DC) - R_Kollektor*r_CE*beta) / (r_BE*(R_Kollektor + (R_Emitter_DC) + r_CE) + (R_Emitter_DC)*(R_Kollektor + (beta + 1.0)*r_CE));
	}
	else
	  ergebnis = -(beta*Parallelschaltung(R_Kollektor, r_CE)) / r_BE;
  }

  return ergebnis;
} // end of V_U_AC_E

int Doppel_Emitterschaltung_Aufruf(HWND hWnd)
{
  DialogBox(hInst, MAKEINTRESOURCE(IDD_DOPPELEMITTERSCHALTUNG), hWnd, DoppelEmitterSchaltung_Dialog);
  return 0;
}	// end of DoppelEmitterschaltung

int Zeichne_DoppelEmitterschaltung(Doppel_Bipolartransistor D_ES, HDC hdc, bool Kopie_Zwischenablage)
{
  UNREFERENCED_PARAMETER(Kopie_Zwischenablage);

  HPEN hStiftSchwarz2, hStiftAlt;
  HBRUSH hPinselSchwarz, hPinselAlt;
  HFONT FontNeu = NULL, FontAlt = NULL;
  char cText[100];

  SetTextColor(hdc, RGB(0, 0, 0));
  if (Kopie_Zwischenablage)
  {
	// Beschriftung erg�nzen am besten in Arial
	FontNeu = CreateFont(24, // nHeight
	  0,	// nWidth
	  0,	// nEscapement
	  0,	// nOrientation
	  FW_DONTCARE, //fnWeight
	  FALSE,	//fdwItalic
	  FALSE,	//fdwUnderline
	  FALSE,	//fdwStrikeOut
	  DEFAULT_CHARSET,	//fdwCharSet
	  OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
	  CLIP_DEFAULT_PRECIS, //fdwClipPrecision
	  CLEARTYPE_QUALITY,	//fdwQuality
	  VARIABLE_PITCH,		//fdwPitchAndFamily
	  TEXT("Arial"));	//lpszFace
	FontAlt = (HFONT)SelectObject(hdc, FontNeu);
	SetTextAlign(hdc, TA_LEFT);
  }

  if (Kopie_Zwischenablage)
  {	// Ausgabe Zwischenablage

	SetTextAlign(hdc, TA_RIGHT);
	Zeichne_Text_xy(hdc, "R1", 125, 50);
	Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[R_BASIS_UB], 99);
	Zeichne_Text_xy(hdc, cText, 125, 75);
	Zeichne_Text_xy(hdc, "R2", 125, 380);
	Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[R_BASIS_GND], 99);
	Zeichne_Text_xy(hdc, cText, 125, 405);
	Zeichne_Text_xy(hdc, "R5", 225, 415);
	Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[4], 99);
	Zeichne_Text_xy(hdc, cText, 225, 440);
	Zeichne_Text_xy(hdc, "R6", 430, 65);
	Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[5], 99);
	Zeichne_Text_xy(hdc, cText, 430, 90);
	Zeichne_Text_xy(hdc, "R8", 430, 400);
	Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[7], 99);
	Zeichne_Text_xy(hdc, cText, 430, 425);

	// Text f�r U_B
	Zeichne_Text_xy(hdc, "U_B", 720, 100);
	Bestimme_Spannungsbezeichner(cText, Doppel_Emitter_Schaltung.U_B, 99);
	Zeichne_Text_xy(hdc, cText, 720, 125);
	Zeichne_Text_xy(hdc, "R3", 230, 90);
	Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[2], 99);
	Zeichne_Text_xy(hdc, cText, 230, 115);

	if (D_ES.NPN_T1) // erster Transistor ist NPN-Transistor, also etwas weiter oben anfangen, damit Platz f�r zwei Emitterwiderst�nde ist
	{
	  	SetTextAlign(hdc, TA_LEFT);
	  // Text f�r U_Ein
	  Zeichne_Text_xy(hdc, "U_Ein", 50, 260);
	  // Text f�r T1
	  Zeichne_Text_xy(hdc, "T1", 250, 190 );
	  // Text f�r C2
	  Zeichne_Text_xy(hdc, "C2", 320, 440);
	  Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[1], 99);
	  Zeichne_Text_xy(hdc, cText, 320, 465);
	  SetTextAlign( hdc, TA_RIGHT );
	  // Text f�r C1
	  Zeichne_Text_xy(hdc, "C1", 95, 150);
	  Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[C_EIN], 99);
	  Zeichne_Text_xy(hdc, cText, 95, 175);
	  // Text und Wert f�r R4
	  Zeichne_Text_xy(hdc, "R4", 225, 255);
	  Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[3], 99);
	  Zeichne_Text_xy(hdc, cText, 225, 280);
	}
	else
	{
	  SetTextAlign(hdc, TA_LEFT);
	  // Text f�r U_Ein
	  Zeichne_Text_xy(hdc, "U_Ein", 50, 360);
	  // Text f�r T1
	  Zeichne_Text_xy(hdc, "T1", 250, 290 );
	  // Text f�r C2
	  Zeichne_Text_xy(hdc, "C2", 320, 10);
	  Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[1], 99);
	  Zeichne_Text_xy(hdc, cText, 320, 35);
	  SetTextAlign( hdc, TA_RIGHT );
	  // Text f�r C1
	  Zeichne_Text_xy(hdc, "C1", 95, 250);
	  Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[C_EIN], 99);
	  Zeichne_Text_xy(hdc, cText, 95, 275);
	  // Text und Wert f�r R4
	  Zeichne_Text_xy(hdc, "R4", 225, 160);
	  Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[3], 99);
	  Zeichne_Text_xy(hdc, cText, 225, 185);
	}
	SetTextAlign( hdc, TA_LEFT );
	if (D_ES.NPN_T2) // zweiter Transistor ist NPN-Transistor, also etwas weiter oben anfangen, damit Platz f�r zwei Emitterwiderst�nde ist
	{
 	  // Text f�r U_Aus
	  Zeichne_Text_xy(hdc, "U_Aus", 630, 210); 
	  // Text f�r C3
	  Zeichne_Text_xy(hdc, "C3", 530, 450);
	  Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[2], 99);
	  Zeichne_Text_xy(hdc, cText, 530, 475);
	  // Text f�r C4
	  Zeichne_Text_xy(hdc, "C4", 550, 160);
	  Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[3], 99);
	  Zeichne_Text_xy(hdc, cText, 550, 185);
	  SetTextAlign( hdc, TA_RIGHT );
	  // Text und Wert f�r R4
	  Zeichne_Text_xy(hdc, "R7", 430, 315);
	  Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[6], 99);
	  Zeichne_Text_xy(hdc, cText, 430, 340);
	  // Text f�r T2
	  Zeichne_Text_xy(hdc, "T2", 450, 190 );
	}
	else
	{
	  // Text f�r U_Aus
	  Zeichne_Text_xy(hdc, "U_Aus", 630, 390); 
	  // Text f�r C3
	  Zeichne_Text_xy(hdc, "C3", 550, 375);
	  Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[2], 99);
	  Zeichne_Text_xy(hdc, cText, 550, 400);
	  // Text f�r C4
	  Zeichne_Text_xy(hdc, "C4", 520, 100);
	  Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[3], 99);
	  Zeichne_Text_xy(hdc, cText, 520, 125);
	  SetTextAlign( hdc, TA_RIGHT );
	  // Text und Wert f�r R4
	  Zeichne_Text_xy(hdc, "R7", 430, 160);
	  Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[6], 99);
	  Zeichne_Text_xy(hdc, cText, 430, 185);
	  // Text f�r T2
	  Zeichne_Text_xy(hdc, "T2", 450, 290 );
	}
  }
  else
  {	// Ausgabe Dialogbox
	// Zeichnen der zugeh�rigen Texte R1-R3 und R5
	Zeichne_Text_xy(hdc, "R1", 109, 50);
	Zeichne_Text_xy(hdc, "R2", 109, 380);
	Zeichne_Text_xy(hdc, "R3", 209, 50);
	Zeichne_Text_xy(hdc, "R5", 209, 400);
	Zeichne_Text_xy(hdc, "R6", 409, 50 );
	Zeichne_Text_xy(hdc, "R8", 409, 400 );
  }

  // Fenster neu zeichnen: Doppelte Emitterschaltung mit Widerst�nden, Transistor und Spannungsquelle

  SetPolyFillMode(hdc, WINDING);

  hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);
  // Wieder auf wei�e Fl�che zur�ck...
  SelectObject(hdc, hPinselAlt);

  Zeichne_Gleichspannungsquelle(hdc, 740, 100, 60, true, 40);

  if (D_ES.NPN_T1) // erster Transistor ist NPN-Transistor, also etwas weiter oben anfangen, damit Platz f�r zwei Emitterwiderst�nde ist
  {
	if (!Kopie_Zwischenablage)
	{
	  // Text f�r R4
	  Zeichne_Text_xy(hdc, "R4", 209, 300);
	  // Text f�r C1
	  Zeichne_Text_xy(hdc, "C1", 80, 180);
	  // Text f�r C2
	  Zeichne_Text_xy(hdc, "C2", 290, 400);
	}
	//Anschlusspunkte links und rechts zeichen, Positionen (Mitte): x: 45; 710; y:250; 400
	Zeichne_Anschluss(hdc, 35, 190, 150);
	// Leitung f�r Kondensator C_Ein Position: x: 55-100 und 120-250, y: 200
	ZP_Linie(hdc, 55, 200, 100, 200);
	ZP_Linie(hdc, 120, 200, 200, 200);
	// Eingangskondensator Position: x: 100, 70 y: 200-300
	Zeichne_Kondensator(hdc, 100, 150, 20, 100, C_HORIZONTAL);
	// Leitung f�r R1, R2 und U_B:
	VP_Linie(hdc, 150, 480, 150, 10, 770, 10, 770, 150);
	// Masse f�r R2
	ZP_Linie(hdc, 135, 480, 165, 480);
	//Widerst�nde R1, R2 Positionen: x=185, y=50, 380:
	Zeichne_Widerstand(hdc, 135, 50, 30, 60);
	Zeichne_Widerstand(hdc, 135, 380, 30, 60);
	// Leitung f�r R3 Postion: x: 300; y: 10-200
	ZP_Linie(hdc, 250, 10, 250, 150);
	// Leitung f�r R4, R5 Position: x: 300, y: 300-500
	ZP_Linie(hdc, 250, 250, 250, 500);
	// Masseanschluss f�r R5 Position: x: 285-315, y: 500
	ZP_Linie(hdc, 235, 500, 265, 500);
	//Widerst�nde R3 bis R5 Positionen: x=285, y=50, 300, 400:
	Zeichne_Widerstand(hdc, 235, 50, 30, 60);
	Zeichne_Widerstand(hdc, 235, 300, 30, 60);
	Zeichne_Widerstand(hdc, 235, 400, 30, 60);
	// Kondensator parallel zu R5
	Zeichne_Kondensator( hdc, 280, 420, 60, 20, false, 0 );
	// Kondensator anschliessen
	DP_Linie( hdc, 250, 375, 310, 375, 310, 420 );
	ZP_Linie( hdc, 310, 440, 310, 500 );
	ZP_Linie( hdc, 295, 500, 325, 500 );

	// Zeichnen der Verbindungspunkte und des Transistors
	SelectObject(hdc, hPinselSchwarz);
	Zeichne_Bipolartransistor(hdc, 200, 150, 50, 100, D_ES.NPN_T1, 0);

	// Verbindungspunkte
	Ellipse_BH(hdc, 145, 195, 10, 10);
	Ellipse_BH(hdc, 245, 5, 10, 10);
	Ellipse_BH(hdc, 245, 370, 10, 10);
	Ellipse_BH(hdc, 245, 130, 10, 10);
	// Wieder auf wei�e Fl�che zur�ck...
	SelectObject(hdc, hPinselAlt);
  }
  else // erster Transistor ist pnp-Typ, dann weiter unten anfangen, damit oben gen�gend Platz bleibt.
  {
	if (!Kopie_Zwischenablage)
	{
	  Zeichne_Text_xy(hdc, "R4", 209, 150);
	  // Text f�r C1
	  Zeichne_Text_xy(hdc, "C1", 80, 280);
	  // Text f�r C2
	  Zeichne_Text_xy(hdc, "C2", 290, 40);
	}

	//Anschlusspunkte links und rechts zeichen, Positionen (Mitte): x: 45; 710; y:250; 400
	Zeichne_Anschluss(hdc, 35, 290, 150);
	// Leitung f�r Kondensator C_Ein Position: x: 55-100 und 120-250, y: 200
	ZP_Linie(hdc, 55, 300, 100, 300);
	ZP_Linie(hdc, 120, 300, 200, 300);
	// Eingangskondensator Position: x: 100, 70 y: 200-300
	Zeichne_Kondensator(hdc, 100, 250, 20, 100, C_HORIZONTAL);
	// Leitung f�r R1, R2 und U_B:
	VP_Linie(hdc, 150, 480, 150, 10, 770, 10, 770, 150);
	// Masse f�r R2
	ZP_Linie(hdc, 135, 480, 165, 480);
	//Widerst�nde R1, R2 Positionen: x=185, y=50, 320:
	Zeichne_Widerstand(hdc, 135, 50, 30, 60);
	Zeichne_Widerstand(hdc, 135, 380, 30, 60);
	// Leitung f�r R3, R4 Postion: x: 300; y: 10-250
	ZP_Linie(hdc, 250, 10, 250, 250);
	// Leitung f�r R5 Position: x: 300, y: 350-500
	ZP_Linie(hdc, 250, 350, 250, 500);
	// Masseanschluss f�r R5 Position: x: 285-315, y: 500
	ZP_Linie(hdc, 235, 500, 265, 500);
	//Widerst�nde R3 bis R5 Positionen: x=285, y=50, 300, 400:
	Zeichne_Widerstand(hdc, 235, 50, 30, 60);
	Zeichne_Widerstand(hdc, 235, 150, 30, 60);
	Zeichne_Widerstand(hdc, 235, 400, 30, 60);
	// Kondensator parallel zu R3
	Zeichne_Kondensator( hdc, 280, 60, 60, 20, false, 0 );
	// Kondensator anschliessen
	DP_Linie( hdc, 250, 130, 310, 130, 310, 80 );
	ZP_Linie( hdc, 310, 60, 310, 10 );

	// Zeichnen der Verbindungspunkte und des Transistors
	SelectObject(hdc, hPinselSchwarz);
	Zeichne_Bipolartransistor(hdc, 200, 250, 50, 100, D_ES.NPN_T1, 0);

	// Verbindungspunkte
	Ellipse_BH(hdc, 145, 295, 10, 10);
	Ellipse_BH(hdc, 245, 5, 10, 10);
	Ellipse_BH(hdc, 305, 5, 10, 10);
	Ellipse_BH(hdc, 245, 125, 10, 10);
	Ellipse_BH(hdc, 245, 345, 10, 10);
	// Verbindungspunkt f�r Kondensator C2
	Ellipse_BH(hdc, 245, 5, 10, 10);
	// Wieder auf wei�e Fl�che zur�ck...
	SelectObject(hdc, hPinselAlt);
  }
  // Zweiter Transistor
  if (D_ES.NPN_T2) // zweiter Transistor ist NPN-Transistor, also etwas weiter oben anfangen, damit Platz f�r zwei Emitterwiderst�nde ist
  {
	if (!Kopie_Zwischenablage)
	{
	  // Text f�r R7
	  Zeichne_Text_xy(hdc, "R7", 409, 300);
	  // Text f�r C4
	  Zeichne_Text_xy(hdc, "C4", 495, 130);
	  // Text f�r C3
	  Zeichne_Text_xy(hdc, "C3", 490, 400);
	}
	//Anschlusspunkte  rechts zeichen, Positionen (Mitte): x: 45; 710; y:250; 400
	Zeichne_Anschluss(hdc, 610, 140, 150);
	// Leitung f�r Kondensator C_Aus Position: x: 55-100 und 120-250, y: 200
	ZP_Linie(hdc, 450, 150, 520, 150);
	ZP_Linie(hdc, 540, 150, 610, 150);
	// Ausgangskondensator Position: x: 550, 70 y: 200-300
	Zeichne_Kondensator(hdc, 520, 100, 20, 100, C_HORIZONTAL);
	// Leitung f�r R6 Postion: x: 450; y: 10-200
	ZP_Linie(hdc, 450, 10, 450, 150);
	// Leitung f�r R7, R8 Position: x: 450, y: 300-500
	ZP_Linie(hdc, 450, 250, 450, 500);
	// Masseanschluss f�r R8 Position: x: 435-465, y: 500
	ZP_Linie(hdc, 435, 500, 465, 500);
	//Widerst�nde R6 bis R8 Positionen: x=435, y=50, 300, 400:
	Zeichne_Widerstand(hdc, 435, 50, 30, 60);
	Zeichne_Widerstand(hdc, 435, 300, 30, 60);
	Zeichne_Widerstand(hdc, 435, 400, 30, 60);
	// Kondensator parallel zu R8
	Zeichne_Kondensator( hdc, 480, 420, 60, 20, false, 0 );
	// Kondensator anschliessen
	DP_Linie( hdc, 450, 375, 510, 375, 510, 420 );
	ZP_Linie( hdc, 510, 440, 510, 500 );
	ZP_Linie( hdc, 495, 500, 525, 500 );

	// Zeichnen der Verbindungspunkte und des Transistors
	SelectObject(hdc, hPinselSchwarz);
	Zeichne_Bipolartransistor(hdc, 400, 150, 50, 100, D_ES.NPN_T2, 0);

	// Verbindungspunkte
	Ellipse_BH(hdc, 445, 5, 10, 10);
	Ellipse_BH(hdc, 445, 370, 10, 10);
	Ellipse_BH(hdc, 445, 145, 10, 10);
	// Wieder auf wei�e Fl�che zur�ck...
	SelectObject(hdc, hPinselAlt);
  }
  else // zweiter Transistor ist pnp-Typ, dann weiter unten anfangen, damit oben gen�gend Platz bleibt.
  {
	if (!Kopie_Zwischenablage)
	{
	  // Text f�r R7
	  Zeichne_Text_xy(hdc, "R7", 409, 150);
	  // Text f�r C4
	  Zeichne_Text_xy(hdc, "C4", 495, 330);
	  // Text f�r C3
	  Zeichne_Text_xy(hdc, "C3", 490, 45);
	}
	//Anschlusspunkte  rechts zeichen, Positionen (Mitte): x: 45; 710; y:250; 400
	Zeichne_Anschluss(hdc, 610, 340, 100);
	// Leitung f�r Kondensator C_Aus Position: x: 55-100 und 120-250, y: 200
	ZP_Linie(hdc, 450, 350, 520, 350);
	ZP_Linie(hdc, 540, 350, 610, 350);
	// Ausgangskondensator Position: x: 550, 70 y: 200-300
	Zeichne_Kondensator(hdc, 520, 300, 20, 100, C_HORIZONTAL);
	// Leitung f�r R6 Postion: x: 450; y: 10-200
	ZP_Linie(hdc, 450, 10, 450, 250);
	// Leitung f�r R7, R8 Position: x: 450, y: 300-500
	ZP_Linie(hdc, 450, 350, 450, 500);
	// Masseanschluss f�r R8 Position: x: 435-465, y: 500
	ZP_Linie(hdc, 435, 500, 465, 500);
	//Widerst�nde R6 bis R8 Positionen: x=435, y=50, 300, 400:
	Zeichne_Widerstand(hdc, 435, 50, 30, 60);
	Zeichne_Widerstand(hdc, 435, 150, 30, 60);
	Zeichne_Widerstand(hdc, 435, 400, 30, 60);
	// Kondensator parallel zu R6
	Zeichne_Kondensator( hdc, 480, 70, 60, 20, false, 0 );
	// Kondensator anschliessen
	DP_Linie( hdc, 450, 130, 510, 130, 510, 90 );
	ZP_Linie( hdc, 510, 10, 510, 70 );

	// Zeichnen der Verbindungspunkte und des Transistors
	SelectObject(hdc, hPinselSchwarz);
	Zeichne_Bipolartransistor(hdc, 400, 250, 50, 100, D_ES.NPN_T2, 0);

	// Verbindungspunkte
	Ellipse_BH(hdc, 445, 5, 10, 10);
	Ellipse_BH(hdc, 505, 5, 10, 10);
	Ellipse_BH(hdc, 445, 345, 10, 10);
	Ellipse_BH(hdc, 445, 125, 10, 10);
	// Wieder auf wei�e Fl�che zur�ck...
	SelectObject(hdc, hPinselAlt);
  }
  if (D_ES.NPN_T1 && D_ES.NPN_T2)
  {
	// Zwei NPN-Transistoren: Hier die Verbindungslinie zwischen beiden
	VP_Linie( hdc, 250, 135, 325, 135, 325, 200, 400, 200 );
  }
  if (!D_ES.NPN_T1 && D_ES.NPN_T2)
  {
	// Ein PNP-Transitor, gefolgt von einem NPN-Transistoren: Hier die Verbindungslinie zwischen beiden
	VP_Linie( hdc, 250, 350, 325, 350, 325, 200, 400, 200 );
  }
  if (D_ES.NPN_T1 && !D_ES.NPN_T2)
  {
	// Zwei NPN-Transistoren: Hier die Verbindungslinie zwischen beiden
	VP_Linie( hdc, 250, 135, 325, 135, 325, 300, 400, 300 );
  }
  if (!D_ES.NPN_T1 && !D_ES.NPN_T2)
  {
	// Ein PNP-Transitor, gefolgt von einem NPN-Transistoren: Hier die Verbindungslinie zwischen beiden
	VP_Linie( hdc, 250, 350, 325, 350, 325, 300, 400, 300 );
  }
  if (Kopie_Zwischenablage)
  {
	SelectObject(hdc, FontAlt);
	DeleteObject(FontNeu);
  }

  SelectObject(hdc, hPinselAlt);
  DeleteObject(hPinselSchwarz);
  SelectObject(hdc, hStiftAlt);
  DeleteObject(hStiftSchwarz2);

  return 0;
} // end of Zeichne_DoppelEmitterschaltung

int Berechne_Doppel_Emitterschaltung(void)
{
  // DC Ein- und Ausgangswiderstand ist generell unendlich und muss nicht gespeichert werden.

  // Generell ist die Schaltung erst einmal berechenbar:
  Doppel_Emitter_Schaltung.Schaltung_berechenbar = true;
  // Berechnung NPN-Transistor
  if (Doppel_Emitter_Schaltung.NPN_T1) //NPN-Typ f�r Transistor 1
  {
	// Basisstrom f�r NPN-Transistor berechnen
	Doppel_Emitter_Schaltung.I_B_T1 = Basisstrom_NPN(Doppel_Emitter_Schaltung.R[R_BASIS_UB], Doppel_Emitter_Schaltung.R[R_BASIS_GND], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_ES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_ES_NPN],
	  Doppel_Emitter_Schaltung.U_BE_T1, Doppel_Emitter_Schaltung.U_B, Doppel_Emitter_Schaltung.Beta_T1);
	if (Doppel_Emitter_Schaltung.I_B_T1 < 0)
	{
	  // Falls der Basisstrom negativ ist, sind auch Kollektor? und Emitterstrom nicht bestimmbar.Das Gleiche gilt f�r die Spannungen...
	  Doppel_Emitter_Schaltung.Schaltung_berechenbar = false;
	}
	else
	{
	  // Kollektorstrom berechnen
	  Doppel_Emitter_Schaltung.I_C_T1 = Doppel_Emitter_Schaltung.Beta_T1 * Doppel_Emitter_Schaltung.I_B_T1;
	  // Emitterstrom berechnen
	  Doppel_Emitter_Schaltung.I_E_T1 = (Doppel_Emitter_Schaltung.Beta_T1 + 1.0) * Doppel_Emitter_Schaltung.I_B_T1;
	  // Emitterspannung NPN
	  Doppel_Emitter_Schaltung.U_E_T1 = Doppel_Emitter_Schaltung.I_E_T1 * (Doppel_Emitter_Schaltung.R[R_EMITTER_DC_ES] + Doppel_Emitter_Schaltung.R[R_EMITTER_AC_ES_NPN]);
	  // Kontrolle: Kollektorspannung muss h�her als Emitterspannung sein, falls nicht, stimmt die L�sung nicht
	  if (Doppel_Emitter_Schaltung.U_E_T1 > Doppel_Emitter_Schaltung.U_C_T1)
		Doppel_Emitter_Schaltung.Schaltung_berechenbar = false;
	  // Basisspannung NPN
	  Doppel_Emitter_Schaltung.U_Basis_T1 = Doppel_Emitter_Schaltung.U_E_T1 + Doppel_Emitter_Schaltung.U_BE_T1;
	  // Kleinsignalwiderst�nde
	  Doppel_Emitter_Schaltung.r_BE_T1 = r_BE(Doppel_Emitter_Schaltung.I_B_T1, U_T(Doppel_Emitter_Schaltung.T, Doppel_Emitter_Schaltung.Naeherung_U_T));
	  Doppel_Emitter_Schaltung.r_CE_T1 = r_CE(Doppel_Emitter_Schaltung.U_C_T1 - Doppel_Emitter_Schaltung.U_E_T1, Doppel_Emitter_Schaltung.U_AF_T1, Doppel_Emitter_Schaltung.I_C_T1);
	  // DC-Verst�rkung
	  Doppel_Emitter_Schaltung.V_U_DC_T1 = V_U_DC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_NPN], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_ES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_ES_NPN], Doppel_Emitter_Schaltung.r_BE_T1, Doppel_Emitter_Schaltung.r_CE_T1, Doppel_Emitter_Schaltung.Beta_T1, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Verst�rkung
	  Doppel_Emitter_Schaltung.V_U_AC_T1 = V_U_AC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_NPN], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_ES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_ES_NPN], Doppel_Emitter_Schaltung.r_BE_T1, Doppel_Emitter_Schaltung.r_CE_T1, Doppel_Emitter_Schaltung.Beta_T1, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Eingangswiderstand
	  Doppel_Emitter_Schaltung.r_Ein_AC = AC_Eingangswiderstand_E(Doppel_Emitter_Schaltung.R[R_BASIS_UB], Doppel_Emitter_Schaltung.R[R_BASIS_GND], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_ES], Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_NPN], Doppel_Emitter_Schaltung.r_BE_T1, Doppel_Emitter_Schaltung.r_CE_T1, Doppel_Emitter_Schaltung.Beta_T1, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	}
	if (Doppel_Emitter_Schaltung.NPN_T2) // Zweiter Transistor ist auch ein NPN-Transistor
	{
	  double nenner;
	  // Berechnung Basisstrom T2
	  nenner = Doppel_Emitter_Schaltung.R[2]+(Doppel_Emitter_Schaltung.Beta_T2+1.0)*(Doppel_Emitter_Schaltung.R[6]+Doppel_Emitter_Schaltung.R[7]);
	  if (nenner == 0.0)
	  {
		Doppel_Emitter_Schaltung.Schaltung_berechenbar=false;
		nenner = 0.1;
	  }
	  Doppel_Emitter_Schaltung.I_B_T2=(Doppel_Emitter_Schaltung.U_B-Doppel_Emitter_Schaltung.U_BE_T2-Doppel_Emitter_Schaltung.R[2]*Doppel_Emitter_Schaltung.Beta_T1*Doppel_Emitter_Schaltung.I_B_T1) / nenner;

	  // Kollektorspannung T1 kann jetzt mit Basisstrom von T2 berechnet werden
	  Doppel_Emitter_Schaltung.U_C_T1 = Doppel_Emitter_Schaltung.U_B - (Doppel_Emitter_Schaltung.I_C_T1+Doppel_Emitter_Schaltung.I_B_T2) * Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_NPN];

	  // Erster Transistor ist NPN, damit ist die Basisspannung identisch zur Kollektorspannung
	  Doppel_Emitter_Schaltung.U_Basis_T2 = Doppel_Emitter_Schaltung.U_C_T1;
	  // Emitterspannung ist um U_BE geringer als Basisspannung
	  Doppel_Emitter_Schaltung.U_E_T2 = Doppel_Emitter_Schaltung.U_Basis_T2 - Doppel_Emitter_Schaltung.U_BE_T2;
	  // Berechnung der Str�me und Spannungen an T2:
	  Doppel_Emitter_Schaltung.I_C_T2=Doppel_Emitter_Schaltung.Beta_T2*Doppel_Emitter_Schaltung.I_B_T2;
	  Doppel_Emitter_Schaltung.I_E_T2=(Doppel_Emitter_Schaltung.Beta_T2+1.0)*Doppel_Emitter_Schaltung.I_B_T2;
	  Doppel_Emitter_Schaltung.U_C_T2=Doppel_Emitter_Schaltung.U_B-Doppel_Emitter_Schaltung.I_C_T2*Doppel_Emitter_Schaltung.R[5];
	  // Kleinsignalwiderst�nde
	  Doppel_Emitter_Schaltung.r_BE_T2 = r_BE(Doppel_Emitter_Schaltung.I_B_T2, U_T(Doppel_Emitter_Schaltung.T, Doppel_Emitter_Schaltung.Naeherung_U_T));
	  Doppel_Emitter_Schaltung.r_CE_T2 = r_CE(Doppel_Emitter_Schaltung.U_C_T2 - Doppel_Emitter_Schaltung.U_E_T2, Doppel_Emitter_Schaltung.U_AF_T2, Doppel_Emitter_Schaltung.I_C_T2);
	  // DC-Verst�rkung
	  Doppel_Emitter_Schaltung.V_U_DC_T2 = V_U_DC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_NPN], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_DES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_DES_NPN], Doppel_Emitter_Schaltung.r_BE_T2, Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Beta_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Verst�rkung
	  Doppel_Emitter_Schaltung.V_U_AC_T2 = V_U_AC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_NPN], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_DES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_DES_NPN], Doppel_Emitter_Schaltung.r_BE_T2, Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Beta_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Ausgangswiderstand
	  Doppel_Emitter_Schaltung.r_Aus_AC = AC_Ausgangswiderstand_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_NPN], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_DES], Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	}
	else // Zweiter Transistor ist pnp-Transistor
	{
	  double nenner;
	  // Berechnung Basisstrom von T2
	  nenner = (Doppel_Emitter_Schaltung.Beta_T2+1.0)*(Doppel_Emitter_Schaltung.R[5]+Doppel_Emitter_Schaltung.R[6])+Doppel_Emitter_Schaltung.R[2];
	  if (nenner == 0.0)
	  {
		Doppel_Emitter_Schaltung.Schaltung_berechenbar=false;
		nenner = 0.1;
	  }
	  // Berechnung der Str�me und Spannungen an T2:
	  Doppel_Emitter_Schaltung.I_B_T2=(Doppel_Emitter_Schaltung.R[2]*Doppel_Emitter_Schaltung.Beta_T1*Doppel_Emitter_Schaltung.I_B_T1-Doppel_Emitter_Schaltung.U_BE_T2 ) / nenner;

	  // Kollektorspannung T1 kann jetzt mit Basisstrom von T2 berechnet werden
	  Doppel_Emitter_Schaltung.U_C_T1 = Doppel_Emitter_Schaltung.U_B - (Doppel_Emitter_Schaltung.I_C_T1-Doppel_Emitter_Schaltung.I_B_T2) * Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP];

	  // Spannungen (Basis, Emitter)
	  Doppel_Emitter_Schaltung.U_Basis_T2=Doppel_Emitter_Schaltung.U_C_T1;
	  Doppel_Emitter_Schaltung.U_E_T2=Doppel_Emitter_Schaltung.U_Basis_T2+Doppel_Emitter_Schaltung.U_BE_T2;

	  // Berechnung der Str�me und Spannungen an T2:
	  Doppel_Emitter_Schaltung.I_C_T2=Doppel_Emitter_Schaltung.Beta_T2*Doppel_Emitter_Schaltung.I_B_T2;
	  Doppel_Emitter_Schaltung.I_E_T2=(Doppel_Emitter_Schaltung.Beta_T2+1.0)*Doppel_Emitter_Schaltung.I_B_T2;
	  Doppel_Emitter_Schaltung.U_C_T2=Doppel_Emitter_Schaltung.I_C_T2*Doppel_Emitter_Schaltung.R[5];
	  // Kleinsignalwiderst�nde
	  Doppel_Emitter_Schaltung.r_BE_T2 = r_BE(Doppel_Emitter_Schaltung.I_B_T2, U_T(Doppel_Emitter_Schaltung.T, Doppel_Emitter_Schaltung.Naeherung_U_T));
	  Doppel_Emitter_Schaltung.r_CE_T2 = r_CE(Doppel_Emitter_Schaltung.U_E_T2 - Doppel_Emitter_Schaltung.U_C_T2, Doppel_Emitter_Schaltung.U_AF_T2, Doppel_Emitter_Schaltung.I_C_T2);
	  // DC-Verst�rkung berechnen
	  Doppel_Emitter_Schaltung.V_U_DC_T2 = V_U_DC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_PNP], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_DES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_DES_PNP], Doppel_Emitter_Schaltung.r_BE_T2, Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Beta_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Verst�rkung
	  Doppel_Emitter_Schaltung.V_U_AC_T2 = V_U_AC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_PNP], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_DES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_DES_PNP], Doppel_Emitter_Schaltung.r_BE_T2, Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Beta_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Ausgangswiderstand
	  Doppel_Emitter_Schaltung.r_Aus_AC = AC_Ausgangswiderstand_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_PNP], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_DES_PNP], Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	}
  }
  if (!Doppel_Emitter_Schaltung.NPN_T1)	// Berechnung f�r PNP-Transistor als linken Transistor
  {
	// Basisstrom f�r PNP-Transistor berechnen
	Doppel_Emitter_Schaltung.I_B_T1 = Basisstrom_PNP(Doppel_Emitter_Schaltung.R[R_BASIS_UB], Doppel_Emitter_Schaltung.R[R_BASIS_GND], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_ES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_ES_PNP], Doppel_Emitter_Schaltung.U_BE_T1, Doppel_Emitter_Schaltung.U_B, Doppel_Emitter_Schaltung.Beta_T1);
	if (Doppel_Emitter_Schaltung.I_B_T1 < 0)
	{
	  // Basisstrom negativ, also nicht berechenbar.
	  Doppel_Emitter_Schaltung.Schaltung_berechenbar = false;
	}
	// Kollektorstrom
	Doppel_Emitter_Schaltung.I_C_T1 = Doppel_Emitter_Schaltung.I_B_T1 * Doppel_Emitter_Schaltung.Beta_T1;
	// Emitterstrom
	Doppel_Emitter_Schaltung.I_E_T1 = Doppel_Emitter_Schaltung.I_B_T1 * (Doppel_Emitter_Schaltung.Beta_T1 + 1.0);
	// Kollektorspannung PNP
	//	  Doppel_Emitter_Schaltung.U_C_T1 = Doppel_Emitter_Schaltung.I_C_T1 * Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP];
	// Emitterspannung PNP
	Doppel_Emitter_Schaltung.U_E_T1 = Doppel_Emitter_Schaltung.U_B - Doppel_Emitter_Schaltung.I_E_T1 * (Doppel_Emitter_Schaltung.R[R_EMITTER_AC_ES_PNP] + Doppel_Emitter_Schaltung.R[R_EMITTER_DC_ES]);
	// Kontrolle: Hier muss die Kollektorspannung niedriger als die Emitterspannung sein, falls nicht, liegt ein Fehler vor
	if (Doppel_Emitter_Schaltung.U_E_T1 < Doppel_Emitter_Schaltung.U_C_T1)
	  Doppel_Emitter_Schaltung.Schaltung_berechenbar = false;
	// Basisspannung
	Doppel_Emitter_Schaltung.U_Basis_T1 = Doppel_Emitter_Schaltung.U_E_T1 - Doppel_Emitter_Schaltung.U_BE_T1;
	// Kleinsignalwiderst�nde berechnen
	Doppel_Emitter_Schaltung.r_BE_T1 = r_BE(Doppel_Emitter_Schaltung.I_B_T1, U_T(Doppel_Emitter_Schaltung.T, Doppel_Emitter_Schaltung.Naeherung_U_T));
	Doppel_Emitter_Schaltung.r_CE_T1 = r_CE(Doppel_Emitter_Schaltung.U_E_T1 - Doppel_Emitter_Schaltung.U_C_T1, Doppel_Emitter_Schaltung.U_AF_T1, Doppel_Emitter_Schaltung.I_C_T1);
	// DC-Verst�rkung berechnen
	Doppel_Emitter_Schaltung.V_U_DC_T1 = V_U_DC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_ES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_ES_PNP], Doppel_Emitter_Schaltung.r_BE_T1, Doppel_Emitter_Schaltung.r_CE_T1, Doppel_Emitter_Schaltung.Beta_T1, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	// AC-Verst�rkung
	Doppel_Emitter_Schaltung.V_U_AC_T1 = V_U_AC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_ES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_ES_PNP], Doppel_Emitter_Schaltung.r_BE_T1, Doppel_Emitter_Schaltung.r_CE_T1, Doppel_Emitter_Schaltung.Beta_T1, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	// AC-Eingangswiderstand
	Doppel_Emitter_Schaltung.r_Ein_AC = AC_Eingangswiderstand_E(Doppel_Emitter_Schaltung.R[R_BASIS_UB], Doppel_Emitter_Schaltung.R[R_BASIS_GND], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_ES], Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP], Doppel_Emitter_Schaltung.r_BE_T1, Doppel_Emitter_Schaltung.r_CE_T1, Doppel_Emitter_Schaltung.Beta_T1, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	// AC-Ausgangswiderstand
	//  Doppel_Emitter_Schaltung.r_Aus_AC = AC_Ausgangswiderstand_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_ES_PNP], Doppel_Emitter_Schaltung.r_CE, Emitter_Schaltung.Naeherung_r_CE);
	if (Doppel_Emitter_Schaltung.NPN_T2) // Zweiter Transistor ist ein NPN-Transistor
	{
	  double nenner;
	  // Berechnung Basisstrom T2
	  nenner = Doppel_Emitter_Schaltung.R[4]+(Doppel_Emitter_Schaltung.Beta_T2+1.0)*(Doppel_Emitter_Schaltung.R[6]+Doppel_Emitter_Schaltung.R[7]);
	  if (nenner == 0.0)
	  {
		Doppel_Emitter_Schaltung.Schaltung_berechenbar=false;
		nenner = 0.1;
	  }
	  Doppel_Emitter_Schaltung.I_B_T2=(Doppel_Emitter_Schaltung.R[4]*Doppel_Emitter_Schaltung.Beta_T1*Doppel_Emitter_Schaltung.I_B_T1-Doppel_Emitter_Schaltung.U_BE_T2) / nenner;

	  // Kollektorspannung T1 kann jetzt mit Basisstrom von T2 berechnet werden
	  Doppel_Emitter_Schaltung.U_C_T1 = (Doppel_Emitter_Schaltung.I_C_T1-Doppel_Emitter_Schaltung.I_B_T2) * Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP];

	  // Erster Transistor ist PNP, damit ist die Basisspannung identisch zur Kollektorspannung
	  Doppel_Emitter_Schaltung.U_Basis_T2 = Doppel_Emitter_Schaltung.U_C_T1;
	  // Emitterspannung ist um U_BE geringer als Basisspannung
	  Doppel_Emitter_Schaltung.U_E_T2 = Doppel_Emitter_Schaltung.U_Basis_T2 - Doppel_Emitter_Schaltung.U_BE_T2;
	  // Berechnung der Str�me und Spannungen an T2:
	  Doppel_Emitter_Schaltung.I_C_T2=Doppel_Emitter_Schaltung.Beta_T2*Doppel_Emitter_Schaltung.I_B_T2;
	  Doppel_Emitter_Schaltung.I_E_T2=(Doppel_Emitter_Schaltung.Beta_T2+1.0)*Doppel_Emitter_Schaltung.I_B_T2;
	  Doppel_Emitter_Schaltung.U_C_T2=Doppel_Emitter_Schaltung.U_B-Doppel_Emitter_Schaltung.I_C_T2*Doppel_Emitter_Schaltung.R[5];
	  // Kleinsignalwiderst�nde
	  Doppel_Emitter_Schaltung.r_BE_T2 = r_BE(Doppel_Emitter_Schaltung.I_B_T2, U_T(Doppel_Emitter_Schaltung.T, Doppel_Emitter_Schaltung.Naeherung_U_T));
	  Doppel_Emitter_Schaltung.r_CE_T2 = r_CE(Doppel_Emitter_Schaltung.U_C_T2 - Doppel_Emitter_Schaltung.U_E_T2, Doppel_Emitter_Schaltung.U_AF_T2, Doppel_Emitter_Schaltung.I_C_T2);
	  // DC-Verst�rkung
	  Doppel_Emitter_Schaltung.V_U_DC_T2 = V_U_DC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_NPN], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_DES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_DES_NPN], Doppel_Emitter_Schaltung.r_BE_T2, Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Beta_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Verst�rkung
	  Doppel_Emitter_Schaltung.V_U_AC_T2 = V_U_AC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_NPN], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_DES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_DES_NPN], Doppel_Emitter_Schaltung.r_BE_T2, Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Beta_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Ausgangswiderstand
	  Doppel_Emitter_Schaltung.r_Aus_AC = AC_Ausgangswiderstand_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_NPN], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_DES], Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	}
	else // Zweiter Transistor ist pnp-Transistor
	{
	  double nenner;
	  // Berechnung Basisstrom von T2
	  nenner = (Doppel_Emitter_Schaltung.Beta_T2+1.0)*(Doppel_Emitter_Schaltung.R[5]+Doppel_Emitter_Schaltung.R[6])+Doppel_Emitter_Schaltung.R[4];
	  if (nenner == 0.0)
	  {
		Doppel_Emitter_Schaltung.Schaltung_berechenbar=false;
		nenner = 0.1;
	  }
	  // Berechnung der Str�me und Spannungen an T2:
	  Doppel_Emitter_Schaltung.I_B_T2=(Doppel_Emitter_Schaltung.U_B-Doppel_Emitter_Schaltung.R[4]*Doppel_Emitter_Schaltung.Beta_T1*Doppel_Emitter_Schaltung.I_B_T1-Doppel_Emitter_Schaltung.U_BE_T2 ) / nenner;

	  // Kollektorspannung T1 kann jetzt mit Basisstrom von T2 berechnet werden
	  Doppel_Emitter_Schaltung.U_C_T1 = (Doppel_Emitter_Schaltung.I_C_T1+Doppel_Emitter_Schaltung.I_B_T2) * Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_ES_PNP];

	  // Spannungen (Basis, Emitter)
	  Doppel_Emitter_Schaltung.U_Basis_T2=Doppel_Emitter_Schaltung.U_C_T1;
	  Doppel_Emitter_Schaltung.U_E_T2=Doppel_Emitter_Schaltung.U_Basis_T2+Doppel_Emitter_Schaltung.U_BE_T2;

	  // Berechnung der Str�me und Spannungen an T2:
	  Doppel_Emitter_Schaltung.I_C_T2=Doppel_Emitter_Schaltung.Beta_T2*Doppel_Emitter_Schaltung.I_B_T2;
	  Doppel_Emitter_Schaltung.I_E_T2=(Doppel_Emitter_Schaltung.Beta_T2+1.0)*Doppel_Emitter_Schaltung.I_B_T2;
	  Doppel_Emitter_Schaltung.U_C_T2=Doppel_Emitter_Schaltung.I_C_T2*Doppel_Emitter_Schaltung.R[5];
	  // Kleinsignalwiderst�nde
	  Doppel_Emitter_Schaltung.r_BE_T2 = r_BE(Doppel_Emitter_Schaltung.I_B_T2, U_T(Doppel_Emitter_Schaltung.T, Doppel_Emitter_Schaltung.Naeherung_U_T));
	  Doppel_Emitter_Schaltung.r_CE_T2 = r_CE(Doppel_Emitter_Schaltung.U_E_T2 - Doppel_Emitter_Schaltung.U_C_T2, Doppel_Emitter_Schaltung.U_AF_T2, Doppel_Emitter_Schaltung.I_C_T2);
	  // DC-Verst�rkung berechnen
	  Doppel_Emitter_Schaltung.V_U_DC_T2 = V_U_DC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_PNP], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_DES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_DES_PNP], Doppel_Emitter_Schaltung.r_BE_T2, Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Beta_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Verst�rkung
	  Doppel_Emitter_Schaltung.V_U_AC_T2 = V_U_AC_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_PNP], Doppel_Emitter_Schaltung.R[R_EMITTER_DC_DES], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_DES_PNP], Doppel_Emitter_Schaltung.r_BE_T2, Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Beta_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	  // AC-Ausgangswiderstand
	  Doppel_Emitter_Schaltung.r_Aus_AC = AC_Ausgangswiderstand_E(Doppel_Emitter_Schaltung.R[R_KOLLEKTOR_DES_PNP], Doppel_Emitter_Schaltung.R[R_EMITTER_AC_DES_PNP], Doppel_Emitter_Schaltung.r_CE_T2, Doppel_Emitter_Schaltung.Naeherung_r_CE);
	}	
  } 
  Doppel_Emitter_Schaltung.V_U_AC_Ges=Doppel_Emitter_Schaltung.V_U_AC_T1*Doppel_Emitter_Schaltung.V_U_AC_T2;
  Doppel_Emitter_Schaltung.V_U_DC_Ges=Doppel_Emitter_Schaltung.V_U_DC_T1*Doppel_Emitter_Schaltung.V_U_DC_T2;
  if ((Doppel_Emitter_Schaltung.I_B_T1<0.0)||(Doppel_Emitter_Schaltung.I_B_T2<0.0) )
	Doppel_Emitter_Schaltung.Schaltung_berechenbar=false;
  return 0;
}	// end of Berechne_Doppel_Emitterschaltung

int Ergebnis_Doppel_Emitterschaltung(HWND hDlg)
{
  // Berechnung der Doppel_Emitterschaltung
  Berechne_Doppel_Emitterschaltung();
  DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_DOPPEL_BIPOLARSCHALTUNG), hDlg, ErgebnisDoppelEmitterSchaltung_Dialog);

  return 0;
}	// end of Ergebnis_Doppel_Emitterschaltung
;
int Zeichne_Ausgabe_DoppelEmitterschaltung(Doppel_Bipolartransistor D_ES, HDC hdc, bool Kopie_Zwischenablage)
{
  UNREFERENCED_PARAMETER(Kopie_Zwischenablage);

  HPEN hStiftSchwarz2, hStiftAlt;
  HBRUSH hPinselSchwarz, hPinselAlt;
  HFONT hFontAlt, hFont;
  int zeilennummer = 2, tabulator[5];
  char cText[100], cAusgabe[255], cWert1[100], cWert2[100];

  hFont = Erstelle_Font_Arial(hdc, 20);
  hFontAlt = (HFONT)SelectObject(hdc, hFont);
  tabulator[0] = 200;
  tabulator[1] = 300;
  tabulator[2] = 500;
  tabulator[3] = 600;

  SetPolyFillMode(hdc, WINDING);

  hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

  // passenden Transistor zeichnen
  Zeichne_Bipolartransistor(hdc, 600, 30, 50, 100, D_ES.NPN_T1, 20);
  // Ausgabe der Ergebnisse
  if (D_ES.Schaltung_berechenbar)
	TabbedTextOut(hdc, 10, 20, (LPCSTR)"\tBerechnung der doppelten Emitterschaltung:", 44, 4, tabulator, 10);
  else
	TabbedTextOut(hdc, 10, 20, (LPCSTR)"\tBerechnung der doppelten Emitterschaltung fehlerhaft!", 55, 4, tabulator, 10);

  sprintf_s(cAusgabe, 255, "Gesamtschaltung:\tDC\tAC");
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);

  // Ausgabe der Eingangswiderst�nde
  zeilennummer++;
  Bestimme_Widerstandsbezeichner(cWert1, D_ES.r_Ein_AC, 99);
  sprintf_s(cAusgabe, 255, "Eingangswiderstand:\tunendlich\t");
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  Bestimme_Widerstandsbezeichner( cWert1, D_ES.r_Aus_AC, 99);
  // printf mit Argument "%s" funktioniert nicht. Am besten eigene Funktion, die zwei Strings einf�gen kann.
  sprintf_s( cAusgabe, 255, "Ausgangswiderstand:\tunendlich\t");
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // Ausgabe der Verst�rkung
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Verst�rkung:\t");
  sprintf_s(cText, 100, "*\t");
  Bestimme_Bezeichner(cWert1, D_ES.V_U_DC_Ges, 99);
  Bestimme_Bezeichner(cWert2, D_ES.V_U_AC_Ges, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  sprintf_s(cText, 255, "\t(* ohne Koppel-C)");
  String_anhaengen(255, cAusgabe, cText);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  // Transistor T1:
  if (D_ES.NPN_T1)
	sprintf_s(cAusgabe, 255, "T1: NPN");
  else
	sprintf_s(cAusgabe, 255, "T1: PNP");
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // Ausgabe der Verst�rkung
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Verst�rkung T1:\t");
  sprintf_s(cText, 100, "*\t");
  Bestimme_Bezeichner(cWert1, D_ES.V_U_DC_T1, 99);
  Bestimme_Bezeichner(cWert2, D_ES.V_U_AC_T1, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  sprintf_s(cText, 255, "\t(* ohne Koppel-C)");
  String_anhaengen(255, cAusgabe, cText);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  // Transistor T2:
  if (D_ES.NPN_T2)
	sprintf_s(cAusgabe, 255, "T2: NPN");
  else
	sprintf_s(cAusgabe, 255, "T2: PNP");
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // Ausgabe der Verst�rkung
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Verst�rkung T2:\t");
  sprintf_s(cText, 100, "*\t");
  Bestimme_Bezeichner(cWert1, D_ES.V_U_DC_T2, 99);
  Bestimme_Bezeichner(cWert2, D_ES.V_U_AC_T2, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  sprintf_s(cText, 255, "\t(* ohne Koppel-C)");
  String_anhaengen(255, cAusgabe, cText);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);

  // Jetzt Str�me und Spannungen, vorher eine weitere Leerzeile. 
  zeilennummer+=2;

  sprintf_s(cAusgabe, 255, "Transistor T1:");
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Basisstrom I_B:\t");
  sprintf_s(cText, 100, "\tBasisspannung U_Basis:\t");
  Bestimme_Strombezeichner(cWert1, D_ES.I_B_T1, 99);
  Bestimme_Spannungsbezeichner(cWert2, D_ES.U_Basis_T1, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Kollektorstrom I_C:\t");
  sprintf_s(cText, 100, "\tKollektorspannung U_C:\t");
  Bestimme_Strombezeichner(cWert1, D_ES.I_C_T1, 99);
  Bestimme_Spannungsbezeichner(cWert2, D_ES.U_C_T1, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Emitterstrom I_E:\t");
  sprintf_s(cText, 100, "\tEmitterspannung U_E:\t");
  Bestimme_Strombezeichner(cWert1, D_ES.I_E_T1, 99);
  Bestimme_Spannungsbezeichner(cWert2, D_ES.U_E_T1, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // die weiteren Werte nach einer Leerzeile ausgeben
  zeilennummer += 2;
  sprintf_s(cAusgabe, 255, "KS-Widerstand r_BE:\t");
  Bestimme_Widerstandsbezeichner(cWert1, D_ES.r_BE_T1, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "KS-Widerstand r_CE:\t");
  Bestimme_Widerstandsbezeichner(cWert1, D_ES.r_CE_T1, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);

  zeilennummer+=2;
  sprintf_s(cAusgabe, 255, "Transistor T2:");
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Basisstrom I_B:\t");
  sprintf_s(cText, 100, "\tBasisspannung U_Basis:\t");
  Bestimme_Strombezeichner(cWert1, D_ES.I_B_T2, 99);
  Bestimme_Spannungsbezeichner(cWert2, D_ES.U_Basis_T2, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Kollektorstrom I_C:\t");
  sprintf_s(cText, 100, "\tKollektorspannung U_C:\t");
  Bestimme_Strombezeichner(cWert1, D_ES.I_C_T2, 99);
  Bestimme_Spannungsbezeichner(cWert2, D_ES.U_C_T2, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Emitterstrom I_E:\t");
  sprintf_s(cText, 100, "\tEmitterspannung U_E:\t");
  Bestimme_Strombezeichner(cWert1, D_ES.I_E_T2, 99);
  Bestimme_Spannungsbezeichner(cWert2, D_ES.U_E_T2, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // die weiteren Werte nach einer Leerzeile ausgeben
  zeilennummer += 2;
  sprintf_s(cAusgabe, 255, "KS-Widerstand r_BE:\t");
  Bestimme_Widerstandsbezeichner(cWert1, D_ES.r_BE_T2, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "KS-Widerstand r_CE:\t");
  Bestimme_Widerstandsbezeichner(cWert1, D_ES.r_CE_T2, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);

  SelectObject(hdc, hPinselAlt);
  DeleteObject(hPinselSchwarz);
  SelectObject(hdc, hStiftAlt);
  DeleteObject(hStiftSchwarz2);
  SelectObject(hdc, hFontAlt);
  DeleteObject(hFont);

  return 0;
}

int Kopiere_DoppelEmitterschaltung(Doppel_Bipolartransistor DES)
{
  HDC hdcMeta;
  HENHMETAFILE hMeta;

  hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
  // Emitterschaltung zeichnen
  Zeichne_DoppelEmitterschaltung(DES, hdcMeta, true);
  hMeta = CloseEnhMetaFile(hdcMeta);
  // Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
  OpenClipboard(hWndElektronikMain);
  EmptyClipboard();
  SetClipboardData(CF_ENHMETAFILE, hMeta);
  CloseClipboard();

  return 0;
} // end of Kopiere_Emitterschaltung


// Funktionen zur Berechnung der Kollektorschaltung 
// April 2016, M. Alles
int Kollektorschaltung_Aufruf(HWND hWnd)
{
  DialogBox(hInst, MAKEINTRESOURCE(IDD_KOLLEKTORSCHALTUNG), hWnd, KollektorSchaltung_Dialog);
  return 0;
}	// end of KOllektorschaltung

int Zeichne_ESB_Kollektorschaltung(Bipolartransistor KS, HDC hdc, bool Kopie_Zwischenablage)
{
  UNREFERENCED_PARAMETER(Kopie_Zwischenablage);

  HPEN hStiftSchwarz2, hStiftAlt;
  HBRUSH hPinselSchwarz, hPinselAlt;
  HFONT FontNeu, FontAlt;

  SetBkColor(hdc, GetSysColor(COLOR_WINDOW));
  //SetPolyFillMode(hdc, WINDING);

  hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);

  //Anschlusspunkte links und rechts, Positionen (Mitte): x: 100, 660; y: 100 ? 260; 260 - 420
  Zeichne_Anschluss(hdc, 90, 90, 160);
  Zeichne_Anschluss(hdc, 650, 250, 160);
  // Leitung f�r R1 Position: x: 180, y: 100-260
  ZP_Linie(hdc, 180, 100, 180, 260);
  // Leitung f�r R2 Position: x: 260, y: 100-260
  ZP_Linie(hdc, 260, 100, 260, 260);
  // Leitung vom Eingang zum Widerstand r_BE Position: x: 110-340, y: 100; 100-260
  ZP_Linie(hdc, 110, 100, 340, 100);
  ZP_Linie(hdc, 340, 100, 340, 260);
  // Leitung weiter bis zum Ausgang Position x: 340-650, y: 260
  ZP_Linie(hdc, 340, 260, 650, 260);
  // Leitung f�r r_CE Position: x: 480, y: 260-420
  ZP_Linie(hdc, 480, 260, 480, 420);
  // Leitung f�r R3 Position: x: 680, y: 100-260
  ZP_Linie(hdc, 580, 260, 580, 420);
  // Widerstand R1 Position: x: 160-200, y: 140-220
  Zeichne_Widerstand(hdc, 160, 140, 40, 80);
  // Widerstand R2 Position: x: 240-280, y: 140-220
  Zeichne_Widerstand(hdc, 240, 140, 40, 80);
  // Widerstand r_BE Position: x: 320-360, y: 140-220
  Zeichne_Widerstand(hdc, 320, 140, 40, 80);
  // Widerstand r_CE Position: x: 460-500, y: 300-380
  Zeichne_Widerstand(hdc, 460, 300, 40, 80);
  // Widerstand R3 Position: x: 560-600, y: 300-380
  Zeichne_Widerstand(hdc, 560, 300, 40, 80);

  // Masseanschl�sse
  // Masse f�r R1 Position x: 165-195, y: 260
  ZP_Linie(hdc, 165, 260, 195, 260);
  // Masse f�r R2 Position x: 245-275, y: 260
  ZP_Linie(hdc, 245, 260, 275, 260);
  // Masse f�r R3 Position x: 565-595, y: 420
  ZP_Linie(hdc, 565, 420, 595, 420);
  // Masse f�r r_CE Position x: 465-495, y: 420
  ZP_Linie(hdc, 465, 420, 495, 420);
  // Masse f�r Stromquelle Position x: 325-355, y: 420
  ZP_Linie(hdc, 325, 420, 355, 420);
  // Zeichnen der Stromquelle Position x: 340, y: 260-420
  ZP_Linie(hdc, 340, 260, 340, 420);
  Ellipse_BH(hdc, 310, 310, 60, 60);
  ZP_Linie(hdc, 310, 340, 370, 340);
  // Beschriftung erg�nzen
  // am besten in Arial
  FontNeu = CreateFont(24, // nHeight
	0,	// nWidth
	0,	// nEscapement
	0,	// nOrientation
	FW_DONTCARE, //fnWeight
	TRUE,	//fdwItalic
	FALSE,	//fdwUnderline
	FALSE,	//fdwStrikeOut
	DEFAULT_CHARSET,	//fdwCharSet
	OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
	CLIP_DEFAULT_PRECIS, //fdwClipPrecision
	CLEARTYPE_QUALITY,	//fdwQuality
	VARIABLE_PITCH,		//fdwPitchAndFamily
	TEXT("Arial"));	//lpszFace
  FontAlt = (HFONT)SelectObject(hdc, FontNeu);
  Zeichne_Text_xy(hdc, "R", 205, 170);
  Zeichne_Text_xy(hdc, "u", 665, 340);
  Zeichne_Text_xy(hdc, "R", 285, 170);
  Zeichne_Text_xy(hdc, "u", 105, 170);
  Zeichne_Text_xy(hdc, "R", 605, 340);
  Zeichne_Text_xy(hdc, "r", 365, 180);
  Zeichne_Text_xy(hdc, "r", 505, 340);
  Zeichne_Text_xy(hdc, "i", 290, 60);
  Zeichne_Text_xy(hdc, "i", 411, 340);
  DeleteObject(FontNeu);
  // auf Symbolschriftart
  FontNeu = CreateFont(24, 0, 0, 0, FW_DONTCARE, TRUE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Symbol"));
  SelectObject(hdc, FontNeu);
  Zeichne_Text_xy(hdc, "b", 390, 337);
  DeleteObject(FontNeu);
  FontNeu = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Arial"));
  SelectObject(hdc, FontNeu);
  Zeichne_Text_xy(hdc, "3", 619, 350);
  Zeichne_Text_xy(hdc, "BE", 375, 190);
  Zeichne_Text_xy(hdc, "2", 299, 180);
  Zeichne_Text_xy(hdc, "CE", 514, 350);
  Zeichne_Text_xy(hdc, "1", 219, 180);
  Zeichne_Text_xy(hdc, "Ein", 119, 180);
  Zeichne_Text_xy(hdc, "Aus", 679, 350);
  Zeichne_Text_xy(hdc, "B", 300, 70);
  Zeichne_Text_xy(hdc, "B", 420, 350);
  Zeichne_Text_xy(hdc, "*", 405, 340);
  if (KS.NPN) // NPN-Schaltung
  {
	// Pfeil f�r i_B x: 275-285, y: 90-110
	DP_Linie(hdc, 295, 90, 305, 100, 295, 110);
	// Pfeil f�r Stromquelle Position x: 380, y: 300-380
	ZP_Linie(hdc, 380, 300, 380, 380);
	DP_Linie(hdc, 370, 310, 380, 300, 390, 310);
	// Unterschrift
	Zeichne_Text_xy(hdc, "NPN-Kollektorschaltung: Kleinsignal-Ersatzschaltbild", 80, 450);
  }
  else
  {
	// Pfeil f�r i_B x: 275-285, y: 90-110
	DP_Linie(hdc, 305, 90, 295, 100, 305, 110);
	// Pfeil f�r Stromquelle Position x: 380, y: 300-380
	ZP_Linie(hdc, 380, 300, 380, 380);
	DP_Linie(hdc, 370, 370, 380, 380, 390, 370);
	// Unterschrift
	Zeichne_Text_xy(hdc, "PNP-Kollektorschaltung: Kleinsignal-Ersatzschaltbild", 80, 450);
  }
  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

  // Verbindungspunkte: Positionen: 180, 100; 260, 100; 340, 260; 480, 260; 580, 260
  Ellipse_BH(hdc, 175, 95, 10, 10);
  Ellipse_BH(hdc, 255, 95, 10, 10);
  Ellipse_BH(hdc, 335, 255, 10, 10);
  Ellipse_BH(hdc, 475, 255, 10, 10);
  Ellipse_BH(hdc, 575, 255, 10, 10);

  DeleteObject(FontNeu);
  SelectObject(hdc, hPinselAlt);
  DeleteObject(hPinselSchwarz);
  SelectObject(hdc, hStiftAlt);
  DeleteObject(hStiftSchwarz2);

  return 0;
} // end of Zeichne_ESB_Kollektorschaltung

int Zeichne_Kollektorschaltung(Bipolartransistor KS, HDC hdc, bool Kopie_Zwischenablage)
{
  UNREFERENCED_PARAMETER(Kopie_Zwischenablage);

  HPEN hStiftSchwarz2, hStiftAlt;
  HBRUSH hPinselSchwarz, hPinselAlt;
  HFONT FontNeu = NULL, FontAlt = NULL;
  char cText[100];

  SetTextColor(hdc, RGB(0, 0, 0));
  if (Kopie_Zwischenablage)
  {
	// Beschriftung erg�nzen, am besten in Arial
	FontNeu = Erstelle_Font_Arial( hdc, 24 );
	FontAlt = (HFONT)SelectObject(hdc, FontNeu);
	SetTextAlign(hdc, TA_LEFT);
  }

  hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
  // F�llfarbe vorher auf Schwarz
  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

  // Verbindungspunkte vorab														
  Ellipse_BH(hdc, 195, 175, 10, 10);
  Ellipse_BH(hdc, 295, 5, 10, 10);

  // Wieder auf wei�en Hintergrund umschalten
  SelectObject(hdc, hPinselAlt);

  //Anschlusspunkte links und rechts, Positionen (Mitte): x: 45; 710; y: 180; 330
  Zeichne_Anschluss(hdc, 35, 170, 150);
  // Leitung f�r Kondensator C_Ein Position: x: 55-100 und 120-250, y: 180
  ZP_Linie(hdc, 55, 180, 100, 180);
  ZP_Linie(hdc, 120, 180, 250, 180);
  // Eingangskondensator Position: x: 100, 120 y: 130-230
  Zeichne_Kondensator(hdc, 100, 130, 20, 100, C_HORIZONTAL);
  Zeichne_Gleichspannungsquelle(hdc, 590, 50, 60, true, 40);
  // Leitung f�r R1, R2 und U_B:
  VP_Linie(hdc, 200, 330, 200, 10, 620, 10, 620, 150);
  // Masse f�r R2 Position 185-215, 330
  ZP_Linie(hdc, 185, 330, 215, 330);

  if (Kopie_Zwischenablage)
  { // Ausgabe Zwischenablage
	// Beschriftung f�r R1 und R2
	Zeichne_Text_xy(hdc, "R1", 220, 50);
	Bestimme_Widerstandsbezeichner(cText, Kollektor_Schaltung.R[R_BASIS_UB], 99);
	Zeichne_Text_xy(hdc, cText, 220, 75);
	SetTextAlign(hdc, TA_RIGHT);
	Zeichne_Text_xy(hdc, "R2", 180, 245);
	Bestimme_Widerstandsbezeichner(cText, Kollektor_Schaltung.R[R_BASIS_UB], 99);
	Zeichne_Text_xy(hdc, cText, 180, 270);
	// Beschriftung f�r C1
	Zeichne_Text_xy(hdc, "C1", 95, 128);
	Bestimme_Kapazitaetsbezeichner(cText, Kollektor_Schaltung.C[C_EIN], 99);
	Zeichne_Text_xy(hdc, cText, 95, 153);
	// Beschrfitung f�r U_B
	Zeichne_Text_xy(hdc, "U_B", 575, 50);
	Bestimme_Spannungsbezeichner(cText, Kollektor_Schaltung.U_B, 99);
	Zeichne_Text_xy(hdc, cText, 575, 75);
	// Beschriftung f�r T1
	SetTextAlign(hdc, TA_LEFT);
	Zeichne_Text_xy(hdc, "T1", 300, 170);
	// Beschriftung f�r U_Ein
	Zeichne_Text_xy(hdc, "U_Ein", 50, 240);
  }
  else
  { // Ausgabe Dialogbox
	// Beschriftung f�r R1 und R2
	Zeichne_Text_xy(hdc, "R1", 220, 50);
	Zeichne_Text_xy(hdc, "R2", 159, 240);
	// Beschriftung f�r C1
	Zeichne_Text_xy(hdc, "C1", 80, 158);
  }
  //Widerst�nde R1, R2 Positionen: x=185, y=50, 240:
  Zeichne_Widerstand(hdc, 185, 50, 30, 60);
  Zeichne_Widerstand(hdc, 185, 240, 30, 60);
  // Leitung f�r R3 Postion: x: 300; y: 10-130
  ZP_Linie(hdc, 300, 10, 300, 130);
  // Leitung f�r R4, R5 Position: x: 300, y: 230-410
  ZP_Linie(hdc, 300, 230, 300, 410);
  // Masseanschluss f�r R5 Position: x: 285315, y: 410
  ZP_Linie(hdc, 285, 410, 315, 410);

  if (KS.NPN)  //NPN-Transistor
  {
	// F�llfarbe schwarz
	SelectObject(hdc, hPinselSchwarz);
	// Verbindungspunkt
	Ellipse_BH(hdc, 295, 225, 10, 10);
	// Transistor (NPN) Position: x: 250 (250-300) y: 130-230
	Zeichne_Bipolartransistor(hdc, 250, 130, 50, 100, Kollektor_Schaltung.NPN, 0);
	SelectObject(hdc, hPinselAlt);
	if (Kopie_Zwischenablage)
	{ // Ausgabe Zwischenabage
	  // Beschriftung R3, C2:
	  Zeichne_Text_xy(hdc, "C2", 380, 175);
	  Bestimme_Kapazitaetsbezeichner(cText, Kollektor_Schaltung.C[C_AUS], 99);
	  Zeichne_Text_xy(hdc, cText, 380, 200);
	  Zeichne_Text_xy(hdc, "R3", 320, 295);
	  Bestimme_Widerstandsbezeichner(cText, Kollektor_Schaltung.R[2], 99);
	  Zeichne_Text_xy(hdc, cText, 320, 320);
	  // Beschriftung U_Aus
	  Zeichne_Text_xy(hdc, "U_Aus", 440, 285);
	}
	else
	{ // Ausgabe Dialogbox
	  // Beschriftung R3, C2:
	  Zeichne_Text_xy(hdc, "C2", 330, 235);
	  Zeichne_Text_xy(hdc, "R3", 259, 290);
	}

	// Widerstand R3 Position: x=285, y= 290
	Zeichne_Widerstand(hdc, 285, 290, 30, 60);
	// Leitung f�r Ausgangskondensator x: 300-350 und 370-420, y: 230
	ZP_Linie(hdc, 300, 230, 350, 230);
	ZP_Linie(hdc, 370, 230, 420, 230);
	// Ausgangskondensator zeichnen x: 350, 370, y: 180-280
	Zeichne_Kondensator(hdc, 350, 180, 20, 100, C_HORIZONTAL);
	// Ausgangsanschluss mit Verbindungspunkt x: 420-440, y: 220-240 bzw. y: 370-390
	Zeichne_Anschluss(hdc, 420, 220, 150);
  }
  else // PNP-Transistor zeichnen
  {
	// Zeichnen der Verbindungspunkte und des Dreiecks vom "PNP-Pfeil" des Transistors
	// schwarze F�llung
	SelectObject(hdc, hPinselSchwarz);
	// Transistor (PNP) Position: x: 250 (250-300) y: 130-230
	Zeichne_Bipolartransistor(hdc, 250, 130, 50, 100, Kollektor_Schaltung.NPN, 0);
	// Verbindungspunkte
	Ellipse_BH(hdc, 295, 125, 10, 10);
	SelectObject(hdc, hPinselAlt);
	if (Kopie_Zwischenablage)
	{ // Ausgabe Zwischenablage
	  // Beschriftung R3 und C2:
	  Zeichne_Text_xy(hdc, "C2", 380, 75);
	  Bestimme_Kapazitaetsbezeichner(cText, Kollektor_Schaltung.C[C_AUS], 99);
	  Zeichne_Text_xy(hdc, cText, 380, 100);
	  Zeichne_Text_xy(hdc, "R3", 320, 35);
	  Bestimme_Widerstandsbezeichner(cText, Kollektor_Schaltung.R[2], 99);
	  Zeichne_Text_xy(hdc, cText, 320, 58);
	  // Beschriftung U_Aus
	  SetTextAlign(hdc, TA_RIGHT);
	  Zeichne_Text_xy(hdc, "U_Aus", 505, 185);
	}
	else
	{ // Ausgabe Dialogbox
	  // Beschriftung R3 und C2:
	  Zeichne_Text_xy(hdc, "C2", 330, 135);
	  Zeichne_Text_xy(hdc, "R3", 320, 80);
	}
	// Widerstand R3 Position: x=285, y= 20
	Zeichne_Widerstand(hdc, 285, 40, 30, 60);
	// Leitung f�r Ausgangskondensator x: 300-350 und 370-420, y: 130
	ZP_Linie(hdc, 300, 130, 350, 130);
	ZP_Linie(hdc, 370, 130, 420, 130);
	// Ausgangskondensator zeichnen x: 350, 370, y: 80-180
	Zeichne_Kondensator(hdc, 350, 80, 20, 100, C_HORIZONTAL);
	// Ausgangsanschluss mit Verbindungspunkt x: 420-440, y: 120-140 bzw. y: 270-290
	Zeichne_Anschluss(hdc, 420, 120, 150);
  }

  if (Kopie_Zwischenablage)
  {
	SelectObject(hdc, FontAlt);
	DeleteObject(FontNeu);
  }

  SelectObject(hdc, hPinselAlt);
  DeleteObject(hPinselSchwarz);
  SelectObject(hdc, hStiftAlt);
  DeleteObject(hStiftSchwarz2);

  return 0;
} // end of Zeichne_Kollektorschaltung

int Ergebnis_Kollektorschaltung(HWND hDlg)
{
  // Berechnung der Kollektorschaltung
  Berechne_Kollektorschaltung();
  DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_BIPOLARSCHALTUNG), hDlg, ErgebnisKollektorSchaltung_Dialog);


  return 0;
}	// end of Ergebnis_Kollektorschaltung

int ESB_Kollektorschaltung(HWND hDlg)
{
  DialogBox(hInst, MAKEINTRESOURCE(IDD_ESB_BIPOLARSCHALTUNG), hDlg, ESB_KollektorSchaltung_Dialog);

  return 0;
}	// end of ESB_Kollektorschaltung

int Kopiere_Kollektorschaltung(Bipolartransistor KS)
{
  HDC hdcMeta;
  HENHMETAFILE hMeta;

  hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
  // Kollektorschaltung zeichnen
  Zeichne_Kollektorschaltung(KS, hdcMeta, true);
  hMeta = CloseEnhMetaFile(hdcMeta);
  // Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
  OpenClipboard(hWndElektronikMain);
  EmptyClipboard();
  SetClipboardData(CF_ENHMETAFILE, hMeta);
  CloseClipboard();

  return 0;
} // end of Kopiere_Kollektorschaltung

int Berechne_Kollektorschaltung(void)
{
  // DC Ein- und Ausgangswiderstand ist generell unendlich und muss nicht gespeichert werden.

  // Generell ist die Schaltung ersteinmal berechenbar:
  Kollektor_Schaltung.Schaltung_berechenbar = true;
  // Berechnung NPN-Transistor

  if (Kollektor_Schaltung.NPN) //NPN-Typ
  {
	// Basisstrom f�r NPN?Transistor berechnen
	Kollektor_Schaltung.I_B = Basisstrom_NPN(Kollektor_Schaltung.R[R_BASIS_UB], Kollektor_Schaltung.R[R_BASIS_GND], Kollektor_Schaltung.R[R_EMITTER_KS], 0.0, Kollektor_Schaltung.U_BE, Kollektor_Schaltung.U_B, Kollektor_Schaltung.Beta);
	if (Kollektor_Schaltung.I_B < 0)
	{
	  // Falls der Basisstrom negativ ist, sind auch Kollektor? und Emitterstrom nicht bestimmbar.Das Gleiche gilt f�r die Spannungen...
	  Kollektor_Schaltung.Schaltung_berechenbar = false;
	}
	else
	{
	  // Kollektorstrom
	  Kollektor_Schaltung.I_C = Kollektor_Schaltung.I_B * Kollektor_Schaltung.Beta;
	  // Emitterstrom
	  Kollektor_Schaltung.I_E = Kollektor_Schaltung.I_B * (Kollektor_Schaltung.Beta + 1.0);
	  // Kollektorspannung NPN
	  Kollektor_Schaltung.U_C = Kollektor_Schaltung.U_B;
	  // Emitterspannung NPN
	  Kollektor_Schaltung.U_E = Kollektor_Schaltung.I_E * Kollektor_Schaltung.R[R_EMITTER_KS];
	  // Kollektorspannung muss h�her als Emitterspannung sein
	  if (Kollektor_Schaltung.U_E > Kollektor_Schaltung.U_C)
		Kollektor_Schaltung.Schaltung_berechenbar = false;
	  // Basisspannung
	  Kollektor_Schaltung.U_Basis = Kollektor_Schaltung.U_E + Kollektor_Schaltung.U_BE;
	  // Kleinsignalwiderst�nde
	  Kollektor_Schaltung.r_BE = r_BE(Kollektor_Schaltung.I_B, U_T(Kollektor_Schaltung.T, Kollektor_Schaltung.Naeherung_U_T));
	  Kollektor_Schaltung.r_CE = r_CE(Kollektor_Schaltung.U_C - Kollektor_Schaltung.U_E, Kollektor_Schaltung.U_AF, Kollektor_Schaltung.I_C);
	  // AC-Ausgangswiderstand
	  Kollektor_Schaltung.r_Aus_AC = AC_Ausgangswiderstand_C(Kollektor_Schaltung.R[R_EMITTER_KS], Kollektor_Schaltung.r_BE, Kollektor_Schaltung.r_CE, Kollektor_Schaltung.Beta, Kollektor_Schaltung.Naeherung_r_CE);
	  // AC-Eingangswiderstand
	  Kollektor_Schaltung.r_Ein_AC = AC_Eingangswiderstand_C(Kollektor_Schaltung.R[R_BASIS_UB], Kollektor_Schaltung.R[R_BASIS_GND], Kollektor_Schaltung.R[R_EMITTER_KS], Kollektor_Schaltung.r_BE, Kollektor_Schaltung.r_CE, Kollektor_Schaltung.Beta, Kollektor_Schaltung.Naeherung_r_CE);
	  // AC-Verst�rkung
	  Kollektor_Schaltung.V_U_AC = V_U_AC_C(Kollektor_Schaltung.R[R_EMITTER_KS], Kollektor_Schaltung.r_BE, Kollektor_Schaltung.r_CE, Kollektor_Schaltung.Beta, Kollektor_Schaltung.Naeherung_r_CE);
	}
  }
  else
  {
	// Basisstrom f�r PNP-Transistor berechnen
	Kollektor_Schaltung.I_B = Basisstrom_PNP(Kollektor_Schaltung.R[R_BASIS_UB], Kollektor_Schaltung.R[R_BASIS_GND], Kollektor_Schaltung.R[R_EMITTER_KS], 0.0, Kollektor_Schaltung.U_BE, Kollektor_Schaltung.U_B, Kollektor_Schaltung.Beta);
	if (Kollektor_Schaltung.I_B < 0)
	{
	  // Falls der Basisstrom negativ ist, sind auch Kollektor- und Emitterstrom nicht bestimmbar.Das Gleiche gilt f�r die Spannungen...
	  Kollektor_Schaltung.Schaltung_berechenbar = false;
	}
	else
	{
	  // Kollektorstrom
	  Kollektor_Schaltung.I_C = Kollektor_Schaltung.I_B*Kollektor_Schaltung.Beta;
	  // Emitterstrom
	  Kollektor_Schaltung.I_E = Kollektor_Schaltung.I_B*(Kollektor_Schaltung.Beta + 1.0);
	  // Kollektorspannung PNP
	  Kollektor_Schaltung.U_C = 0.0;
	  // Emitterspannung PNP
	  Kollektor_Schaltung.U_E = Kollektor_Schaltung.U_B - Kollektor_Schaltung.I_E*Kollektor_Schaltung.R[R_EMITTER_KS];
	  // Basisspannung
	  Kollektor_Schaltung.U_Basis = Kollektor_Schaltung.U_E - Kollektor_Schaltung.U_BE;
	  // Kleinsignalwiderst�nde
	  Kollektor_Schaltung.r_BE = r_BE(Kollektor_Schaltung.I_B, U_T(Kollektor_Schaltung.T, Kollektor_Schaltung.Naeherung_U_T));
	  Kollektor_Schaltung.r_CE = r_CE(Kollektor_Schaltung.U_E - Kollektor_Schaltung.U_C, Kollektor_Schaltung.U_AF, Kollektor_Schaltung.I_C);
	  // AC-Ausgangswiderstand
	  Kollektor_Schaltung.r_Aus_AC = AC_Ausgangswiderstand_C(Kollektor_Schaltung.R[R_EMITTER_KS], Kollektor_Schaltung.r_BE, Kollektor_Schaltung.r_CE, Kollektor_Schaltung.Beta, Kollektor_Schaltung.Naeherung_r_CE);
	  // AC-Eingangswiderstand
	  Kollektor_Schaltung.r_Ein_AC = AC_Eingangswiderstand_C(Kollektor_Schaltung.R[R_BASIS_UB], Kollektor_Schaltung.R[R_BASIS_GND], Kollektor_Schaltung.R[R_EMITTER_KS], Kollektor_Schaltung.r_BE, Kollektor_Schaltung.r_CE, Kollektor_Schaltung.Beta, Kollektor_Schaltung.Naeherung_r_CE);
	  // AC-Verst�rkung
	  Kollektor_Schaltung.V_U_AC = V_U_AC_C(Kollektor_Schaltung.R[R_EMITTER_KS], Kollektor_Schaltung.r_BE, Kollektor_Schaltung.r_CE, Kollektor_Schaltung.Beta, Kollektor_Schaltung.Naeherung_r_CE);
	}
  }
  if (Kollektor_Schaltung.I_B<0.0)
	Kollektor_Schaltung.Schaltung_berechenbar=false;
  return 0;
}	// end of Berechne_Kollektorschaltung

int Zeichne_Ausgabe_Kollektorschaltung(Bipolartransistor KS, HDC hdc, bool Kopie_Zwischenablage)
{
  UNREFERENCED_PARAMETER (Kopie_Zwischenablage);
  HPEN hStiftSchwarz2, hStiftAlt;
  HBRUSH hPinselSchwarz, hPinselAlt;
  HFONT hFontAlt, hFont;
  int zeilennummer = 2, tabulator[5];
  char cAusgabe[255], cText[100], cWert1[100], cWert2[100];

  hFont = Erstelle_Font_Arial(hdc, 20);
  hFontAlt = (HFONT)SelectObject(hdc, hFont);
  tabulator[0] = 200;
  tabulator[1] = 300;
  tabulator[2] = 500;
  tabulator[3] = 600;

  SetPolyFillMode(hdc, WINDING);

  hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

  // passenden Transistor zeichnen
  Zeichne_Bipolartransistor(hdc, 600, 50, 50, 100, KS.NPN, 20);
  // Ausgabe der Ergebnisse
  // Ausgabe der Ergebnisse.
  if (KS.Schaltung_berechenbar)
	TabbedTextOut(hdc, 10, 20, (LPCSTR)"\tBerechnung der Kollektorschaltung:", 35, 4, tabulator, 10);
  else
	TabbedTextOut(hdc, 10, 20, (LPCSTR)"\tBerechnung der Kollektorschaltung fehlerhaft!", 47, 4, tabulator, 10);
  // N�chste Zeile, also eine Art �berschrift
  if (KS.NPN)
	sprintf_s(cAusgabe, 255, "NPN\tDC\tAC");
  else
	sprintf_s(cAusgabe, 255, "PNP\tDC\tAC");
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // Ausgabe der Eingangswiderst�nde
  zeilennummer++;
  Bestimme_Widerstandsbezeichner(cWert1, KS.r_Ein_AC, 99);
  sprintf_s(cAusgabe, 255, "Eingangswiderstand:\tunendlich\t");
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  Bestimme_Widerstandsbezeichner(cWert1, KS.r_Aus_AC, 99);
  // printf mit Argument "%s" funktioniert nicht. Am besten eigene Funktion, die zwei Strings einf�gen kann.
  sprintf_s(cAusgabe, 255, "Ausgangswiderstand:\tunendlich\t");
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // Ausgabe der Verst�rkung
  sprintf_s(cAusgabe, 255, "Verst�rkung:\t-/-\t");
  Bestimme_Bezeichner(cWert1, KS.V_U_AC, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  zeilennummer++;
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // Jetzt Str�me und Spannungen, vorher eine weitere Leerzeile. 
  zeilennummer += 3;
  sprintf_s(cAusgabe, 255, "Basisstrom I_B:\t");
  sprintf_s(cText, 100, "\tBasisspannung U_Basis:\t");
  Bestimme_Strombezeichner(cWert1, KS.I_B, 99);
  Bestimme_Spannungsbezeichner(cWert2, KS.U_Basis, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Kollektorstrom I_C:\t");
  sprintf_s(cText, 100, "\tKollektorspannung U_C:\t");
  Bestimme_Strombezeichner(cWert1, KS.I_C, 99);
  Bestimme_Spannungsbezeichner(cWert2, KS.U_C, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Emitterstrom I_E:\t");
  sprintf_s(cText, 100, "\tEmitterspannung U_E:\t");
  Bestimme_Strombezeichner(cWert1, KS.I_E, 99);
  Bestimme_Spannungsbezeichner(cWert2, KS.U_E, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // die weiteren Werte nach einer Leerzeile ausgeben
  zeilennummer += 2;
  sprintf_s(cAusgabe, 255, "KS-Widerstand r_BE:\t");
  Bestimme_Widerstandsbezeichner(cWert1, KS.r_BE, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "KS-Widerstand r_CE:\t");
  Bestimme_Widerstandsbezeichner(cWert1, KS.r_CE, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);

  SelectObject(hdc, hPinselAlt);
  DeleteObject(hPinselSchwarz);
  SelectObject(hdc, hStiftAlt);
  DeleteObject(hStiftSchwarz2);
  SelectObject(hdc, hFontAlt);
  DeleteObject(hFont);

  return 0;
}

int Kopiere_ESB_Kollektorschaltung(Bipolartransistor KS)
{
  HDC hdcMeta;
  HENHMETAFILE hMeta;

  hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
  // ESB-Kollektorschaltung zeichnen
  Zeichne_ESB_Kollektorschaltung(KS, hdcMeta, true);
  hMeta = CloseEnhMetaFile(hdcMeta);
  // Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
  OpenClipboard(hWndElektronikMain);
  EmptyClipboard();
  SetClipboardData(CF_ENHMETAFILE, hMeta);
  CloseClipboard();

  return 0;
} // end of Kopiere_ESB_Kollektorschaltung

double AC_Eingangswiderstand_C(double R_Basis1, double R_Basis2, double R_Emitter, double r_BE, double r_CE, double beta, bool N�herung_r_CE)
{
  // Berechnung des Kleinsignal-Eingangswiderstandes f�r eine unendliche hohe Frequenz
  // Eingabeparameter: Widerstandswerte des Basisspannungsteilers R1 und R2,
  // Basisstrom IB, Emitterwiderstand, Stromverst�rkung und Temperaturspannung

  double ergebnis, hilfs_widerstand;

  ergebnis = 1.0 / R_Basis1 + 1.0 / R_Basis2;
  if (N�herung_r_CE)
	hilfs_widerstand = r_BE + (beta + 1)*R_Emitter;
  else
	hilfs_widerstand = r_BE + (beta + 1)*Parallelschaltung(R_Emitter, r_CE);
  ergebnis += 1.0 / hilfs_widerstand;	// Hier sind jetzt die drei Leitwerte addiert
  ergebnis = 1.0 / ergebnis;			// Kehrwert...

  return ergebnis;
} // end of AC_Eingangswiderstand_C

double AC_Ausgangswiderstand_C(double R_Emitter, double r_BE, double r_CE, double beta, bool N�herung_r_CE)
{
  // Berechnung des AC-Ausgangswiderstands
  // ist eine Erg�nzung R_E||r_CE sinnvoll?

  double ergebnis;

  if (N�herung_r_CE)
	ergebnis = 1.0 / R_Emitter + beta / r_BE; // Die Kehrwerte werden addiert, das gilt auch f�r r_BE/beta!
  else
	ergebnis = 1.0 / R_Emitter + beta / r_BE + 1.0 / r_CE;
  ergebnis = 1.0 / ergebnis;

  return ergebnis;
} // end of AC_Ausgangswiderstand

double V_U_AC_C(double R3, double r_BE, double r_CE, double beta, bool r_CE_hochohmig)
{
  // Berechnung der Verst�rkung: 
  // M. Alles, 21. April 2016
  double ergebnis, hilf;

  if (r_CE_hochohmig)
	hilf = R3;
  else
	hilf = Parallelschaltung(R3, r_CE);

  ergebnis = (beta + 1.0)*hilf / (r_BE + (beta + 1.0)*hilf);

  return ergebnis;
} // end of VU_AC_C

// Funktionen zur Berechnung der Basisschaltung 
// April 2016, M. Alles

int Zeichne_ESB_Basisschaltung(Bipolartransistor BS, HDC hdc, bool Kopie_Zwischenablage)
{
  UNREFERENCED_PARAMETER(Kopie_Zwischenablage);

  HPEN hStiftSchwarz2, hStiftAlt;
  HBRUSH hPinselSchwarz, hPinselAlt;
  HFONT FontNeu, FontAlt;

  SetBkColor(hdc, GetSysColor(COLOR_WINDOW));
  //SetPolyFillMode(hdc, WINDING);
  SetTextColor(hdc, RGB(0, 0, 0));
  hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);

  //Anschlusspunkte links und rechts, Positionen (Mitte): x: 100, 580; y: 100 - 260; 260 - 420
  Zeichne_Anschluss(hdc, 90, 90, 160);
  Zeichne_Anschluss(hdc, 570, 250, 160);
  // Leitung f�r R4 Position: x: 180, y: 100-260
  ZP_Linie(hdc, 180, 100, 180, 260);
  // Leitung f�r r_BE Position: x: 260, y: 100-260
  ZP_Linie(hdc, 260, 100, 260, 260);
  // Leitung vom Eingang zum Widerstand R_3 Position: x: 110-480, y: 100; 100-420
  ZP_Linie(hdc, 110, 100, 480, 100);
  ZP_Linie(hdc, 480, 100, 480, 420);
  // Leitung von Stromquelle bis zum Ausgang Position x: 340-570, y: 100-260
  ZP_Linie(hdc, 340, 100, 340, 260);
  ZP_Linie(hdc, 340, 260, 570, 260);
  // Widerstand R4 Position: x: 160-200, y: 140-220
  Zeichne_Widerstand(hdc, 160, 140, 40, 80);
  // Widerstand r_BE Position: x: 240-280, y: 140-220
  Zeichne_Widerstand(hdc, 240, 140, 40, 80);
  // Widerstand r_CE Position: x: 460-500, y: 140-220
  Zeichne_Widerstand(hdc, 460, 140, 40, 80);
  // Widerstand R3 Position: x: 460-500, y: 300-380
  Zeichne_Widerstand(hdc, 460, 300, 40, 80);

  // Masseanschl�sse
  // Masse f�r R4 Position x: 165-195, y: 260
  ZP_Linie(hdc, 165, 260, 195, 260);
  // Masse f�r r_BE Position x: 245-275, y: 260
  ZP_Linie(hdc, 245, 260, 275, 260);
  // Masse f�r R3 Position x: 465-495, y: 420
  ZP_Linie(hdc, 465, 420, 495, 420);
  // Zeichnen der Stromquelle Position x: 340, y: 150-210
  Ellipse_BH(hdc, 310, 150, 60, 60);	// wei� gef�llt
  ZP_Linie(hdc, 310, 180, 370, 180);
  // Beschriftung erg�nzen
  // am besten in Arial
  FontNeu = CreateFont(24, // nHeight
	0,	// nWidth
	0,	// nEscapement
	0,	// nOrientation
	FW_DONTCARE, //fnWeight
	TRUE,	//fdwItalic
	FALSE,	//fdwUnderline
	FALSE,	//fdwStrikeOut
	DEFAULT_CHARSET,	//fdwCharSet
	OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
	CLIP_DEFAULT_PRECIS, //fdwClipPrecision
	CLEARTYPE_QUALITY,	//fdwQuality
	VARIABLE_PITCH,		//fdwPitchAndFamily
	TEXT("Arial"));	//lpszFace
  FontAlt = (HFONT)SelectObject(hdc, FontNeu);
  Zeichne_Text_xy(hdc, "R", 205, 170);
  Zeichne_Text_xy(hdc, "r", 285, 210);
  Zeichne_Text_xy(hdc, "u", 105, 170);
  Zeichne_Text_xy(hdc, "u", 588, 340);
  Zeichne_Text_xy(hdc, "R", 510, 330);
  Zeichne_Text_xy(hdc, "r", 505, 170);
  Zeichne_Text_xy(hdc, "i", 275, 110);
  Zeichne_Text_xy(hdc, "*i", 403, 170);
  DeleteObject(FontNeu);
  // auf Symbolschriftart
  FontNeu = CreateFont(24, 0, 0, 0, FW_DONTCARE, TRUE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Symbol"));
  SelectObject(hdc, FontNeu);
  Zeichne_Text_xy(hdc, "b", 390, 167);
  DeleteObject(FontNeu);
  FontNeu = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Arial"));
  SelectObject(hdc, FontNeu);
  Zeichne_Text_xy(hdc, "Ein", 120, 180);
  Zeichne_Text_xy(hdc, "Aus", 600, 350);
  Zeichne_Text_xy(hdc, "B", 285, 120);
  Zeichne_Text_xy(hdc, "B", 421, 180);
  Zeichne_Text_xy(hdc, "BE", 295, 220);
  Zeichne_Text_xy(hdc, "CE", 515, 180);

  if (BS.NPN) // NPN-Schaltung
  {
	// Pfeil f�r i_B x: 250?270, y: 115?125
	DP_Linie(hdc, 250, 115, 260, 125, 270, 115);
	// Pfeil f�r Stromquelle Position x: 380, y: 140?220
	ZP_Linie(hdc, 380, 140, 380, 220);
	DP_Linie(hdc, 370, 210, 380, 220, 390, 210);
	// Beschriftung R3 und R4 erg�nzen
	Zeichne_Text_xy(hdc, "3", 525, 340);
	Zeichne_Text_xy(hdc, "4", 220, 180);
	// Unterschrift
	Zeichne_Text_xy(hdc, "NPN-Basisschaltung: Kleinsignal-Ersatzschaltbild", 80, 430);
  }
  else	// PNP-Schaltung
  {
	// Pfeil f�r i_B x: 250-270, y: 115-125
	DP_Linie(hdc, 250, 125, 260, 115, 270, 125);
	// Pfeil f�r Stromquelle Position x: 380, y: 140?220
	ZP_Linie(hdc, 380, 140, 380, 220);
	DP_Linie(hdc, 370, 150, 380, 140, 390, 150);
	// Beschriftung R3 und R4 erg�nzen
	Zeichne_Text_xy(hdc, "4", 530, 340);
	Zeichne_Text_xy(hdc, "3", 220, 180);
	// Unterschrift
	Zeichne_Text_xy(hdc, "PNP-Basisschaltung: Kleinsignal-Ersatzschaltbild", 80, 430);
  }

  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

  // Verbindungspunkte: Positionen: 180, 100; 260, 100; 340, 100; 480, 260
  Ellipse_BH(hdc, 175, 95, 10, 10);
  Ellipse_BH(hdc, 255, 95, 10, 10);
  Ellipse_BH(hdc, 335, 95, 10, 10);
  Ellipse_BH(hdc, 475, 255, 10, 10);

  DeleteObject(FontNeu);
  SelectObject(hdc, hPinselAlt);
  DeleteObject(hPinselSchwarz);
  SelectObject(hdc, hStiftAlt);
  DeleteObject(hStiftSchwarz2);

  return 0;
} // end of Zeichne_ESB_Basisschaltung
int Berechne_Basisschaltung(void)
{
  // DC Ein- und Ausgangswiderstand ist generell unendlich und wird nicht berechnet
  // Generell treten erst einmal keine Fehler auf:
  Basis_Schaltung.Schaltung_berechenbar = true;

  if (Basis_Schaltung.NPN)	// NPN-Schaltung
  {
	Basis_Schaltung.I_B = Basisstrom_NPN(Basis_Schaltung.R[R_BASIS_UB], Basis_Schaltung.R[R_BASIS_GND], Basis_Schaltung.R[R_EMITTER_BS_NPN], 0.0, Basis_Schaltung.U_BE, Basis_Schaltung.U_B, Basis_Schaltung.Beta);
	if (Basis_Schaltung.I_B < 0.0)
	{
	  // negativer Basisstrom: Schaltung nicht berechnenbar
	  Basis_Schaltung.Schaltung_berechenbar = false;
	}
	else
	{
	  // Kollektorstrom
	  Basis_Schaltung.I_C = Basis_Schaltung.I_B * Basis_Schaltung.Beta;
	  // Emitterstrom
	  Basis_Schaltung.I_E = Basis_Schaltung.I_B * (Basis_Schaltung.Beta + 1.0);
	  // Kollektorspannung NPN
	  Basis_Schaltung.U_C = Basis_Schaltung.U_B - Basis_Schaltung.I_C * Basis_Schaltung.R[R_KOLLEKTOR_BS_NPN];
	  // Emitterspannung NPN
	  Basis_Schaltung.U_E = Basis_Schaltung.I_E * Basis_Schaltung.R[R_EMITTER_BS_NPN];
	  // Basisspannung
	  Basis_Schaltung.U_Basis = Basis_Schaltung.U_E + Basis_Schaltung.U_BE;
	  // Kleinsignalwiderst�nde
	  Basis_Schaltung.r_BE = r_BE(Basis_Schaltung.I_B, U_T(Basis_Schaltung.T, Basis_Schaltung.Naeherung_U_T));
	  Basis_Schaltung.r_CE = r_CE(Basis_Schaltung.U_C - Basis_Schaltung.U_E, Basis_Schaltung.U_AF, Basis_Schaltung.I_C);
	  // AC-Eingangswiderstand
	  Basis_Schaltung.r_Ein_AC = AC_Eingangswiderstand_B(Basis_Schaltung.R[R_EMITTER_BS_NPN], Basis_Schaltung.R[R_KOLLEKTOR_BS_NPN], Basis_Schaltung.r_BE, Basis_Schaltung.r_CE, Basis_Schaltung.Beta, Basis_Schaltung.Naeherung_r_CE);
	  // AC-Ausgangswiderstand
	  Basis_Schaltung.r_Aus_AC = AC_Ausgangswiderstand_B(Basis_Schaltung.R[R_KOLLEKTOR_BS_NPN], Basis_Schaltung.R[R_EMITTER_BS_NPN], Basis_Schaltung.r_BE, Basis_Schaltung.r_CE, Basis_Schaltung.Beta, Basis_Schaltung.Naeherung_r_CE);
	  // AC-Verst�rkung
	  Basis_Schaltung.V_U_AC = V_U_AC_B(Basis_Schaltung.R[R_KOLLEKTOR_BS_NPN], Basis_Schaltung.r_BE, Basis_Schaltung.r_CE, Basis_Schaltung.Beta, Basis_Schaltung.Naeherung_r_CE);
	  // DC-Verst�rkung gibt es hier nicht sinnvoll.
	}
  }
  if (!Basis_Schaltung.NPN)
  {
	Basis_Schaltung.I_B = Basisstrom_PNP(Basis_Schaltung.R[R_BASIS_UB], Basis_Schaltung.R[R_BASIS_GND], Basis_Schaltung.R[R_EMITTER_BS_PNP], 0.0, Basis_Schaltung.U_BE, Basis_Schaltung.U_B, Basis_Schaltung.Beta);
	if (Basis_Schaltung.I_B < 0)
	{
	  // Falls der Basisstrom negativ ist, sind auch Kollektor? und Emitterstrom nicht bestimmbar.Das Gleiche gilt f�r die Spannungen...
	  Basis_Schaltung.Schaltung_berechenbar = false;
	}
	else
	{
	  // Kollektorstrom
	  Basis_Schaltung.I_C = Basis_Schaltung.I_B * Basis_Schaltung.Beta;
	  // Emitterstrom
	  Basis_Schaltung.I_E = Basis_Schaltung.I_B * (Basis_Schaltung.Beta + 1.0);
	  // Kollektorspannung PNP
	  Basis_Schaltung.U_C = Basis_Schaltung.I_C * Basis_Schaltung.R[R_KOLLEKTOR_BS_PNP];
	  // Emitterspannung PNP
	  Basis_Schaltung.U_E = Basis_Schaltung.U_B - Basis_Schaltung.I_E * Basis_Schaltung.R[R_EMITTER_BS_PNP];
	  // Kontrolle: Kollektorspannung muss hier niedriger als Emitterspannung sein, sonst stimmt die Berechnung nicht
	  if (Basis_Schaltung.U_E < Basis_Schaltung.U_C)
		Basis_Schaltung.Schaltung_berechenbar = false;
	  // Basisspannung
	  Basis_Schaltung.U_Basis = Basis_Schaltung.U_E - Basis_Schaltung.U_BE;
	  // Kleinsignalwiderst�nde
	  Basis_Schaltung.r_BE = r_BE(Basis_Schaltung.I_B, U_T(Basis_Schaltung.T, Basis_Schaltung.Naeherung_U_T));
	  Basis_Schaltung.r_CE = r_CE(Basis_Schaltung.U_E - Basis_Schaltung.U_C, Basis_Schaltung.U_AF, Basis_Schaltung.I_C);
	  // AC-Verst�rkung
	  Basis_Schaltung.V_U_AC = V_U_AC_B(Basis_Schaltung.R[R_KOLLEKTOR_BS_PNP], Basis_Schaltung.r_BE, Basis_Schaltung.r_CE, Basis_Schaltung.Beta, Basis_Schaltung.Naeherung_r_CE);
	  // AC-Eingangswiderstand
	  Basis_Schaltung.r_Ein_AC = AC_Eingangswiderstand_B(Basis_Schaltung.R[R_EMITTER_BS_PNP], Basis_Schaltung.R[R_KOLLEKTOR_BS_PNP], Basis_Schaltung.r_BE, Basis_Schaltung.r_CE, Basis_Schaltung.Beta, Basis_Schaltung.Naeherung_r_CE);
	  // AC-Ausgangswiderstand
	  Basis_Schaltung.r_Aus_AC = AC_Ausgangswiderstand_B(Basis_Schaltung.R[R_KOLLEKTOR_BS_PNP], Basis_Schaltung.R[R_EMITTER_BS_PNP], Basis_Schaltung.r_BE, Basis_Schaltung.r_CE, Basis_Schaltung.Beta, Basis_Schaltung.Naeherung_r_CE);
	}
  }
  if (Basis_Schaltung.I_B<0.0)
	Basis_Schaltung.Schaltung_berechenbar=false;
  return 0;
}	// end of Berechne_Basisschaltung

int Zeichne_Ausgabe_Basisschaltung(Bipolartransistor BS, HDC hdc, bool Kopie_Zwischenablage)
{
  UNREFERENCED_PARAMETER( Kopie_Zwischenablage );

  HPEN hStiftSchwarz2, hStiftAlt;
  HBRUSH hPinselSchwarz, hPinselAlt;
  HFONT hFontAlt, hFont;
  int zeilennummer = 2, tabulator[5];
  char cAusgabe[255], cText[100], cWert1[100], cWert2[100];

  hFont = Erstelle_Font_Arial(hdc, 20);
  hFontAlt = (HFONT)SelectObject(hdc, hFont);
  tabulator[0] = 200;
  tabulator[1] = 300;
  tabulator[2] = 500;
  tabulator[3] = 600;

  SetPolyFillMode(hdc, WINDING);

  hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

  // passenden Transistor zeichnen
  Zeichne_Bipolartransistor(hdc, 600, 50, 50, 100, BS.NPN, 20);
  // Ausgabe der Ergebnisse
  // Ausgabe der Ergebnisse.
  if (BS.Schaltung_berechenbar)
	TabbedTextOut(hdc, 10, 20, (LPCSTR)"\tBerechnung der Basisschaltung:", 31, 4, tabulator, 10);
  else
	TabbedTextOut(hdc, 10, 20, (LPCSTR)"\tBerechnung der Basisschaltung fehlerhaft!", 43, 4, tabulator, 10);
  // N�chste Zeile, also eine Art �berschrift
  if (BS.NPN)
	sprintf_s(cAusgabe, 255, "NPN\tDC\tAC");
  else
	sprintf_s(cAusgabe, 255, "PNP\tDC\tAC");
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // Ausgabe der Eingangswiderst�nde
  zeilennummer++;
  Bestimme_Widerstandsbezeichner(cWert1, BS.r_Ein_AC, 99);
  sprintf_s(cAusgabe, 255, "Eingangswiderstand:\tunendlich\t");
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  Bestimme_Widerstandsbezeichner(cWert1, BS.r_Aus_AC, 99);
  // printf mit Argument "%s" funktioniert nicht. Am besten eigene Funktion, die zwei Strings einf�gen kann.
  sprintf_s(cAusgabe, 255, "Ausgangswiderstand:\tunendlich\t");
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // Ausgabe der Verst�rkung
  sprintf_s(cAusgabe, 255, "Verst�rkung:\t-/-\t");
  Bestimme_Bezeichner(cWert1, BS.V_U_AC, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  zeilennummer++;
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // Jetzt Str�me und Spannungen, vorher eine weitere Leerzeile. 
  zeilennummer += 3;
  sprintf_s(cAusgabe, 255, "Basisstrom I_B:\t");
  sprintf_s(cText, 100, "\tBasisspannung U_Basis:\t");
  Bestimme_Strombezeichner(cWert1, BS.I_B, 99);
  Bestimme_Spannungsbezeichner(cWert2, BS.U_Basis, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Kollektorstrom I_C:\t");
  sprintf_s(cText, 100, "\tKollektorspannung U_C:\t");
  Bestimme_Strombezeichner(cWert1, BS.I_C, 99);
  Bestimme_Spannungsbezeichner(cWert2, BS.U_C, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "Emitterstrom I_E:\t");
  sprintf_s(cText, 100, "\tEmitterspannung U_E:\t");
  Bestimme_Strombezeichner(cWert1, BS.I_E, 99);
  Bestimme_Spannungsbezeichner(cWert2, BS.U_E, 99);
  String_anhaengen(255, cAusgabe, cWert1, cText, cWert2);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);
  // die weiteren Werte nach einer Leerzeile ausgeben
  zeilennummer += 2;
  sprintf_s(cAusgabe, 255, "KS-Widerstand r_BE:\t");
  Bestimme_Widerstandsbezeichner(cWert1, BS.r_BE, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, lstrlen(cAusgabe), 4, tabulator, 10);
  zeilennummer++;
  sprintf_s(cAusgabe, 255, "KS-Widerstand r_CE:\t");
  Bestimme_Widerstandsbezeichner(cWert1, BS.r_CE, 99);
  String_anhaengen(255, cAusgabe, cWert1);
  TabbedTextOut(hdc, 10, 20 + zeilennummer * Zeichenhoehe, (LPCSTR)cAusgabe, strlen(cAusgabe), 4, tabulator, 10);

  SelectObject(hdc, hPinselAlt);
  DeleteObject(hPinselSchwarz);
  SelectObject(hdc, hStiftAlt);
  DeleteObject(hStiftSchwarz2);
  SelectObject(hdc, hFontAlt);
  DeleteObject(hFont);

  return 0;
}

int Basisschaltung_Aufruf(HWND hWnd)
{
  DialogBox(hInst, MAKEINTRESOURCE(IDD_BASISSCHALTUNG), hWnd, BasisSchaltung_Dialog);
  // Warnung((LPSTR)L"Nach DialogBox");

  return 0;
}	// end of Basisschaltung

int Zeichne_Basisschaltung(Bipolartransistor BS, HDC hdc, bool Kopie_Zwischenablage)
{
  UNREFERENCED_PARAMETER(Kopie_Zwischenablage);

  HPEN hStiftSchwarz2, hStiftAlt;
  HBRUSH hPinselSchwarz, hPinselAlt;
  HFONT FontNeu = NULL, FontAlt = NULL;
  char cText[100];

  SetTextColor(hdc, RGB(0, 0, 0));
  if (Kopie_Zwischenablage)
  {
	// Beschriftung erg�nzen am besten in Arial
	FontNeu = CreateFont(24, // nHeight
	  0,	// nWidth
	  0,	// nEscapement
	  0,	// nOrientation
	  FW_DONTCARE, //fnWeight
	  FALSE,	//fdwItalic
	  FALSE,	//fdwUnderline
	  FALSE,	//fdwStrikeOut
	  DEFAULT_CHARSET,	//fdwCharSet
	  OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
	  CLIP_DEFAULT_PRECIS, //fdwClipPrecision
	  CLEARTYPE_QUALITY,	//fdwQuality
	  VARIABLE_PITCH,		//fdwPitchAndFamily
	  TEXT("Arial"));	//lpszFace
	FontAlt = (HFONT)SelectObject(hdc, FontNeu);
	SetTextAlign(hdc, TA_LEFT);
  }

  // Fenster neu zeichnen: Basisschaltung mit Widerst�nden, Transistor und Spannungsquelle

  SetPolyFillMode(hdc, WINDING);

  hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
  // F�llfarbe vorher auf Schwarz
  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);
  // Zeichnen der Verbindungspunkte vorab
  //Verbindungspunkt R4-C3 x: 200, y:385
  Ellipse_BH(hdc, 195, 330, 10, 10);
  Ellipse_BH(hdc, 295, 5, 10, 10);
  SelectObject(hdc, hPinselAlt);
  // Wieder auf wei�en Hintergrund umschalten

  // Beschriftung der Widerst�nde R1-R4 und C3:
  if (Kopie_Zwischenablage)
  {
	// Ausgabe f�r Zwischenablage
	SetTextAlign(hdc, TA_RIGHT);
	Zeichne_Text_xy(hdc, "R1", 180, 55);
	Bestimme_Widerstandsbezeichner(cText, Basis_Schaltung.R[R_BASIS_UB], 99);
	Zeichne_Text_xy(hdc, cText, 180, 80);
	Zeichne_Text_xy(hdc, "R3", 280, 30);
	Bestimme_Widerstandsbezeichner(cText, Basis_Schaltung.R[2], 99);
	Zeichne_Text_xy(hdc, cText, 280, 55);
	Zeichne_Text_xy(hdc, "U_B", 575, 50);
	Bestimme_Spannungsbezeichner(cText, Basis_Schaltung.U_B, 99);
	Zeichne_Text_xy(hdc, cText, 575, 75);
	SetTextAlign(hdc, TA_LEFT);
	Zeichne_Text_xy(hdc, "R2", 221, 374);
	Bestimme_Widerstandsbezeichner(cText, Basis_Schaltung.R[R_BASIS_GND], 99);
	Zeichne_Text_xy(hdc, cText, 221, 399);
	Zeichne_Text_xy(hdc, "R4", 320, 405);
	Bestimme_Widerstandsbezeichner(cText, Basis_Schaltung.R[3], 99);
	Zeichne_Text_xy(hdc, cText, 320, 430);

  }
  else
  {
	// Ausgabe in Dialogfenster
	Zeichne_Text_xy(hdc, "R1", 160, 55);
	Zeichne_Text_xy(hdc, "R2", 221, 374);
	Zeichne_Text_xy(hdc, "R3", 259, 25);
	Zeichne_Text_xy(hdc, "R4", 320, 400);
	Zeichne_Text_xy(hdc, "C3", 72, 400);
  }

  Zeichne_Gleichspannungsquelle(hdc, 590, 50, 60, true, 40);
  // Leitung f�r R1, R2 und U_B:
  VP_Linie(hdc, 200, 480, 200, 10, 620, 10, 620, 150);
  // Masse f�r R2
  ZP_Linie(hdc, 185, 480, 215, 480);

  //Widerst�nde R1, R2 Positionen: x=185, y=50, x=185, y=370:
  Zeichne_Widerstand(hdc, 185, 50, 30, 60);
  Zeichne_Widerstand(hdc, 185, 370, 30, 60);
  // Masseanschluss f�r R4 Position: x: 285-315, y: 480
  ZP_Linie(hdc, 285, 480, 315, 480);
  // Leitung f�r C3 (parallel zu R2) Position: x: 100-200, y: 335-425
  DP_Linie(hdc, 200, 335, 100, 335, 100, 425);
  // Zweite Leitung f�r C3: x: 100, y: 445-480
  ZP_Linie(hdc, 100, 445, 100, 480);
  // Kondensator C3 zeichen (quer) x:50-150, y: 425, 445
  Zeichne_Kondensator(hdc, 50, 425, 100, 20, C_VERTIKAL);

  if (BS.NPN) //Basis_Schaltung.NPN)  //NPN-Transistor
  {
	if (Kopie_Zwischenablage)
	{
	  // Beschriftung C1, C2, C3 und Spannungen f�r Zwischenablage:
	  SetTextAlign(hdc, TA_RIGHT);
	  Zeichne_Text_xy(hdc, "C1", 90, 190);
	  Bestimme_Kapazitaetsbezeichner(cText, Basis_Schaltung.C[C_EIN], 99);
	  Zeichne_Text_xy(hdc, cText, 90, 165);
	  SetTextAlign(hdc, TA_LEFT);
	  Zeichne_Text_xy(hdc, "C2", 375, 70);
	  Bestimme_Kapazitaetsbezeichner(cText, Basis_Schaltung.C[C_AUS], 99);
	  Zeichne_Text_xy(hdc, cText, 375, 45);
	  Zeichne_Text_xy(hdc, "C3", 110, 395);
	  Bestimme_Kapazitaetsbezeichner(cText, Basis_Schaltung.C[C_BASIS_BS], 99);
	  Zeichne_Text_xy(hdc, cText, 110, 370);
	  // Beschriftung U_Ein, U_Aus, T1 f�r Zwischenablage
	  Zeichne_Text_xy(hdc, "U_Ein", 50, 275);
	  Zeichne_Text_xy(hdc, "U_Aus", 435, 155);
	  Zeichne_Text_xy(hdc, "T1", 280, 145);
	}
	else
	{
	  // Beschriftung C1, C2 f�r Dialogbox:
	  Zeichne_Text_xy(hdc, "C1", 80, 230);
	  Zeichne_Text_xy(hdc, "C2", 325, 105);
	}

	SelectObject(hdc, hPinselSchwarz);
	// Transistor (NPN) Position: x: 250 (250-300) y: 100-200
	Zeichne_Bipolartransistor(hdc, 250, 100, 50, 100, Basis_Schaltung.NPN, 0);
	// Verbindungspunkte C_Ein zu R4
	Ellipse_BH(hdc, 295, 95, 10, 10);
	Ellipse_BH(hdc, 295, 215, 10, 10);
	//Verbindungspunkt R1/R2 zur Basis x: 200, y:150
	Ellipse_BH(hdc, 195, 145, 10, 10);
	// Wieder auf wei�e Fl�che zur�ck...
	SelectObject(hdc, hPinselAlt);

	//Anschlusspunkte U_Ein (links), Positionen (Mitte): x: 45; 710; y: 220; 370
	Zeichne_Anschluss(hdc, 35, 210, 150);
	// Leitung f�r Kondensator C_Ein Position: x: 55-100 und 120-300, y: 220
	ZP_Linie(hdc, 55, 220, 100, 220);
	ZP_Linie(hdc, 120, 220, 300, 220);
	// Eingangskondensator Position: x: 100, 120 y: 170-270
	Zeichne_Kondensator(hdc, 100, 170, 20, 100, C_HORIZONTAL);
	// Verbindung von R1/R2 zur Basis: x: 200?250, y: 150
	ZP_Linie(hdc, 200, 150, 250, 150);
	// Leitung f�r R3 Postion: x: 300; y: 10?100
	ZP_Linie(hdc, 300, 10, 300, 100);
	// Leitung f�r R4 Position: x: 300, y: 200?480
	ZP_Linie(hdc, 300, 200, 300, 480);
	// Leitung f�r Ausgangskondensator x: 300-350 und 370-420, y: 100
	ZP_Linie(hdc, 300, 100, 350, 100);
	ZP_Linie(hdc, 370, 100, 420, 100);
	// Ausgangskondensator zeichnen x: 350, 370, y: 50-150
	Zeichne_Kondensator(hdc, 350, 50, 20, 100, C_HORIZONTAL);
	// Ausgangsanschluss mit Verbindungspunkt x: 420-440, y: 90-210 bzw. y: 240-260
	Zeichne_Anschluss(hdc, 420, 90, 150);
	// Masseanschluss f�r C3 Position: x: 85-115, y: 480
	ZP_Linie(hdc, 85, 480, 115, 480);
  }
  else // PNP-Transistor zeichnen
  {
	if (Kopie_Zwischenablage)
	{
	  // Beschriftung C1, C2, C3 und Spannungen f�r Zwischenablage
	  SetTextAlign(hdc, TA_RIGHT);
	  Zeichne_Text_xy(hdc, "C1", 90, 140);
	  Bestimme_Kapazitaetsbezeichner(cText, Basis_Schaltung.C[C_EIN], 99);
	  Zeichne_Text_xy(hdc, cText, 90, 115);
	  Zeichne_Text_xy(hdc, "C3", 85, 395);
	  Bestimme_Kapazitaetsbezeichner(cText, Basis_Schaltung.C[C_BASIS_BS], 99);
	  Zeichne_Text_xy(hdc, cText, 85, 370);
	  SetTextAlign(hdc, TA_LEFT);
	  Zeichne_Text_xy(hdc, "C2", 375, 270);
	  Bestimme_Kapazitaetsbezeichner(cText, Basis_Schaltung.C[C_AUS], 99);
	  Zeichne_Text_xy(hdc, cText, 375, 245);
	  // Beschriftung U_Ein, U_Aus, T1 f�r Zwischenablage
	  Zeichne_Text_xy(hdc, "U_Ein", 50, 225);
	  Zeichne_Text_xy(hdc, "U_Aus", 435, 355);
	  Zeichne_Text_xy(hdc, "T1", 280, 240);
	}
	else
	{
	  // Beschriftung C1, C2 f�r Dialogbox
	  Zeichne_Text_xy(hdc, "C1", 80, 180);
	  Zeichne_Text_xy(hdc, "C2", 325, 305);
	}
	SelectObject(hdc, hPinselSchwarz);
	// Transistor (PNP) Position: x: 250 (250-300) y: 200-300
	Zeichne_Bipolartransistor(hdc, 250, 200, 50, 100, Basis_Schaltung.NPN, 0);
	// Verbindungspunkt 250, 150
	Ellipse_BH(hdc, 195, 245, 10, 10);
	//Verbindungspunkt
	Ellipse_BH(hdc, 295, 295, 10, 10);
	Ellipse_BH(hdc, 295, 165, 10, 10);
	SelectObject(hdc, hPinselAlt);
	//Anschlusspunkte U_Ein (links), Positionen (Mitte): x: 45; 710; y: 160; 310
	Zeichne_Anschluss(hdc, 35, 160, 150);
	// Verbindung von R1/R2 zur Basis: x: 200-250, y: 150
	ZP_Linie(hdc, 200, 250, 250, 250);
	// Leitung f�r R3 Postion: x: 300; y: 10-200
	ZP_Linie(hdc, 300, 10, 300, 200);
	// Leitung f�r R4 Position: x: 300, y: 300-480
	ZP_Linie(hdc, 300, 300, 300, 480);
	// Leitung f�r Kondensator C_Ein Position: x: 55-100 und 120-300, y: 170
	ZP_Linie(hdc, 55, 170, 100, 170);
	ZP_Linie(hdc, 120, 170, 300, 170);
	// Eingangskondensator Position: x: 100, 120 y: 120-220
	Zeichne_Kondensator(hdc, 100, 120, 20, 100, C_HORIZONTAL);

	// Leitung f�r Ausgangskondensator x: 300-350 und 370-420, y: 300
	ZP_Linie(hdc, 300, 300, 350, 300);
	ZP_Linie(hdc, 370, 300, 420, 300);
	// Ausgangskondensator zeichnen x: 350, 370, y: 250-350
	Zeichne_Kondensator(hdc, 350, 250, 20, 100, C_HORIZONTAL);
	// Ausgangsanschluss mit Verbindungspunkt x: 420-440, y: 290-310 bzw. y: 440-460
	Zeichne_Anschluss(hdc, 420, 290, 150);
	// Masseanschluss f�r C3 Position: x: 85?115, y: 480
	ZP_Linie(hdc, 85, 480, 115, 480);
  }
  //Widerst�nde R3, R4 Positionen: x=285, y=25, 400
  Zeichne_Widerstand(hdc, 285, 25, 30, 60);
  Zeichne_Widerstand(hdc, 285, 400, 30, 60);

  SelectObject(hdc, hPinselAlt);
  DeleteObject(hPinselSchwarz);
  SelectObject(hdc, hStiftAlt);
  DeleteObject(hStiftSchwarz2);

  if (Kopie_Zwischenablage)
  {
	SelectObject(hdc, FontAlt);
	DeleteObject(FontNeu);
  }

  return 0;
} // end of Zeichne_Basisschaltung

double AC_Eingangswiderstand_B(double R_Emitter, double R_Kollektor, double r_BE, double r_CE, double beta, bool N�herung_r_CE)
{
  // Berechnung des Kleinsignal-Eingangswiderstandes f�r eine unendliche hohe Frequenz

  double ergebnis, hilf;

  if (N�herung_r_CE)
	ergebnis = Parallelschaltung(r_BE / beta, R_Emitter);
  else
  {
	hilf = beta*r_CE / (r_CE + Parallelschaltung(R_Emitter, R_Kollektor));
	ergebnis = Parallelschaltung(r_BE / hilf, R_Emitter);
  }
  return ergebnis;
} // end of AC_Eingangswiderstand 

double AC_Ausgangswiderstand_B(double R_Kollektor, double R_Emitter, double r_BE, double r_CE, double beta, bool N�herung_r_CE)
{
  // Berechnung des AC-Ausgangswiderstands bei beliebig hoher Frequenz f

  double ergebnis;

  if (N�herung_r_CE)
	// r_CE wird vernachl�ssigt)
	ergebnis = R_Kollektor;
  else
	ergebnis = Parallelschaltung(R_Kollektor, (r_CE + Parallelschaltung(R_Emitter, r_BE*beta)));

  return ergebnis;
} // end of AC_Ausgangswiderstand

double V_U_AC_B(double R_Kollektor, double r_BE, double r_CE, double Beta, bool N�herung_r_CE)
{
  //Berechnung der AC-Verst�rkung
  //Funktion i.O. 24.4.2016 M. Alles
  double ergebnis;

  if (N�herung_r_CE)
	// R_CE wird vernachl�ssigt (hochohmig)
	ergebnis = Beta*R_Kollektor / r_BE;
  else
	ergebnis = (R_Kollektor*(r_BE + Beta*r_CE)) / ((R_Kollektor + r_CE)*r_BE);

  return ergebnis;
} // end of V_U_AC_B

int Kopiere_Basisschaltung(Bipolartransistor BS)
{
  HDC hdcMeta;
  HENHMETAFILE hMeta;

  hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
  // Basisschaltung zeichnen
  Zeichne_Basisschaltung(BS, hdcMeta, true);
  hMeta = CloseEnhMetaFile(hdcMeta);
  // Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
  OpenClipboard(hWndElektronikMain);
  EmptyClipboard();
  SetClipboardData(CF_ENHMETAFILE, hMeta);
  CloseClipboard();

  return 0;
} // end of Kopiere_Basisschaltung

int Kopiere_ESB_Basisschaltung(Bipolartransistor BS)
{
  HDC hdcMeta;
  HENHMETAFILE hMeta;

  hdcMeta = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
  // Basisschaltung zeichnen
  Zeichne_ESB_Basisschaltung(BS, hdcMeta, true);
  hMeta = CloseEnhMetaFile(hdcMeta);
  // Zwischenablage �ffnen, leeren und mit der Metadatei f�llen
  OpenClipboard(hWndElektronikMain);
  EmptyClipboard();
  SetClipboardData(CF_ENHMETAFILE, hMeta);
  CloseClipboard();

  return 0;
} // end of Kopiere_ESB_Basisschaltung

int Ergebnis_Basisschaltung(HWND hDlg)
{
  // Berechnung der Basisschaltung
  Berechne_Basisschaltung();
  DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_BIPOLARSCHALTUNG), hDlg, ErgebnisBasisSchaltung_Dialog);


  return 0;
}	// end of Ergebnis_Basisschaltung

int ESB_Basisschaltung(HWND hDlg)
{
  DialogBox(hInst, MAKEINTRESOURCE(IDD_ESB_BIPOLARSCHALTUNG), hDlg, ESB_BasisSchaltung_Dialog);

  return 0;
}	// end of ESB_Basisschaltung

// Weitere Bipolartransistorfunktionen
int Eingabe_BipolarTransistorwerte_Aufruf(int Schaltungsauswahl, int Transistorparameter)
/*	Funktion wird verwendet, um Daten der Bipolartransistoren einzugeben.
�bergabeparameter:	Schaltungsauswahl: Nummer der aufrufenden Schaltung - 1: Basis, 2: Emitter, 3: Kollektor, 8: Bipolartransistor als Schalter
10: Differenzverst�rker Parallelzweig (T1), 11: Differenzverst�rker Stromquelle (T2)
Transistorparameter:  0: alle Parameter �nderbar, 1: keine Earlyspannung, 2: nur NPN, 4: nur PNP-Transistor, 8: kein U_CE_Sat,
// 16: kein I_CB_Sperr; 32: keine Temperatur
R�ckgabewert:		0 */
{
  if (!Eingabe_Dialog.Eingabe_BipolarTransistor)
  {
	Eingabe_Dialog.Eingabe_BipolarTransistor = true;
	Eingabe_Dialog.Auswahl_Schaltung = Schaltungsauswahl;
	Eingabe_Dialog.Parameter_Bipolartransistor = Transistorparameter;
	DialogBox(hInst, MAKEINTRESOURCE(IDD_EINGABEBIPOLARTRANSISTOR), hWndElektronikMain, Eingabe_BipolarTransistorwerte_Dialog);
	Eingabe_Dialog.Eingabe_BipolarTransistor = false;
  }

  return 0;
}	// end of Eingabe_BipolarTransistorwerte

double r_BE(double I_B, double U_T)
{
  // Berechnung des Kleinsignal-Basis-Emitterwiderstandes, gilt f�r alle Transistorschaltungen
  // Funktion in Ordnung, M. Alles, 21.4.2016
  double ergebnis;

  ergebnis = U_T / I_B;

  return ergebnis;
} // end of r_BE

double r_CE(double U_CE, double U_AF, double I_C)
{
  // Berechnung des Kleinsignal-Kollektor-Emitterwiderstandes f�r alle Transistorschaltungen
  // Funktion i.O. 24.4.2016 M. Alles

  double ergebnis;

  ergebnis = (U_CE + U_AF) / I_C;

  return ergebnis;
} // end of r_CE

double U_T(double Temp, bool Naeherung_U_T)
{
  // Berechnung der Temperaturspannung
  // Falls die Variable Naeherung_U_T true ist, wird mit 26mV gerechnet, ansonsten wird die Temperaturspannung aus der Temperatur bestimmt
  // Funktion in Ordnung, M. Alles 21. April 2016
  double rueckgabe;

  if (Naeherung_U_T)													//genauen Wert f�r die Temperaturspannung oder
	rueckgabe = 0.026;
  else
	rueckgabe = k_b*Temp / q_0;

  return rueckgabe;
} // end of U_T

double Basisstrom_NPN(double Basis_R1, double Basis_R2, double Emitter_R1, double Emitter_R2, double U_BE, double U_B, double Beta)
{
  // Berechnung des Basisstroms: Auf der Basisseite gilt: U_B=(R1+R2)/R2*U_Basis+R1*I_Basis
  // Auf der Emitterseite gilt: U_Basis-UBE=I_Basis*(B+1)*(R4+R5). Durch Gleichsetzen kann
  // der Basisstrom bestimmt werden. F�r PNP-Transistoren werden die beiden Basis-Widerst�nde verstauscht.
  // Bei der Basis- und der Kollektorschaltung gibt es nur einen Emitterwiderstand. Der Aufruf muss geeignet erfolgen!
  //  M. Alles, 13.5.2016
  double ergebnis, nenner;

  if (Basis_R2 != 0)
  {
	nenner = Basis_R1 + ((Basis_R1 + Basis_R2)*(Emitter_R1 + Emitter_R2)*(Beta + 1) / Basis_R2);
	if (nenner != 0)
	  ergebnis = (U_B - (Basis_R1 + Basis_R2) / Basis_R2*U_BE) / nenner;
	else
	  ergebnis = -1.0;
  }
  else
	ergebnis = -1.0;
  return ergebnis;
} // end of Basisstrom_NPN

double Basisstrom_PNP(double Basis_R1, double Basis_R2, double Emitter_R1, double Emitter_R2, double U_BE, double U_B, double Beta)
{
  // Berechnung des Basisstroms
  // Bei der Basis- und der Kollektorschaltung gibt es nur einen Emitterwiderstand. Der Aufruf muss geeignet erfolgen!
  //  M. Alles, 13.5.2016
  double ergebnis, nenner;

  if (Basis_R2 != 0)
  {
	nenner = Basis_R1*Basis_R2 + (Basis_R1 + Basis_R2)*(Emitter_R1 + Emitter_R2)*(Beta + 1);
	if (nenner != 0)
	  ergebnis = (U_B*Basis_R1 - U_BE*(Basis_R1 + Basis_R2)) / nenner;
	else
	  ergebnis = -1.0;
  }
  else
	ergebnis = -1.0;
  return ergebnis;
} // end of Basisstrom_PNP

int Kopiere_Ergebnis_Bipolar_Transistorschaltung(Bipolartransistor TS, HWND hWnd, int Schaltung)
{
  HGLOBAL hGlobal;
  WCHAR *wcGlobal;
  WCHAR wcText[2001];
  char cZeile[100];
  WCHAR wcZeile[MAX_DATEINAME];
  int i, laenge = 0;

  // Der Reihe nach die Daten in den String kopieren
  switch (Schaltung)
  {
  case BASIS_SCHALTUNG: 
	wcscpy_s(wcText, 50, L"Berechnung Basisschaltung\n");
	break;
  case EMITTER_SCHALTUNG: 
	wcscpy_s(wcText, 50, L"Berechnung Emitterschaltung\n");
	break;
  case KOLLEKTOR_SCHALTUNG:
	wcscpy_s(wcText, 50, L"Berechnung Kollektorschaltung\n");
	break;
  }
  // Falls die Schaltung nicht berechenbar ist, wird hier auch die Fehlermeldung kopiert.
  if (!TS.Schaltung_berechenbar)
	wcscat_s(wcText, 25, L"Berechnung fehlerhaft!\n");

  // Transistordaten ausgeben
  wcscat_s(wcText, 2000, L"Bipolar-Transistor: ");
  if (TS.NPN)
	wcscat_s(wcText, 2000, L"NPN, ");
  else
	wcscat_s(wcText, 2000, L"PNP, ");

  laenge = wcslen(wcText);
  //Text[laenge] = (char)(3 * 256 + 11 * 16 + 2); // beta eintragen
  wcText[laenge] = 3*256+11*16+2; //'�'; // beta eintragen
  wcText[laenge + 1] = 0;
  wcscat_s(wcText, 2000, L"=");
  Bestimme_Bezeichner_wissenschaftlich( cZeile, TS.Beta, (int)99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  wcscat_s(wcText, 2000, L", U_BE=");
  Bestimme_Spannungsbezeichner(cZeile, TS.U_BE, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  wcscat_s(wcText, 2000, L", U_AF=");
  Bestimme_Spannungsbezeichner( cZeile, TS.U_AF, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  wcscat_s(wcText, 2000, L", Temp.=");
  Bestimme_Temperaturbezeichner( cZeile, TS.T, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  // Versorgungsspannung und Widerst�nde ausgeben
  wcscat_s(wcText, 2000, L"\nVersorgungsspannung U_B=");
  Bestimme_Spannungsbezeichner( cZeile, TS.U_B, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  // Widerst�nde ausgeben
  if (TS.R_Max > 0)
  {
	wcscat_s(wcText, 2000, L"\nWiderst�nde:");
	for (i = 0; i < TS.R_Max; i++)
	{
	  if (i == 0)
		swprintf_s(wcZeile, 20, L"\tR1=");
	  else
		swprintf_s(wcZeile, 20, L", R%u=", i + 1);
	  wcscat_s(wcText, 2000, wcZeile);
	  Bestimme_Widerstandsbezeichner(cZeile, TS.R[i], 99);
	  char_to_widechar( wcZeile, cZeile, 99);
	  wcscat_s(wcText, 2000, wcZeile);
	}
  }
  // Kondensatoren ausgeben
  if (TS.C_Max > 0)
  {
	wcscat_s(wcText, 2000, L"\nKondensatoren:");
	for (i = 0; i < TS.C_Max; i++)
	{
	  if (i == 0)
		swprintf_s(wcZeile, 20, L"\tC1=");
	  else
		swprintf_s(wcZeile, 20, L", C%u=", i + 1);
	  wcscat_s(wcText, 2000, wcZeile);
	  Bestimme_Kapazitaetsbezeichner( cZeile, TS.C[i], 99);
	  char_to_widechar( wcZeile, cZeile, 99);
	  wcscat_s(wcText, 2000, wcZeile);
	}
  }
  // Arbeitspunkt ausgeben
  wcscat_s(wcText, 2000, L"\nArbeitspunkt:\nSpannungen\tU_Basis=");
  Bestimme_Spannungsbezeichner( cZeile, TS.U_Basis, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  wcscat_s(wcText, 2000, L", U_C=");
  Bestimme_Spannungsbezeichner( cZeile, TS.U_C, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  wcscat_s(wcText, 2000, L", U_E=");
  Bestimme_Spannungsbezeichner(cZeile, TS.U_E, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  wcscat_s(wcText, 2000, L"\nStr�me\tI_Basis=");
  Bestimme_Strombezeichner(cZeile, TS.I_B, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  wcscat_s(wcText, 2000, L", I_C=");
  Bestimme_Strombezeichner(cZeile, TS.I_C, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  wcscat_s(wcText, 2000, L", I_E=");
  Bestimme_Strombezeichner(cZeile, TS.I_E, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  // Ausgabe r_BE und r_CE:
  wcscat_s(wcText, 2000, L"\nESB-Daten\tr_BE=");
  Bestimme_Widerstandsbezeichner(cZeile, TS.r_BE, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  wcscat_s(wcText, 2000, L", r_CE=");
  Bestimme_Strombezeichner(cZeile, TS.r_CE, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);

  // Ausgabe Verst�rkungen
  switch (Schaltung)
  {
  case BASIS_SCHALTUNG: 
	wcscat_s(wcText, 2000, L"\nDC_Daten:\tnicht verf�gbar\nAC_Daten:\tr_Ein=");
	break;
  case EMITTER_SCHALTUNG:
	wcscat_s(wcText, 2000, L"\nDC_Daten:\tr_Aus, r_Ein: nicht verf�gbar");
	wcscat_s(wcText, 2000, L", Verst�rkung=");
	Bestimme_Bezeichner_wissenschaftlich(cZeile, TS.V_U_DC, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 2000, wcZeile);
	wcscat_s(wcText, 2000, L"\nAC_Daten:\tr_Ein=");
	break;
  case KOLLEKTOR_SCHALTUNG:
	wcscat_s(wcText, 2000, L"\nDC_Daten:\tnicht verf�gbar\nAC_Daten:\tr_Ein=");
	break;
  }

  Bestimme_Widerstandsbezeichner(cZeile, TS.r_Ein_AC, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  wcscat_s(wcText, 2000, L", r_Aus=");
  Bestimme_Widerstandsbezeichner(cZeile, TS.r_Aus_AC, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  wcscat_s(wcText, 2000, L", Verst�rkung=");
  Bestimme_Bezeichner_wissenschaftlich(cZeile, TS.V_U_AC, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 2000, wcZeile);
  if (Datei_gespeichert)
  {
	wcscat_s(wcText, 2000, L"\nDateiname; ");
	char_to_widechar( wcZeile, Dateiname, MAX_DATEINAME);
	wcscat_s(wcText, 2000, wcZeile);
  }
  laenge = wcslen(wcText);
  //hGlobal = GlobalAlloc(GHND, (laenge + 2) * sizeof(WCHAR));
  hGlobal = GlobalAlloc( GHND, (laenge+1)*sizeof(WCHAR));
  if (hGlobal == NULL)
	return 1;
  wcGlobal = (WCHAR*)GlobalLock(hGlobal);

  wcscpy_s(wcGlobal, (size_t)(laenge+1), wcText);
  if (GlobalUnlock(hGlobal)!=0)
	return 2;
  if (!OpenClipboard(hWnd))
	return 3;
  EmptyClipboard();
  if (SetClipboardData(CF_UNICODETEXT, hGlobal)==NULL)
	return 4;
  CloseClipboard();

  return 0;
} // end of Kopiere_Ergebnis_Bipolar_Transistorschaltung

int Kopiere_Ergebnis_Doppel_Bipolar_Transistorschaltung(Doppel_Bipolartransistor D_ES, HWND hWnd, int Schaltung)
{
  HGLOBAL hGlobal;
  WCHAR *wcGlobal;
  WCHAR wcText[3001];
  char cZeile[100];
  WCHAR wcZeile[MAX_DATEINAME];
  int i, laenge = 0;

  // Der Reihe nach die Daten in den String kopieren
  switch (Schaltung)
  {
  case DOPPEL_EMITTER: 
	wcscpy_s(wcText, 50, L"Berechnung Doppel-Emitterschaltung\n");
	break;
  }
  // Falls die Schaltung nicht berechenbar ist, wird hier auch die Fehlermeldung kopiert.
  if (!D_ES.Schaltung_berechenbar)
	wcscat_s(wcText, 3000, L"Berechnung fehlerhaft!\n");

  // Transistordaten von T1 ausgeben
  wcscat_s(wcText, 3000, L"Bipolar-Transistor T1: ");
  if (D_ES.NPN_T1)
	wcscat_s(wcText, 3000, L"NPN, ");
  else
	wcscat_s(wcText, 3000, L"PNP, ");

  laenge = wcslen(wcText);
  wcText[laenge] = 3*256+11*16+2; //'�'; // beta eintragen
  wcText[laenge + 1] = 0;
  wcscat_s(wcText, 3000, L"=");
  Bestimme_Bezeichner_wissenschaftlich( cZeile, D_ES.Beta_T1, (int)99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", U_BE=");
  Bestimme_Spannungsbezeichner(cZeile, D_ES.U_BE_T1, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", U_AF=");
  Bestimme_Spannungsbezeichner( cZeile, D_ES.U_AF_T1, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  // Transistordaten von T2 ausgeben
  wcscat_s(wcText, 3000, L"Bipolar-Transistor T2: ");
  if (D_ES.NPN_T2)
	wcscat_s(wcText, 3000, L"NPN, ");
  else
	wcscat_s(wcText, 3000, L"PNP, ");

  laenge = wcslen(wcText);
  wcText[laenge] = 3*256+11*16+2; //'�'; // beta eintragen
  wcText[laenge + 1] = 0;
  wcscat_s(wcText, 3000, L"=");
  Bestimme_Bezeichner_wissenschaftlich( cZeile, D_ES.Beta_T2, (int)99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", U_BE=");
  Bestimme_Spannungsbezeichner(cZeile, D_ES.U_BE_T2, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", U_AF=");
  Bestimme_Spannungsbezeichner( cZeile, D_ES.U_AF_T2, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", Temp.=");
  Bestimme_Temperaturbezeichner( cZeile, D_ES.T, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  // Versorgungsspannung und Widerst�nde ausgeben
  wcscat_s(wcText, 3000, L"\nVersorgungsspannung U_B=");
  Bestimme_Spannungsbezeichner( cZeile, D_ES.U_B, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  // Widerst�nde ausgeben
  if (D_ES.R_Max > 0)
  {
	wcscat_s(wcText, 3000, L"\nWiderst�nde:");
	for (i = 0; i < D_ES.R_Max; i++)
	{
	  if (i == 0)
		swprintf_s(wcZeile, 20, L"\tR1=");
	  else
		swprintf_s(wcZeile, 20, L", R%u=", i + 1);
	  wcscat_s(wcText, 3000, wcZeile);
	  Bestimme_Widerstandsbezeichner(cZeile, D_ES.R[i], 99);
	  char_to_widechar( wcZeile, cZeile, 99);
	  wcscat_s(wcText, 3000, wcZeile);
	}
  }
  // Kondensatoren ausgeben
  if (D_ES.C_Max > 0)
  {
	wcscat_s(wcText, 3000, L"\nKondensatoren:");
	for (i = 0; i < D_ES.C_Max; i++)
	{
	  if (i == 0)
		swprintf_s(wcZeile, 20, L"\tC1=");
	  else
		swprintf_s(wcZeile, 20, L", C%u=", i + 1);
	  wcscat_s(wcText, 3000, wcZeile);
	  Bestimme_Kapazitaetsbezeichner( cZeile, D_ES.C[i], 99);
	  char_to_widechar( wcZeile, cZeile, 99);
	  wcscat_s(wcText, 3000, wcZeile);
	}
  }
  // Arbeitspunkt vonN T1 ausgeben
  wcscat_s(wcText, 3000, L"\nArbeitspunkt T1:\nSpannungen\tU_Basis=");
  Bestimme_Spannungsbezeichner( cZeile, D_ES.U_Basis_T1, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", U_C=");
  Bestimme_Spannungsbezeichner( cZeile, D_ES.U_C_T1, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", U_E=");
  Bestimme_Spannungsbezeichner(cZeile, D_ES.U_E_T1, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L"\nStr�me\tI_Basis=");
  Bestimme_Strombezeichner(cZeile, D_ES.I_B_T1, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", I_C=");
  Bestimme_Strombezeichner(cZeile, D_ES.I_C_T1, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", I_E=");
  Bestimme_Strombezeichner(cZeile, D_ES.I_E_T1, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  // Ausgabe r_BE und r_CE:
  wcscat_s(wcText, 3000, L"\nESB-Daten\tr_BE=");
  Bestimme_Widerstandsbezeichner(cZeile, D_ES.r_BE_T1, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", r_CE=");
  Bestimme_Strombezeichner(cZeile, D_ES.r_CE_T1, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);

  // Arbeitspunkt von T2 ausgeben
  wcscat_s(wcText, 3000, L"\nArbeitspunkt T2:\nSpannungen\tU_Basis=");
  Bestimme_Spannungsbezeichner( cZeile, D_ES.U_Basis_T2, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", U_C=");
  Bestimme_Spannungsbezeichner( cZeile, D_ES.U_C_T2, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", U_E=");
  Bestimme_Spannungsbezeichner(cZeile, D_ES.U_E_T2, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L"\nStr�me\tI_Basis=");
  Bestimme_Strombezeichner(cZeile, D_ES.I_B_T2, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", I_C=");
  Bestimme_Strombezeichner(cZeile, D_ES.I_C_T2, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", I_E=");
  Bestimme_Strombezeichner(cZeile, D_ES.I_E_T2, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  // Ausgabe r_BE und r_CE:
  wcscat_s(wcText, 3000, L"\nESB-Daten\tr_BE=");
  Bestimme_Widerstandsbezeichner(cZeile, D_ES.r_BE_T2, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", r_CE=");
  Bestimme_Strombezeichner(cZeile, D_ES.r_CE_T2, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);

  // Ausgabe Verst�rkungen
  switch (Schaltung)
  {
  case DOPPEL_EMITTER:
	wcscat_s(wcText, 3000, L"\nDC_Daten:\tr_Aus, r_Ein: nicht verf�gbar");
	wcscat_s(wcText, 3000, L", Verst�rkung T1=");
	Bestimme_Bezeichner_wissenschaftlich(cZeile, D_ES.V_U_DC_T1, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 3000, L", Verst�rkung T2=");
	Bestimme_Bezeichner_wissenschaftlich(cZeile, D_ES.V_U_DC_T2, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 3000, L", Verst�rkung Ges=");
	Bestimme_Bezeichner_wissenschaftlich(cZeile, D_ES.V_U_DC_Ges, 99);
	char_to_widechar( wcZeile, cZeile, 99);
	wcscat_s(wcText, 3000, wcZeile);
	wcscat_s(wcText, 3000, L"\nAC_Daten:\tr_Ein=");
	break;
  }

  Bestimme_Widerstandsbezeichner(cZeile, D_ES.r_Ein_AC, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", r_Aus=");
  Bestimme_Widerstandsbezeichner(cZeile, D_ES.r_Aus_AC, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", Verst�rkung T1=");
  Bestimme_Bezeichner_wissenschaftlich(cZeile, D_ES.V_U_AC_T1, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", Verst�rkung T2=");
  Bestimme_Bezeichner_wissenschaftlich(cZeile, D_ES.V_U_AC_T2, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  wcscat_s(wcText, 3000, L", Verst�rkung T_Ges=");
  Bestimme_Bezeichner_wissenschaftlich(cZeile, D_ES.V_U_AC_Ges, 99);
  char_to_widechar( wcZeile, cZeile, 99);
  wcscat_s(wcText, 3000, wcZeile);
  if (Datei_gespeichert)
  {
	wcscat_s(wcText, 3000, L"\nDateiname; ");
	char_to_widechar( wcZeile, Dateiname, MAX_DATEINAME);
	wcscat_s(wcText, 3000, wcZeile);
  }
  laenge = wcslen(wcText);
  //hGlobal = GlobalAlloc(GHND, (laenge + 2) * sizeof(WCHAR));
  hGlobal = GlobalAlloc( GHND, (laenge+1)*sizeof(WCHAR));
  if (hGlobal == NULL)
	return 1;
  wcGlobal = (WCHAR*)GlobalLock(hGlobal);

  wcscpy_s(wcGlobal, (size_t)(laenge+1), wcText);
  if (GlobalUnlock(hGlobal)!=0)
	return 2;
  if (!OpenClipboard(hWnd))
	return 3;
  EmptyClipboard();
  if (SetClipboardData(CF_UNICODETEXT, hGlobal)==NULL)
	return 4;
  CloseClipboard();

  return 0;
} // end of Kopiere_Ergebnis_Bipolar_Transistorschaltung

// Funktionen zur Darstellung von Kennlinien

int Kennlinienfeld_Bipolar_Aufruf(HWND hWnd)
{
  DialogBox(hInst, MAKEINTRESOURCE(IDD_ERGEBNIS_KENNLINIENFELD_BIPOLAR), hWnd, Kennlinienfeld_Bipolar_Dialog);

  return 0;
}	// end of Kennlinienfeld_Bipolar_Aufruf

int Berechne_Parameter_Kennlinienfeld_Bipolar(Bipolartransistor *Trans)
{
  double U_Temp;

  // Berechnung der Parameter f�r das Ebers-Moll-Modell
  // A_N:
  Trans->A_N = Trans->Beta / (Trans->Beta + 1.0);
  // Emitters�ttigungsstrom als N�herung im Arbeitspunkt
  U_Temp = U_T(Trans->T, Trans->Naeherung_U_T);
  Trans->I_ES = Trans->I_C / (Trans->A_N * (exp((Trans->U_Basis - Trans->U_E) / U_Temp) - 1.0));
  Trans->I_ES /= (1.0 + (Trans->U_C - Trans->U_E) / Trans->U_AF);
  Trans->I_CS = Trans->I_ES * Trans->A_N;

  return 0;
} // end of Berechne_Parameter_Kennlinienfeld_Bipolar

double Berechne_I_C(double U_BE, double U_CE, double U_T, Bipolartransistor Trans)
{
  double rueckgabe;


  rueckgabe = Trans.I_ES*Trans.A_N*(exp((U_BE) / U_T) - 1.0) - Trans.I_CS*(exp((U_BE-U_CE) / U_T) - 1.0);
  // Early-Effekt erg�nzen
  rueckgabe *= (1 + U_CE / Trans.U_AF);

  return rueckgabe;
} // end of Berechne_I_C

int Berechne_Kennlinienfeld(Bipolartransistor Trans, double U_lauf, double U_Temp, int i_max, float *U_CE, float *I_C)
{
  int i;

  for (i = 0; i < i_max; i++)
  {
	U_CE[i] = (float)(Trans.U_CE_Max / 199.0*(double)i);
	I_C[i] = (float)Berechne_I_C(U_lauf, U_CE[i], U_Temp, Emitter_Schaltung);
  }

  return 0;
}