// Electronic_Test_V03.cpp : Definiert den Einstiegspunkt f�r die Anwendung.
//
// Zum Einbinden der Befehle (also Verzicht auf die Datei MSVCP140D.dll): 
// Projekt->Eigenschaften->Codegenerierung Punkt Laufzeitbibliothek: /MT f�r die Release
/*******************************************************************************************************************\
|																													|
| Modul Elektronische_Schaltungen.cpp																				|
|																													|
| In diesem Modul ist die Haupt-Meldungsschleife enthalten. Au�erdem sind hier einige Windows-spezifische			|
| Variablen global deklariert.																						|
| - wWinMain();																										|
| - MyRegisterClass();																								|
| - InitInstance();																									|
| - MainWndProc();																									|
|  																													|
\*******************************************************************************************************************/
#include "stdafx.h"
#include "Elektronische_Schaltungen_V1_5.h"

// Globale Variablen:
HINSTANCE hInst;									// Aktuelle Instanz
HWND hWndElektronikMain, hWndStatus, hWndMDIClient;	// Fensterhandle
char szTitle[MAX_LOADSTRING];						// Titelleistentext
WCHAR szWindowClass[MAX_LOADSTRING];				// Klassenname des Hauptfensters
WCHAR szChild[MAX_LOADSTRING];						// Klassenname des Dialogfensters

// Vorw�rtsdeklarationen der in diesem Codemodul enthaltenen Funktionen:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    MainWndProc(HWND, UINT, WPARAM, LPARAM);	
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: Hier Code einf�gen.

    // Globale Zeichenfolgen initialisieren
    //LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDS_APP_TITLE, (LPSTR)szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_ELEKTRONISCHE_SCHALTUNGEN, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // Anwendungsinitialisierung ausf�hren:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_ELEKTRONISCHE_SCHALTUNGEN));

    MSG msg;

    // Hauptnachrichtenschleife:
    while (GetMessage(&msg, NULL, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}

//
//  FUNKTION: MyRegisterClass()
//
//  ZWECK: Registriert die Fensterklasse.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

	// Daten f�r das Rahmenfenster 
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = MainWndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TRANSISTORSCHALTUNG));
    wcex.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_APPWORKSPACE+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_ELEKTRONISCHE_SCHALTUNGEN);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_TRANSISTORSCHALTUNG));

	if (!RegisterClassExW(&wcex))
		return FALSE;

    return TRUE;
}

//
//   FUNKTION: InitInstance(HINSTANCE, int)
//
//   ZWECK: Speichert das Instanzenhandle und erstellt das Hauptfenster.
//
//   KOMMENTARE:
//
//        In dieser Funktion wird das Instanzenhandle in einer globalen Variablen gespeichert, und das
//        Hauptprogrammfenster wird erstellt und angezeigt.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // Instanzenhandle in der globalen Variablen speichern

   hWndElektronikMain = CreateWindowW(szWindowClass, (LPCWSTR)szTitle, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWndElektronikMain)
   {
      return FALSE;
   }

   // Statuszeile anzeigen "How to create Status Bars: Ggf. in einzelne Abschnitte aufteilen...
   hWndStatus = CreateWindowEx(0, STATUSCLASSNAME, (LPCTSTR)TEXT(""), WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hWndElektronikMain, (HMENU)ID_STATUS_WINDOW, hInst, NULL);
   // Aufteilen in einzelne Bereiche
   // Create status bar "compartments" one width 150, other 300, then 400...   last - 1 means that it fills the rest of the window
   int Statwidths[] = { 15, 30, 45, 550, -1 };
   SendMessage(hWndStatus, SB_SETPARTS, (WPARAM)(sizeof(Statwidths) / sizeof(int)), (LPARAM)Statwidths);
   SendMessage(hWndStatus, (UINT)SB_SETTEXT, (WPARAM)(INT)4, (LPARAM)(LPSTR)("Elektronische Schaltungen"));
 
   ShowWindow(hWndElektronikMain, nCmdShow);
   UpdateWindow(hWndElektronikMain);

   if (GetCurrentDirectory(MAX_DATEINAME - 1, (LPSTR)Initialisierungsdatei) == 0)
	   FehlerMeldung("Konnte Programmverzeichnis nicht ermitteln.");
   else
	   // Anh�ngen von 'Elektronik.ini'
	   strcat_s(Initialisierungsdatei, MAX_DATEINAME - 1, "\\Elektronik_V1_1.ini");
	   //wcscat_s(Initialisierungsdatei, MAX_DATEINAME - 1, "\\Elektronik_V1_1.ini");
   // �berpr�fe Kennwort  546b5-23dc1-23eeb-37b4d //SoSe 2016
   if (!Ueberpruefe_Kennwort())
	   DestroyWindow(hWndElektronikMain);
   init();

   return TRUE;
}

//
//  FUNKTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  ZWECK:  Verarbeitet Meldungen vom Hauptfenster.
//
//  WM_COMMAND  - Verarbeiten des Anwendungsmen�s
//  WM_PAINT    - Darstellen des Hauptfensters
//  WM_DESTROY  - Ausgeben einer Beendenmeldung und zur�ckkehren
//
//
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
	case WM_CREATE:
	{
		HDC hdc;
		HFONT hFontAlt, hFont;
		TEXTMETRIC tm;

		// SChriftgr��e bestimmen.
		hdc = GetDC(hWnd);
		hFont = Erstelle_Font_Arial(hdc, 24);
		hFontAlt = (HFONT)SelectObject(hdc, hFont);
		GetTextMetrics(hdc, &tm);
		Zeichenbreite = tm.tmAveCharWidth;
		Zeichenhoehe = tm.tmHeight;
		SelectObject(hdc, hFontAlt);
		// Schriftart hier l�schen
		DeleteObject(hFont);
		ReleaseDC(hWnd, hdc);
		break;
	}
	case WM_CLOSE:
		if (Daten_ver�ndert)
		{
			int Ergebnis_Abfrage;

			Ergebnis_Abfrage = Abfrage("Daten wurden ver�ndert. Programm trotzdem beenden?");
			if ( Ergebnis_Abfrage == 0)
				DestroyWindow(hWnd);
		}
		else
			DestroyWindow(hWnd);
			break;
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // Men�auswahl bearbeiten:
            switch (wmId)
            {
			case IDM_NEU:
				if (Daten_ver�ndert)
				{
					if (Abfrage("Daten wurden ver�ndert. Trotzdem alle Werte zur�cksetzen?") == 0)
						init();
				}
				else
					init();
				break;
			case IDM_OEFFNEN:
				if (Daten_ver�ndert)
				{
					if (Abfrage("Daten wurden ver�ndert. Trotzdem neue Datei laden?") == 0)
						Datei_Oeffnen();
				}
				else
					Datei_Oeffnen();
				break;
			case IDM_SPEICHERN:
				DateiSpeichern((LPCSTR)Dateiname);
				break;
			case IDM_SPEICHERN_UNTER:
				Datei_Speichern_unter();
				break;
			case IDM_NI_BERECHNEN:
				Berechne_n_i_Aufruf(hWnd);
				break;
			case IDM_FERMI_ENERGIE:
				Berechne_Fermi_Energie_Aufruf(hWnd);
				break;
			case IDM_SPEZ_WIDERSTAND:
				Berechne_Spez_Widerstand_Aufruf(hWnd);
				break;
			case IDM_PN_BERECHNEN:
				pn_Uebergang_Aufruf(hWnd);
				break;
			case IDM_GLEICH:
				Gleichrichterschaltung(hWnd);
				break;
			case IDM_WAERME:
				ThermischerWiderstand( hWnd );
				break;
			case IDM_B_BASIS:
				Basisschaltung_Aufruf( hWnd );
				break;
			case IDM_B_EMITTER:
				Emitterschaltung_Aufruf(hWnd);
				break;
			case IDM_B_KOLLEKTOR:
				Kollektorschaltung_Aufruf(hWnd);
				break;
			case IDM_B_SCHALT:
				Transistor_als_Schalter_Aufruf(hWnd);
				break;
			case IDM_F_DRAIN:
				Drainschaltung_Aufruf(hWnd);
				break;
			case IDM_F_GATE:
				Gateschaltung_Aufruf(hWnd);
				break;
			case IDM_F_SOURCE:
				Sourceschaltung(hWnd);
				break;
			case IDM_T_DIFFERENZ:
				Differenzverstaerker_Bipolar_Aufruf(hWnd);
				break;
			case IDM_T_AUSGANG:
				break;
			case IDM_DB_U_I:
				DezibelRechner_Aufruf();
				break;
			case IDM_DB_P_NF:
				dBmRechner_Aufruf();
				break;
			case IDM_E_FELD: 
				Elektrisches_Feld_Aufruf();
				break;
			case IDM_ZEIGERDIAGRAMM:
				Zeigerdiagramm_Aufruf();
				break;
			case IDM_REIHENSCHALTUNG:
				Reihenschaltung_Aufruf(hWnd);
				break;
			case IDM_PARALLELSCHALTUNG:
				Parallelschaltung_Aufruf(hWnd);
				break;
			case IDM_STERN_DREIECK:
				Stern_Dreieckschaltung_Aufruf(hWnd);
				break;
			case IDM_OP_INV:
				Invertierender_OP_Aufruf(hWnd);
				break;
			case IDM_OP_NONINV:
				Nichtinvertiernder_OP_Aufruf(hWnd);
				break;
			case IDM_OP_DIFFERENZIERER:
				Differenzierer_OP_Aufruf(hWnd);
				break;
			case IDM_OP_INTEGRATOR:
				Integrierer_OP_Aufruf(hWnd);
				break;
			case IDM_OP_SUMME:
				Summations_OP_Aufruf(hWnd);
				break;
			case IDM_BODE:
				Zeichne_OP_Bodeplot_Aufruf(hWnd);
				break;
			case IDM_RECHNER:
				ShellExecute(NULL, (LPCSTR)"open", (LPCSTR)"calc.exe", NULL, NULL, SW_SHOW);
				break;
			case IDM_EDITOR:
				ShellExecute(NULL, (LPCSTR)"open", (LPCSTR)"notepad.exe", NULL, NULL, SW_SHOW);
				break;
			case IDM_HILFE:
				Hilfe_Aufruf();
				break;
            case IDM_ABOUT:
				About_Aufruf();
                break;
            case IDM_EXIT:
				if (Daten_ver�ndert)
				{
					if (Abfrage("Daten wurden ver�ndert. Programm trotzdem beenden?") == 0)
						DestroyWindow(hWnd);
				}
				else
					DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_PAINT:
        {
	        PAINTSTRUCT ps;
		//	HDC hdc;
				
			BeginPaint(hWnd, &ps);
            //TODO: Zeichencode, der hdc verwendet, hier einf�gen...
            EndPaint(hWnd, &ps);
			return true;
        }
	case WM_SIZE:
		// Statuszeile anpassen
		SendMessage(hWndStatus, WM_SIZE, 0, 0);
		break;
	case WM_MENUSELECT:
		// Ein Menubefehl wurde ausgeklappt
		Kurzhilfe_Menu(LOWORD(wParam), hWndStatus);
		break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}
