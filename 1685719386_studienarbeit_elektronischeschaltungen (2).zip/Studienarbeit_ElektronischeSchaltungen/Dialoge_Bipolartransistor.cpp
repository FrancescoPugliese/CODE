#include "stdafx.h"

/*******************************************************************************************************************\
|																													|
| Modul Dialoge.cpp																									|
|																													|
| In diesem Modul sind die Meldungshandler f�r die Dialoge enthalten												|
| - BasisSchaltung_Dialog();																						|
| - Eingabe_BipolarTransistorwerte_Dialog();																		|
| - EmitterSchaltung_Dialog();																						|
| - Ergebnis_Bipolartransistor_als_Schalter_Dialog();																|
| -	ErgebnisBasisSchaltung_Dialog);																					|
| -	ErgebnisEmitterSchaltung_Dialog();																				|
| - ErgebnisKollektorSchaltung_Dialog();																			|
| - ESB_BasisSchaltung_Dialog();																					|
| -	ESB_EmitterSchaltung_Dialog();																					|
| - ESB_KollektorSchaltung_Dialog();																				|
| - Kennlinienfeld_Bipolar_Dialog();																				|
| - KollektorSchaltung_Dialog();																					|
| - Transistor_als_Schalter_Dialog();																				|
| - DoppelEmitterschaltung_Dialog();																				|
|  																													|
\*******************************************************************************************************************/

// Meldungshandler f�r Eingabe Bipolartransistor.
INT_PTR CALLBACK Eingabe_BipolarTransistorwerte_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
  // Ausgabe ge�ndert auf die Funktion "Bestimme_Bezeichner_wissenschaftlich. So wird ein Komma angezeigt
  // M. Alles 15.2.2018
  // �nderung 17.10.2019: Eingabe neben dem Fenster platzieren
  // �nderung 20.2.2020: Erweiterung auf Doppel-Emitterschaltung
  UNREFERENCED_PARAMETER(lParam);
  static bool NPN;
  HICON hIcon;
  char cText[40];

  switch (message)
  {
  case WM_SHOWWINDOW:
	// Fenster neben dem Dialog platzieren
	if (Eingabe_Dialog.Eingabe_Dialog_Positionieren)
	{
	  RECT Position_Aufrufer;

	  if (Eingabe_Dialog.hDlg_Aufrufer!=NULL)
	  {
		GetWindowRect(Eingabe_Dialog.hDlg_Aufrufer, &Position_Aufrufer );
		SetWindowPos( hDlg, NULL, Position_Aufrufer.right-UEBERLAPPUNG, Position_Aufrufer.top, 0, 0, SWP_NOZORDER|SWP_NOSIZE );
	  }
	  Eingabe_Dialog.Eingabe_Dialog_Positionieren = false; // Positionierung wieder ausschalten
	}
	// Eingabefokus in das erste Feld und den Wert markieren
	SetFocus(GetDlgItem(hDlg, ID_TXT1)); 
	SendMessage(GetDlgItem(hDlg, ID_TXT1), EM_SETSEL, 0, -1);
	break;
  case WM_INITDIALOG:
	hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_TRANSISTOR), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
	if (hIcon)
	  SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
	// Standardwerte f�r die optionalen Eingaben:
	SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)"0");
	SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)"0");
	SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)"0");
	SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)"0");
	// Nicht darzustellende Werte ausgrauen
	if (Eingabe_Dialog.Parameter_Bipolartransistor&1)	// keine Earlyspannung
	  EnableWindow(GetDlgItem(hDlg, ID_TXT3), FALSE); 
	if (Eingabe_Dialog.Parameter_Bipolartransistor & 8)	// kein U_CE_Sat
	  EnableWindow(GetDlgItem(hDlg, ID_TXT5), FALSE);
	if (Eingabe_Dialog.Parameter_Bipolartransistor & 16)	// kein IC_B_Sperrstrom
	  EnableWindow(GetDlgItem(hDlg, ID_TXT6), FALSE);
	if (Eingabe_Dialog.Parameter_Bipolartransistor & 32)	// keine Temperatur
	  EnableWindow(GetDlgItem(hDlg, ID_TXT4), FALSE);
	if (Eingabe_Dialog.Parameter_Bipolartransistor & 2)	// nur NPN-Transistor
	{
	  NPN = true;
	  SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 1, 0);
	  EnableWindow(GetDlgItem(hDlg, ID_PNP), FALSE);
	}
	if (Eingabe_Dialog.Parameter_Bipolartransistor & 4) // nur PNP-Transistor
	{
	  NPN = false;
	  SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 1, 0);
	  EnableWindow(GetDlgItem(hDlg, ID_NPN), FALSE);
	}
	// Daten des Transistors eintragen
	switch (Eingabe_Dialog.Auswahl_Schaltung)
	{
	case BASIS_SCHALTUNG:	// Basisschaltung
	  {
		Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.Beta, 39);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.U_BE, 39);
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.U_AF, 39);
		SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.T, 39);
		SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
		SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 0, 0);
		SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 0, 0);
		if (Basis_Schaltung.NPN)
		{
		  SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 1, 0);
		  NPN = true;
		}
		else
		{
		  SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 1, 0);
		  NPN = false;
		}
		break;
	  }
	case EMITTER_SCHALTUNG: // Emitterschaltung
	  {
		Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.Beta, 39);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.U_BE, 39);
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.U_AF, 39);
		SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.T, 39);
		SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
		SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 0, 0);
		SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 0, 0);
		if (Emitter_Schaltung.NPN)
		{
		  SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 1, 0);
		  NPN = true;
		}
		else
		{
		  SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 1, 0);
		  NPN = false;
		}
		break;
	  }
	case KOLLEKTOR_SCHALTUNG:	// Kollektorschaltung
	  {
		Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.Beta, 39);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.U_BE, 39);
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.U_AF, 39);
		SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.T, 39);
		SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
		SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 0, 0);
		SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 0, 0);
		if (Kollektor_Schaltung.NPN)
		{
		  SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 1, 0);
		  NPN = true;
		}
		else
		{
		  SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 1, 0);
		  NPN = false;
		}
		break;
	  }
	case TRANSISTOR_ALS_SCHALTER: // Bipolartransistor als Schalter
	  {
		Bestimme_Bezeichner_wissenschaftlich(cText, Bipolartransistor_als_Schalter.Beta, 39);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Bipolartransistor_als_Schalter.U_BE, 39);
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Bipolartransistor_als_Schalter.I_CB_Sperr, 39);
		SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Bipolartransistor_als_Schalter.U_CE_Sat, 39);
		SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
		SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 0, 0);
		SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 0, 0);
		if (Bipolartransistor_als_Schalter.NPN)
		{
		  SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 1, 0);
		  NPN = true;
		}
		else
		{
		  SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 1, 0);
		  NPN = false;
		}
		break;
	  }
	case DIFFERENZVERSTAERKER: // Differenzverst�rker, Transistoren in den beiden Parallelzweigen
	  {
		Bestimme_Bezeichner_wissenschaftlich(cText, Differenzverstaerker.Beta_T1, 39);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Differenzverstaerker.U_BE_T1, 39);
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Differenzverstaerker.U_AF_T1, 39);
		SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
		SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 0, 0);
		SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 0, 0);
		if (Differenzverstaerker.NPN_T1)
		{
		  SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 1, 0);
		  NPN = true;
		}
		else
		{
		  SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 1, 0);
		  NPN = false;
		}
		break;
	  }
	case DIFFERENZVERSTAERKER_STROMQUELLE: // Differenzverst�rker, Stromquellentransistor
	  {
		Bestimme_Bezeichner_wissenschaftlich(cText, Differenzverstaerker.Beta_T2, 39);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Differenzverstaerker.U_BE_T2, 39);
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
		SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 0, 0);
		SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 0, 0);
		if (Differenzverstaerker.NPN_T2)
		{
		  SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 1, 0);
		  NPN = true;
		}
		else
		{
		  SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 1, 0);
		  NPN = false;
		}
		break;
	  }
	case DOPPEL_EMITTER: // EmitterSchaltung mit zwei Bipolartransistoren, erster Transistor
	  {
		Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.Beta_T1, 39);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.U_BE_T1, 39);
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.U_AF_T1, 39);
		SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.T, 39);
		SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
		SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 0, 0);
		SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 0, 0);
		if (Doppel_Emitter_Schaltung.NPN_T1)
		{
		  SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 1, 0);
		  NPN = true;
		}
		else
		{
		  SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 1, 0);
		  NPN = false;
		}
		break;
	  }
	case DOPPEL_EMITTER_TRANS_2: // EmitterSchaltung mit zwei Bipolartransistoren, zweiter Transistor
	  {
		Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.Beta_T2, 39);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.U_BE_T2, 39);
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.U_AF_T2, 39);
		SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.T, 39);
		SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
		SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 0, 0);
		SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 0, 0);
		if (Doppel_Emitter_Schaltung.NPN_T2)
		{
		  SendMessage(GetDlgItem(hDlg, ID_NPN), BM_SETCHECK, 1, 0);
		  NPN = true;
		}
		else
		{
		  SendMessage(GetDlgItem(hDlg, ID_PNP), BM_SETCHECK, 1, 0);
		  NPN = false;
		}
		break;
	  }
	}

	return (INT_PTR)TRUE;
  case WM_PAINT: // Transistor zeichnen
	{
	  PAINTSTRUCT ps;
	  HPEN hStiftSchwarz3, hStiftAlt;
	  HBRUSH hPinselSchwarz, hPinselAlt;
	  HDC hdc = BeginPaint(hDlg, &ps);

	  Rechteck_BH_Flaeche(hdc, 220, 300, 300, 400, (HBRUSH)COLOR_WINDOW);

	  hStiftSchwarz3 = CreatePen(PS_SOLID, 3, BLACK_PEN);
	  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz3);
	  hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
	  hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

	  // Transistor (NPN) Position: x: 250 (250-300) y: 300-400
	  Zeichne_Bipolartransistor(hdc, 250, 300, 50, 100, NPN, 25);

	  SelectObject(hdc, hStiftAlt);
	  DeleteObject(hStiftSchwarz3);
	  SelectObject(hdc, hPinselAlt);
	  DeleteObject(hPinselSchwarz);

	  EndPaint(hDlg, &ps);
	}
	break;
  case WM_COMMAND:
	switch (wParam)
	{
	case IDOK: // Eingabe pr�fen und �bernehmen
	  {
		double wert1, wert2, wert3, wert4, wert5, wert6;
		bool eingabe_ok = true;

		wert1 = Eingabe_parsen(hDlg, ID_TXT1);
		// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
		if (wert1 <= 0.0)
		{
		  Warnung("Wert f�r Beta muss gr��er 0 sein!");
		  SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)"200");
		  eingabe_ok = false;
		}
		wert2 = Eingabe_parsen(hDlg, ID_TXT2);
		// Die Werte kontrollieren: negative Werte sind unsinnig...
		if (wert2 < 0.0)
		{
		  Warnung("Wert f�r U_BE muss gr��er oder gleich 0V sein!");
		  SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"600m");
		  eingabe_ok = false;
		}
		wert3 = 0.0;
		if (!(Eingabe_Dialog.Parameter_Bipolartransistor & BIPOLAR_EARLYSPANNUNG)) // Earlyspannung auswerten
		{
		  wert3 = Eingabe_parsen(hDlg, ID_TXT3);
		  // Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
		  if (wert3 <= 0.0)
		  {
			Warnung("Wert f�r Early-Spannung muss gr��er 0V sein!");
			SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)"80");
			eingabe_ok = false;
		  }
		}
		wert4 = 0.0;
		if (!(Eingabe_Dialog.Parameter_Bipolartransistor & BIPOLAR_TEMPERATUR)) // Temperatur auswerten
		{
		  wert4 = Eingabe_parsen(hDlg, ID_TXT4);
		  // Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
		  if (wert4 <= 0.0)
		  {
			Warnung("Wert f�r Temperatur muss gr��er 0K sein!");
			SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)"300");
			eingabe_ok = false;
		  }
		}
		wert5 = 0.0;
		if (!(Eingabe_Dialog.Parameter_Bipolartransistor & BIPOLAR_U_CE_SAT)) // U_CE_Sat auswerten
		{
		  wert5 = Eingabe_parsen(hDlg, ID_TXT5);
		  // Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
		  if (wert5 <= 0.0)
		  {
			Warnung("Wert f�r S�ttigungsspannung muss gr��er 0V sein!");
			SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)"300m");
			eingabe_ok = false;
		  }
		}
		wert6 = 0.0;
		if (!(Eingabe_Dialog.Parameter_Bipolartransistor & BIPOLAR_I_CB_SPERR)) // Sperrstrom auswerten
		{
		  wert6 = Eingabe_parsen(hDlg, ID_TXT6);
		  // Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
		  if (wert6 <= 0.0)
		  {
			Warnung("Wert f�r Sperrstrom muss gr��er 0�A sein!");
			SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)"5");
			eingabe_ok = false;
		  }
		}
		if (eingabe_ok)
		{
		  switch( Eingabe_Dialog.Auswahl_Schaltung)
		  {
		  case BASIS_SCHALTUNG: // Basisschaltung				// Die Werte speichern und das Dialogfenster schlie�en
			{
			  Basis_Schaltung.Beta = wert1;
			  Basis_Schaltung.U_BE = wert2;
			  Basis_Schaltung.U_AF = wert3;
			  Basis_Schaltung.T = wert4;
			  Basis_Schaltung.NPN = NPN;
			  break;
			}
		  case EMITTER_SCHALTUNG: 	// Emitterschaltung				// Die Werte speichern und das Dialogfenster schlie�en
			{
			  Emitter_Schaltung.Beta = wert1;
			  Emitter_Schaltung.U_BE = wert2;
			  Emitter_Schaltung.U_AF = wert3;
			  Emitter_Schaltung.T = wert4;
			  Emitter_Schaltung.NPN = NPN;
			  break;
			}
		  case KOLLEKTOR_SCHALTUNG:	// Kollektorschaltung				// Die Werte speichern und das Dialogfenster schlie�en
			{
			  Kollektor_Schaltung.Beta = wert1;
			  Kollektor_Schaltung.U_BE = wert2;
			  Kollektor_Schaltung.U_AF = wert3;
			  Kollektor_Schaltung.T = wert4;
			  Kollektor_Schaltung.NPN = NPN;
			  break;
			}
		  case TRANSISTOR_ALS_SCHALTER:	// Bipolartransistor als Schalter		// Die Werte speichern und das Dialogfenster schlie�en
			{
			  Bipolartransistor_als_Schalter.Beta = wert1;
			  Bipolartransistor_als_Schalter.U_BE = wert2;
			  Bipolartransistor_als_Schalter.U_CE_Sat = wert5;
			  Bipolartransistor_als_Schalter.I_CB_Sperr = wert6;
			  Bipolartransistor_als_Schalter.NPN = NPN;
			  break;
			}
		  case DIFFERENZVERSTAERKER:	// Differenzverst�rker, Parallelzweig = T1		// Die Werte speichern und das Dialogfenster schlie�en
			{
			  Differenzverstaerker.Beta_T1 = wert1;
			  Differenzverstaerker.U_BE_T1 = wert2;
			  Differenzverstaerker.NPN_T1 = NPN;
			  Differenzverstaerker.U_AF_T1 = wert3;
			  break;
			}
		  case DIFFERENZVERSTAERKER_STROMQUELLE:	// Differenzverst�rker, Stromquelle = T3		// Die Werte speichern und das Dialogfenster schlie�en
			{
			  Differenzverstaerker.Beta_T2 = wert1;
			  Differenzverstaerker.U_BE_T2 = wert2;
			  Differenzverstaerker.NPN_T2 = NPN;
			  break;
			}
		  case DOPPEL_EMITTER:	// Emitterschaltung mit zwei Transistoren, Transistor 1		// Die Werte speichern und das Dialogfenster schlie�en
			{
			  Doppel_Emitter_Schaltung.Beta_T1 = wert1;
			  Doppel_Emitter_Schaltung.U_BE_T1 = wert2;
			  Doppel_Emitter_Schaltung.U_AF_T1 = wert3;
			  Doppel_Emitter_Schaltung.T = wert4;
			  Doppel_Emitter_Schaltung.NPN_T1 = NPN;
			  break;
			}
		  case DOPPEL_EMITTER_TRANS_2:	// Emitterschaltung mit zwei Transistoren, Transistor 2		// Die Werte speichern und das Dialogfenster schlie�en
			{
			  Doppel_Emitter_Schaltung.Beta_T2 = wert1;
			  Doppel_Emitter_Schaltung.U_BE_T2 = wert2;
			  Doppel_Emitter_Schaltung.U_AF_T2 = wert3;
			  Doppel_Emitter_Schaltung.T = wert4;
			  Doppel_Emitter_Schaltung.NPN_T2 = NPN;
			  break;
			}
		  }
		  Daten_geaendert();
		  EndDialog(hDlg, LOWORD(wParam));
		}
		break;
	  }
	case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
	case ID_NPN:
	  NPN = true;
	  CheckRadioButton(hDlg, ID_NPN, ID_PNP, LOWORD(wParam));
	  InvalidateRect(hDlg, NULL, true);	// Erforderlich, um den Transistor neu zu zeichnen
	  break;
	case ID_PNP:
	  NPN = false;
	  InvalidateRect(hDlg, NULL, true);	// Erforderlich, um den Transistor neu zu zeichnen
	  CheckRadioButton(hDlg, ID_NPN, ID_PNP, LOWORD(wParam));
	  break;
	}
	break;

  }
  return (INT_PTR)FALSE;
}	// end of Eingabe_Bipolartransistor

// Meldungshandler f�r BasisSchaltung.
INT_PTR CALLBACK BasisSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Funktion ok
	// �nderung 19.10.2019: Erg�nzung, dass Eingabefelder neben diesem Dialog angezeigt werden
	// �nderung 19.10.2019 Dialogfenster kann erst geschlossen werden, wenn alle Eingaben beendet sind
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	bool neuzeichnen = false;
	HICON hIcon;
	static int Anzahl_Dialoge; // Z�hlt die offenen Dialoge und erlaubt ein Schlie�en des Fensters erst, wenn alle Eingabe beendet sind

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Kapazitaetsbezeichner(cText, Basis_Schaltung.C[C_EIN], 99);
		SetDlgItemText(hDlg, ID_C1, (LPCSTR)cText);
		Bestimme_Kapazitaetsbezeichner(cText, Basis_Schaltung.C[C_AUS], 99);
		SetDlgItemText(hDlg, ID_C2, (LPCSTR)cText);
		Bestimme_Kapazitaetsbezeichner(cText, Basis_Schaltung.C[C_BASIS_BS], 99);
		SetDlgItemText(hDlg, ID_C3, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Basis_Schaltung.R[R_BASIS_UB], 99);
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Basis_Schaltung.R[R_BASIS_GND], 99);
		SetDlgItemText(hDlg, ID_R2, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Basis_Schaltung.R[2], 99);
		SetDlgItemText(hDlg, ID_R3, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Basis_Schaltung.R[3], 99);
		SetDlgItemText(hDlg, ID_R4, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Basis_Schaltung.U_B, 99);
		SetDlgItemText(hDlg, ID_UB, (LPCSTR)cText);
		if (Basis_Schaltung.Naeherung_r_CE)
			SendMessage(GetDlgItem(hDlg, ID_CB1), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_CB1), BM_SETCHECK, 0, 0);
		if (Basis_Schaltung.Naeherung_U_T)
			SendMessage(GetDlgItem(hDlg, ID_CB2), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_CB2), BM_SETCHECK, 0, 0);

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_BASISSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Zu Beginn die Kn�pfe positionieren, die Daten aus der Resource-Datei weichen ab...
		// Verschieben von R1-R5:
		MoveWindow(GetDlgItem(hDlg, ID_R1), 120, 70, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R2), 220, 390, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R3), 220, 45, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R4), 320, 420, 60, 40, true);
		//Verschieben von C3 
		MoveWindow(GetDlgItem(hDlg, ID_C3), 110, 380, 60, 40, true);
		// Verschieben von U_B 
		MoveWindow(GetDlgItem(hDlg, ID_UB), 520, 60, 40, 40, true);
		if (Basis_Schaltung.NPN) // NPN-Transistor
		{
			// Verschieben von C1 auf die alte Position
			MoveWindow(GetDlgItem(hDlg, ID_C1), 80, 275, 60, 40, true);
			// Verschieben von C2 auf die alte Position
			MoveWindow(GetDlgItem(hDlg, ID_C2), 330, 160, 60, 40, true);
			// Verschieben von T1
			MoveWindow(GetDlgItem(hDlg, ID_TRANS), 270, 135, 40, 30, true);
		}
		else
		{
			// Verschieben von C1 auf die PNP- Position
			MoveWindow(GetDlgItem(hDlg, ID_C1), 80, 220, 60, 40, true);
			// Verschieben von C2 auf die PNP- Position
			MoveWindow(GetDlgItem(hDlg, ID_C2), 330, 350, 60, 40, true);
			// Verschieben von T1 auf die PNP- Position
			MoveWindow(GetDlgItem(hDlg, ID_TRANS), 275, 235, 40, 30, true);
		}
		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);

		Zeichne_Basisschaltung(Basis_Schaltung, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		// sorgt mit der globalen Variablen Eingabe_Dialog_Positionieren f�r eine Platzierung der Eingabe neben dem
		// aktuellen Fenster
		Eingabe_Dialog.hDlg_Aufrufer = hDlg;
		switch (wParam)
		{
		case ID_C1:
			Anzahl_Dialoge++;
			// Erste Kapazit�t: 1, Zweite Kapazit�t 2, ...
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Kapazitaetswerte_Aufruf(1, 3, BASIS_SCHALTUNG);
			Anzahl_Dialoge--;
			neuzeichnen = true;
			break;
		case ID_C2:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Kapazitaetswerte_Aufruf(2, 3, BASIS_SCHALTUNG);
			Anzahl_Dialoge--;
			neuzeichnen = true;
			break;
		case ID_C3:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Kapazitaetswerte_Aufruf(3, 3, BASIS_SCHALTUNG);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_R1:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			// Erster Widerstand: 1, Zweiter Widerstand 2, ...
			Eingabe_Widerstandswerte_Aufruf(1, 4, BASIS_SCHALTUNG);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_R2:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(2, 4, BASIS_SCHALTUNG);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_R3:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(3, 4, BASIS_SCHALTUNG);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_R4:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(4, 4, BASIS_SCHALTUNG);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_TRANS:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_BipolarTransistorwerte_Aufruf(BASIS_SCHALTUNG, 24);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_UB:
			Anzahl_Dialoge++;
			Eingabe_Spannungswert_Aufruf(BASIS_SCHALTUNG, U_BETRIEB);
			neuzeichnen = true;
			Anzahl_Dialoge--;
			break;
		case ID_ESB:
			ESB_Basisschaltung(hDlg);
			break;
		case ID_CB1:
			(IsDlgButtonChecked(hDlg, ID_CB1) == BST_CHECKED) ? Basis_Schaltung.Naeherung_r_CE = true : Basis_Schaltung.Naeherung_r_CE = false;
			Daten_geaendert();
			break;
		case ID_CB2:
			(IsDlgButtonChecked(hDlg, ID_CB2) == BST_CHECKED) ? Basis_Schaltung.Naeherung_U_T = true : Basis_Schaltung.Naeherung_U_T = false;
			Daten_geaendert();
			break;
		case ID_CALC:
			Ergebnis_Basisschaltung(hDlg);
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Basisschaltung(Basis_Schaltung);
			break;
		case IDCANCEL:
		case ID_CLOSE:
			if (Anzahl_Dialoge==0)
				EndDialog(hDlg, LOWORD(wParam));
			else
				Warnung( (LPSTR)"Bitte erst die Eingabefenster beenden.");
			break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
			InvalidateRect(hDlg, 0, true);
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of BasisSchaltung

// Meldungshandler f�r EmitterSchaltung.
INT_PTR CALLBACK EmitterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Funktion ok
	// �nderung 19.10.2019: Eingabegfelder werden neben diesem Dialog angezeigt
	// �nderung 19.10.2019 Dialogfenster kann erst geschlossen werden, wenn alle Eingaben beendet sind
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	HICON hIcon;
	bool neuzeichnen = false;
	static int Anzahl_Dialoge; // Z�hlt die offenen Dialoge und erlaubt ein Schlie�en des Fensters erst, wenn alle Eingabe beendet sind
	
	switch (message)
	{
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_EMITTERSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Kapazitaetsbezeichner(cText, Emitter_Schaltung.C[0], 99);
		SetDlgItemText(hDlg, ID_C1, (LPCSTR)cText);
		Bestimme_Kapazitaetsbezeichner(cText, Emitter_Schaltung.C[1], 99);
		SetDlgItemText(hDlg, ID_C2, (LPCSTR)cText);
		Bestimme_Kapazitaetsbezeichner(cText, Emitter_Schaltung.C[2], 99);
		SetDlgItemText(hDlg, ID_C3, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[R_BASIS_UB], 99);
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[R_BASIS_GND], 99);
		SetDlgItemText(hDlg, ID_R2, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[2], 99);
		SetDlgItemText(hDlg, ID_R3, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[3], 99);
		SetDlgItemText(hDlg, ID_R4, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Emitter_Schaltung.R[4], 99);
		SetDlgItemText(hDlg, ID_R5, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Emitter_Schaltung.U_B, 99);
		SetDlgItemText(hDlg, ID_UB, (LPCSTR)cText);
		if (Emitter_Schaltung.Naeherung_r_CE)
			SendMessage(GetDlgItem(hDlg, ID_CB1), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_CB1), BM_SETCHECK, 0, 0);
		if (Emitter_Schaltung.Naeherung_U_T)
			SendMessage(GetDlgItem(hDlg, ID_CB2), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_CB2), BM_SETCHECK, 0, 0);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Emitterschaltung mit Widerst�nden, Transistor und Spannungsquelle

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		// Zu Beginn die Kn�pfe positionieren, die Daten aus der Resource-Datei weichen ab...
		// Verschieben von R1-R5:
		MoveWindow(GetDlgItem(hDlg, ID_R1), 120, 70, 60, 40, true);  // funktioniert
		MoveWindow(GetDlgItem(hDlg, ID_R2), 120, 340, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R3), 220, 50, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R5), 220, 420, 60, 40, true);
		//Verschieben von C1 und Text f�r C1
		MoveWindow(GetDlgItem(hDlg, ID_C1), 80, 155, 60, 40, true);
		// Verschieben von U_B 
		MoveWindow(GetDlgItem(hDlg, ID_UB), 520, 60, 40, 40, true);
		if (Emitter_Schaltung.NPN)   //Emitterschaltung mit NPN-Transistor
		{
			// Verschieben von Button R4 auf den alten Wert
			MoveWindow(GetDlgItem(hDlg, ID_R4), 220, 330, 60, 40, true);  // funktioniert
			// Verschieben von Button C2
			MoveWindow(GetDlgItem(hDlg, ID_C2), 330, 260, 60, 40, true);  // funktioniert
			// Verschieben von C3
			MoveWindow(GetDlgItem(hDlg, ID_C3), 420, 450, 60, 40, true);
			// Verschieben von T1
			MoveWindow(GetDlgItem(hDlg, ID_TRANS), 270, 235, 40, 30, true);
		}
		else
		{
			// Verschieben von Button R4 um ?190
			MoveWindow(GetDlgItem(hDlg, ID_R4), 220, 140, 60, 40, true);  // funktioniert
			// Verschieben von Button C2
			MoveWindow(GetDlgItem(hDlg, ID_C2), 330, 350, 60, 40, true);
			// Verschieben von C3
			MoveWindow(GetDlgItem(hDlg, ID_C3), 410, 70, 60, 40, true);
			// Verschieben von T1 auf die PNP- Position
			MoveWindow(GetDlgItem(hDlg, ID_TRANS), 275, 235, 40, 30, true);
		}
		Zeichne_Emitterschaltung(Emitter_Schaltung, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		// sorgt mit der globalen Variablen Eingabe_Dialog_Positionieren f�r eine Platzierung der Eingabe neben dem
		// aktuellen Fenster
		Eingabe_Dialog.hDlg_Aufrufer = hDlg;
		switch (wParam)
		{
		case ID_C1: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Kapazitaetswerte_Aufruf(1, 3, EMITTER_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_C2: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Kapazitaetswerte_Aufruf(2, 3, EMITTER_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_C3: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Kapazitaetswerte_Aufruf(3, 3, EMITTER_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R1: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(1, 5, EMITTER_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R2: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(2, 5, EMITTER_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R3: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(3, 5, EMITTER_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R4: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(4, 5, EMITTER_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R5: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(5, 5, EMITTER_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_TRANS: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_BipolarTransistorwerte_Aufruf(EMITTER_SCHALTUNG, 24); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_UB: 
			Anzahl_Dialoge++;
			Eingabe_Spannungswert_Aufruf(EMITTER_SCHALTUNG, U_BETRIEB); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_ESB: ESB_Emitterschaltung(hDlg);  break;
		case ID_CB1: 
			(IsDlgButtonChecked(hDlg, ID_CB1) == BST_CHECKED) ? Emitter_Schaltung.Naeherung_r_CE = true : Emitter_Schaltung.Naeherung_r_CE = false; 
			Daten_geaendert();
			break;
		case ID_CB2: 
			(IsDlgButtonChecked(hDlg, ID_CB2) == BST_CHECKED) ? Emitter_Schaltung.Naeherung_U_T = true : Emitter_Schaltung.Naeherung_U_T = false; 
			Daten_geaendert();
			break;
		case ID_CALC:
			Ergebnis_Emitterschaltung(hDlg);
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Emitterschaltung(Emitter_Schaltung);
			break;
		case IDCANCEL:
		case ID_CLOSE:
			if (Anzahl_Dialoge==0)
				EndDialog(hDlg, LOWORD(wParam));
			else
				Warnung( (LPSTR)"Bitte erst die Eingabefenster beenden.");
			break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
		}InvalidateRect(hDlg, 0, true);
		break;
	}
	return (INT_PTR)FALSE;
}	// end of EmitterSchaltung

// Meldungshandler f�r KollektorSchaltung.
INT_PTR CALLBACK KollektorSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	HICON hIcon;
	bool neuzeichnen = false;
	static int Anzahl_Dialoge; // Z�hlt die offenen Dialoge und erlaubt ein Schlie�en des Fensters erst, wenn alle Eingabe beendet sind

	switch (message)
	{
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_KOLLEKTORSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Kapazitaetsbezeichner(cText, Kollektor_Schaltung.C[0], 99);
		SetDlgItemText(hDlg, ID_C1, (LPCSTR)cText);
		Bestimme_Kapazitaetsbezeichner(cText, Kollektor_Schaltung.C[1], 99);
		SetDlgItemText(hDlg, ID_C2, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Kollektor_Schaltung.R[0], 99);
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Kollektor_Schaltung.R[1], 99);
		SetDlgItemText(hDlg, ID_R2, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Kollektor_Schaltung.R[2], 99);
		SetDlgItemText(hDlg, ID_R3, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Kollektor_Schaltung.U_B, 99);
		SetDlgItemText(hDlg, ID_UB, (LPCSTR)cText);
		if (Kollektor_Schaltung.Naeherung_r_CE)
			SendMessage(GetDlgItem(hDlg, ID_CB1), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_CB1), BM_SETCHECK, 0, 0);
		if (Kollektor_Schaltung.Naeherung_U_T)
			SendMessage(GetDlgItem(hDlg, ID_CB2), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_CB2), BM_SETCHECK, 0, 0);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Kollektorschaltung mit Widerst�nden, Transistor und Spannungsquelle
		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		// Zu Beginn die Kn�pfe positionieren, die Daten aus der Resource-Datei weichen ab...
		// Verschieben von R1-R3:
		MoveWindow(GetDlgItem(hDlg, ID_R1), 220, 70, 60, 40, true);  // funktioniert
		MoveWindow(GetDlgItem(hDlg, ID_R2), 120, 260, 60, 40, true);
		//Verschieben von C1 und Text f�r C1
		MoveWindow(GetDlgItem(hDlg, ID_C1), 80, 85, 60, 40, true);
		// Verschieben von U_B 
		MoveWindow(GetDlgItem(hDlg, ID_UB), 520, 60, 40, 40, true);
		// Verschieben von T1
		MoveWindow(GetDlgItem(hDlg, ID_TRANS), 270, 165, 40, 30, true);

		if (Kollektor_Schaltung.NPN)   //Kollektorschaltung mit NPN-Transistor
		{
			// Verschieben von Button C2
			MoveWindow(GetDlgItem(hDlg, ID_C2), 330, 285, 60, 40, true);  
			// Verschieben von Button R3
			MoveWindow(GetDlgItem(hDlg, ID_R3), 220, 310, 60, 40, true);  
		}
		else
		{
			// Verschieben von Button C2
			MoveWindow(GetDlgItem(hDlg, ID_C2), 330, 185, 60, 40, true);
			// Verschieben von Button R3
			MoveWindow(GetDlgItem(hDlg, ID_R3), 320, 35, 60, 40, true);  // Kondensator im Weg
		}
		Zeichne_Kollektorschaltung(Kollektor_Schaltung, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		// sorgt mit der globalen Variablen Eingabe_Dialog_Positionieren f�r eine Platzierung der Eingabe neben dem
		// aktuellen Fenster
		Eingabe_Dialog.hDlg_Aufrufer = hDlg;
		switch (wParam)
		{
		case ID_C1:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Kapazitaetswerte_Aufruf(1, 2, KOLLEKTOR_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_C2:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Kapazitaetswerte_Aufruf(2, 2, KOLLEKTOR_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R1:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(1, 3, KOLLEKTOR_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R2:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(2, 3, KOLLEKTOR_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R3:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(3, 3, KOLLEKTOR_SCHALTUNG); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_TRANS:
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_BipolarTransistorwerte_Aufruf(KOLLEKTOR_SCHALTUNG, 24); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_UB:
			Anzahl_Dialoge++;
			Eingabe_Spannungswert_Aufruf(KOLLEKTOR_SCHALTUNG, U_BETRIEB); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_ESB: ESB_Kollektorschaltung(hDlg);  break;
		case ID_CB1: 
			(IsDlgButtonChecked(hDlg, ID_CB1) == BST_CHECKED) ? Kollektor_Schaltung.Naeherung_r_CE = true : Kollektor_Schaltung.Naeherung_r_CE = false; 
			Daten_geaendert();
			break;
		case ID_CB2: 
			(IsDlgButtonChecked(hDlg, ID_CB2) == BST_CHECKED) ? Kollektor_Schaltung.Naeherung_U_T = true : Kollektor_Schaltung.Naeherung_U_T = false; 
			Daten_geaendert();
			break;
		case ID_CALC:
			Ergebnis_Kollektorschaltung(hDlg);
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Kollektorschaltung(Kollektor_Schaltung);
			break;
		case IDCANCEL:
		case ID_CLOSE:
			if (Anzahl_Dialoge==0)
				EndDialog(hDlg, LOWORD(wParam));
			else
				Warnung( (LPSTR)"Bitte erst die Eingabefenster beenden.");
			break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
		}InvalidateRect(hDlg, 0, true);
		break;
	}
	return (INT_PTR)FALSE;
}	// end of Kollektorschaltung

// Meldungshandler f�r ErgebnisBasisSchaltung.
INT_PTR CALLBACK ErgebnisBasisSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);

	switch (message)
	{
	case WM_INITDIALOG:
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_BASISSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		SetWindowText(hDlg, (LPCSTR)"Berechnung der Basisschaltung : ");
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		Zeichne_Ausgabe_Basisschaltung(Basis_Schaltung, hdc, false);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_COPY_CLIPBOARD:
			Kopiere_Ergebnis_Bipolar_Transistorschaltung(Basis_Schaltung, hWndElektronikMain, BASIS_SCHALTUNG);
			break;
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Ergebnis_BasisSchaltung

// Meldungshandler f�r ESB_BasisSchaltung.
INT_PTR CALLBACK ESB_BasisSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		HICON hIcon;

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_BASISSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Basisschaltung mit Widerst�nden, Transistor und Spannungsquelle
		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		Zeichne_ESB_Basisschaltung(Basis_Schaltung, hdc, false);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_COPY_CLIPBOARD:
			Kopiere_ESB_Basisschaltung(Basis_Schaltung);
			break;
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of ESB_BasisSchaltung

// Meldungshandler f�r ErgebnisEmitterSchaltung.
INT_PTR CALLBACK ErgebnisEmitterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);

	switch (message)
	{
	case WM_INITDIALOG:
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_EMITTERSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
		SetWindowText(hDlg, (LPCSTR)"Berechnung der Emitterschaltung : ");

		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;

		HDC hdc = BeginPaint(hDlg, &ps);

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		Zeichne_Ausgabe_Emitterschaltung(Emitter_Schaltung, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_KENNLINIE:
			Kennlinienfeld_Bipolar_Aufruf(hWndElektronikMain);
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Ergebnis_Bipolar_Transistorschaltung(Emitter_Schaltung, hWndElektronikMain, EMITTER_SCHALTUNG);
			break;
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Ergebnis_EmitterSchaltung

// Meldungshandler f�r ESB_EmitterSchaltung.
INT_PTR CALLBACK ESB_EmitterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		HICON hIcon;

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_EMITTERSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Emitterschaltung mit Widerst�nden, Transistor und Spannungsquelle
		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		Zeichne_ESB_Emitterschaltung(Emitter_Schaltung, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_COPY_CLIPBOARD:
			Kopiere_ESB_Emitterschaltung(Emitter_Schaltung);
			break;
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); 
			break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of ESB_EmitterSchaltung

// Meldungshandler f�r ErgebnisKollektorSchaltung.
INT_PTR CALLBACK ErgebnisKollektorSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);

	switch (message)
	{
	case WM_INITDIALOG:
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_KOLLEKTORSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		SetWindowText(hDlg, (LPCSTR)"Berechnung der Kollektorschaltung : ");

		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;

		HDC hdc = BeginPaint(hDlg, &ps);
		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);

		Zeichne_Ausgabe_Kollektorschaltung(Kollektor_Schaltung, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_COPY_CLIPBOARD:
			Kopiere_Ergebnis_Bipolar_Transistorschaltung(Kollektor_Schaltung, hWndElektronikMain, KOLLEKTOR_SCHALTUNG);
			break;
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Ergebnis_KollektorSchaltung

// Meldungshandler f�r ESB_KollektorSchaltung.
INT_PTR CALLBACK ESB_KollektorSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		HICON hIcon;

		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_KOLLEKTORSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Kollektorschaltung mit Widerst�nden, Transistor und Spannungsquelle
		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		Zeichne_ESB_Kollektorschaltung( Kollektor_Schaltung, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_COPY_CLIPBOARD:
			Kopiere_ESB_Kollektorschaltung(Kollektor_Schaltung);
			break;
		case IDCANCEL: 
			EndDialog(hDlg, LOWORD(wParam)); 
		break;
		}
	break;
	}
	return (INT_PTR)FALSE;
}	// end of ESB_KollektorSchaltung



// Meldungshandler f�r Bipolartransistor als Schalter
INT_PTR CALLBACK Transistor_als_Schalter_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Funktion ok
	// �nderung 19.10.2019: Eingabefenster werden neben diesem Dialog dargestellt.
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	HICON hIcon;
	bool neuzeichnen = false;

	switch (message)
	{
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_EMITTERSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		//Bestimme_Kapazitaetsbezeichner(Text, Bipolartransistor_als_Schalter.C, 99);
		//SetDlgItemText(hDlg, ID_TXT_C1, (LPCWSTR)Text);
		Bestimme_Widerstandsbezeichner(cText, Bipolartransistor_als_Schalter.R[0], 99);
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Bipolartransistor_als_Schalter.R[1], 99);
		SetDlgItemText(hDlg, ID_R2, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Bipolartransistor_als_Schalter.R[2], 99);
		SetDlgItemText(hDlg, ID_R3, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Bipolartransistor_als_Schalter.U_B, 99);
		SetDlgItemText(hDlg, ID_UB, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Bipolartransistor_als_Schalter.U_Schalt, 99);
		SetDlgItemText(hDlg, ID_U_SCHALT, (LPCSTR)cText);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);

		// Zu Beginn die Kn�pfe positionieren, die Daten aus der Resource-Datei weichen ab...
		// Verschieben von R1-R3:
		MoveWindow(GetDlgItem(hDlg, ID_R1), 145, 270, 60, 40, true);  // funktioniert
		MoveWindow(GetDlgItem(hDlg, ID_R2), 320, 70, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R3), 270, 280, 60, 40, true);
		// Verschieben von U_B 
		MoveWindow(GetDlgItem(hDlg, ID_UB), 585, 80, 40, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_U_SCHALT), 55, 290, 40, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_TRANS), 400, 235, 40, 30, true);
		Zeichne_Transistor_als_Schalter(Bipolartransistor_als_Schalter, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		// sorgt mit der globalen Variablen Eingabe_Dialog_Positionieren f�r eine Platzierung der Eingabe neben dem
		// aktuellen Fenster
		Eingabe_Dialog.hDlg_Aufrufer = hDlg;
		switch (wParam)
		{
		case ID_R1: 
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(1, 3, TRANSISTOR_ALS_SCHALTER); 
			neuzeichnen = true; 
			break;
		case ID_R2: 
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(2, 3, TRANSISTOR_ALS_SCHALTER); 
			neuzeichnen = true; 
			break;
		case ID_R3: 
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_Widerstandswerte_Aufruf(3, 3, TRANSISTOR_ALS_SCHALTER); 
			neuzeichnen = true; 
			break;
		case ID_TRANS: 
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true;
			Eingabe_BipolarTransistorwerte_Aufruf(TRANSISTOR_ALS_SCHALTER, 35); 
			neuzeichnen = true; 
			break;
		case ID_UB: 
			Eingabe_Spannungswert_Aufruf(TRANSISTOR_ALS_SCHALTER, U_BETRIEB); 
			neuzeichnen = true; 
			break;
		case ID_U_SCHALT: 
			Eingabe_Spannungswert_Aufruf(TRANSISTOR_ALS_SCHALTER_U_SCHALT, U_SCHALT); 
			neuzeichnen = true; 
			break;
		case ID_CALC:
			Ergebnis_Bipolartransistor_als_Schalter_Aufruf(hDlg);
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Transistor_als_Schalter(Bipolartransistor_als_Schalter);
			break;
		case IDCANCEL:
		case ID_CLOSE:
			EndDialog(hDlg, LOWORD(wParam));
			break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
			InvalidateRect(hDlg, 0, true);
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of Transistor_als_Schalter_Dialog

// Meldungshandler f�r Ergebnis_Bipolartransistor_als_Schalter_Dialog.
INT_PTR CALLBACK Ergebnis_Bipolartransistor_als_Schalter_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];

	switch (message)
	{
	case WM_INITDIALOG:
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_TRANSISTOR_SCHALTER), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		if (!Bipolartransistor_als_Schalter.Schaltung_berechenbar)
			SetDlgItemText(hDlg, ID_CAPTION, (LPCSTR)"Berechnung des Transistors als Schalter fehlerhaft!");

		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz2, hStiftAlt;
		HBRUSH hPinselSchwarz, hPinselAlt;

		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Transistor einzeichnen

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		hStiftSchwarz2 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz2);
		hPinselSchwarz = CreateSolidBrush(BLACK_BRUSH);
		hPinselAlt = (HBRUSH)SelectObject(hdc, hPinselSchwarz);

		// passenden Transistor zeichnen, hier von x=450
		Zeichne_Bipolartransistor(hdc, 450, 100, 50, 100, Bipolartransistor_als_Schalter.NPN, 30);
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		if (Bipolartransistor_als_Schalter.NPN)
			Zeichne_Text_xy(hdc, "Typ: NPN", 450, 80);
		else
			Zeichne_Text_xy(hdc, "Typ: PNP", 450, 80);
		Bestimme_Strombezeichner(cText, Bipolartransistor_als_Schalter.I_B, 99);
		Zeichne_Text_xy(hdc, cText, 280, 120);
		Bestimme_Strombezeichner(cText, Bipolartransistor_als_Schalter.I_C, 99);
		Zeichne_Text_xy(hdc, cText, 280, 151);
		Bestimme_Strombezeichner(cText, Bipolartransistor_als_Schalter.I_E, 99);
		Zeichne_Text_xy(hdc, cText, 280, 182);
		Bestimme_Bezeichner(cText, Bipolartransistor_als_Schalter.m, 99);
		Zeichne_Text_xy(hdc, cText, 280, 213);
		Bestimme_Strombezeichner(cText, Bipolartransistor_als_Schalter.I_Ableit, 99);
		Zeichne_Text_xy(hdc, cText, 280, 244);

		Bestimme_Spannungsbezeichner(cText, Bipolartransistor_als_Schalter.U_BE_Sperr, 99);
		Zeichne_Text_xy(hdc, cText, 280, 330);
		Bestimme_Strombezeichner(cText, Bipolartransistor_als_Schalter.I_CB_Sperr*1.0e-6, 99);	// in �A
		Zeichne_Text_xy(hdc, cText, 280, 360);
		
		SelectObject(hdc, hPinselAlt);
		DeleteObject(hPinselSchwarz);
		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz2);
		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case IDCANCEL: 
			EndDialog(hDlg, LOWORD(wParam)); 
			break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Ergebnis_Bipolartransistor_als_Schalter_Dialog


// Meldungshandler f�r Kennlinienfeld_Bipolar
INT_PTR CALLBACK Kennlinienfeld_Bipolar_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	HICON hIcon;
	static bool neuzeichnen = false;

	switch (message)
	{
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_EMITTERSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Bezeichner(cText, Emitter_Schaltung.U_BE_min, 99);
		SetDlgItemText(hDlg, ID_U_BE_MIN, (LPCSTR)cText);
		Bestimme_Bezeichner(cText, Emitter_Schaltung.U_BE_max, 99);
		SetDlgItemText(hDlg, ID_U_BE_MAX, (LPCSTR)cText);
		Bestimme_Bezeichner(cText, Emitter_Schaltung.Delta_U_BE, 99);
		SetDlgItemText(hDlg, ID_DELTA_U_BE, (LPCSTR)cText);
		Bestimme_Bezeichner(cText, Emitter_Schaltung.U_CE_Max, 99);
		SetDlgItemText(hDlg, ID_U_CE_MAX, (LPCSTR)cText);

		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);
		struct Koordinatensystem KS;
		float I_C[200], U_CE[200];
		double U_Temp;

		// Fenster neu zeichnen: Emitterschaltung mit Widerst�nden, Transistor und Spannungsquelle

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);
		if (neuzeichnen)
		{
			KS.x_min1 = 0.0;
			KS.x_max1 = Emitter_Schaltung.U_CE_Max;
			KS.y_min1 = 0.0;
			KS.y_max1 = 1.0e-3;
			KS.Rand_x_min = 200;
			KS.Rand_x_max = 600;
			KS.Rand_y_min = 30;
			KS.Rand_y_max = 300;
			KS.Grafik_x_max = 0;

			// F�r Kopie in Zwischenablage anpassen...
			Zeichne_Koordinatensystem_Ursprung_links_unten(hdc, &KS, "U_CE in V", "I_C in A", "", "", "Kennlinienfeld Bipolartransistor", false);
			U_Temp = U_T(Emitter_Schaltung.T, Emitter_Schaltung.Naeherung_U_T);
			Berechne_Kennlinienfeld(Emitter_Schaltung, Emitter_Schaltung.U_BE, U_Temp, 200, U_CE, I_C);
/*			for (i = 0; i < 200; i++)
			{
				U_CE[i] = (float)(Emitter_Schaltung.U_CE_Max / 199.0*(double)i);
				I_C[i] = (float)Berechne_I_C(Emitter_Schaltung.U_BE, U_CE[i], U_Temp, Emitter_Schaltung);
			}*/
			Zeichne_Kurve_in_Koordinatensystem_Ursprung_links_unten(hdc, &KS, U_CE, I_C, 200, 0, 0, 255);

		}

		EndPaint(hDlg, &ps);
	}
	return TRUE;
	
	case WM_COMMAND:
		switch (wParam)
		{
			case ID_CALC:
			{
				double wert1, wert2, wert3, wert4;
				bool eingabe_ok = true;
				// Kennlinienfeld berechnen und Anzeigen.
				// Vorher die Werte f�r U_BE holen
					
				wert1 = Eingabe_parsen(hDlg, ID_U_BE_MIN);
				if (wert1 < 0.0) // U_BE_min auswerten
				{
					Warnung("Wert f�r U_BE_min muss gr��er 0V sein!");
					SetDlgItemText(hDlg, ID_U_BE_MIN, (LPSTR)"0,5");
					eingabe_ok = false;
				}
				wert2 = Eingabe_parsen(hDlg, ID_U_BE_MAX);
				if ((wert2 < 0.0) || (wert2 <= wert1)) // U_BE_max auswerten
				{
					Warnung("Wert f�r U_BE_max muss gr��er als U_BE,min sein!");
					SetDlgItemText(hDlg, ID_U_BE_MAX, (LPSTR)"0,6");
					eingabe_ok = false;
				}
				wert3 = Eingabe_parsen(hDlg, ID_DELTA_U_BE);
				if ((wert3 < 0.0)||(wert1+wert3>wert2)) // Delta_U_BE auswerten
				{
					Warnung("Wert f�r Schrittweite Delta_U_BE muss gr��er 0V sein und mindestens zwei Schritte erlauben!");
					SetDlgItemText(hDlg, ID_DELTA_U_BE, (LPSTR)"0,05");
					eingabe_ok = false;
				}
				wert4 = Eingabe_parsen(hDlg, ID_U_CE_MAX);
				if (wert4 < 0.0) // U_CE_MAX auswerten
				{
					Warnung("Wert f�r maximale Spannung U_CE muss gr��er 0V sein!");
					SetDlgItemText(hDlg, ID_U_CE_MAX, (LPSTR)"10");
					eingabe_ok = false;
				}
				if (eingabe_ok)
				{
					// Daten in die Struktur �bernehmen
					Emitter_Schaltung.U_BE_min = wert1;
					Emitter_Schaltung.U_BE_max = wert2;
					Emitter_Schaltung.Delta_U_BE = wert3;
					Emitter_Schaltung.U_CE_Max = wert4;
					// Transistorschaltung noch einmal berechnen
					Berechne_Emitterschaltung();
					if (!Emitter_Schaltung.Schaltung_berechenbar)
					{
						Warnung("Kennlinienfeld kann nicht gezeichnet werden, da Schaltung nicht berechenbar.");
						break;
					}
					if (Berechne_Parameter_Kennlinienfeld_Bipolar(&Emitter_Schaltung) == 0)
					{
						neuzeichnen = true;
						InvalidateRect(hDlg, NULL, true);
					}
				}
				// Ergebnis_Emitterschaltung(hDlg);
				break;
			}
			case IDCANCEL:
			case ID_CLOSE:
				EndDialog(hDlg, LOWORD(wParam));
				break;
			break;
		}
	}
	return (INT_PTR)FALSE;
}	// end of Kennlinienfeld_Bipolar_Dialog


// Meldungshandler f�r EmitterSchaltung.
INT_PTR CALLBACK DoppelEmitterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	HICON hIcon;
	bool neuzeichnen = false;
	static int Anzahl_Dialoge; // Z�hlt die offenen Dialoge und erlaubt ein Schlie�en des Fensters erst, wenn alle Eingabe beendet sind
	
	switch (message)
	{
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_EMITTERSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Beschriftungen f�r die Bauteilwerte und die Spannungsquelle erg�nzen.
		Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[0], 99);
		SetDlgItemText(hDlg, ID_C1, (LPCSTR)cText);
		Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[1], 99);
		SetDlgItemText(hDlg, ID_C2, (LPCSTR)cText);
		Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[2], 99);
		SetDlgItemText(hDlg, ID_C3, (LPCSTR)cText);
		Bestimme_Kapazitaetsbezeichner(cText, Doppel_Emitter_Schaltung.C[3], 99);
		SetDlgItemText(hDlg, ID_C4, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[R_BASIS_UB], 99);
		SetDlgItemText(hDlg, ID_R1, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[R_BASIS_GND], 99);
		SetDlgItemText(hDlg, ID_R2, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[2], 99);
		SetDlgItemText(hDlg, ID_R3, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[3], 99);
		SetDlgItemText(hDlg, ID_R4, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[4], 99);
		SetDlgItemText(hDlg, ID_R5, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[5], 99);
		SetDlgItemText(hDlg, ID_R6, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[6], 99);
		SetDlgItemText(hDlg, ID_R7, (LPCSTR)cText);
		Bestimme_Widerstandsbezeichner(cText, Doppel_Emitter_Schaltung.R[7], 99);
		SetDlgItemText(hDlg, ID_R8, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, Doppel_Emitter_Schaltung.U_B, 99);
		SetDlgItemText(hDlg, ID_UB, (LPCSTR)cText);
		if (Doppel_Emitter_Schaltung.Naeherung_r_CE)
			SendMessage(GetDlgItem(hDlg, ID_CB1), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_CB1), BM_SETCHECK, 0, 0);
		if (Doppel_Emitter_Schaltung.Naeherung_U_T)
			SendMessage(GetDlgItem(hDlg, ID_CB2), BM_SETCHECK, 1, 0);
		else
			SendMessage(GetDlgItem(hDlg, ID_CB2), BM_SETCHECK, 0, 0);
		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hDlg, &ps);

		// Fenster neu zeichnen: Emitterschaltung mit Widerst�nden, Transistor und Spannungsquelle

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		SetPolyFillMode(hdc, WINDING);

		// Zu Beginn die Kn�pfe positionieren, die Daten aus der Resource-Datei weichen ab...
		// Verschieben von R1:
		MoveWindow(GetDlgItem(hDlg, ID_R1), 70, 70, 60, 40, true);  // funktioniert
		// Verschieben von R2, R3 und R5, R6 und R8
		MoveWindow(GetDlgItem(hDlg, ID_R2), 70, 400, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R3), 170, 70, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R5), 170, 420, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R6), 370, 70, 60, 40, true);
		MoveWindow(GetDlgItem(hDlg, ID_R8), 370, 420, 60, 40, true);
		// Verschieben von U_B 
		MoveWindow(GetDlgItem(hDlg, ID_UB), 680, 100, 40, 40, true);

		if (Doppel_Emitter_Schaltung.NPN_T1)
		{
			//Verschieben von C1 
			MoveWindow(GetDlgItem(hDlg, ID_C1), 30, 135, 60, 40, true);
			// Verschieben von T1
			MoveWindow(GetDlgItem(hDlg, ID_TRANS), 220, 185, 40, 30, true);
			// Verschieben von Button R4
			MoveWindow(GetDlgItem(hDlg, ID_R4), 170, 320, 60, 40, true);  // funktioniert
			// Verschieben von Button C2
			MoveWindow(GetDlgItem(hDlg, ID_C2), 320, 370, 60, 40, true);  // funktioniert
		}
		else
		{
			//Verschieben von C1 
			MoveWindow(GetDlgItem(hDlg, ID_C1), 30, 235, 60, 40, true);
			// Verschieben von T1
			MoveWindow(GetDlgItem(hDlg, ID_TRANS), 220, 285, 40, 30, true);
			// Verschieben von Button R4
			MoveWindow(GetDlgItem(hDlg, ID_R4), 170, 170, 60, 40, true);  // funktioniert
			// Verschieben von Button C2
			MoveWindow(GetDlgItem(hDlg, ID_C2), 320, 15, 60, 40, true);  // funktioniert
		}
		if (Doppel_Emitter_Schaltung.NPN_T2)   //Emitterschaltung mit NPN-Transistor rechts
		{
			// Verschieben von T2
			MoveWindow(GetDlgItem(hDlg, ID_TRANS_2), 420, 185, 40, 30, true);
			// Verschieben von Button R7
			MoveWindow(GetDlgItem(hDlg, ID_R7), 370, 320, 60, 40, true);
			// Verschieben von C3 und C4
			MoveWindow(GetDlgItem(hDlg, ID_C3), 520, 370, 60, 40, true);
			MoveWindow(GetDlgItem(hDlg, ID_C4), 550, 100, 60, 40, true);
		}
		else
		{
			// Verschieben von T2
			MoveWindow(GetDlgItem(hDlg, ID_TRANS_2), 430, 285, 40, 30, true);
			// Verschieben von Button R7
			MoveWindow(GetDlgItem(hDlg, ID_R7), 370, 170, 60, 40, true);
			// Verschieben von Button C3
			MoveWindow(GetDlgItem(hDlg, ID_C3), 520, 20, 60, 40, true);
			// Verschieben von C4
			MoveWindow(GetDlgItem(hDlg, ID_C4), 550, 300, 60, 40, true);
		}
		Zeichne_DoppelEmitterschaltung(Doppel_Emitter_Schaltung, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		// sorgt mit der globalen Variablen Eingabe_Dialog_Positionieren f�r eine Platzierung der Eingabe neben dem
		// aktuellen Fenster
		Eingabe_Dialog.hDlg_Aufrufer = hDlg;
		switch (wParam)
		{
		case ID_C1: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Kapazitaetswerte_Aufruf(1, 4, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_C2: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Kapazitaetswerte_Aufruf(2, 4, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_C3: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Kapazitaetswerte_Aufruf(3, 4, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_C4: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Kapazitaetswerte_Aufruf(4, 4, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R1: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(1, 8, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R2: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(2, 8, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R3: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(3, 8, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R4: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(4, 8, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R5: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(5, 8, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R6: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(6, 8, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R7: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(7, 8, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_R8: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_Widerstandswerte_Aufruf(8, 8, DOPPEL_EMITTER); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_TRANS: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_BipolarTransistorwerte_Aufruf(DOPPEL_EMITTER, 24); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_TRANS_2: 
			Anzahl_Dialoge++;
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = true; 
			Eingabe_BipolarTransistorwerte_Aufruf(DOPPEL_EMITTER_TRANS_2, 24); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_UB: 
			Anzahl_Dialoge++;
			Eingabe_Spannungswert_Aufruf(DOPPEL_EMITTER, U_BETRIEB); 
			neuzeichnen = true; 
			Anzahl_Dialoge--;
			break;
		case ID_ESB: 
//		  ESB_Emitterschaltung(hDlg);  
		  break;
		case ID_CB1: 
			(IsDlgButtonChecked(hDlg, ID_CB1) == BST_CHECKED) ? Doppel_Emitter_Schaltung.Naeherung_r_CE = true : Doppel_Emitter_Schaltung.Naeherung_r_CE = false; 
			Daten_geaendert();
			break;
		case ID_CB2: 
			(IsDlgButtonChecked(hDlg, ID_CB2) == BST_CHECKED) ? Doppel_Emitter_Schaltung.Naeherung_U_T = true : Doppel_Emitter_Schaltung.Naeherung_U_T = false; 
			Daten_geaendert();
			break;
		case ID_CALC:
			Ergebnis_Doppel_Emitterschaltung(hDlg);
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_DoppelEmitterschaltung(Doppel_Emitter_Schaltung);
			break;
		case IDCANCEL:
		case ID_CLOSE:
			if (Anzahl_Dialoge==0)
				EndDialog(hDlg, LOWORD(wParam));
			else
				Warnung( (LPSTR)"Bitte erst die Eingabefenster beenden.");
			break;
		}
		if (neuzeichnen)
		{
			// Alle Schaltkn�pfe aktualisieren...
			SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
			// ... und neu zeichnen
		}InvalidateRect(hDlg, 0, true);
		break;
	}
	return (INT_PTR)FALSE;
}	// end of DoppelEmitterSchaltung

// Meldungshandler f�r ErgebnisDoppelEmitterSchaltung.
INT_PTR CALLBACK ErgebnisDoppelEmitterSchaltung_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);

	switch (message)
	{
	case WM_INITDIALOG:
		HICON hIcon;

		// Icon laden
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_EMITTERSCHALTUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
		SetWindowText(hDlg, (LPCSTR)"Berechnung der Doppel-Emitterschaltung : ");

		return (INT_PTR)TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;

		HDC hdc = BeginPaint(hDlg, &ps);

		// Hintergrund l�schen
		FillRect(hdc, &ps.rcPaint, (HBRUSH)COLOR_WINDOW);
		Zeichne_Ausgabe_DoppelEmitterschaltung(Doppel_Emitter_Schaltung, hdc, false);

		EndPaint(hDlg, &ps);
	}
	return TRUE;

	case WM_COMMAND:
		switch (wParam)
		{
		case ID_KENNLINIE:
//			Kennlinienfeld_Bipolar_Aufruf(hWndElektronikMain);
			break;
		case ID_COPY_CLIPBOARD:
			Kopiere_Ergebnis_Doppel_Bipolar_Transistorschaltung(Doppel_Emitter_Schaltung, hWndElektronikMain, DOPPEL_EMITTER);
			break;
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
} // end of Ergebnis_DoppelEmitterSchaltung

