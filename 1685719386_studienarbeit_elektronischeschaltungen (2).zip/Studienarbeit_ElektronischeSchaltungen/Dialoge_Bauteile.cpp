#include "stdafx.h"

/*******************************************************************************************************************\
|																													|
| Modul Dialoge_Bauteile.cpp																						|
|																													|
| In diesem Modul sind die Meldungshandler f�r die Dialoge enthalten												|
| - DezibelRechner_Dialog();																						|
| - Eingabe_Beta_Dialog();																							|
| - Eingabe_Impedanz_Parallelschaltung_Dialog();																	|
| - Eingabe_Impedanz_Reihenschaltung_Dialog();																		|
| - Eingabe_Impedanz_SternDreieck_Dialog();																			|
| - Eingabe_Impedanz_Zeigerdiagramm_Dialog();																		|
| - Eingabe_kompl_Impedanz_Dialog();																				|
| - Eingabe_Komplexe_Spannung_Dialog();																				|
| - Eingabe_Laenge_Dialog();																						|
| - Eingabe_Leitungswiderstand_Dialog();																			|
| - EingabeKapazitaetswerte_DialogP();																				|
| - EingabeSpannungswert_Dialog();																					|
| - EingabeWiderstandswerte_Dialog();																				|
| - Parallelschaltung_Dialog();																						|
| - Reihenschaltung_Dialog();																						|	
| - Stern_Dreieckschaltung_Dialog();																				|
|  																													|
\*******************************************************************************************************************/

// Meldungshandler f�r EingabeKapazitaet.
INT_PTR CALLBACK EingabeKapazitaetswerte_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
// Ausgabe ge�ndert auf die Funktion "Bestimme_Bezeichner_wissenschaftlich. So wird ein Komma angezeigt
// M. Alles 15.2.2018
// �nderung 17.10.2019: Dialogbox wird rechts neben dem aufrufenden Fenster platziert
// �nderung 20.02.2020: Dialogbox wird auf vier Kondensatoren und Doppel-Emitterschaltung erweitert
{
  UNREFERENCED_PARAMETER(lParam);
  char cText[40];
  HICON hIcon;

  switch (message)
  {
  case WM_SHOWWINDOW:
	// Fenster neben dem Dialog platzieren
	if (Eingabe_Dialog.Eingabe_Dialog_Positionieren)
	{
	  RECT Position_Aufrufer;

	  if (Eingabe_Dialog.hDlg_Aufrufer!=NULL)
	  {
		GetWindowRect(Eingabe_Dialog.hDlg_Aufrufer, &Position_Aufrufer );
		SetWindowPos( hDlg, NULL, Position_Aufrufer.right-UEBERLAPPUNG, Position_Aufrufer.top, 0, 0, SWP_NOZORDER|SWP_NOSIZE );
	  }
	  Eingabe_Dialog.Eingabe_Dialog_Positionieren = false; // Positionierung wieder ausschalten

	}
	switch (Eingabe_Dialog.Auswahl_Kondensator)
	{
	case 1: SetFocus(GetDlgItem(hDlg, ID_TXT1)); SendMessage(GetDlgItem(hDlg, ID_TXT1), EM_SETSEL, 0, -1); break;
	case 2: SetFocus(GetDlgItem(hDlg, ID_TXT2)); SendMessage(GetDlgItem(hDlg, ID_TXT2), EM_SETSEL, 0, -1); break;
	case 3: SetFocus(GetDlgItem(hDlg, ID_TXT3)); SendMessage(GetDlgItem(hDlg, ID_TXT3), EM_SETSEL, 0, -1); break;
	case 4: SetFocus(GetDlgItem(hDlg, ID_TXT4)); SendMessage(GetDlgItem(hDlg, ID_TXT3), EM_SETSEL, 0, -1); break;
	}
	break;
  case WM_INITDIALOG:

	hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_KONDENSATOR), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
	if (hIcon)
	  SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
	switch (Eingabe_Dialog.Anzahl_Kondensator)
	{
	case 1:
	  EnableWindow(GetDlgItem(hDlg, ID_TXT2), FALSE);
	case 2:
	  EnableWindow(GetDlgItem(hDlg, ID_TXT3), FALSE);
	case 3:
	  EnableWindow(GetDlgItem(hDlg, ID_TXT4), FALSE);
	}
	switch (Eingabe_Dialog.Auswahl_Kondensator)
	{
	case 1: SetFocus(GetDlgItem(hDlg, ID_TXT1)); break;
	case 2: SetFocus(GetDlgItem(hDlg, ID_TXT2)); break;
	case 3: SetFocus(GetDlgItem(hDlg, ID_TXT3)); break;
	case 4: SetFocus(GetDlgItem(hDlg, ID_TXT4)); break;
	}
	// Daten der Kondensatoren eintragen
	switch (Eingabe_Dialog.Auswahl_Schaltung)
	{
	case BASIS_SCHALTUNG:	// Basisschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.C[0], 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.C[1], 39);
	  SetDlgItemText(hDlg, ID_TXT2, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.C[2], 39);
	  SetDlgItemText(hDlg, ID_TXT3, cText);
	  SetDlgItemText(hDlg, ID_TXT4, "0");
	  break;
	case EMITTER_SCHALTUNG:	// Emitterschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.C[0], 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.C[1], 39);
	  SetDlgItemText(hDlg, ID_TXT2, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.C[2], 39);
	  SetDlgItemText(hDlg, ID_TXT3, cText);
	  SetDlgItemText(hDlg, ID_TXT4, "0");
	  break;
	case KOLLEKTOR_SCHALTUNG:	// Kollektorschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.C[0], 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.C[1], 39);
	  SetDlgItemText(hDlg, ID_TXT2, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.C[2], 39);
	  SetDlgItemText(hDlg, ID_TXT3, cText);
	  SetDlgItemText(hDlg, ID_TXT4, "0");
	  break;
	case SOURCE_SCHALTUNG:	// Sourceschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Source_Schaltung.C[0], 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Source_Schaltung.C[1], 39);
	  SetDlgItemText(hDlg, ID_TXT2, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Source_Schaltung.C[2], 39);
	  SetDlgItemText(hDlg, ID_TXT3, cText);
	  SetDlgItemText(hDlg, ID_TXT4, "0");
	  break;
	case DRAIN_SCHALTUNG:	// Drainschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Drain_Schaltung.C[0], 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Drain_Schaltung.C[1], 39);
	  SetDlgItemText(hDlg, ID_TXT2, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Drain_Schaltung.C[2], 39);
	  SetDlgItemText(hDlg, ID_TXT3, cText);
	  SetDlgItemText(hDlg, ID_TXT4, "0");
	  break;
	case GATE_SCHALTUNG:	// Gateschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Gate_Schaltung.C[0], 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Gate_Schaltung.C[0], 39);
	  SetDlgItemText(hDlg, ID_TXT2, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Gate_Schaltung.C[0], 39);
	  SetDlgItemText(hDlg, ID_TXT3, cText);
	  SetDlgItemText(hDlg, ID_TXT4, "0");
	  break;
	case GLEICHRICHTER:	// Gleichrichter
	  Bestimme_Bezeichner_wissenschaftlich(cText, Gleichrichter.C, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  SetDlgItemText(hDlg, ID_TXT2, "0");
	  SetDlgItemText(hDlg, ID_TXT3, "0");
	  SetDlgItemText(hDlg, ID_TXT4, "0");
	  break;
	case DIFFERENZIERER_OP:	// Differenzierer
	  Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.C, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  SetDlgItemText(hDlg, ID_TXT2, "0");
	  SetDlgItemText(hDlg, ID_TXT3, "0");
	  SetDlgItemText(hDlg, ID_TXT4, "0");
	  break;
	case INTEGRIERER_OP:	// Integrationsschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.C, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  SetDlgItemText(hDlg, ID_TXT2, "0");
	  SetDlgItemText(hDlg, ID_TXT3, "0");
	  SetDlgItemText(hDlg, ID_TXT4, "0");
	  break;
	case DOPPEL_EMITTER:	// Emitter-Schaltung mit zwei Bipolartransistoren
	  Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.C[0], 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.C[1], 39);
	  SetDlgItemText(hDlg, ID_TXT2, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.C[2], 39);
	  SetDlgItemText(hDlg, ID_TXT3, cText);
	  Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.C[3], 39);
	  SetDlgItemText(hDlg, ID_TXT4, cText);
	  break;
	default:
	  Warnung("Fehler bei der Eingabe der Kapazit�tswerte: Unbekannte Schaltung.");
	}
	return (INT_PTR)TRUE;
  case WM_PAINT: // Kondensator zeichnen
	{
	  PAINTSTRUCT ps;
	  HPEN hStiftSchwarz3, hStiftAlt;
	  HDC hdc = BeginPaint(hDlg, &ps);

	  hStiftSchwarz3 = CreatePen(PS_SOLID, 3, BLACK_PEN);
	  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz3);

	  // Kondensator zeichnen
	  Zeichne_Kondensator(hdc, 250, 80, 20, 80, true, 30);

	  SelectObject(hdc, hStiftAlt);
	  DeleteObject(hStiftSchwarz3);
	  EndPaint(hDlg, &ps);
	}
	break;
  case WM_COMMAND:
	switch (wParam)
	{
	case IDOK: // Eingabe pr�fen und �bernehmen
	  {
		double wert1, wert2, wert3, wert4;
		bool eingabe_ok = true;

		wert1 = Eingabe_parsen(hDlg, ID_TXT1);
		wert2 = Eingabe_parsen(hDlg, ID_TXT2);
		wert3 = Eingabe_parsen(hDlg, ID_TXT3);
		wert4 = Eingabe_parsen(hDlg, ID_TXT4);

		// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
		if (wert1 <= 0.0)
		{
		  Warnung((LPSTR)"Wert f�r Kapazit�t 1 muss gr��er 0 sein!");
		  SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)"1m");
		  eingabe_ok = false;
		}
		if ((wert2 <= 0.0) && (Eingabe_Dialog.Anzahl_Kondensator > 1))	// Wenn nur ein Kondensator eingegeben werden muss
		{
		  Warnung((LPSTR)"Wert f�r Kapazit�t 2 muss gr��er 0 sein!");
		  SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"1m");
		  eingabe_ok = false;
		}
		if ((wert3 <= 0.0) && (Eingabe_Dialog.Anzahl_Kondensator > 2))	// wenn nur einer oder zwei Kondensatoren eingegeben werden muss
		{
		  Warnung((LPSTR)"Wert f�r Kapazit�t 3 muss gr��er 0 sein!");
		  SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)"1m");
		  eingabe_ok = false;
		}
		if ((wert4 <= 0.0) && (Eingabe_Dialog.Anzahl_Kondensator > 3))	// wenn nur einer oder zwei Kondensatoren eingegeben werden muss
		{
		  Warnung((LPSTR)"Wert f�r Kapazit�t 4 muss gr��er 0 sein!");
		  SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)"1m");
		  eingabe_ok = false;
		}
		if (eingabe_ok)
		{
		  switch (Eingabe_Dialog.Auswahl_Schaltung)
		  {
		  case BASIS_SCHALTUNG:
			// Die Werte speichern und das Dialogfenster schlie�en
			Basis_Schaltung.C[0] = wert1;
			Basis_Schaltung.C[1] = wert2;
			Basis_Schaltung.C[2] = wert3;
			break;
		  case EMITTER_SCHALTUNG:
			// Die Werte speichern und das Dialogfenster schlie�en
			Emitter_Schaltung.C[0] = wert1;
			Emitter_Schaltung.C[1] = wert2;
			Emitter_Schaltung.C[2] = wert3;
			break;
		  case KOLLEKTOR_SCHALTUNG:
			// Die Werte speichern und das Dialogfenster schlie�en
			Kollektor_Schaltung.C[0] = wert1;
			Kollektor_Schaltung.C[1] = wert2;
			Kollektor_Schaltung.C[2] = wert3;
			break;
		  case SOURCE_SCHALTUNG:
			// Die Werte speichern und das Dialogfenster schlie�en
			Source_Schaltung.C[0] = wert1;
			Source_Schaltung.C[1] = wert2;
			Source_Schaltung.C[2] = wert3;
			break;
		  case DRAIN_SCHALTUNG:
			// Die Werte speichern und das Dialogfenster schlie�en
			Drain_Schaltung.C[0] = wert1;
			Drain_Schaltung.C[1] = wert2;
			Drain_Schaltung.C[2] = wert3;
			break;
		  case GATE_SCHALTUNG:
			// Die Werte speichern und das Dialogfenster schlie�en
			Gate_Schaltung.C[0] = wert1;
			Gate_Schaltung.C[1] = wert2;
			Gate_Schaltung.C[2] = wert3;
			break;
		  case GLEICHRICHTER:
			// Die Werte speichern und das Dialogfenster schlie�en
			Gleichrichter.C = wert1;
			break;
		  case INTEGRIERER_OP:
			Integrierer_OP.C = wert1;
			break;
		  case DIFFERENZIERER_OP:
			Differenzierer_OP.C = wert1;
			break;
		  case DOPPEL_EMITTER:
			Doppel_Emitter_Schaltung.C[0]=wert1;
			Doppel_Emitter_Schaltung.C[1]=wert2;
			Doppel_Emitter_Schaltung.C[2]=wert3;
			Doppel_Emitter_Schaltung.C[3]=wert4;
			break;
		  }
		  Daten_geaendert();
		  EndDialog(hDlg, LOWORD(wParam));
		}
		break;
	  }
	case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
	}
	break;
  }
  return (INT_PTR)FALSE;
}	// end of EingabeKapazitaet

// Meldungshandler f�r EingabeWiderstand.
INT_PTR CALLBACK EingabeWiderstandswerte_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Ausgabe ge�ndert auf die Funktion "Bestimme_Bezeichner_wissenschaftlich. So wird ein Komma angezeigt
	// M. Alles 15.2.2018
	// �nderung 17.10.2019: Fenster wird rechts neben der Schaltung platziert
	UNREFERENCED_PARAMETER(lParam);
	char cText[40];
	HICON hIcon;

	switch (message)
	{
	case WM_SHOWWINDOW:
		// Fenster neben dem Dialog platzieren
		if (Eingabe_Dialog.Eingabe_Dialog_Positionieren)
		{
			RECT Position_Aufrufer;

			if (Eingabe_Dialog.hDlg_Aufrufer!=NULL)
			{
				GetWindowRect(Eingabe_Dialog.hDlg_Aufrufer, &Position_Aufrufer );
				SetWindowPos( hDlg, NULL, Position_Aufrufer.right-UEBERLAPPUNG, Position_Aufrufer.top, 0, 0, SWP_NOZORDER|SWP_NOSIZE );
			}
			Eingabe_Dialog.Eingabe_Dialog_Positionieren = false; // Positionierung wieder ausschalten
			
		}
		switch (Eingabe_Dialog.Auswahl_Widerstand)
		{
		case 1: SetFocus(GetDlgItem(hDlg, ID_TXT1)); SendMessage(GetDlgItem(hDlg, ID_TXT1), EM_SETSEL, 0, -1); break;
		case 2: SetFocus(GetDlgItem(hDlg, ID_TXT2)); SendMessage(GetDlgItem(hDlg, ID_TXT2), EM_SETSEL, 0, -1); break;
		case 3: SetFocus(GetDlgItem(hDlg, ID_TXT3)); SendMessage(GetDlgItem(hDlg, ID_TXT3), EM_SETSEL, 0, -1); break;
		case 4: SetFocus(GetDlgItem(hDlg, ID_TXT4)); SendMessage(GetDlgItem(hDlg, ID_TXT4), EM_SETSEL, 0, -1); break;
		case 5: SetFocus(GetDlgItem(hDlg, ID_TXT5)); SendMessage(GetDlgItem(hDlg, ID_TXT5), EM_SETSEL, 0, -1); break;
		case 6: SetFocus(GetDlgItem(hDlg, ID_TXT6)); SendMessage(GetDlgItem(hDlg, ID_TXT6), EM_SETSEL, 0, -1); break;
		case 7: SetFocus(GetDlgItem(hDlg, ID_TXT7)); SendMessage(GetDlgItem(hDlg, ID_TXT7), EM_SETSEL, 0, -1); break;
		case 8: SetFocus(GetDlgItem(hDlg, ID_TXT8)); SendMessage(GetDlgItem(hDlg, ID_TXT8), EM_SETSEL, 0, -1); break;
		}
		break;
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_WIDERSTAND), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		switch (Eingabe_Dialog.Anzahl_Widerstand)
		{	// "Durchrutschen" durch die Case-Anweisung ist hier beabsichtigt!
		case 1: EnableWindow(GetDlgItem(hDlg, ID_TXT2), FALSE);
		case 2: EnableWindow(GetDlgItem(hDlg, ID_TXT3), FALSE);
		case 3: EnableWindow(GetDlgItem(hDlg, ID_TXT4), FALSE);
		case 4: EnableWindow(GetDlgItem(hDlg, ID_TXT5), FALSE);
		case 5: EnableWindow(GetDlgItem(hDlg, ID_TXT6), FALSE);
		case 6: EnableWindow(GetDlgItem(hDlg, ID_TXT7), FALSE);
		case 7: EnableWindow(GetDlgItem(hDlg, ID_TXT8), FALSE);
		}
		// Daten der Widerst�nde eintragen
		switch (Eingabe_Dialog.Auswahl_Schaltung)
		{
			case BASIS_SCHALTUNG: // Basisschaltung
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.R[2], 39);
				SetDlgItemText(hDlg, ID_TXT3, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.R[3], 39);
				SetDlgItemText(hDlg, ID_TXT4, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.R[4], 39);
				SetDlgItemText(hDlg, ID_TXT5, cText);
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case EMITTER_SCHALTUNG:	// Emitterschaltung
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.R[2], 39);
				SetDlgItemText(hDlg, ID_TXT3, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.R[3], 39);
				SetDlgItemText(hDlg, ID_TXT4, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.R[4], 39);
				SetDlgItemText(hDlg, ID_TXT5, cText);
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case KOLLEKTOR_SCHALTUNG:	// Kollektorschaltung
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.R[2], 39);
				SetDlgItemText(hDlg, ID_TXT3, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.R[3], 39);
				SetDlgItemText(hDlg, ID_TXT4, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.R[4], 39);
				SetDlgItemText(hDlg, ID_TXT5, cText);
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case SOURCE_SCHALTUNG:	// Sourceschaltung
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Source_Schaltung.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Source_Schaltung.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Source_Schaltung.R[2], 39);
				SetDlgItemText(hDlg, ID_TXT3, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Source_Schaltung.R[3], 39);
				SetDlgItemText(hDlg, ID_TXT4, cText);
				SetDlgItemText(hDlg, ID_TXT5, "0");
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case DRAIN_SCHALTUNG:	// Drainschaltung
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Drain_Schaltung.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Drain_Schaltung.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Drain_Schaltung.R[2], 39);
				SetDlgItemText(hDlg, ID_TXT3, cText);
				SetDlgItemText(hDlg, ID_TXT4, "0");	
				SetDlgItemText(hDlg, ID_TXT5, "0");
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case GATE_SCHALTUNG:	// Gateschaltung
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Gate_Schaltung.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Gate_Schaltung.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Gate_Schaltung.R[2], 39);
				SetDlgItemText(hDlg, ID_TXT3, cText);
				SetDlgItemText(hDlg, ID_TXT4, "0");
				SetDlgItemText(hDlg, ID_TXT5, "0");
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case GLEICHRICHTER: 	// Gleichrichterschaltung
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Gleichrichter.R, 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				SetDlgItemText(hDlg, ID_TXT2, "0");
				SetDlgItemText(hDlg, ID_TXT3, "0");
				SetDlgItemText(hDlg, ID_TXT4, "0");
				SetDlgItemText(hDlg, ID_TXT5, "0");
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case TRANSISTOR_ALS_SCHALTER: 	// Bipolartransistor als Schalter
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Bipolartransistor_als_Schalter.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Bipolartransistor_als_Schalter.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Bipolartransistor_als_Schalter.R[2], 39);
				SetDlgItemText(hDlg, ID_TXT3, cText);
				SetDlgItemText(hDlg, ID_TXT4, "0");
				SetDlgItemText(hDlg, ID_TXT5, "0");
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case DIFFERENZVERSTAERKER: 	// Differenzverst�rker
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzverstaerker.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzverstaerker.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzverstaerker.R[2], 39);
				SetDlgItemText(hDlg, ID_TXT3, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzverstaerker.R[3], 39);
				SetDlgItemText(hDlg, ID_TXT4, cText);
				SetDlgItemText(hDlg, ID_TXT5, "0");
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case INVERTIERENDER_OP: 	// OP als invertierender Verst�rker
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Invertierender_OP.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Invertierender_OP.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				SetDlgItemText(hDlg, ID_TXT3, "0");
				SetDlgItemText(hDlg, ID_TXT4, "0");
				SetDlgItemText(hDlg, ID_TXT5, "0");
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case NICHTINVERTIERENDER_OP: 	// OP als nichtinvertierender Verst�rker
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Nichtinvertierender_OP.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Nichtinvertierender_OP.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				SetDlgItemText(hDlg, ID_TXT3, "0");
				SetDlgItemText(hDlg, ID_TXT4, "0");
				SetDlgItemText(hDlg, ID_TXT5, "0");
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case DIFFERENZIERER_OP: 	// OP als differenzierender Verst�rker
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				SetDlgItemText(hDlg, ID_TXT2, "0");
				SetDlgItemText(hDlg, ID_TXT3, "0");
				SetDlgItemText(hDlg, ID_TXT4, "0");
				SetDlgItemText(hDlg, ID_TXT5, "0");
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case INTEGRIERER_OP: 	// OP als integrierender Verst�rker
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				SetDlgItemText(hDlg, ID_TXT2, "0");
				SetDlgItemText(hDlg, ID_TXT3, "0");
				SetDlgItemText(hDlg, ID_TXT4, "0");
				SetDlgItemText(hDlg, ID_TXT5, "0");
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case SUMMATIONS_OP: 	// OP als Summationsverst�rker
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.R[2], 39);
				SetDlgItemText(hDlg, ID_TXT3, cText);
				SetDlgItemText(hDlg, ID_TXT4, "0");
				SetDlgItemText(hDlg, ID_TXT5, "0");
				SetDlgItemText(hDlg, ID_TXT6, "0");	
				SetDlgItemText(hDlg, ID_TXT7, "0");
				SetDlgItemText(hDlg, ID_TXT8, "0");	
				break;
			}
			case DOPPEL_EMITTER:	// Emitterschaltung mit zwei Transistoren
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.R[0], 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.R[1], 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.R[2], 39);
				SetDlgItemText(hDlg, ID_TXT3, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.R[3], 39);
				SetDlgItemText(hDlg, ID_TXT4, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.R[4], 39);
				SetDlgItemText(hDlg, ID_TXT5, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.R[5], 39);
				SetDlgItemText(hDlg, ID_TXT6, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.R[6], 39);
				SetDlgItemText(hDlg, ID_TXT7, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, Doppel_Emitter_Schaltung.R[7], 39);
				SetDlgItemText(hDlg, ID_TXT8, cText);
				break;
			}
			default:
				Warnung((LPSTR)"Fehler bei der Eingabe der Widerst�nde: Unbekannte Schaltung.");
		}
		return (INT_PTR)TRUE;
	case WM_PAINT: // Widerstand zeichnen
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz3, hStiftAlt;
		HDC hdc = BeginPaint(hDlg, &ps);

		hStiftSchwarz3 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz3);

		// Widerstand zeichnen
		Zeichne_Widerstand(hdc, 245, 120, 30, 60, 20);

		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz3);
		EndPaint(hDlg, &ps);
	}
	break;
	case WM_COMMAND:
		switch (wParam)
		{
		case IDOK: // Eingabe pr�fen und �bernehmen
		{
			double wert1, wert2, wert3, wert4, wert5, wert6, wert7, wert8;
			bool eingabe_ok = true;

			wert1 = Eingabe_parsen(hDlg, ID_TXT1);
			wert2 = Eingabe_parsen(hDlg, ID_TXT2);
			wert3 = Eingabe_parsen(hDlg, ID_TXT3);
			wert4 = Eingabe_parsen(hDlg, ID_TXT4);
			wert5 = Eingabe_parsen(hDlg, ID_TXT5);
			wert6 = Eingabe_parsen(hDlg, ID_TXT6);
			wert7 = Eingabe_parsen(hDlg, ID_TXT7);
			wert8 = Eingabe_parsen(hDlg, ID_TXT8);
			// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
			if (wert1 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 1 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert2 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 2 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert3 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 3 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert4 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 4 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert5 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 5 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert6 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 6 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT6, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert7 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 7 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT7, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert8 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 8 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT8, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (eingabe_ok)
			{
				switch (Eingabe_Dialog.Auswahl_Schaltung)
				{
					case BASIS_SCHALTUNG:	// Basisschaltung				// Die Werte speichern und das Dialogfenster schlie�en
					{
						Basis_Schaltung.R[0] = wert1;
						Basis_Schaltung.R[1] = wert2;
						Basis_Schaltung.R[2] = wert3;
						Basis_Schaltung.R[3] = wert4;
						Basis_Schaltung.R[4] = wert5;
						break;
					}
					case EMITTER_SCHALTUNG:	// Emitterschaltung				// Die Werte speichern und das Dialogfenster schlie�en
					{
						Emitter_Schaltung.R[0] = wert1;
						Emitter_Schaltung.R[1] = wert2;
						Emitter_Schaltung.R[2] = wert3;
						Emitter_Schaltung.R[3] = wert4;
						Emitter_Schaltung.R[4] = wert5;
						break;
					}
					case KOLLEKTOR_SCHALTUNG:	// Kollektorschaltung				// Die Werte speichern und das Dialogfenster schlie�en
					{
						Kollektor_Schaltung.R[0] = wert1;
						Kollektor_Schaltung.R[1] = wert2;
						Kollektor_Schaltung.R[2] = wert3;
						Kollektor_Schaltung.R[3] = wert4;
						Kollektor_Schaltung.R[4] = wert5;
						break;
					}
					case SOURCE_SCHALTUNG:	// Sourceschaltung				// Die Werte speichern und das Dialogfenster schlie�en
					{
						Source_Schaltung.R[0] = wert1;
						Source_Schaltung.R[1] = wert2;
						Source_Schaltung.R[2] = wert3;
						Source_Schaltung.R[3] = wert4;
						Source_Schaltung.R[4] = wert5;
						break;
					}
					case DRAIN_SCHALTUNG:	// Drainschaltung				// Die Werte speichern und das Dialogfenster schlie�en
					{
						Drain_Schaltung.R[0] = wert1;
						Drain_Schaltung.R[1] = wert2;
						Drain_Schaltung.R[2] = wert3;
						Drain_Schaltung.R[3] = wert4;
						Drain_Schaltung.R[4] = wert5;
						break;
					}
					case GATE_SCHALTUNG:	// Gateschaltung				// Die Werte speichern und das Dialogfenster schlie�en
					{
						Gate_Schaltung.R[0] = wert1;
						Gate_Schaltung.R[1] = wert2;
						Gate_Schaltung.R[2] = wert3;
						Gate_Schaltung.R[3] = wert4;
						Gate_Schaltung.R[4] = wert5;
						break;
					}
					case GLEICHRICHTER:	// Gleichrichter				// Die Werte speichern und das Dialogfenster schlie�en
					{
						Gleichrichter.R = wert1;
						break;
					}
					case TRANSISTOR_ALS_SCHALTER: // Transistor als Schalter
					{
						Bipolartransistor_als_Schalter.R[0] = wert1;
						Bipolartransistor_als_Schalter.R[1] = wert2;
						Bipolartransistor_als_Schalter.R[2] = wert3;
						break;
					}
					case DIFFERENZVERSTAERKER: // Differenzverst�rker
					{
						Differenzverstaerker.R[0] = wert1;
						Differenzverstaerker.R[1] = wert2;
						Differenzverstaerker.R[2] = wert3;
						Differenzverstaerker.R[3] = wert4;
						break;
					}
					case INVERTIERENDER_OP: // Invertierender Operationsverst�rker
					{
						Invertierender_OP.R[0] = wert1;
						Invertierender_OP.R[1] = wert2;
						break;
					}
					case NICHTINVERTIERENDER_OP: // nicht-invertierender Operationsverst�rker
					{
						Nichtinvertierender_OP.R[0] = wert1;
						Nichtinvertierender_OP.R[1] = wert2;
						break;
					}
					case DIFFERENZIERER_OP: // differenzierender Operationsverst�rker
					{
						Differenzierer_OP.R[0] = wert1;
						break;
					}
					case INTEGRIERER_OP: // differenzierender Operationsverst�rker
					{
						Integrierer_OP.R[0] = wert1;
						break;
					}
					case SUMMATIONS_OP: // Operationsverst�rker als addierender Verst�rker
					{
						Summations_OP.R[0] = wert1;
						Summations_OP.R[1] = wert2;
						Summations_OP.R[2] = wert3;
						break;
					}
					case DOPPEL_EMITTER: // Emitterschaltung mit zwei Transistoren
					{
						Doppel_Emitter_Schaltung.R[0] = wert1;
						Doppel_Emitter_Schaltung.R[1] = wert2;
						Doppel_Emitter_Schaltung.R[2] = wert3;
						Doppel_Emitter_Schaltung.R[3] = wert4;
						Doppel_Emitter_Schaltung.R[4] = wert5;
						Doppel_Emitter_Schaltung.R[5] = wert6;
						Doppel_Emitter_Schaltung.R[6] = wert7;
						Doppel_Emitter_Schaltung.R[7] = wert8;
						break;
					}
				}
				Daten_geaendert();
				EndDialog(hDlg, LOWORD(wParam));
			}
			break;
		}
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of EingabeWiderstand

// Meldungshandler zur Eingabe eines komplexen Widerstandes und zur Umrechnung der versch. Darstellungen
INT_PTR CALLBACK Eingabe_kompl_Impedanz_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// M. Alles 18.8.2019
	UNREFERENCED_PARAMETER(lParam);
	char cText[40];
	HICON hIcon;
	bool Dialogfenster_schliessen = false;

	switch (message)
	{
	case WM_SHOWWINDOW:
		SetFocus(GetDlgItem(hDlg, ID_R)); SendMessage(GetDlgItem(hDlg, ID_R), EM_SETSEL, 0, -1); break;
		break;
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_WIDERSTAND), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Daten der Impedanz eintragen
		switch (Eingabe_Dialog.Auswahl_Schaltung)
		{
			case HF_LEITUNG: // Hochfrequenzleitung
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, real(HF_Leitung.Abschluss_R) , 39);
				SetDlgItemText(hDlg, ID_R, cText);
				// Induktivit�t und Kapazit�t auf 0 setzten, typischerweise wird nur ein Wert verwendet
				SetDlgItemText(hDlg, ID_L, "0");
				SetDlgItemText(hDlg, ID_C, "0");
				if (imag(HF_Leitung.Abschluss_R)>0.0)
				{
					Bestimme_Bezeichner_wissenschaftlich(cText, imag(HF_Leitung.Abschluss_R)/2.0/pi/HF_Leitung.Frequenz , 39);
					SetDlgItemText(hDlg, ID_L, cText);
				}
				if (imag(HF_Leitung.Abschluss_R)<0.0)
				{
					Bestimme_Bezeichner_wissenschaftlich(cText, 2.0*pi*HF_Leitung.Frequenz/-imag(HF_Leitung.Abschluss_R) , 39);
					SetDlgItemText(hDlg, ID_L, cText);
				}
				Bestimme_Bezeichner_wissenschaftlich(cText, HF_Leitung.Frequenz , 39);
				SetDlgItemText(hDlg, ID_FREQ, cText);

				Bestimme_Bezeichner_wissenschaftlich(cText, real(HF_Leitung.Abschluss_R), 39);
				SetDlgItemText(hDlg, ID_IMPEDANZ_REAL, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, imag(HF_Leitung.Abschluss_R), 39);
				SetDlgItemText(hDlg, ID_IMPEDANZ_IMAG, cText);

				Bestimme_Bezeichner_wissenschaftlich(cText, sqrt(real(HF_Leitung.Abschluss_R)*real(HF_Leitung.Abschluss_R)+imag(HF_Leitung.Abschluss_R)*imag(HF_Leitung.Abschluss_R) ), 39);
				SetDlgItemText(hDlg, ID_Z_BETRAG, cText);
				SetDlgItemText(hDlg, ID_Z_BETRAG_2, cText );
				Bestimme_Bezeichner_wissenschaftlich(cText, 180.0/pi*arg(HF_Leitung.Abschluss_R), 39);
				SetDlgItemText(hDlg, ID_Z_GRAD, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, arg(HF_Leitung.Abschluss_R), 39);
				SetDlgItemText(hDlg, ID_Z_RADIAN, cText);
				break;
			}
			default:
				Warnung((LPSTR)"Fehler bei der Eingabe der kompl. Impedanz: unbekannte Schaltung.");
		}
		return (INT_PTR)TRUE;
	case WM_PAINT: // Widerstand zeichnen
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz3, hStiftAlt;
		HDC hdc = BeginPaint(hDlg, &ps);

		hStiftSchwarz3 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz3);

		// Widerstand zeichnen
		Zeichne_Widerstand(hdc, 350, 60, 60, 30, 20);

		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz3);
		EndPaint(hDlg, &ps);
	}
	break;
	case WM_COMMAND:
		switch (wParam)
		{
		case ID_OK_AUSWAHL_1: // Eingabe pr�fen und umrechnen, hier R, L, C, Freq
			Dialogfenster_schliessen = true;
		case ID_AUSWAHL_1: // Eingabe pr�fen und umrechnen
		{
			double wert1, wert2, wert3, wert4;
			bool eingabe_ok = true;

			wert1 = Eingabe_parsen(hDlg, ID_R);
			wert2 = Eingabe_parsen(hDlg, ID_C);
			wert3 = Eingabe_parsen(hDlg, ID_L);
			wert4 = Eingabe_parsen(hDlg, ID_FREQ);
			// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
			if (wert1 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_R, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert2 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Kapazit�t muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_C, (LPCSTR)"1n");
				eingabe_ok = false;
			}
			if (wert3 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Induktivit�t muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_L, (LPCSTR)"1n");
				eingabe_ok = false;
			}
			if (wert4 <= 0.0)
			{
				Warnung((LPSTR)"Wert f�r Frequenz muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_FREQ, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (eingabe_ok)
			{
				switch (Eingabe_Dialog.Auswahl_Schaltung)
				{
					case HF_LEITUNG:	// HF_Leitung				// Die Werte speichern, das Dialogfenster bleibt offen!
					{
						if (wert2!=0.0)
							HF_Leitung.Abschluss_R= complex<double>(wert1, wert3*2.0*pi*wert4-1.0/(wert2*2.0*pi*wert4) );
						else
							HF_Leitung.Abschluss_R= complex<double>(wert1, wert3*2.0*pi*wert4 );
						break;
					}
				}
				if (Dialogfenster_schliessen)
				{
					Daten_geaendert();
					EndDialog(hDlg, LOWORD(wParam));
				}
			else
				{
					// Kn�pfe f�r Dialogbox aktualisieren
					SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
				}	
			}
			break;
		}
		case ID_OK_AUSWAHL_2: // Eingabe pr�fen und umrechnen, hier real, imag
			Dialogfenster_schliessen = true;
		case ID_AUSWAHL_2: // Eingabe pr�fen und umrechnen
		{
			double wert1, wert2;
			bool eingabe_ok = true;

			wert1 = Eingabe_parsen(hDlg, ID_IMPEDANZ_REAL);
			wert2 = Eingabe_parsen(hDlg, ID_IMPEDANZ_IMAG);
			// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
			if (wert1 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Realteil muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_IMPEDANZ_REAL, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (eingabe_ok)
			{
				switch (Eingabe_Dialog.Auswahl_Schaltung)
				{
					case HF_LEITUNG:	// HF_Leitung				// Die Werte speichern, das Dialogfenster bleibt offen!
					{
						HF_Leitung.Abschluss_R= complex<double>(wert1, wert2 );
						break;
					}
				}
				if (Dialogfenster_schliessen)
				{
					Daten_geaendert();
					EndDialog(hDlg, LOWORD(wParam));
				}
				else
				{
					// Kn�pfe f�r Dialogbox aktualisieren
					SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
				}
			}
			break;
		}
		case ID_OK_AUSWAHL_3: // Eingabe pr�fen und umrechnen, hier real, imag
			Dialogfenster_schliessen = true;
		case ID_AUSWAHL_3: // Eingabe pr�fen und umrechnen
		{
			double wert1, wert2;
			bool eingabe_ok = true;

			wert1 = Eingabe_parsen(hDlg, ID_Z_BETRAG);
			wert2 = Eingabe_parsen(hDlg, ID_Z_GRAD);
			// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
			if (wert1 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Betrag muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_IMPEDANZ_REAL, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if ( (wert2 < -360.0)||(wert2 > 360.0) )
			{
				Warnung((LPSTR)"Gradzahl muss gr��er -360� und kleiner +360� sein!");
				SetDlgItemText(hDlg, ID_Z_GRAD, (LPCSTR)"0.0");
				eingabe_ok = false;
			}
			if (eingabe_ok)
			{
				switch (Eingabe_Dialog.Auswahl_Schaltung)
				{
					case HF_LEITUNG:	// HF_Leitung				// Die Werte speichern, das Dialogfenster bleibt offen!
					{
						HF_Leitung.Abschluss_R= complex<double>(wert1*cos(wert2*pi/180.0), wert1*sin(wert2*pi/180.0) );
						break;
					}
				}
				if (Dialogfenster_schliessen)
				{
					Daten_geaendert();
					EndDialog(hDlg, LOWORD(wParam));
				}
				else
				{
					// Kn�pfe f�r Dialogbox aktualisieren
					SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
				}
			}
			break;
		}
		case ID_OK_AUSWAHL_4: // Eingabe pr�fen und umrechnen, hier real, imag
			Dialogfenster_schliessen = true;
		case ID_AUSWAHL_4: // Eingabe pr�fen und umrechnen
		{
			double wert1, wert2;
			bool eingabe_ok = true;

			wert1 = Eingabe_parsen(hDlg, ID_Z_BETRAG);
			wert2 = Eingabe_parsen(hDlg, ID_Z_GRAD);
			// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
			if (wert1 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Betrag muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_IMPEDANZ_REAL, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if ( (wert2 < -2.0*pi)||(wert2 > 2.0*pi) )
			{
				Warnung((LPSTR)"Winkel muss gr��er -2*pi und kleiner +2*pi sein!");
				SetDlgItemText(hDlg, ID_Z_GRAD, (LPCSTR)"0.0");
				eingabe_ok = false;
			}
			if (eingabe_ok)
			{
				switch (Eingabe_Dialog.Auswahl_Schaltung)
				{
					case HF_LEITUNG:	// HF_Leitung				// Die Werte speichern, das Dialogfenster bleibt offen!
					{
						HF_Leitung.Abschluss_R= complex<double>(wert1*cos(wert2), wert1*sin(wert2) );
						break;
					}
				}
				if (Dialogfenster_schliessen)
				{
					// Kn�pfe f�r Dialogbox aktualisieren
					SendMessage(hDlg, WM_INITDIALOG, (WPARAM)0, (LPARAM)0);
				}
				else
				{
					// Dialogbox neu zeichnen
					UpdateWindow( hDlg );
					InvalidateRect( hDlg, NULL, true );
				}
			}
			break;
		}



		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of EingabeWiderstand

// Meldungshandler zur Eingabe von Wellenwiderstand und Abschlusswiderstand
INT_PTR CALLBACK Eingabe_Leitungswiderstand_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Ausgabe ge�ndert auf die Funktion "Bestimme_Bezeichner_wissenschaftlich. So wird ein Komma angezeigt
	UNREFERENCED_PARAMETER(lParam);
	char cText[40];
	HICON hIcon;

	switch (message)
	{
	case WM_SHOWWINDOW:
		switch (Eingabe_Dialog.Auswahl_Leitungswiderstand)
		{
		case 1: SetFocus(GetDlgItem(hDlg, ID_TXT1)); SendMessage(GetDlgItem(hDlg, ID_TXT1), EM_SETSEL, 0, -1); break;
		case 2: SetFocus(GetDlgItem(hDlg, ID_TXT2)); SendMessage(GetDlgItem(hDlg, ID_TXT2), EM_SETSEL, 0, -1); break;
		case 3: SetFocus(GetDlgItem(hDlg, ID_TXT3)); SendMessage(GetDlgItem(hDlg, ID_TXT3), EM_SETSEL, 0, -1); break;
		case 4: SetFocus(GetDlgItem(hDlg, ID_TXT4)); SendMessage(GetDlgItem(hDlg, ID_TXT4), EM_SETSEL, 0, -1); break;
		case 5: SetFocus(GetDlgItem(hDlg, ID_TXT5)); SendMessage(GetDlgItem(hDlg, ID_TXT5), EM_SETSEL, 0, -1); break;
		}
		break;
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_WIDERSTAND), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		switch (Eingabe_Dialog.Anzahl_Widerstand)
		{	// "Durchrutschen" durch die Case-Anweisung ist hier beabsichtigt!
		case 1: EnableWindow(GetDlgItem(hDlg, ID_TXT2), FALSE);
		case 2: EnableWindow(GetDlgItem(hDlg, ID_TXT3), FALSE);
		case 3: EnableWindow(GetDlgItem(hDlg, ID_TXT4), FALSE);
		case 4: EnableWindow(GetDlgItem(hDlg, ID_TXT5), FALSE);
		}
		// Daten der Widerst�nde eintragen
		switch (Eingabe_Dialog.Auswahl_Schaltung)
		{
		case HF_LEITUNG: // �bertragungsleitung
			{
				Bestimme_Bezeichner_wissenschaftlich(cText, HF_Leitung.Abschlusswiderstand, 39);
				SetDlgItemText(hDlg, ID_TXT1, cText);
				Bestimme_Bezeichner_wissenschaftlich(cText, HF_Leitung.Wellenwiderstand, 39);
				SetDlgItemText(hDlg, ID_TXT2, cText);
				break;
			}
		default:
			Warnung((LPSTR)"Fehler bei der Eingabe der Widerst�nde: Unbekannte Schaltung.");
		}
		return (INT_PTR)TRUE;
	case WM_PAINT: // Widerstand zeichnen
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz3, hStiftAlt;
		HDC hdc = BeginPaint(hDlg, &ps);

		hStiftSchwarz3 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz3);

		// Widerstand zeichnen
		Zeichne_Widerstand(hdc, 245, 120, 30, 60, 20);

		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz3);
		EndPaint(hDlg, &ps);
	}
	break;
	case WM_COMMAND:
		switch (wParam)
		{
		case IDOK: // Eingabe pr�fen und �bernehmen
		{
			double wert1, wert2, wert3, wert4, wert5;
			bool eingabe_ok = true;

			wert1 = Eingabe_parsen(hDlg, ID_TXT1);
			wert2 = Eingabe_parsen(hDlg, ID_TXT2);
			wert3 = Eingabe_parsen(hDlg, ID_TXT3);
			wert4 = Eingabe_parsen(hDlg, ID_TXT4);
			wert5 = Eingabe_parsen(hDlg, ID_TXT5);
			// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
			if (wert1 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 1 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert2 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 2 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert3 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 3 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert4 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 4 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (wert5 < 0.0)
			{
				Warnung((LPSTR)"Wert f�r Widerstand 5 muss gr��er oder gleich 0 sein!");
				SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)"1k");
				eingabe_ok = false;
			}
			if (eingabe_ok)
			{
				switch (Eingabe_Dialog.Auswahl_Schaltung)
				{
					case HF_LEITUNG:	// �bertragungsleitung				// Die Werte speichern und das Dialogfenster schlie�en
					{
						HF_Leitung.Abschlusswiderstand = wert1;
						HF_Leitung.Wellenwiderstand = wert2;
						break;
					}
				}
				Daten_geaendert();
				EndDialog(hDlg, LOWORD(wParam));
			}
			break;
		}
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of EingabeLeitungswiderstand
// Meldungshandler f�r EingabeBeta
INT_PTR CALLBACK Eingabe_Beta_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Funktion ok
	// Funktion erweitert auf Eingabe von eps_r 10.11.2019
	UNREFERENCED_PARAMETER(lParam);
	char cText[40];
	HICON hIcon;

	switch (message)
	{
	case WM_SHOWWINDOW:
		// Wert markieren und Cursor setzen
		if (Eingabe_Dialog.Auswahl_Beta==0)
		{
			SetFocus(GetDlgItem(hDlg, ID_TXT2)); 
			SendMessage(GetDlgItem(hDlg, ID_TXT2), EM_SETSEL, 0, -1); break;
		}
		if (Eingabe_Dialog.Auswahl_Beta==1)
		{
			SetFocus(GetDlgItem(hDlg, ID_TXT1)); 
			SendMessage(GetDlgItem(hDlg, ID_TXT1), EM_SETSEL, 0, -1); break;
		}
		break;
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_LEITUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Wert eintragen
		Bestimme_Bezeichner_wissenschaftlich(cText, HF_Leitung.Ausbreitungskonstante, 39);
		SetDlgItemText(hDlg, ID_TXT1, cText);
		Bestimme_Bezeichner_wissenschaftlich(cText, HF_Leitung.eps_r, 39);
		SetDlgItemText(hDlg, ID_TXT2, cText);
		return (INT_PTR)TRUE;
	case WM_PAINT: // Widerstand zeichnen
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz3, hStiftAlt;
		HDC hdc = BeginPaint(hDlg, &ps);

		hStiftSchwarz3 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz3);

		// Leitung zeichnen
		Zeichne_Leitung(hdc, 50, 150, 200, 30, 20);

		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz3);
		EndPaint(hDlg, &ps);
	}
	break;
	case WM_COMMAND:
		switch (wParam)
		{
		case IDOK: // Eingabe pr�fen und �bernehmen
		{
			double wert1, wert2;
			bool eingabe_ok = true;

			wert1 = Eingabe_parsen(hDlg, ID_TXT1);
			wert2 = Eingabe_parsen(hDlg, ID_TXT2);

			// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
			if (wert1 <= 0.0)
			{
				Warnung((LPSTR)"Wert f�r die Ausbreitungskonstante muss gr��er 0 sein!");
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)"100");
				eingabe_ok = false;
			}
			if (wert2 <= 0.0)
			{
				Warnung((LPSTR)"Wert f�r effektive eps_r muss gr��er 0 sein!");
				SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"1.5");
				eingabe_ok = false;
			}
			if (eingabe_ok)
			{
				HF_Leitung.Ausbreitungskonstante=wert1;
				HF_Leitung.eps_r=wert2;
				Daten_geaendert();
				EndDialog(hDlg, LOWORD(wParam));
			}
			break;
		}
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of EingabeBeta
// Meldungshandler f�r die Eingabe der Leitungsl�nge
INT_PTR CALLBACK Eingabe_Laenge_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[40];
	HICON hIcon;

	switch (message)
	{
	case WM_SHOWWINDOW:
		// Wert markieren und Cursor setzen
		SetFocus(GetDlgItem(hDlg, ID_TXT1)); SendMessage(GetDlgItem(hDlg, ID_TXT1), EM_SETSEL, 0, -1); break;

		break;
	case WM_INITDIALOG:
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_LEITUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		// Wert eintragen
		Bestimme_Bezeichner_wissenschaftlich(cText, HF_Leitung.Laenge, 39);
		SetDlgItemText(hDlg, ID_TXT1, cText);
		return (INT_PTR)TRUE;
	case WM_PAINT: // Leitung zeichnen
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz3, hStiftAlt;
		HDC hdc = BeginPaint(hDlg, &ps);

		hStiftSchwarz3 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz3);

		// Leitung zeichnen
		Zeichne_Leitung(hdc, 50, 150, 200, 30, 20);

		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz3);
		EndPaint(hDlg, &ps);
	}
	break;
	case WM_COMMAND:
		switch (wParam)
		{
		case IDOK: // Eingabe pr�fen und �bernehmen
		{
			double wert1;
			bool eingabe_ok = true;

			wert1 = Eingabe_parsen(hDlg, ID_TXT1);

			// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
			if (wert1 <= 0.0)
			{
				Warnung((LPSTR)"Wert f�r die Leitungsl�nge muss gr��er 0 sein!");
				SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)"100m");
				eingabe_ok = false;
			}
			if (eingabe_ok)
			{
				HF_Leitung.Laenge=wert1;
				Daten_geaendert();
				EndDialog(hDlg, LOWORD(wParam));
			}
			break;
		}
		case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}	// end of EingabeBeta
// Meldungshandler f�r Eingabe Spannung.
INT_PTR CALLBACK EingabeSpannungswert_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
  // Ausgabe ge�ndert auf die Funktion "Bestimme_Bezeichner_wissenschaftlich. So wird ein Komma angezeigt
  // M. Alles 15.2.2018
  // Erg�nzung 18.8.2019: Wechselspannungsquelle
  // Erg�nzung 22.2.2020: Doppel-Emitterschaltung
  UNREFERENCED_PARAMETER(lParam);
  char cText[40];
  HICON hIcon;

  switch (message)
  {
  case WM_SHOWWINDOW:
	SetFocus(GetDlgItem(hDlg, ID_TXT1)); SendMessage(GetDlgItem(hDlg, ID_TXT1), EM_SETSEL, 0, -1);
	break;
  case WM_INITDIALOG:
	hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_SPANNUNG), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
	if (hIcon)
	  SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
	// Daten der Spannungsquelle eintragen
	switch (Eingabe_Dialog.Auswahl_Schaltung)
	{
	case BASIS_SCHALTUNG: // Basisschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Basis_Schaltung.U_B, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case EMITTER_SCHALTUNG:	// Emitterschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Emitter_Schaltung.U_B, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case KOLLEKTOR_SCHALTUNG:	// Kollektorschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Kollektor_Schaltung.U_B, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case SOURCE_SCHALTUNG: // Sourceschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Source_Schaltung.U_B, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case DRAIN_SCHALTUNG: // Drainschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Drain_Schaltung.U_B, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case GATE_SCHALTUNG: // Gateschaltung
	  Bestimme_Bezeichner_wissenschaftlich(cText, Gate_Schaltung.U_B, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case TRANSISTOR_ALS_SCHALTER: // Transistor als Schalter U_B
	  Bestimme_Bezeichner_wissenschaftlich(cText, Bipolartransistor_als_Schalter.U_B, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case TRANSISTOR_ALS_SCHALTER_U_SCHALT: // Transistor als Schalter, U_Schalt
	  Bestimme_Bezeichner_wissenschaftlich(cText, Bipolartransistor_als_Schalter.U_Schalt, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case DIFFERENZVERSTAERKER: // Differenzverstaerker, U_B
	  Bestimme_Bezeichner_wissenschaftlich(cText, Differenzverstaerker.U_B, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case DIFFERENZVERSTAERKER_STROMQUELLE: // Differenzverstaerker, U_Ref
	  Bestimme_Bezeichner_wissenschaftlich(cText, Differenzverstaerker.U_Ref, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case INVERTIERENDER_OP: // Invertierende OP-Schaltung, U_Ein
	  Bestimme_Bezeichner_wissenschaftlich(cText, Invertierender_OP.U_Ein, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case NICHTINVERTIERENDER_OP: // nicht-invertierende OP-Schaltung, U_Ein
	  Bestimme_Bezeichner_wissenschaftlich(cText, Nichtinvertierender_OP.U_Ein, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case DIFFERENZIERER_OP: // differenzierende OP-Schaltung, U_Ein
	  Bestimme_Bezeichner_wissenschaftlich(cText, Differenzierer_OP.U_Ein, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case INTEGRIERER_OP: // integrierende OP-Schaltung, U_Ein
	  Bestimme_Bezeichner_wissenschaftlich(cText, Integrierer_OP.U_Ein, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case SUMMATIONS_OP: // addierende OP-Schaltung, U_Ein_1
	  Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.U_Ein, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case SUMMATIONS_OP_EINGANG_2: // addierende OP-Schaltung, U_Ein_2
	  Bestimme_Bezeichner_wissenschaftlich(cText, Summations_OP.U_Ein_2, 39);
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case HF_LEITUNG: // Hochfrequenzleitung, ist eigentlich eine Wechselspannung
	  Bestimme_Bezeichner_wissenschaftlich(cText, HF_Leitung.Spannung, 39 );
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	case DOPPEL_EMITTER: // Emitterschaltung mit zwei Bipolartransistoren
	  Bestimme_Bezeichner_wissenschaftlich( cText, Doppel_Emitter_Schaltung.U_B, 39 );
	  SetDlgItemText(hDlg, ID_TXT1, cText);
	  break;
	default: 
	  Warnung((LPSTR)"Fehler beim Aufruf der Spannungseingabe: Unbekannte Schaltung.");
	}
	switch (Eingabe_Dialog.Auswahl_Spannung)
	{
	case U_SCHALT:
	  SetDlgItemText(hDlg, ID_TXT_U_B, (LPCSTR)"Bitte Schaltspannung eingeben:");
	  SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"U_Sch.");
	  break;
	case U_REFERENZ:
	  SetDlgItemText(hDlg, ID_TXT_U_B, (LPCSTR)"Bitte Referenzspannung eingeben:");
	  SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"U_Ref");
	  break;
	case U_EINGANG:
	  SetDlgItemText(hDlg, ID_TXT_U_B, (LPCSTR)"Bitte Eingangsspannung eingeben:");
	  SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"U_Ein");
	  break;
	case U_EIN_1:
	  SetDlgItemText(hDlg, ID_TXT_U_B, (LPCSTR)"Bitte Spannung f�r Eingang 1 eingeben:");
	  SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"U_Ein_1");
	  break;
	case U_EIN_2:
	  SetDlgItemText(hDlg, ID_TXT_U_B, (LPCSTR)"Bitte Spannung f�r Eingang 2 eingeben:");
	  SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"U_Ein_2");
	  break;
	case U_WECHSEL:
	  SetDlgItemText(hDlg, ID_TXT_U_B, (LPCSTR)"Bitte Wechselspannung eingeben:");
	  SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)"U_B_AC");
	  break;
	}
	return (INT_PTR)TRUE;
  case WM_PAINT: // Spannungsquelle zeichnen
	{
	  PAINTSTRUCT ps;
	  HPEN hStiftSchwarz3, hStiftAlt;
	  HDC hdc = BeginPaint(hDlg, &ps);

	  hStiftSchwarz3 = CreatePen(PS_SOLID, 3, BLACK_PEN);
	  hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz3);

	  // Spannungsquelle Position: x: 240-340, y: 50-150
	  Zeichne_Gleichspannungsquelle(hdc, 225, 75, 60, false, 20);

	  SelectObject(hdc, hStiftAlt);
	  DeleteObject(hStiftSchwarz3);
	  EndPaint(hDlg, &ps);
	}
	break;
  case WM_COMMAND:
	switch (wParam)
	{
	case IDOK: // Eingabe pr�fen und �bernehmen
	  {
		double wert1;
		bool eingabe_ok = true;

		wert1 = Eingabe_parsen(hDlg, ID_TXT1);

		// Die Werte kontrollieren: negative Werte oder Null sind unsinnig...
		if ( (wert1 <= 0.0)&&( (Eingabe_Dialog.Auswahl_Spannung == 0)||(Eingabe_Dialog.Auswahl_Spannung==1) ) )
		{
		  Warnung("Wert f�r Spannungsquelle muss gr��er 0 sein!");
		  SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)"5");
		  eingabe_ok = false;
		}

		if (eingabe_ok)
		{
		  switch (Eingabe_Dialog.Auswahl_Schaltung)
		  {
		  case BASIS_SCHALTUNG:	// Basisschaltung				// Die Werte speichern und das Dialogfenster schlie�en
			Basis_Schaltung.U_B = wert1;
			break;
		  case EMITTER_SCHALTUNG:	// Emitterschaltung				// Die Werte speichern und das Dialogfenster schlie�en
			Emitter_Schaltung.U_B = wert1;
			break;
		  case KOLLEKTOR_SCHALTUNG:	// Kollektorschaltung				// Die Werte speichern und das Dialogfenster schlie�en
			Kollektor_Schaltung.U_B = wert1;
			break;
		  case SOURCE_SCHALTUNG:	// Sourceschaltung				// Die Werte speichern und das Dialogfenster schlie�en
			Source_Schaltung.U_B = wert1;
			break;
		  case DRAIN_SCHALTUNG:	// Drainschaltung				// Die Werte speichern und das Dialogfenster schlie�en
			Drain_Schaltung.U_B = wert1;
			break;
		  case GATE_SCHALTUNG:	// Gateschaltung				// Die Werte speichern und das Dialogfenster schlie�en
			Gate_Schaltung.U_B = wert1;
			break;
		  case TRANSISTOR_ALS_SCHALTER: // Transistor als Schalter: U_B
			Bipolartransistor_als_Schalter.U_B = wert1;
			break;
		  case TRANSISTOR_ALS_SCHALTER_U_SCHALT: // Transistor als Schalter U_Schalt
			Bipolartransistor_als_Schalter.U_Schalt = wert1;
			break;
		  case DIFFERENZVERSTAERKER: // Differenzverst�rker, U_B
			Differenzverstaerker.U_B = wert1;
			break;
		  case DIFFERENZVERSTAERKER_STROMQUELLE: // Differenzverst�rker, U_Ref
			Differenzverstaerker.U_Ref = wert1;
			break;
		  case INVERTIERENDER_OP: // Invertierende OP-Schaltung, U_Ein
			Invertierender_OP.U_Ein = wert1;
			break;
		  case NICHTINVERTIERENDER_OP: // Invertierende OP-Schaltung, U_Ein
			Nichtinvertierender_OP.U_Ein = wert1;
			break;
		  case DIFFERENZIERER_OP: // differenzierende OP-Schaltung, U_Ein
			Differenzierer_OP.U_Ein = wert1;
			break;
		  case INTEGRIERER_OP: // integrierende OP-Schaltung, U_Ein
			Integrierer_OP.U_Ein = wert1;
			break;
		  case SUMMATIONS_OP: // addierende OP-Schaltung, U_Ein_1
			Summations_OP.U_Ein = wert1;
			break;
		  case SUMMATIONS_OP_EINGANG_2: // addierende OP-Schaltung, U_Ein_2
			Summations_OP.U_Ein_2 = wert1;
			break;
		  case HF_LEITUNG: // �bertragungsleitung
			HF_Leitung.Spannung = wert1;
			break;
		  case DOPPEL_EMITTER: // Emitterschaltung mit zwei Bipolartransistoren
			Doppel_Emitter_Schaltung.U_B = wert1;
			break;
		  }
		  Daten_geaendert();
		  EndDialog(hDlg, LOWORD(wParam));
		}
		break;
	  }
	case IDCANCEL: EndDialog(hDlg, LOWORD(wParam)); break;
	}
	break;
  }
  return (INT_PTR)FALSE;
}

// Meldungshandler f�r DezibelRechner
INT_PTR CALLBACK DezibelRechner_Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char cText[100];
	HICON hIcon;
	static int Zu_Berechnen;

	switch (message)
	{
	case WM_INITDIALOG:
		// Beschriftungen f�r die Werte erg�nzen bzw. Auswahl dB / dBm
		if (!Eingabe_Dialog.Auswahl_dB)
		{
			// F�r dBm auf 50Ohm-Bezugsgr��e gehen
			DezibelRechner.U_0 = 0.255;
			DezibelRechner.P_0 = 1.0e-3;
			// Felder ausgrauen
			EnableWindow(GetDlgItem(hDlg, ID_U_0), FALSE);
			EnableWindow(GetDlgItem(hDlg, ID_TXT3), FALSE);
			EnableWindow(GetDlgItem(hDlg, ID_TXT4), FALSE);
			SetDlgItemText(hDlg, ID_DB_UEBERSCHRIFT, (LPCSTR)"Bitte Spannung, Leistung oder dBm-Wert eingeben:");
			SetDlgItemText(hDlg, ID_DB_BEZEICHNER, (LPCSTR)"dBm");
			SetDlgItemText(hDlg, ID_DB_ENTSPRICHT, (LPCSTR)"U_1/U_0 bzw. P_1/P_0 entspricht dBm-Wert");
		}
		else
		{
			// Felder wieder einschalten
			EnableWindow(GetDlgItem(hDlg, ID_U_0), TRUE);
			EnableWindow(GetDlgItem(hDlg, ID_TXT3), TRUE);
			EnableWindow(GetDlgItem(hDlg, ID_TXT4), TRUE);
			SetDlgItemText(hDlg, ID_DB_UEBERSCHRIFT, (LPCSTR)"Bitte Spannungen, Leistungen oder dB-Werte eingeben:");
			SetDlgItemText(hDlg, ID_DB_BEZEICHNER, (LPCSTR)"dB");
			SetDlgItemText(hDlg, ID_DB_ENTSPRICHT, (LPCSTR)"U_1/U_0 bzw. P_1/P_0 entspricht dB-Wert. Getrennte Rechnung f�r U und P!");
		}
		Bestimme_Spannungsbezeichner(cText, DezibelRechner.U_1, 99);
		SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
		Bestimme_Leistungsbezeichner(cText, DezibelRechner.P_1, 99);
		SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
		Bestimme_Spannungsbezeichner(cText, DezibelRechner.U_0, 99);
		SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
		Bestimme_Leistungsbezeichner(cText, DezibelRechner.P_0, 99);
		SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
		Bestimme_Bezeichner(cText, DezibelRechner.dB_Wert, 99);
		SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);

		SendMessage(GetDlgItem(hDlg, ID_U_1), BM_SETCHECK, 1, 0);
		Zu_Berechnen = 1;
		hIcon = (HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_DEZIBELRECHNER), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
		if (hIcon)
		{
			SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		}
		return (INT_PTR)TRUE;
	case WM_PAINT: // Schaltungsblock zeichnen
	{
		PAINTSTRUCT ps;
		HPEN hStiftSchwarz3, hStiftAlt;
		HDC hdc = BeginPaint(hDlg, &ps);
		HFONT FontNeu, FontAlt;

		hStiftSchwarz3 = CreatePen(PS_SOLID, 3, BLACK_PEN);
		hStiftAlt = (HPEN)SelectObject(hdc, hStiftSchwarz3);
		Rechteck_BH_Rahmen(hdc, 100, 20, 120, 120);
		// Anschl�sse links und rechts
		//Anschlusspunkte links und rechts, Positionen (Mitte): x: 50, 270; y: 30 - 110; 30 - 110
		Zeichne_Anschluss(hdc, 40, 30, 80);
		Zeichne_Anschluss(hdc, 260, 30, 80);
		// Verbindung zum Rechteck
		ZP_Linie(hdc, 60, 40, 100, 40);
		ZP_Linie(hdc, 60, 120, 100, 120);
		ZP_Linie(hdc, 260, 40, 220, 40);
		ZP_Linie(hdc, 260, 120, 220, 120);

		// Beschriftung erg�nzen
		// am besten in Arial
		FontNeu = CreateFont(24, // nHeight
			0,	// nWidth
			0,	// nEscapement
			0,	// nOrientation
			FW_DONTCARE, //fnWeight
			TRUE,	//fdwItalic
			FALSE,	//fdwUnderline
			FALSE,	//fdwStrikeOut
			DEFAULT_CHARSET,	//fdwCharSet
			OUT_OUTLINE_PRECIS,	//fdwOutputPrecision
			CLIP_DEFAULT_PRECIS, //fdwClipPrecision
			CLEARTYPE_QUALITY,	//fdwQuality
			VARIABLE_PITCH,		//fdwPitchAndFamily
			TEXT("Arial"));	//lpszFace
		FontAlt = (HFONT)SelectObject(hdc, FontNeu);
		Zeichne_Text_xy(hdc, "U", 55, 65);
		Zeichne_Text_xy(hdc, "U", 275, 65);

		DeleteObject(FontNeu);
		FontNeu = CreateFont(18, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Arial"));
		SelectObject(hdc, FontNeu);

		Zeichne_Text_xy(hdc, "0", 70, 76);
		Zeichne_Text_xy(hdc, "1", 290, 76);

		SelectObject(hdc, hStiftAlt);
		DeleteObject(hStiftSchwarz3);
		SelectObject, (hdc, FontAlt);
		DeleteObject(FontNeu);
		EndPaint(hDlg, &ps);
	}
	break;
	case WM_COMMAND:
		switch (wParam)
		{
		case ID_U_1: Zu_Berechnen = U1_P1_AUS_DB; break;
		case ID_U_0: Zu_Berechnen = U0_P0_AUS_DB; break;
		case ID_DB_U: Zu_Berechnen = DB_AUS_U; break;
		case ID_DB_P: Zu_Berechnen = DB_AUS_P; break;

		case ID_CALC:
		{
			// Eingabe �bernehmen
			double wert1 = 0, wert2 = 0, wert3 = 0, wert4 = 0, wert5 = 0;
			bool eingabe_ok = true;

			if (Zu_Berechnen != U1_P1_AUS_DB)
			{
				wert1 = Eingabe_parsen(hDlg, ID_TXT1);
				if (wert1 <= 0.0)
				{
					Warnung("Spannung am Ausgang muss gr��er 0V sein!");
					SetDlgItemText(hDlg, ID_TXT1, (LPSTR)"0,255");
					eingabe_ok = false;
				}
				wert2 = Eingabe_parsen(hDlg, ID_TXT2);
				if (wert2 <= 0.0)
				{
					Warnung("Leistung am Ausgang muss gr��er 0W sein!");
					SetDlgItemText(hDlg, ID_TXT2, (LPSTR)"0,001");
					eingabe_ok = false;
				}
			}
			if (Zu_Berechnen != U0_P0_AUS_DB)
			{
				wert3 = Eingabe_parsen(hDlg, ID_TXT3);
				if (wert3 <= 0.0)
				{
					Warnung("Spannung am Eingang muss gr��er 0V sein!");
					SetDlgItemText(hDlg, ID_TXT3, (LPSTR)"0,255");
					eingabe_ok = false;
				}
				wert4 = Eingabe_parsen(hDlg, ID_TXT4);
				if (wert4 <= 0.0)
				{
					Warnung("Leistung am Eingang muss gr��er 0W sein!");
					SetDlgItemText(hDlg, ID_TXT4, (LPSTR)"0,001");
					eingabe_ok = false;
				}
			}
			if (Zu_Berechnen != DB_AUS_U)
			{
				wert5 = Eingabe_parsen(hDlg, ID_TXT5);
			}
			if (eingabe_ok)
			{
				// Eingaben speichern
				DezibelRechner.U_1 = wert1;
				DezibelRechner.P_1 = wert2;
				DezibelRechner.U_0 = wert3;
				DezibelRechner.P_0 = wert4;
				DezibelRechner.dB_Wert = wert5;
				Ergebnis_DezibelRechner(Zu_Berechnen);
//				Daten_geaendert();
				// Ergebnis anzeigen
				switch (Zu_Berechnen)
				{
				case U1_P1_AUS_DB:
					Bestimme_Spannungsbezeichner(cText, DezibelRechner.U_1, 99);
					SetDlgItemText(hDlg, ID_TXT1, (LPCSTR)cText);
					Bestimme_Leistungsbezeichner(cText, DezibelRechner.P_1, 99);
					SetDlgItemText(hDlg, ID_TXT2, (LPCSTR)cText);
					break;
				case U0_P0_AUS_DB:
					Bestimme_Spannungsbezeichner(cText, DezibelRechner.U_0, 99);
					SetDlgItemText(hDlg, ID_TXT3, (LPCSTR)cText);
					Bestimme_Leistungsbezeichner(cText, DezibelRechner.P_0, 99);
					SetDlgItemText(hDlg, ID_TXT4, (LPCSTR)cText);
					break;
				case DB_AUS_U:
					Bestimme_Bezeichner(cText, DezibelRechner.dB_Wert, 99);
					SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
					break;
				case DB_AUS_P:
					Bestimme_Bezeichner(cText, DezibelRechner.dB_Wert, 99);
					SetDlgItemText(hDlg, ID_TXT5, (LPCSTR)cText);
					break;
				}
			}
			break;
		}
		case IDCANCEL:
		case ID_CLOSE:
			EndDialog(hDlg, LOWORD(wParam)); break;
		}

		break;
	}
	return (INT_PTR)FALSE;
}	// end of DezibelRechner
